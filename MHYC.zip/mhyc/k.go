package mhyc

import (
	"github.com/gorilla/websocket"
	"google.golang.org/protobuf/proto"
)

type Client struct {
	Conn *websocket.Conn
}

func (c *Client) Login(info *C2SLogin) error {
	body, err := proto.Marshal(info)
	if err != nil {
		return err
	}
	body = append([]byte{0, 0, 0, 1}, body...)
	return c.Conn.WriteMessage(websocket.BinaryMessage, body)
}

func (c *Client) Ping() error {
	body, err := proto.Marshal(&Ping{})
	if err != nil {
		return err
	}
	body = append([]byte{0, 0, 0, 22}, body...)
	return c.Conn.WriteMessage(websocket.BinaryMessage, body)
}

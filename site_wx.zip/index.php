<?php

include_once('inc.func.php');
echo LoadTmplContent('page_wx', 'page_wx_002', 86400, false);

?>
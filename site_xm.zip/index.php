<?php

include_once('inc.func.php');

if (strpos(strtolower($_SERVER['HTTP_HOST']), 'www.') !== false) {
    echo LoadTmplContent('page_xm', '', 0, true);
} else {
    echo LoadTmplContent('page_xm', '', 0, false);
}

?>
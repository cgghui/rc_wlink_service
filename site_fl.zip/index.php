<?php

include_once('inc.func.php');

if (strpos(strtolower($_SERVER['HTTP_HOST']), 'www.') !== false) {
    echo LoadTmplContent('page_fl_pro', 'page_fl_pro', 2419200, true);
} else {
    echo LoadTmplContent('page_fl_pro', 'page_fl_pro', 2419200, false);
}

?>
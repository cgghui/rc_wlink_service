<?php

define('APP_PATH', dirname(__FILE__) . '/');

const API_SERVICE_URL = 'http://127.0.0.1:886';

function HostDomain(): string
{
    return $_SERVER['HTTP_HOST'];
}

function HostTop(): string
{
    if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        return $_SERVER['HTTP_HOST'];
    }
    $top = explode('.', $_SERVER['HTTP_HOST'], 2)[1];
    if (strpos($top, '.') === false) {
        $top = $_SERVER['HTTP_HOST'];
    }
    return $top;
}

function LoadTmplContent(string $tmpl, string $cache_id = '', int $cache_expire = 0, bool $global = false, bool $debug = false): string
{
    $url = API_SERVICE_URL . '/load/' . $tmpl;
    if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        $top = $_SERVER['HTTP_HOST'];
    } else {
        $top = explode('.', $_SERVER['HTTP_HOST'], 2)[1];
        if (strpos($top, '.') === false) {
            $top = $_SERVER['HTTP_HOST'];
        }
    }
    if ($cache_id !== '') {
        if ($global) {
            $url .= '?cache_id=' . md5($top . '_' . $cache_id);
        } else {
            $url .= '?cache_id=' . md5($_SERVER['HTTP_HOST'] . '_' . $cache_id);
        }
    } else {
        $url .= '?cache_id=';
    }
    if ($cache_expire > 0) {
        $url .= '&cache_expire=' . $cache_expire;
    }
    if ($debug) {
        $url .= '&debug=1';
    }
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url . '&ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-Host: ' . $_SERVER['HTTP_HOST'],
        'Param-TopHost: ' . $top,
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip,
        'X-Store-Path:' . base64_encode(APP_PATH)
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

function StoreGet(string $k, bool $global = false): string
{
    if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        $top = $_SERVER['HTTP_HOST'];
    } else {
        $top = explode('.', $_SERVER['HTTP_HOST'], 2)[1];
        if (strpos($top, '.') === false) {
            $top = $_SERVER['HTTP_HOST'];
        }
    }
    if ($global) {
        $k = md5($top . '_' . $k);
    } else {
        $k = md5($_SERVER['HTTP_HOST'] . '_' . $k);
    }
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/store/get?key=' . $k . '&ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-Host: ' . $_SERVER['HTTP_HOST'],
        'Param-TopHost: ' . $top,
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip,
        'X-Store-Path:' . base64_encode(APP_PATH)
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

function StoreSet(string $k, string $v, bool $global = false): bool
{
    if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        $top = $_SERVER['HTTP_HOST'];
    } else {
        $top = explode('.', $_SERVER['HTTP_HOST'], 2)[1];
        if (strpos($top, '.') === false) {
            $top = $_SERVER['HTTP_HOST'];
        }
    }
    if ($global) {
        $k = md5($top . '_' . $k);
    } else {
        $k = md5($_SERVER['HTTP_HOST'] . '_' . $k);
    }
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/store/set?key=' . $k . '&val=' . $v . '&ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-Host: ' . $_SERVER['HTTP_HOST'],
        'Param-TopHost: ' . $top,
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip,
        'X-Store-Path:' . base64_encode(APP_PATH)
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output == "1";
}

function StoreDel(string $k, bool $global = false): void
{
    if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        $top = $_SERVER['HTTP_HOST'];
    } else {
        $top = explode('.', $_SERVER['HTTP_HOST'], 2)[1];
        if (strpos($top, '.') === false) {
            $top = $_SERVER['HTTP_HOST'];
        }
    }
    if ($global) {
        $k = md5($top . '_' . $k);
    } else {
        $k = md5($_SERVER['HTTP_HOST'] . '_' . $k);
    }
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/store/set?key=' . $k . '&ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-Host: ' . $_SERVER['HTTP_HOST'],
        'Param-TopHost: ' . $top,
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip,
        'X-Store-Path:' . base64_encode(APP_PATH)
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_exec($ch);
    curl_close($ch);
}

function StoreClear(): void
{
    if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        $top = $_SERVER['HTTP_HOST'];
    } else {
        $top = explode('.', $_SERVER['HTTP_HOST'], 2)[1];
        if (strpos($top, '.') === false) {
            $top = $_SERVER['HTTP_HOST'];
        }
    }
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/store/clear?ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-Host: ' . $_SERVER['HTTP_HOST'],
        'Param-TopHost: ' . $top,
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip,
        'X-Store-Path:' . base64_encode(APP_PATH)
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_exec($ch);
    curl_close($ch);
}

function RandWord(string $lib_name, int $num = 1): array
{
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/data/rand/word/' . $lib_name . '/' . $num . '?ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-Host: ' . $_SERVER['HTTP_HOST'],
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($ch);
    curl_close($ch);
    return json_decode($output, true);
}

function RandKV(string $lib_name, int $num = 1): array
{
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/data/rand/kv/' . $lib_name . '/' . $num . '?ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($ch);
    curl_close($ch);
    return json_decode($output, true);
}

function SearchKV(string $lib_name, string $word): array
{
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/data/search_kv/' . $lib_name . '/' . $word . '?ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($ch);
    curl_close($ch);
    return json_decode($output, true);
}

function FindKV(string $lib_name, string $key): string
{
    $ip = client_ip();
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, API_SERVICE_URL . '/data/find_kv/' . $lib_name . '/' . $key . '?ip=' . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Param-WebName:',
        'User-Agent: ' . $_SERVER['HTTP_USER_AGENT'],
        'X-Real-IP: ' . $ip,
        'X-Forward-For: ' . $ip
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $output = curl_exec($ch);
    curl_close($ch);
    return json_decode($output, true);
}


function client_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return is_ip($_SERVER['HTTP_CLIENT_IP']);
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return is_ip($_SERVER['HTTP_X_FORWARDED_FOR']);
    }
    return check_ip($_SERVER['REMOTE_ADDR']);
}

function check_ip($str)
{
    if (stripos($str, ',') !== false) {
        $strArr = explode(',', $str);
        $ip = $strArr[0];
    } else {
        $ip = $str;
    }
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return $ip;
    }
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        return $ip;
    }
    return '未知IP';
}
<?php

include_once('inc.func.php');

header('Access-Control-Allow-Origin: *');

if (isset($_GET['m']) === true && $_GET['m'] === 'cron') {
    exit;
}

//m=ajax&c=Site&type=ajax
if (isset($_GET['m'], $_GET['c'], $_GET['type']) === true && $_GET['m'] === 'ajax' && $_GET['c'] === 'Site' && $_GET['type'] === 'ajax') {
    exit('<span class="hp_head_ft_city_x">全国站</span><span class="hp_head_ft_city_qh">【切换城市】</span>');
}

$host_top = HostTop();
$host_domain = $_SERVER['HTTP_HOST'];
$host_name = '';
if ($host_top != $host_domain) {
    $host_name = str_replace($host_top, '', $host_domain);
    $host_name = rtrim($host_name, '.');
}

// web name
$web_name = StoreGet('web_name1', true);
if ($web_name === '') {
    $web_name = RandWord('cy')[0] . RandWord('hy')[0] . '人才招聘网';
    StoreSet('web_name1', $web_name);
}

// title
$key = 'tit1-' . md5($_SERVER['REQUEST_URI']);
$tit = StoreGet($key);
if ($tit === '') {
    if ($host_name === '' || $host_name === 'www') {
        if ($_SERVER['REQUEST_URI'] == "/" || $_SERVER['REQUEST_URI'] == "") {
            $tit = $web_name;
        } else {
            $tit = RandWord('company')[0] . $web_name;
        }
    } else {
        $search = [];
        foreach (SearchKV('domain_all', $host_name . '.x.com') as $val) {
            $search = $val;
        }
        if (count($search) === 0) {
            $tit = RandWord('company')[0] . $web_name;
        } else {
            $search = explode(' ', $search[0]);
            $tit = $search[2] . $web_name;
        }
    }
    StoreSet($key, $tit);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
    <meta name="keywords" content="<?php echo $tit?>"/>
    <meta name="description" content="<?php echo $tit?>"/>
    <link href="http://<?php echo $host_domain?>/css/index.css" rel="stylesheet" type="text/css"/>
    <link href="http://<?php echo $host_domain?>/css/css.css" rel="stylesheet" type="text/css"/>
    <link href="http://<?php echo $host_domain?>/css/layui.css" rel="stylesheet" type="text/css"/>
    <title><?php echo $tit?></title>
    <style type="text/css">
        #footer {margin-bottom: 50px;padding-top: 5px; text-align: center; line-height: 2em;}
        #footer .footerFuncCity {width: 98%;padding-top: 20px;padding-bottom: 20px;}
        #footer .footerFuncCity ul li a {color: #666;}
        .clearfix {zoom: 1; display: block;}
        .footerFuncCity{margin: 0 auto; width: 950px; padding: 20px;}
        .footerFuncCity .char {color: #1787FB; font: bold 14px/20px "arial"; margin-left: 8px;}
        .footerFuncCity li {height: 30px;}
        .footerFuncCity li {float: left; color: #b0b0b0; height: 20px; line-height: 20px; white-space: nowrap; padding: 5px 0px; font-size: 14px;}
        .footerFuncCity strong{font-style: normal; font-weight: 400;}
        .footerFuncCity a {outline: none; padding: 0 8px; color: #2A2A2A; font-family: Microsoft YaHei;}
    </style>
</head>

<body class="body_bg">
<div class="yun_new_top">
    <div class="yun_new_cont">
        <div class="yun_new_left">
            <span class="fl">
              <span class="yun_new_left_city" id="substation_city_id">
                <span class="hp_head_ft_city_x">全国站</span>
                <span class="hp_head_ft_city_qh">【<a href="http://<?php echo $host_domain?>/">切换城市</a>】</span>
              </span>
              <input type="hidden" id="indexdir" value="">
            </span>
        </div>
        <div class="yun_new_right" id="login_head_div">
            <span class="yun_new_right_we"><a href="http://<?php echo $host_top?>"><?php echo $tit?>欢迎您！</a></span>
        </div>
    </div>
</div>
<!--top end-->
<div class="hp_head hp_head_box">
    <div class="w1200">
        <div class="hp_head_ft fl">
            <div class="phpyun_logo fl">
                <a href="http://www.<?php echo $host_top?>" title="<?php echo $tit?>最新招聘求职信息">
                    <img src="http://<?php echo $host_domain?>/css/logo.png" alt="<?php echo $tit?>" />
                </a>
            </div>
        </div>
        <div class="yun_header_nav_box">
            <ul>
                <li>
                    <a href="http://<?php echo $host_top?>">首页</a>
                    <i class="yun_new_headernav_list_line"></i>
                </li>
                <?php echo LoadTmplContent('top', 'top_navs_v1', 2592000, true, true)?>
            </ul>
        </div>
    </div>
</div>
<!-- 分站首页-->
<div class="w1200">
    <div class="clear"></div>
    <!-- 搜索-->
    <div class="fz_index_search">
        <form action="http://job.<?php echo $host_top?>/"
              method="get" onsubmit="return search_keyword(this);" id="index_search_form">
            <input type="hidden"  value="job" id="m" />
            <input type="hidden" name="c" value="search" id="search"/>

            <div class="fz_index_search_select">
                <span class="" id="search_name">职位</span>
                <div class="yunHeaderSearch_list_box fz_index_search_select_box none">
                    <a href="javascript:void(0)"
                       onclick="top_search('job', '找工作', 'http://job.<?php echo $host_top?>/', '1', 'job'); $('#search').attr('name', 'c');">找工作</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('resume', '找人才', 'http://resume.<?php echo $host_top?>/', '1', 'resume'); $('#search').attr('name', 'c');">
                        找人才</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('tiny', '普工简历', 'http://tiny.<?php echo $host_top?>/', '1', 'tiny'); $('#search').attr('name', '');">普工简历</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('article', '新闻', 'http://article.<?php echo $host_top?>/', '1', 'article');"
                       class="none">新闻</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('once', '店铺招聘', 'http://once.<?php echo $host_top?>/', '1', 'once'); $('#search').attr('name', '');">店铺招聘</a>
                </div>
            </div>
            <div class="fz_index_search_textbox">
                <input class="fz_index_search_text" type="text" name="keyword" value="" placeholder="请输入职位关键词，如：java ,销售代表，行政助理等">
            </div>
            <input class="fz_index_search_bth" type="submit" value="搜索"/>
        </form>

    </div>
    <div class="fz_index_tag">热门搜索：
    </div>
    <div class="clear"></div>

    <!-- 幻灯片-->
    <div class="fz_hd">
        <div class="" id="ban">
            <div class="layui-carousel" id="test1" lay-filter="test1">
                <div carousel-item="">
                    <span><img src='/images/14970247553.jpg'></span>
                    <span><img src='/images/14992057095.png'></span>
                </div>
            </div>
        </div>
    </div>
    <div class="clear"></div>

    <!-- 职场资讯-->
    <div class="index_zl_box">
        <div class="new_index_tit">
            <span class="new_index_tit_list new_index_tit_cur"><?php echo $tit?><i class="new_index_tit_line"></i></span>
        </div>
        <div style="padding-top: 30px; padding-left: 15px;">
            <?php echo $tit?>是为广大用户提供最新人才招聘信息的网站。找工作的你，招聘人才的企业信息供您选择，<?php echo LoadTmplContent('body', 'body_news', 2592000, false, false)?>每天都有各类人才招聘信息更新，我们都会审核有效性，欢迎您使用<?php echo $tit?>。

        </div>
    </div>

    <div class="index_zl_box">
        <div class="new_index_tit">
            <span class="new_index_tit_list new_index_tit_cur"><?php echo $tit?>区分站<i class="new_index_tit_line"></i></span>
            <a href="http://www.<?php echo $host_top?>/" class="new_index_tit_more">查看更多</a>
        </div>
        <div class="index_link_box fl">
            <div id="footer">
                <div class="footerFuncCity clearfix">
                    <ul>
                        <li class="char">A</li>
                        <li><strong><a href="http://anningshi.<?php echo $host_top?>" target="_blank">安宁</a></strong>|</li>
                        <li><strong><a href="http://anhui.<?php echo $host_top?>" target="_blank">安徽</a></strong>|</li>
                        <li><strong><a href="http://alaer.<?php echo $host_top?>" target="_blank">阿拉尔</a></strong>|</li>
                        <li><strong><a href="http://anqing.<?php echo $host_top?>" target="_blank">安庆</a></strong>|</li>
                        <li><strong><a href="http://alashanmeng.<?php echo $host_top?>" target="_blank">阿拉善盟</a></strong>|</li>
                        <li><strong><a href="http://ankang.<?php echo $host_top?>" target="_blank">安康</a></strong>|</li>
                        <li><strong><a href="http://anqiushi.<?php echo $host_top?>" target="_blank">安丘</a></strong>|</li>
                        <li><strong><a href="http://akesu.<?php echo $host_top?>" target="_blank">阿克苏</a></strong>|</li>
                        <li><strong><a href="http://andashi.<?php echo $host_top?>" target="_blank">安达</a></strong>|</li>
                        <li><strong><a href="http://anlushi.<?php echo $host_top?>" target="_blank">安陆</a></strong>|</li>
                        <li><strong><a href="http://anguoshi.<?php echo $host_top?>" target="_blank">安国</a></strong>|</li>
                        <li><strong><a href="http://anshan.<?php echo $host_top?>" target="_blank">鞍山</a></strong>|</li>
                        <li><strong><a href="http://anyang.<?php echo $host_top?>" target="_blank">安阳</a></strong>|</li>
                        <li><strong><a href="http://aershanshi.<?php echo $host_top?>" target="_blank">阿尔山</a></strong>|</li>
                        <li><strong><a href="http://aba.<?php echo $host_top?>" target="_blank">阿坝</a></strong>|</li>
                        <li><strong><a href="http://atushenshi.<?php echo $host_top?>" target="_blank">阿图什</a></strong>|</li>
                        <li><strong><a href="http://anshun.<?php echo $host_top?>" target="_blank">安顺</a></strong>|</li>
                        <li><strong><a href="http://aleitaishi.<?php echo $host_top?>" target="_blank">阿勒泰</a></strong></li>
                        <li class="char">B</li>
                        <li><strong><a href="http://bayinguoleng.<?php echo $host_top?>" target="_blank">巴音郭楞</a></strong>|</li>
                        <li><strong><a href="http://bazhoushi.<?php echo $host_top?>" target="_blank">霸州</a></strong>|</li>
                        <li><strong><a href="http://beianshi.<?php echo $host_top?>" target="_blank">北安</a></strong>|</li>
                        <li><strong><a href="http://bayannaoermeng.<?php echo $host_top?>" target="_blank">巴彦淖尔</a></strong>|</li>
                        <li><strong><a href="http://beijing.<?php echo $host_top?>" target="_blank">北京</a></strong>|</li>
                        <li><strong><a href="http://baisha.<?php echo $host_top?>" target="_blank">白沙</a></strong>|</li>
                        <li><strong><a href="http://baoting.<?php echo $host_top?>" target="_blank">保亭</a></strong>|</li>
                        <li><strong><a href="http://baoding.<?php echo $host_top?>" target="_blank">保定</a></strong>|</li>
                        <li><strong><a href="http://bijie.<?php echo $host_top?>" target="_blank">毕节</a></strong>|</li>
                        <li><strong><a href="http://baoshan.<?php echo $host_top?>" target="_blank">保山</a></strong>|</li>
                        <li><strong><a href="http://benxi.<?php echo $host_top?>" target="_blank">本溪</a></strong>|</li>
                        <li><strong><a href="http://bangbu.<?php echo $host_top?>" target="_blank">蚌埠</a></strong>|</li>
                        <li><strong><a href="http://beizhenshi.<?php echo $host_top?>" target="_blank">北镇</a></strong>|</li>
                        <li><strong><a href="http://bozhou.<?php echo $host_top?>" target="_blank">亳州</a></strong>|</li>
                        <li><strong><a href="http://baiyin.<?php echo $host_top?>" target="_blank">白银</a></strong>|</li>
                        <li><strong><a href="http://baicheng.<?php echo $host_top?>" target="_blank">白城</a></strong>|</li>
                        <li><strong><a href="http://binzhou.<?php echo $host_top?>" target="_blank">滨州</a></strong>|</li>
                        <li><strong><a href="http://bazhong.<?php echo $host_top?>" target="_blank">巴中</a></strong>|</li>
                        <li><strong><a href="http://boertala.<?php echo $host_top?>" target="_blank">博尔塔拉</a></strong>|</li>
                        <li><strong><a href="http://boleshi.<?php echo $host_top?>" target="_blank">博乐</a></strong>|</li>
                        <li><strong><a href="http://beiliushi.<?php echo $host_top?>" target="_blank">北流</a></strong>|</li>
                        <li><strong><a href="http://potoushi.<?php echo $host_top?>" target="_blank">泊头</a></strong>|</li>
                        <li><strong><a href="http://beipiaoshi.<?php echo $host_top?>" target="_blank">北票</a></strong>|</li>
                        <li><strong><a href="http://baotou.<?php echo $host_top?>" target="_blank">包头</a></strong>|</li>
                        <li><strong><a href="http://baishan.<?php echo $host_top?>" target="_blank">白山</a></strong>|</li>
                        <li><strong><a href="http://baise.<?php echo $host_top?>" target="_blank">百色</a></strong>|</li>
                        <li><strong><a href="http://beihai.<?php echo $host_top?>" target="_blank">北海</a></strong>|</li>
                        <li><strong><a href="http://baoji.<?php echo $host_top?>" target="_blank">宝鸡</a></strong></li>
                        <li class="char">C</li>
                        <li><strong><a href="http://changji.<?php echo $host_top?>" target="_blank">昌吉</a></strong>|</li>
                        <li><strong><a href="http://zhangsha.<?php echo $host_top?>" target="_blank">长沙</a></strong>|</li>
                        <li><strong><a href="http://chengmaixian.<?php echo $host_top?>" target="_blank">澄迈</a></strong>|</li>
                        <li><strong><a href="http://changjiang.<?php echo $host_top?>" target="_blank">昌江</a></strong>|</li>
                        <li><strong><a href="http://cixishi.<?php echo $host_top?>" target="_blank">慈溪</a></strong>|</li>
                        <li><strong><a href="http://conghuashi.<?php echo $host_top?>" target="_blank">从化</a></strong>|</li>
                        <li><strong><a href="http://changshushi.<?php echo $host_top?>" target="_blank">常熟</a></strong>|</li>
                        <li><strong><a href="http://chongzuo.<?php echo $host_top?>" target="_blank">崇左</a></strong>|</li>
                        <li><strong><a href="http://chuxiong.<?php echo $host_top?>" target="_blank">楚雄</a></strong>|</li>
                        <li><strong><a href="http://cangzhou.<?php echo $host_top?>" target="_blank">沧州</a></strong>|</li>
                        <li><strong><a href="http://changyiqu.<?php echo $host_top?>" target="_blank">昌邑</a></strong>|</li>
                        <li><strong><a href="http://chaoyang.<?php echo $host_top?>" target="_blank">朝阳</a></strong>|</li>
                        <li><strong><a href="http://chuzhou.<?php echo $host_top?>" target="_blank">滁州</a></strong>|</li>
                        <li><strong><a href="http://changde.<?php echo $host_top?>" target="_blank">常德</a></strong>|</li>
                        <li><strong><a href="http://zhangzhi.<?php echo $host_top?>" target="_blank">长治</a></strong>|</li>
                        <li><strong><a href="http://chifeng.<?php echo $host_top?>" target="_blank">赤峰</a></strong>|</li>
                        <li><strong><a href="http://zhongqing.<?php echo $host_top?>" target="_blank">重庆</a></strong>|</li>
                        <li><strong><a href="http://changzhou.<?php echo $host_top?>" target="_blank">常州</a></strong>|</li>
                        <li><strong><a href="http://changningshi.<?php echo $host_top?>" target="_blank">常宁</a></strong>|</li>
                        <li><strong><a href="http://chengdou.<?php echo $host_top?>" target="_blank">成都</a></strong>|</li>
                        <li><strong><a href="http://chenzhou.<?php echo $host_top?>" target="_blank">郴州</a></strong>|</li>
                        <li><strong><a href="http://zhangleshi.<?php echo $host_top?>" target="_blank">长乐</a></strong>|</li>
                        <li><strong><a href="http://chibishi.<?php echo $host_top?>" target="_blank">赤壁</a></strong>|</li>
                        <li><strong><a href="http://chaozhou.<?php echo $host_top?>" target="_blank">潮州</a></strong>|</li>
                        <li><strong><a href="http://cenxishi.<?php echo $host_top?>" target="_blank">岑溪</a></strong>|</li>
                        <li><strong><a href="http://chishuishi.<?php echo $host_top?>" target="_blank">赤水</a></strong>|</li>
                        <li><strong><a href="http://chizhou.<?php echo $host_top?>" target="_blank">池州</a></strong>|</li>
                        <li><strong><a href="http://zhangchun.<?php echo $host_top?>" target="_blank">长春</a></strong>|</li>
                        <li><strong><a href="http://zhanggeshi.<?php echo $host_top?>" target="_blank">长葛</a></strong>|</li>
                        <li><strong><a href="http://chaohu.<?php echo $host_top?>" target="_blank">巢湖</a></strong>|</li>
                        <li><strong><a href="http://chongzhoushi.<?php echo $host_top?>" target="_blank">崇州</a></strong>|</li>
                        <li><strong><a href="http://chengde.<?php echo $host_top?>" target="_blank">承德</a></strong></li>
                        <li class="char">D</li>
                        <li><strong><a href="http://dongfang.<?php echo $host_top?>" target="_blank">东方</a></strong>|</li>
                        <li><strong><a href="http://dongchengqu.<?php echo $host_top?>" target="_blank">东城</a></strong>|</li>
                        <li><strong><a href="http://dehuishi.<?php echo $host_top?>" target="_blank">德惠</a></strong>|</li>
                        <li><strong><a href="http://dalian.<?php echo $host_top?>" target="_blank">大连</a></strong>|</li>
                        <li><strong><a href="http://dinganxian.<?php echo $host_top?>" target="_blank">定安</a></strong>|</li>
                        <li><strong><a href="http://danjiangkoushi.<?php echo $host_top?>" target="_blank">丹江口</a></strong>|</li>
                        <li><strong><a href="http://dongyangshi.<?php echo $host_top?>" target="_blank">东阳</a></strong>|</li>
                        <li><strong><a href="http://dongxingshi.<?php echo $host_top?>" target="_blank">东兴</a></strong>|</li>
                        <li><strong><a href="http://dingxi.<?php echo $host_top?>" target="_blank">定西</a></strong>|</li>
                        <li><strong><a href="http://dongguan.<?php echo $host_top?>" target="_blank">东莞</a></strong>|</li>
                        <li><strong><a href="http://dongying.<?php echo $host_top?>" target="_blank">东营</a></strong>|</li>
                        <li><strong><a href="http://dengfengshi.<?php echo $host_top?>" target="_blank">登封</a></strong>|</li>
                        <li><strong><a href="http://diaobingshanshi.<?php echo $host_top?>" target="_blank">调兵山</a></strong>|</li>
                        <li><strong><a href="http://dehong.<?php echo $host_top?>" target="_blank">德宏</a></strong>|</li>
                        <li><strong><a href="http://danzhou.<?php echo $host_top?>" target="_blank">儋州</a></strong>|</li>
                        <li><strong><a href="http://dingzhoushi.<?php echo $host_top?>" target="_blank">定州</a></strong>|</li>
                        <li><strong><a href="http://deyang.<?php echo $host_top?>" target="_blank">德阳</a></strong>|</li>
                        <li><strong><a href="http://dafengshi.<?php echo $host_top?>" target="_blank">大丰</a></strong>|</li>
                        <li><strong><a href="http://dengtashi.<?php echo $host_top?>" target="_blank">灯塔</a></strong>|</li>
                        <li><strong><a href="http://diqing.<?php echo $host_top?>" target="_blank">迪庆</a></strong>|</li>
                        <li><strong><a href="http://danyangshi.<?php echo $host_top?>" target="_blank">丹阳</a></strong>|</li>
                        <li><strong><a href="http://dalishi.<?php echo $host_top?>" target="_blank">大理</a></strong>|</li>
                        <li><strong><a href="http://datong.<?php echo $host_top?>" target="_blank">大同</a></strong>|</li>
                        <li><strong><a href="http://dandong.<?php echo $host_top?>" target="_blank">丹东</a></strong>|</li>
                        <li><strong><a href="http://dongningxian.<?php echo $host_top?>" target="_blank">东宁</a></strong>|</li>
                        <li><strong><a href="http://dunhuangshi.<?php echo $host_top?>" target="_blank">敦煌</a></strong>|</li>
                        <li><strong><a href="http://dayeshi.<?php echo $host_top?>" target="_blank">大冶</a></strong>|</li>
                        <li><strong><a href="http://dashiqiaoshi.<?php echo $host_top?>" target="_blank">大石桥</a></strong>|</li>
                        <li><strong><a href="http://dunhuashi.<?php echo $host_top?>" target="_blank">敦化</a></strong>|</li>
                        <li><strong><a href="http://daqing.<?php echo $host_top?>" target="_blank">大庆</a></strong>|</li>
                        <li><strong><a href="http://dezhou.<?php echo $host_top?>" target="_blank">德州</a></strong>|</li>
                        <li><strong><a href="http://douyunshi.<?php echo $host_top?>" target="_blank">都匀</a></strong>|</li>
                        <li><strong><a href="http://daanshi.<?php echo $host_top?>" target="_blank">大安</a></strong>|</li>
                        <li><strong><a href="http://dazhou.<?php echo $host_top?>" target="_blank">达州</a></strong>|</li>
                        <li><strong><a href="http://dongtaishi.<?php echo $host_top?>" target="_blank">东台</a></strong>|</li>
                        <li><strong><a href="http://dexingshi.<?php echo $host_top?>" target="_blank">德兴</a></strong>|</li>
                        <li><strong><a href="http://delinghashi.<?php echo $host_top?>" target="_blank">德令哈</a></strong>|</li>
                        <li><strong><a href="http://doujiangyanshi.<?php echo $host_top?>" target="_blank">都江堰</a></strong>|</li>
                        <li><strong><a href="http://dangyangshi.<?php echo $host_top?>" target="_blank">当阳</a></strong>|</li>
                        <li><strong><a href="http://dengzhoushi.<?php echo $host_top?>" target="_blank">邓州</a></strong>|</li>
                        <li><strong><a href="http://donggangshi.<?php echo $host_top?>" target="_blank">东港</a></strong>|</li>
                        <li><strong><a href="http://daxinganling.<?php echo $host_top?>" target="_blank">大兴安岭</a></strong></li>
                        <li class="char">E</li>
                        <li><strong><a href="http://eergunashi.<?php echo $host_top?>" target="_blank">额尔古纳</a></strong>|</li>
                        <li><strong><a href="http://ezhou.<?php echo $host_top?>" target="_blank">鄂州</a></strong>|</li>
                        <li><strong><a href="http://enshi.<?php echo $host_top?>" target="_blank">恩施</a></strong>|</li>
                        <li><strong><a href="http://erlianhaoteshi.<?php echo $host_top?>" target="_blank">二连浩特</a></strong>|</li>
                        <li><strong><a href="http://emeishanshi.<?php echo $host_top?>" target="_blank">峨眉山</a></strong>|</li>
                        <li><strong><a href="http://enpingshi.<?php echo $host_top?>" target="_blank">恩平</a></strong></li>
                        <li class="char">F</li>
                        <li><strong><a href="http://fuanshi.<?php echo $host_top?>" target="_blank">福安</a></strong>|</li>
                        <li><strong><a href="http://fudingshi.<?php echo $host_top?>" target="_blank">福鼎</a></strong>|</li>
                        <li><strong><a href="http://fengchengshi.<?php echo $host_top?>" target="_blank">丰城</a></strong>|</li>
                        <li><strong><a href="http://fushan.<?php echo $host_top?>" target="_blank">佛山</a></strong>|</li>
                        <li><strong><a href="http://feichengshi.<?php echo $host_top?>" target="_blank">肥城</a></strong>|</li>
                        <li><strong><a href="http://fuzhou2.<?php echo $host_top?>" target="_blank">抚州</a></strong>|</li>
                        <li><strong><a href="http://fangchenggang.<?php echo $host_top?>" target="_blank">防城港</a></strong>|</li>
                        <li><strong><a href="http://fujian.<?php echo $host_top?>" target="_blank">福建</a></strong>|</li>
                        <li><strong><a href="http://fuyuxian2.<?php echo $host_top?>" target="_blank">扶余</a></strong>|</li>
                        <li><strong><a href="http://fenyangshi.<?php echo $host_top?>" target="_blank">汾阳</a></strong>|</li>
                        <li><strong><a href="http://fuyangshi.<?php echo $host_top?>" target="_blank">富阳</a></strong>|</li>
                        <li><strong><a href="http://fuzhou.<?php echo $host_top?>" target="_blank">福州</a></strong>|</li>
                        <li><strong><a href="http://fengzhenshi.<?php echo $host_top?>" target="_blank">丰镇</a></strong>|</li>
                        <li><strong><a href="http://fuquanshi.<?php echo $host_top?>" target="_blank">福泉</a></strong>|</li>
                        <li><strong><a href="http://fuyang.<?php echo $host_top?>" target="_blank">阜阳</a></strong>|</li>
                        <li><strong><a href="http://fuxin.<?php echo $host_top?>" target="_blank">阜新</a></strong>|</li>
                        <li><strong><a href="http://fushun.<?php echo $host_top?>" target="_blank">抚顺</a></strong>|</li>
                        <li><strong><a href="http://fujinshi.<?php echo $host_top?>" target="_blank">富锦</a></strong>|</li>
                        <li><strong><a href="http://fuyuanxian.<?php echo $host_top?>" target="_blank">抚远</a></strong>|</li>
                        <li><strong><a href="http://fenghuashi.<?php echo $host_top?>" target="_blank">奉化</a></strong>|</li>
                        <li><strong><a href="http://fuqingshi.<?php echo $host_top?>" target="_blank">福清</a></strong>|</li>
                        <li><strong><a href="http://fengchengshi2.<?php echo $host_top?>" target="_blank">凤城</a></strong></li>
                        <li class="char">G</li>
                        <li><strong><a href="http://genheshi.<?php echo $host_top?>" target="_blank">根河</a></strong>|</li>
                        <li><strong><a href="http://guangshuishi.<?php echo $host_top?>" target="_blank">广水</a></strong>|</li>
                        <li><strong><a href="http://ganzi.<?php echo $host_top?>" target="_blank">甘孜</a></strong>|</li>
                        <li><strong><a href="http://gejiushi.<?php echo $host_top?>" target="_blank">个旧</a></strong>|</li>
                        <li><strong><a href="http://gaoanshi.<?php echo $host_top?>" target="_blank">高安</a></strong>|</li>
                        <li><strong><a href="http://guoluo.<?php echo $host_top?>" target="_blank">果洛</a></strong>|</li>
                        <li><strong><a href="http://guangzhou.<?php echo $host_top?>" target="_blank">广州</a></strong>|</li>
                        <li><strong><a href="http://gaopingshi.<?php echo $host_top?>" target="_blank">高平</a></strong>|</li>
                        <li><strong><a href="http://gaoyoushi.<?php echo $host_top?>" target="_blank">高邮</a></strong>|</li>
                        <li><strong><a href="http://gaochengshi.<?php echo $host_top?>" target="_blank">藁城</a></strong>|</li>
                        <li><strong><a href="http://guizhou.<?php echo $host_top?>" target="_blank">贵州</a></strong>|</li>
                        <li><strong><a href="http://guipingshi.<?php echo $host_top?>" target="_blank">桂平</a></strong>|</li>
                        <li><strong><a href="http://gongyishi.<?php echo $host_top?>" target="_blank">巩义</a></strong>|</li>
                        <li><strong><a href="http://guangyuan.<?php echo $host_top?>" target="_blank">广元</a></strong>|</li>
                        <li><strong><a href="http://gaomishi.<?php echo $host_top?>" target="_blank">高密</a></strong>|</li>
                        <li><strong><a href="http://guangan.<?php echo $host_top?>" target="_blank">广安</a></strong>|</li>
                        <li><strong><a href="http://gaoyaoshi.<?php echo $host_top?>" target="_blank">高要</a></strong>|</li>
                        <li><strong><a href="http://gaobeidianshi.<?php echo $host_top?>" target="_blank">高碑店</a></strong>|</li>
                        <li><strong><a href="http://guyuan.<?php echo $host_top?>" target="_blank">固原</a></strong>|</li>
                        <li><strong><a href="http://gujiaoshi.<?php echo $host_top?>" target="_blank">古交</a></strong>|</li>
                        <li><strong><a href="http://gaozhoushi.<?php echo $host_top?>" target="_blank">高州</a></strong>|</li>
                        <li><strong><a href="http://gannan.<?php echo $host_top?>" target="_blank">甘南</a></strong>|</li>
                        <li><strong><a href="http://guiyang.<?php echo $host_top?>" target="_blank">贵阳</a></strong>|</li>
                        <li><strong><a href="http://guangdong.<?php echo $host_top?>" target="_blank">广东</a></strong>|</li>
                        <li><strong><a href="http://gaizhoushi.<?php echo $host_top?>" target="_blank">盖州</a></strong>|</li>
                        <li><strong><a href="http://guangxi.<?php echo $host_top?>" target="_blank">广西</a></strong>|</li>
                        <li><strong><a href="http://guanghanshi.<?php echo $host_top?>" target="_blank">广汉</a></strong>|</li>
                        <li><strong><a href="http://gongzhulingshi.<?php echo $host_top?>" target="_blank">公主岭</a></strong>|</li>
                        <li><strong><a href="http://gansu.<?php echo $host_top?>" target="_blank">甘肃</a></strong>|</li>
                        <li><strong><a href="http://geermushi.<?php echo $host_top?>" target="_blank">格尔木</a></strong>|</li>
                        <li><strong><a href="http://guixishi.<?php echo $host_top?>" target="_blank">贵溪</a></strong>|</li>
                        <li><strong><a href="http://guigang.<?php echo $host_top?>" target="_blank">贵港</a></strong>|</li>
                        <li><strong><a href="http://ganzhou.<?php echo $host_top?>" target="_blank">赣州</a></strong>|</li>
                        <li><strong><a href="http://guilin.<?php echo $host_top?>" target="_blank">桂林</a></strong></li>
                        <li class="char">I</li>
                        <li><strong><a href="http://yili.<?php echo $host_top?>" target="_blank">伊犁</a></strong>|</li>
                        <li><strong><a href="http://neimenggu.<?php echo $host_top?>" target="_blank">内蒙古</a></strong></li>
                        <li class="char">J</li>
                        <li><strong><a href="http://jiangsu.<?php echo $host_top?>" target="_blank">江苏</a></strong>|</li>
                        <li><strong><a href="http://jingjiangshi.<?php echo $host_top?>" target="_blank">靖江</a></strong>|</li>
                        <li><strong><a href="http://jingdezhen.<?php echo $host_top?>" target="_blank">景德镇</a></strong>|</li>
                        <li><strong><a href="http://jinzhou.<?php echo $host_top?>" target="_blank">锦州</a></strong>|</li>
                        <li><strong><a href="http://jinchang.<?php echo $host_top?>" target="_blank">金昌</a></strong>|</li>
                        <li><strong><a href="http://jieyang.<?php echo $host_top?>" target="_blank">揭阳</a></strong>|</li>
                        <li><strong><a href="http://jingshanxian.<?php echo $host_top?>" target="_blank">京山</a></strong>|</li>
                        <li><strong><a href="http://jiangyinshi.<?php echo $host_top?>" target="_blank">江阴</a></strong>|</li>
                        <li><strong><a href="http://jizhoushi.<?php echo $host_top?>" target="_blank">冀州</a></strong>|</li>
                        <li><strong><a href="http://jieshoushi.<?php echo $host_top?>" target="_blank">界首</a></strong>|</li>
                        <li><strong><a href="http://jimoshi.<?php echo $host_top?>" target="_blank">即墨</a></strong>|</li>
                        <li><strong><a href="http://jilin.<?php echo $host_top?>" target="_blank">吉林</a></strong>|</li>
                        <li><strong><a href="http://jiangyoushi.<?php echo $host_top?>" target="_blank">江油</a></strong>|</li>
                        <li><strong><a href="http://jianoushi.<?php echo $host_top?>" target="_blank">建瓯</a></strong>|</li>
                        <li><strong><a href="http://jiangxi.<?php echo $host_top?>" target="_blank">江西</a></strong>|</li>
                        <li><strong><a href="http://jinghongshi.<?php echo $host_top?>" target="_blank">景洪</a></strong>|</li>
                        <li><strong><a href="http://jian.<?php echo $host_top?>" target="_blank">吉安</a></strong>|</li>
                        <li><strong><a href="http://jiuquan.<?php echo $host_top?>" target="_blank">酒泉</a></strong>|</li>
                        <li><strong><a href="http://jiaozhoushi.<?php echo $host_top?>" target="_blank">胶州</a></strong>|</li>
                        <li><strong><a href="http://jining.<?php echo $host_top?>" target="_blank">济宁</a></strong>|</li>
                        <li><strong><a href="http://jinjiangshi.<?php echo $host_top?>" target="_blank">晋江</a></strong>|</li>
                        <li><strong><a href="http://jiaoheshi.<?php echo $host_top?>" target="_blank">蛟河</a></strong>|</li>
                        <li><strong><a href="http://jiangmen.<?php echo $host_top?>" target="_blank">江门</a></strong>|</li>
                        <li><strong><a href="http://jiangshanshi.<?php echo $host_top?>" target="_blank">江山</a></strong>|</li>
                        <li><strong><a href="http://jinzhoushi.<?php echo $host_top?>" target="_blank">晋州</a></strong>|</li>
                        <li><strong><a href="http://jingzhou.<?php echo $host_top?>" target="_blank">荆州</a></strong>|</li>
                        <li><strong><a href="http://jiamusi.<?php echo $host_top?>" target="_blank">佳木斯</a></strong>|</li>
                        <li><strong><a href="http://jinzhong.<?php echo $host_top?>" target="_blank">晋中</a></strong>|</li>
                        <li><strong><a href="http://jixi.<?php echo $host_top?>" target="_blank">鸡西</a></strong>|</li>
                        <li><strong><a href="http://jintanshi.<?php echo $host_top?>" target="_blank">金坛</a></strong>|</li>
                        <li><strong><a href="http://jurongshi.<?php echo $host_top?>" target="_blank">句容</a></strong>|</li>
                        <li><strong><a href="http://jiaxing.<?php echo $host_top?>" target="_blank">嘉兴</a></strong>|</li>
                        <li><strong><a href="http://jianshi.<?php echo $host_top?>" target="_blank">集安</a></strong>|</li>
                        <li><strong><a href="http://jiayuguan.<?php echo $host_top?>" target="_blank">嘉峪关</a></strong>|</li>
                        <li><strong><a href="http://jiaozuo.<?php echo $host_top?>" target="_blank">焦作</a></strong>|</li>
                        <li><strong><a href="http://jinggangshanshi.<?php echo $host_top?>" target="_blank">井冈山</a></strong>|</li>
                        <li><strong><a href="http://jinan.<?php echo $host_top?>" target="_blank">济南</a></strong>|</li>
                        <li><strong><a href="http://jiyuanshi.<?php echo $host_top?>" target="_blank">济源</a></strong>|</li>
                        <li><strong><a href="http://jinshishi.<?php echo $host_top?>" target="_blank">津市</a></strong>|</li>
                        <li><strong><a href="http://jingmen.<?php echo $host_top?>" target="_blank">荆门</a></strong>|</li>
                        <li><strong><a href="http://jiandeshi.<?php echo $host_top?>" target="_blank">建德</a></strong>|</li>
                        <li><strong><a href="http://jinhua.<?php echo $host_top?>" target="_blank">金华</a></strong>|</li>
                        <li><strong><a href="http://jishoushi.<?php echo $host_top?>" target="_blank">吉首</a></strong>|</li>
                        <li><strong><a href="http://jiujiang.<?php echo $host_top?>" target="_blank">九江</a></strong>|</li>
                        <li><strong><a href="http://jiutaishi.<?php echo $host_top?>" target="_blank">九台</a></strong>|</li>
                        <li><strong><a href="http://jincheng.<?php echo $host_top?>" target="_blank">晋城</a></strong>|</li>
                        <li><strong><a href="http://jianyangshi2.<?php echo $host_top?>" target="_blank">简阳</a></strong>|</li>
                        <li><strong><a href="http://jiexiushi.<?php echo $host_top?>" target="_blank">介休</a></strong>|</li>
                        <li><strong><a href="http://jianyangshi.<?php echo $host_top?>" target="_blank">建阳</a></strong></li>
                        <li class="char">K</li>
                        <li><strong><a href="http://kuerleishi.<?php echo $host_top?>" target="_blank">库尔勒</a></strong>|</li>
                        <li><strong><a href="http://kangdingxian.<?php echo $host_top?>" target="_blank">康定</a></strong>|</li>
                        <li><strong><a href="http://kaiyuanshi2.<?php echo $host_top?>" target="_blank">开远</a></strong>|</li>
                        <li><strong><a href="http://kashen.<?php echo $host_top?>" target="_blank">喀什</a></strong>|</li>
                        <li><strong><a href="http://kunshan.<?php echo $host_top?>" target="_blank">昆山</a></strong>|</li>
                        <li><strong><a href="http://kaiyuanshi.<?php echo $host_top?>" target="_blank">开原</a></strong>|</li>
                        <li><strong><a href="http://kaifeng.<?php echo $host_top?>" target="_blank">开封</a></strong>|</li>
                        <li><strong><a href="http://kailishi.<?php echo $host_top?>" target="_blank">凯里</a></strong>|</li>
                        <li><strong><a href="http://kaipingqu.<?php echo $host_top?>" target="_blank">开平</a></strong>|</li>
                        <li><strong><a href="http://kuitunshi.<?php echo $host_top?>" target="_blank">奎屯</a></strong>|</li>
                        <li><strong><a href="http://kunming.<?php echo $host_top?>" target="_blank">昆明</a></strong>|</li>
                        <li><strong><a href="http://kezileisu.<?php echo $host_top?>" target="_blank">克孜勒苏</a></strong>|</li>
                        <li><strong><a href="http://kelamayi.<?php echo $host_top?>" target="_blank">克拉玛依</a></strong></li>
                        <li class="char">L</li>
                        <li><strong><a href="http://liupanshui.<?php echo $host_top?>" target="_blank">六盘水</a></strong>|</li>
                        <li><strong><a href="http://linjiangshi.<?php echo $host_top?>" target="_blank">临江</a></strong>|</li>
                        <li><strong><a href="http://lijiang.<?php echo $host_top?>" target="_blank">丽江</a></strong>|</li>
                        <li><strong><a href="http://lengshuijiangshi.<?php echo $host_top?>" target="_blank">冷水江</a></strong>|</li>
                        <li><strong><a href="http://lianyuanshi.<?php echo $host_top?>" target="_blank">涟源</a></strong>|</li>
                        <li><strong><a href="http://lelingshi.<?php echo $host_top?>" target="_blank">乐陵</a></strong>|</li>
                        <li><strong><a href="http://lianzhoushi.<?php echo $host_top?>" target="_blank">连州</a></strong>|</li>
                        <li><strong><a href="http://lanxishi.<?php echo $host_top?>" target="_blank">兰溪</a></strong>|</li>
                        <li><strong><a href="http://lingaoxian.<?php echo $host_top?>" target="_blank">临高</a></strong>|</li>
                        <li><strong><a href="http://ledong.<?php echo $host_top?>" target="_blank">乐东</a></strong>|</li>
                        <li><strong><a href="http://lushanqu.<?php echo $host_top?>" target="_blank">庐山</a></strong>|</li>
                        <li><strong><a href="http://lingshui.<?php echo $host_top?>" target="_blank">陵水</a></strong>|</li>
                        <li><strong><a href="http://luzhou.<?php echo $host_top?>" target="_blank">泸州</a></strong>|</li>
                        <li><strong><a href="http://lvliang.<?php echo $host_top?>" target="_blank">吕梁</a></strong>|</li>
                        <li><strong><a href="http://liaocheng.<?php echo $host_top?>" target="_blank">聊城</a></strong>|</li>
                        <li><strong><a href="http://lianjiangshi.<?php echo $host_top?>" target="_blank">廉江</a></strong>|</li>
                        <li><strong><a href="http://leizhoushi.<?php echo $host_top?>" target="_blank">雷州</a></strong>|</li>
                        <li><strong><a href="http://linxia.<?php echo $host_top?>" target="_blank">临夏</a></strong>|</li>
                        <li><strong><a href="http://lushuixian.<?php echo $host_top?>" target="_blank">泸水</a></strong>|</li>
                        <li><strong><a href="http://liaoyang.<?php echo $host_top?>" target="_blank">辽阳</a></strong>|</li>
                        <li><strong><a href="http://luquanshi.<?php echo $host_top?>" target="_blank">鹿泉</a></strong>|</li>
                        <li><strong><a href="http://lanzhou.<?php echo $host_top?>" target="_blank">兰州</a></strong>|</li>
                        <li><strong><a href="http://linhaishi.<?php echo $host_top?>" target="_blank">临海</a></strong>|</li>
                        <li><strong><a href="http://laohekoushi.<?php echo $host_top?>" target="_blank">老河口</a></strong>|</li>
                        <li><strong><a href="http://liaoning.<?php echo $host_top?>" target="_blank">辽宁</a></strong>|</li>
                        <li><strong><a href="http://longyan.<?php echo $host_top?>" target="_blank">龙岩</a></strong>|</li>
                        <li><strong><a href="http://lepingshi.<?php echo $host_top?>" target="_blank">乐平</a></strong>|</li>
                        <li><strong><a href="http://linxiangshi.<?php echo $host_top?>" target="_blank">临湘</a></strong>|</li>
                        <li><strong><a href="http://lishui.<?php echo $host_top?>" target="_blank">丽水</a></strong>|</li>
                        <li><strong><a href="http://linghaishi.<?php echo $host_top?>" target="_blank">凌海</a></strong>|</li>
                        <li><strong><a href="http://linyi.<?php echo $host_top?>" target="_blank">临沂</a></strong>|</li>
                        <li><strong><a href="http://liuyangshi.<?php echo $host_top?>" target="_blank">浏阳</a></strong>|</li>
                        <li><strong><a href="http://longchangxian.<?php echo $host_top?>" target="_blank">隆昌</a></strong>|</li>
                        <li><strong><a href="http://laixishi.<?php echo $host_top?>" target="_blank">莱西</a></strong>|</li>
                        <li><strong><a href="http://luchengshi.<?php echo $host_top?>" target="_blank">潞城</a></strong>|</li>
                        <li><strong><a href="http://liangshan.<?php echo $host_top?>" target="_blank">凉山</a></strong>|</li>
                        <li><strong><a href="http://leshan.<?php echo $host_top?>" target="_blank">乐山</a></strong>|</li>
                        <li><strong><a href="http://laiwu.<?php echo $host_top?>" target="_blank">莱芜</a></strong>|</li>
                        <li><strong><a href="http://linqingshi.<?php echo $host_top?>" target="_blank">临清</a></strong>|</li>
                        <li><strong><a href="http://linanshi.<?php echo $host_top?>" target="_blank">临安</a></strong>|</li>
                        <li><strong><a href="http://longnan.<?php echo $host_top?>" target="_blank">陇南</a></strong>|</li>
                        <li><strong><a href="http://leiyangshi.<?php echo $host_top?>" target="_blank">耒阳</a></strong>|</li>
                        <li><strong><a href="http://lingbaoshi.<?php echo $host_top?>" target="_blank">灵宝</a></strong>|</li>
                        <li><strong><a href="http://langzhongshi.<?php echo $host_top?>" target="_blank">阆中</a></strong>|</li>
                        <li><strong><a href="http://liuzhou.<?php echo $host_top?>" target="_blank">柳州</a></strong>|</li>
                        <li><strong><a href="http://longquanshi.<?php echo $host_top?>" target="_blank">龙泉</a></strong>|</li>
                        <li><strong><a href="http://lingwushi.<?php echo $host_top?>" target="_blank">灵武</a></strong>|</li>
                        <li><strong><a href="http://lingyuanshi.<?php echo $host_top?>" target="_blank">凌源</a></strong>|</li>
                        <li><strong><a href="http://langfang.<?php echo $host_top?>" target="_blank">廊坊</a></strong>|</li>
                        <li><strong><a href="http://luoyang.<?php echo $host_top?>" target="_blank">洛阳</a></strong>|</li>
                        <li><strong><a href="http://lianyungang.<?php echo $host_top?>" target="_blank">连云港</a></strong>|</li>
                        <li><strong><a href="http://lasa.<?php echo $host_top?>" target="_blank">拉萨</a></strong>|</li>
                        <li><strong><a href="http://loudi.<?php echo $host_top?>" target="_blank">娄底</a></strong>|</li>
                        <li><strong><a href="http://longjingshi.<?php echo $host_top?>" target="_blank">龙井</a></strong>|</li>
                        <li><strong><a href="http://luodingshi.<?php echo $host_top?>" target="_blank">罗定</a></strong>|</li>
                        <li><strong><a href="http://linfen.<?php echo $host_top?>" target="_blank">临汾</a></strong>|</li>
                        <li><strong><a href="http://lilingshi.<?php echo $host_top?>" target="_blank">醴陵</a></strong>|</li>
                        <li><strong><a href="http://lincang.<?php echo $host_top?>" target="_blank">临沧</a></strong>|</li>
                        <li><strong><a href="http://linzhoushi.<?php echo $host_top?>" target="_blank">林州</a></strong>|</li>
                        <li><strong><a href="http://longhaishi.<?php echo $host_top?>" target="_blank">龙海</a></strong>|</li>
                        <li><strong><a href="http://lechangshi.<?php echo $host_top?>" target="_blank">乐昌</a></strong>|</li>
                        <li><strong><a href="http://luohe.<?php echo $host_top?>" target="_blank">漯河</a></strong>|</li>
                        <li><strong><a href="http://liyangshi.<?php echo $host_top?>" target="_blank">溧阳</a></strong>|</li>
                        <li><strong><a href="http://laibin.<?php echo $host_top?>" target="_blank">来宾</a></strong>|</li>
                        <li><strong><a href="http://lufengshi.<?php echo $host_top?>" target="_blank">陆丰</a></strong>|</li>
                        <li><strong><a href="http://liaoyuan.<?php echo $host_top?>" target="_blank">辽源</a></strong>|</li>
                        <li><strong><a href="http://longkoushi.<?php echo $host_top?>" target="_blank">龙口</a></strong>|</li>
                        <li><strong><a href="http://laiyangshi.<?php echo $host_top?>" target="_blank">莱阳</a></strong>|</li>
                        <li><strong><a href="http://laizhoushi.<?php echo $host_top?>" target="_blank">莱州</a></strong>|</li>
                        <li><strong><a href="http://liuan.<?php echo $host_top?>" target="_blank">六安</a></strong></li>
                        <li class="char">M</li>
                        <li><strong><a href="http://mengzhoushi.<?php echo $host_top?>" target="_blank">孟州</a></strong>|</li>
                        <li><strong><a href="http://maanshan.<?php echo $host_top?>" target="_blank">马鞍山</a></strong>|</li>
                        <li><strong><a href="http://mengzixian.<?php echo $host_top?>" target="_blank">蒙自</a></strong>|</li>
                        <li><strong><a href="http://mileixian.<?php echo $host_top?>" target="_blank">弥勒</a></strong>|</li>
                        <li><strong><a href="http://meizhou.<?php echo $host_top?>" target="_blank">梅州</a></strong>|</li>
                        <li><strong><a href="http://machengshi.<?php echo $host_top?>" target="_blank">麻城</a></strong>|</li>
                        <li><strong><a href="http://maoming.<?php echo $host_top?>" target="_blank">茂名</a></strong>|</li>
                        <li><strong><a href="http://mudanjiang.<?php echo $host_top?>" target="_blank">牡丹江</a></strong>|</li>
                        <li><strong><a href="http://miluoshi.<?php echo $host_top?>" target="_blank">汨罗</a></strong>|</li>
                        <li><strong><a href="http://meihekoushi.<?php echo $host_top?>" target="_blank">梅河口</a></strong>|</li>
                        <li><strong><a href="http://meishan.<?php echo $host_top?>" target="_blank">眉山</a></strong>|</li>
                        <li><strong><a href="http://mulengshi.<?php echo $host_top?>" target="_blank">穆棱</a></strong>|</li>
                        <li><strong><a href="http://maerkangxian.<?php echo $host_top?>" target="_blank">马尔康</a></strong>|</li>
                        <li><strong><a href="http://mingguangshi.<?php echo $host_top?>" target="_blank">明光</a></strong>|</li>
                        <li><strong><a href="http://mianzhushi.<?php echo $host_top?>" target="_blank">绵竹</a></strong>|</li>
                        <li><strong><a href="http://mianyang.<?php echo $host_top?>" target="_blank">绵阳</a></strong>|</li>
                        <li><strong><a href="http://mishanshi.<?php echo $host_top?>" target="_blank">密山</a></strong>|</li>
                        <li><strong><a href="http://manzhoulishi.<?php echo $host_top?>" target="_blank">满洲里</a></strong></li>
                        <li class="char">N</li>
                        <li><strong><a href="http://ningxia.<?php echo $host_top?>" target="_blank">宁夏</a></strong>|</li>
                        <li><strong><a href="http://nangongshi.<?php echo $host_top?>" target="_blank">南宫</a></strong>|</li>
                        <li><strong><a href="http://neijiang.<?php echo $host_top?>" target="_blank">内江</a></strong>|</li>
                        <li><strong><a href="http://ali.<?php echo $host_top?>" target="_blank">阿里</a></strong>|</li>
                        <li><strong><a href="http://nujiang.<?php echo $host_top?>" target="_blank">怒江</a></strong>|</li>
                        <li><strong><a href="http://nanning.<?php echo $host_top?>" target="_blank">南宁</a></strong>|</li>
                        <li><strong><a href="http://nanchong.<?php echo $host_top?>" target="_blank">南充</a></strong>|</li>
                        <li><strong><a href="http://nantong.<?php echo $host_top?>" target="_blank">南通</a></strong>|</li>
                        <li><strong><a href="http://nanjing.<?php echo $host_top?>" target="_blank">南京</a></strong>|</li>
                        <li><strong><a href="http://ningxiangxian.<?php echo $host_top?>" target="_blank">宁乡</a></strong>|</li>
                        <li><strong><a href="http://nananshi.<?php echo $host_top?>" target="_blank">南安</a></strong>|</li>
                        <li><strong><a href="http://ningguoshi.<?php echo $host_top?>" target="_blank">宁国</a></strong>|</li>
                        <li><strong><a href="http://neheshi.<?php echo $host_top?>" target="_blank">讷河</a></strong>|</li>
                        <li><strong><a href="http://nanyang.<?php echo $host_top?>" target="_blank">南阳</a></strong>|</li>
                        <li><strong><a href="http://nanchang.<?php echo $host_top?>" target="_blank">南昌</a></strong>|</li>
                        <li><strong><a href="http://ninganshi.<?php echo $host_top?>" target="_blank">宁安</a></strong>|</li>
                        <li><strong><a href="http://ningde.<?php echo $host_top?>" target="_blank">宁德</a></strong>|</li>
                        <li><strong><a href="http://naqu.<?php echo $host_top?>" target="_blank">那曲</a></strong>|</li>
                        <li><strong><a href="http://ningbo.<?php echo $host_top?>" target="_blank">宁波</a></strong>|</li>
                        <li><strong><a href="http://nanxiongshi.<?php echo $host_top?>" target="_blank">南雄</a></strong>|</li>
                        <li><strong><a href="http://nanping.<?php echo $host_top?>" target="_blank">南平</a></strong>|</li>
                        <li><strong><a href="http://linzhi.<?php echo $host_top?>" target="_blank">林芝</a></strong>|</li>
                        <li><strong><a href="http://nankangshi.<?php echo $host_top?>" target="_blank">南康</a></strong></li>
                        <li class="char">O</li>
                        <li><strong><a href="http://eerduosi.<?php echo $host_top?>" target="_blank">鄂尔多斯</a></strong></li>
                        <li class="char">P</li>
                        <li><strong><a href="http://pingliang.<?php echo $host_top?>" target="_blank">平凉</a></strong>|</li>
                        <li><strong><a href="http://puyang.<?php echo $host_top?>" target="_blank">濮阳</a></strong>|</li>
                        <li><strong><a href="http://pingdingshan.<?php echo $host_top?>" target="_blank">平顶山</a></strong>|</li>
                        <li><strong><a href="http://pulandianshi.<?php echo $host_top?>" target="_blank">普兰店</a></strong>|</li>
                        <li><strong><a href="http://pingquanxian.<?php echo $host_top?>" target="_blank">平泉</a></strong>|</li>
                        <li><strong><a href="http://putian.<?php echo $host_top?>" target="_blank">莆田</a></strong>|</li>
                        <li><strong><a href="http://puningshi.<?php echo $host_top?>" target="_blank">普宁</a></strong>|</li>
                        <li><strong><a href="http://pingdushi.<?php echo $host_top?>" target="_blank">平度</a></strong>|</li>
                        <li><strong><a href="http://pingxiang.<?php echo $host_top?>" target="_blank">萍乡</a></strong>|</li>
                        <li><strong><a href="http://puer.<?php echo $host_top?>" target="_blank">普洱</a></strong>|</li>
                        <li><strong><a href="http://panshishi.<?php echo $host_top?>" target="_blank">磐石</a></strong>|</li>
                        <li><strong><a href="http://pizhoushi.<?php echo $host_top?>" target="_blank">邳州</a></strong>|</li>
                        <li><strong><a href="http://pingxiangshi.<?php echo $host_top?>" target="_blank">凭祥</a></strong>|</li>
                        <li><strong><a href="http://panjin.<?php echo $host_top?>" target="_blank">盘锦</a></strong>|</li>
                        <li><strong><a href="http://panzhihua.<?php echo $host_top?>" target="_blank">攀枝花</a></strong>|</li>
                        <li><strong><a href="http://pengzhoushi.<?php echo $host_top?>" target="_blank">彭州</a></strong>|</li>
                        <li><strong><a href="http://pinghushi.<?php echo $host_top?>" target="_blank">平湖</a></strong>|</li>
                        <li><strong><a href="http://penglaishi.<?php echo $host_top?>" target="_blank">蓬莱</a></strong></li>
                        <li class="char">Q</li>
                        <li><strong><a href="http://qinyangshi.<?php echo $host_top?>" target="_blank">沁阳</a></strong>|</li>
                        <li><strong><a href="http://qionghai.<?php echo $host_top?>" target="_blank">琼海</a></strong>|</li>
                        <li><strong><a href="http://qingdao.<?php echo $host_top?>" target="_blank">青岛</a></strong>|</li>
                        <li><strong><a href="http://quanzhou.<?php echo $host_top?>" target="_blank">泉州</a></strong>|</li>
                        <li><strong><a href="http://qiongzhong.<?php echo $host_top?>" target="_blank">琼中</a></strong>|</li>
                        <li><strong><a href="http://quzhou.<?php echo $host_top?>" target="_blank">衢州</a></strong>|</li>
                        <li><strong><a href="http://qiqihaer.<?php echo $host_top?>" target="_blank">齐齐哈尔</a></strong>|</li>
                        <li><strong><a href="http://qianxinan.<?php echo $host_top?>" target="_blank">黔西南</a></strong>|</li>
                        <li><strong><a href="http://qingzhoushi.<?php echo $host_top?>" target="_blank">青州</a></strong>|</li>
                        <li><strong><a href="http://qiandongnan.<?php echo $host_top?>" target="_blank">黔东南</a></strong>|</li>
                        <li><strong><a href="http://qujing.<?php echo $host_top?>" target="_blank">曲靖</a></strong>|</li>
                        <li><strong><a href="http://qingtongxiashi.<?php echo $host_top?>" target="_blank">青铜峡</a></strong>|</li>
                        <li><strong><a href="http://changdou.<?php echo $host_top?>" target="_blank">昌都</a></strong>|</li>
                        <li><strong><a href="http://qinzhou.<?php echo $host_top?>" target="_blank">钦州</a></strong>|</li>
                        <li><strong><a href="http://qianshanxian.<?php echo $host_top?>" target="_blank">潜山</a></strong>|</li>
                        <li><strong><a href="http://qidongshi.<?php echo $host_top?>" target="_blank">启东</a></strong>|</li>
                        <li><strong><a href="http://qufushi.<?php echo $host_top?>" target="_blank">曲阜</a></strong>|</li>
                        <li><strong><a href="http://qingyang.<?php echo $host_top?>" target="_blank">庆阳</a></strong>|</li>
                        <li><strong><a href="http://qingyuan.<?php echo $host_top?>" target="_blank">清远</a></strong>|</li>
                        <li><strong><a href="http://qiannan.<?php echo $host_top?>" target="_blank">黔南</a></strong>|</li>
                        <li><strong><a href="http://qianjiang.<?php echo $host_top?>" target="_blank">潜江</a></strong>|</li>
                        <li><strong><a href="http://qionglaishi.<?php echo $host_top?>" target="_blank">邛崃</a></strong>|</li>
                        <li><strong><a href="http://qiananshi.<?php echo $host_top?>" target="_blank">迁安</a></strong>|</li>
                        <li><strong><a href="http://qinghai.<?php echo $host_top?>" target="_blank">青海</a></strong>|</li>
                        <li><strong><a href="http://qitaihe.<?php echo $host_top?>" target="_blank">七台河</a></strong>|</li>
                        <li><strong><a href="http://qingzhenshi.<?php echo $host_top?>" target="_blank">清镇</a></strong>|</li>
                        <li><strong><a href="http://qinhuangdao.<?php echo $host_top?>" target="_blank">秦皇岛</a></strong>|</li>
                        <li><strong><a href="http://qixiaqu.<?php echo $host_top?>" target="_blank">栖霞</a></strong></li>
                        <li class="char">R</li>
                        <li><strong><a href="http://ruichangshi.<?php echo $host_top?>" target="_blank">瑞昌</a></strong>|</li>
                        <li><strong><a href="http://rikaze.<?php echo $host_top?>" target="_blank">日喀则</a></strong>|</li>
                        <li><strong><a href="http://ruijinshi.<?php echo $host_top?>" target="_blank">瑞金</a></strong>|</li>
                        <li><strong><a href="http://ruilishi.<?php echo $host_top?>" target="_blank">瑞丽</a></strong>|</li>
                        <li><strong><a href="http://ruzhoushi.<?php echo $host_top?>" target="_blank">汝州</a></strong>|</li>
                        <li><strong><a href="http://rongchengshi.<?php echo $host_top?>" target="_blank">荣成</a></strong>|</li>
                        <li><strong><a href="http://rushanshi.<?php echo $host_top?>" target="_blank">乳山</a></strong>|</li>
                        <li><strong><a href="http://ruianshi.<?php echo $host_top?>" target="_blank">瑞安</a></strong>|</li>
                        <li><strong><a href="http://rizhao.<?php echo $host_top?>" target="_blank">日照</a></strong>|</li>
                        <li><strong><a href="http://renqiushi.<?php echo $host_top?>" target="_blank">任丘</a></strong>|</li>
                        <li><strong><a href="http://rugaoshi.<?php echo $host_top?>" target="_blank">如皋</a></strong>|</li>
                        <li><strong><a href="http://renhuaishi.<?php echo $host_top?>" target="_blank">仁怀</a></strong></li>
                        <li class="char">S</li>
                        <li><strong><a href="http://shangqiu.<?php echo $host_top?>" target="_blank">商丘</a></strong>|</li>
                        <li><strong><a href="http://sanheshi.<?php echo $host_top?>" target="_blank">三河</a></strong>|</li>
                        <li><strong><a href="http://suqian.<?php echo $host_top?>" target="_blank">宿迁</a></strong>|</li>
                        <li><strong><a href="http://shaheshi.<?php echo $host_top?>" target="_blank">沙河</a></strong>|</li>
                        <li><strong><a href="http://shinanqu.<?php echo $host_top?>" target="_blank">市南</a></strong>|</li>
                        <li><strong><a href="http://shibeiqu.<?php echo $host_top?>" target="_blank">市北</a></strong>|</li>
                        <li><strong><a href="http://songyuan.<?php echo $host_top?>" target="_blank">松原</a></strong>|</li>
                        <li><strong><a href="http://suihua.<?php echo $host_top?>" target="_blank">绥化</a></strong>|</li>
                        <li><strong><a href="http://shangzhishi.<?php echo $host_top?>" target="_blank">尚志</a></strong>|</li>
                        <li><strong><a href="http://shaoshanshi.<?php echo $host_top?>" target="_blank">韶山</a></strong>|</li>
                        <li><strong><a href="http://sichuan.<?php echo $host_top?>" target="_blank">四川</a></strong>|</li>
                        <li><strong><a href="http://suzhou.<?php echo $host_top?>" target="_blank">宿州</a></strong>|</li>
                        <li><strong><a href="http://shijiazhuang.<?php echo $host_top?>" target="_blank">石家庄</a></strong>|</li>
                        <li><strong><a href="http://shuozhou.<?php echo $host_top?>" target="_blank">朔州</a></strong>|</li>
                        <li><strong><a href="http://shihezi.<?php echo $host_top?>" target="_blank">石河子</a></strong>|</li>
                        <li><strong><a href="http://shaowushi.<?php echo $host_top?>" target="_blank">邵武</a></strong>|</li>
                        <li><strong><a href="http://sanmenxia.<?php echo $host_top?>" target="_blank">三门峡</a></strong>|</li>
                        <li><strong><a href="http://shenmuxian.<?php echo $host_top?>" target="_blank">神木</a></strong>|</li>
                        <li><strong><a href="http://shandong.<?php echo $host_top?>" target="_blank">山东</a></strong>|</li>
                        <li><strong><a href="http://shannan.<?php echo $host_top?>" target="_blank">山南</a></strong>|</li>
                        <li><strong><a href="http://shanghai.<?php echo $host_top?>" target="_blank">上海</a></strong>|</li>
                        <li><strong><a href="http://shouguangshi.<?php echo $host_top?>" target="_blank">寿光</a></strong>|</li>
                        <li><strong><a href="http://shuangyashan.<?php echo $host_top?>" target="_blank">双鸭山</a></strong>|</li>
                        <li><strong><a href="http://shaoxing.<?php echo $host_top?>" target="_blank">绍兴</a></strong>|</li>
                        <li><strong><a href="http://shangyushi.<?php echo $host_top?>" target="_blank">上虞</a></strong>|</li>
                        <li><strong><a href="http://shenzhoushi.<?php echo $host_top?>" target="_blank">深州</a></strong>|</li>
                        <li><strong><a href="http://shishishi.<?php echo $host_top?>" target="_blank">石狮</a></strong>|</li>
                        <li><strong><a href="http://shulanshi.<?php echo $host_top?>" target="_blank">舒兰</a></strong>|</li>
                        <li><strong><a href="http://shizhongqu.<?php echo $host_top?>" target="_blank">市中</a></strong>|</li>
                        <li><strong><a href="http://shaoguan.<?php echo $host_top?>" target="_blank">韶关</a></strong>|</li>
                        <li><strong><a href="http://shashiqu.<?php echo $host_top?>" target="_blank">沙市</a></strong>|</li>
                        <li><strong><a href="http://siping.<?php echo $host_top?>" target="_blank">四平</a></strong>|</li>
                        <li><strong><a href="http://shangrao.<?php echo $host_top?>" target="_blank">上饶</a></strong>|</li>
                        <li><strong><a href="http://shanwei.<?php echo $host_top?>" target="_blank">汕尾</a></strong>|</li>
                        <li><strong><a href="http://shaoyang.<?php echo $host_top?>" target="_blank">邵阳</a></strong>|</li>
                        <li><strong><a href="http://sanya.<?php echo $host_top?>" target="_blank">三亚</a></strong>|</li>
                        <li><strong><a href="http://suifenheshi.<?php echo $host_top?>" target="_blank">绥芬河</a></strong>|</li>
                        <li><strong><a href="http://shenyang.<?php echo $host_top?>" target="_blank">沈阳</a></strong>|</li>
                        <li><strong><a href="http://suizhou.<?php echo $host_top?>" target="_blank">随州</a></strong>|</li>
                        <li><strong><a href="http://shantou.<?php echo $host_top?>" target="_blank">汕头</a></strong>|</li>
                        <li><strong><a href="http://suining.<?php echo $host_top?>" target="_blank">遂宁</a></strong>|</li>
                        <li><strong><a href="http://shangluo.<?php echo $host_top?>" target="_blank">商洛</a></strong>|</li>
                        <li><strong><a href="http://shengzhoushi.<?php echo $host_top?>" target="_blank">嵊州</a></strong>|</li>
                        <li><strong><a href="http://sanming.<?php echo $host_top?>" target="_blank">三明</a></strong>|</li>
                        <li><strong><a href="http://sihuishi.<?php echo $host_top?>" target="_blank">四会</a></strong>|</li>
                        <li><strong><a href="http://shizuishan.<?php echo $host_top?>" target="_blank">石嘴山</a></strong>|</li>
                        <li><strong><a href="http://shiyan.<?php echo $host_top?>" target="_blank">十堰</a></strong>|</li>
                        <li><strong><a href="http://shanxi2.<?php echo $host_top?>" target="_blank">陕西</a></strong>|</li>
                        <li><strong><a href="http://shishoushi.<?php echo $host_top?>" target="_blank">石首</a></strong>|</li>
                        <li><strong><a href="http://shenfangshi.<?php echo $host_top?>" target="_blank">什邡</a></strong>|</li>
                        <li><strong><a href="http://shennongjialinqu.<?php echo $host_top?>" target="_blank">神农架</a></strong>|</li>
                        <li><strong><a href="http://shuangliaoshi.<?php echo $host_top?>" target="_blank">双辽</a></strong>|</li>
                        <li><strong><a href="http://songzishi.<?php echo $host_top?>" target="_blank">松滋</a></strong>|</li>
                        <li><strong><a href="http://shanxi.<?php echo $host_top?>" target="_blank">山西</a></strong>|</li>
                        <li><strong><a href="http://shuangchengshi.<?php echo $host_top?>" target="_blank">双城</a></strong>|</li>
                        <li><strong><a href="http://shenzhen.<?php echo $host_top?>" target="_blank">深圳</a></strong>|</li>
                        <li><strong><a href="http://suzhou2.<?php echo $host_top?>" target="_blank">苏州</a></strong>|</li>
                        <li><strong><a href="http://shuifuxian.<?php echo $host_top?>" target="_blank">水富</a></strong></li>
                        <li class="char">T</li>
                        <li><strong><a href="http://tieling.<?php echo $host_top?>" target="_blank">铁岭</a></strong>|</li>
                        <li><strong><a href="http://taixingshi.<?php echo $host_top?>" target="_blank">泰兴</a></strong>|</li>
                        <li><strong><a href="http://tunchangxian.<?php echo $host_top?>" target="_blank">屯昌</a></strong>|</li>
                        <li><strong><a href="http://tianjin2.<?php echo $host_top?>" target="_blank">天津</a></strong>|</li>
                        <li><strong><a href="http://tengzhoushi.<?php echo $host_top?>" target="_blank">滕州</a></strong>|</li>
                        <li><strong><a href="http://tumushukeshi.<?php echo $host_top?>" target="_blank">图木舒克</a></strong>|</li>
                        <li><strong><a href="http://taiyuan.<?php echo $host_top?>" target="_blank">太原</a></strong>|</li>
                        <li><strong><a href="http://taicangshi.<?php echo $host_top?>" target="_blank">太仓</a></strong>|</li>
                        <li><strong><a href="http://tonghua.<?php echo $host_top?>" target="_blank">通化</a></strong>|</li>
                        <li><strong><a href="http://xicang.<?php echo $host_top?>" target="_blank">西藏</a></strong>|</li>
                        <li><strong><a href="http://tielishi.<?php echo $host_top?>" target="_blank">铁力</a></strong>|</li>
                        <li><strong><a href="http://tongchengshi.<?php echo $host_top?>" target="_blank">桐城</a></strong>|</li>
                        <li><strong><a href="http://tengchongxian.<?php echo $host_top?>" target="_blank">腾冲</a></strong>|</li>
                        <li><strong><a href="http://tongchuan.<?php echo $host_top?>" target="_blank">铜川</a></strong>|</li>
                        <li><strong><a href="http://tongrenshi.<?php echo $host_top?>" target="_blank">铜仁</a></strong>|</li>
                        <li><strong><a href="http://tangshan.<?php echo $host_top?>" target="_blank">唐山</a></strong>|</li>
                        <li><strong><a href="http://tulufan.<?php echo $host_top?>" target="_blank">吐鲁番</a></strong>|</li>
                        <li><strong><a href="http://taizhou.<?php echo $host_top?>" target="_blank">泰州</a></strong>|</li>
                        <li><strong><a href="http://tianzhangshi.<?php echo $host_top?>" target="_blank">天长</a></strong>|</li>
                        <li><strong><a href="http://tumenshi.<?php echo $host_top?>" target="_blank">图们</a></strong>|</li>
                        <li><strong><a href="http://taishanshi.<?php echo $host_top?>" target="_blank">台山</a></strong>|</li>
                        <li><strong><a href="http://tianmenshi.<?php echo $host_top?>" target="_blank">天门</a></strong>|</li>
                        <li><strong><a href="http://taonanshi.<?php echo $host_top?>" target="_blank">洮南</a></strong>|</li>
                        <li><strong><a href="http://tianshui.<?php echo $host_top?>" target="_blank">天水</a></strong>|</li>
                        <li><strong><a href="http://taian.<?php echo $host_top?>" target="_blank">泰安</a></strong>|</li>
                        <li><strong><a href="http://tonglingxian.<?php echo $host_top?>" target="_blank">铜陵</a></strong>|</li>
                        <li><strong><a href="http://tongjiangshi.<?php echo $host_top?>" target="_blank">同江</a></strong>|</li>
                        <li><strong><a href="http://tongliao.<?php echo $host_top?>" target="_blank">通辽</a></strong>|</li>
                        <li><strong><a href="http://tongxiangshi.<?php echo $host_top?>" target="_blank">桐乡</a></strong>|</li>
                        <li><strong><a href="http://taizhou2.<?php echo $host_top?>" target="_blank">台州</a></strong></li>
                        <li class="char">U</li>
                        <li><strong><a href="http://wulanchabushi.<?php echo $host_top?>" target="_blank">乌兰察布</a></strong>|</li>
                        <li><strong><a href="http://wulumuqi.<?php echo $host_top?>" target="_blank">乌鲁木齐</a></strong></li>
                        <li class="char">W</li>
                        <li><strong><a href="http://wuhan.<?php echo $host_top?>" target="_blank">武汉</a></strong>|</li>
                        <li><strong><a href="http://wuzhishan.<?php echo $host_top?>" target="_blank">五指山</a></strong>|</li>
                        <li><strong><a href="http://weifang.<?php echo $host_top?>" target="_blank">潍坊</a></strong>|</li>
                        <li><strong><a href="http://wenchang.<?php echo $host_top?>" target="_blank">文昌</a></strong>|</li>
                        <li><strong><a href="http://wanning.<?php echo $host_top?>" target="_blank">万宁</a></strong>|</li>
                        <li><strong><a href="http://wudalianchishi.<?php echo $host_top?>" target="_blank">五大连池</a></strong>|</li>
                        <li><strong><a href="http://wuhai.<?php echo $host_top?>" target="_blank">乌海</a></strong>|</li>
                        <li><strong><a href="http://wanyuanshi.<?php echo $host_top?>" target="_blank">万源</a></strong>|</li>
                        <li><strong><a href="http://wuchangshi.<?php echo $host_top?>" target="_blank">五常</a></strong>|</li>
                        <li><strong><a href="http://wuzhong.<?php echo $host_top?>" target="_blank">吴忠</a></strong>|</li>
                        <li><strong><a href="http://wuchuanshi.<?php echo $host_top?>" target="_blank">吴川</a></strong>|</li>
                        <li><strong><a href="http://wuwei.<?php echo $host_top?>" target="_blank">武威</a></strong>|</li>
                        <li><strong><a href="http://weihai.<?php echo $host_top?>" target="_blank">威海</a></strong>|</li>
                        <li><strong><a href="http://wendengshi.<?php echo $host_top?>" target="_blank">文登</a></strong>|</li>
                        <li><strong><a href="http://wenzhou.<?php echo $host_top?>" target="_blank">温州</a></strong>|</li>
                        <li><strong><a href="http://wujiaqu.<?php echo $host_top?>" target="_blank">五家渠</a></strong>|</li>
                        <li><strong><a href="http://wuyishanshi.<?php echo $host_top?>" target="_blank">武夷山</a></strong>|</li>
                        <li><strong><a href="http://wuxueshi.<?php echo $host_top?>" target="_blank">武穴</a></strong>|</li>
                        <li><strong><a href="http://wenlingshi.<?php echo $host_top?>" target="_blank">温岭</a></strong>|</li>
                        <li><strong><a href="http://wuzhou.<?php echo $host_top?>" target="_blank">梧州</a></strong>|</li>
                        <li><strong><a href="http://wafangdianshi.<?php echo $host_top?>" target="_blank">瓦房店</a></strong>|</li>
                        <li><strong><a href="http://wugangshi.<?php echo $host_top?>" target="_blank">舞钢</a></strong>|</li>
                        <li><strong><a href="http://wenshan.<?php echo $host_top?>" target="_blank">文山</a></strong>|</li>
                        <li><strong><a href="http://wusushi.<?php echo $host_top?>" target="_blank">乌苏</a></strong>|</li>
                        <li><strong><a href="http://wulanhaoteshi.<?php echo $host_top?>" target="_blank">乌兰浩特</a></strong>|</li>
                        <li><strong><a href="http://weihuishi.<?php echo $host_top?>" target="_blank">卫辉</a></strong>|</li>
                        <li><strong><a href="http://wuanshi.<?php echo $host_top?>" target="_blank">武安</a></strong>|</li>
                        <li><strong><a href="http://weinan.<?php echo $host_top?>" target="_blank">渭南</a></strong>|</li>
                        <li><strong><a href="http://wuxi.<?php echo $host_top?>" target="_blank">无锡</a></strong>|</li>
                        <li><strong><a href="http://wuhu.<?php echo $host_top?>" target="_blank">芜湖</a></strong>|</li>
                        <li><strong><a href="http://wugangshi2.<?php echo $host_top?>" target="_blank">武冈</a></strong></li>
                        <li class="char">X</li>
                        <li><strong><a href="http://xinghuashi.<?php echo $host_top?>" target="_blank">兴化</a></strong>|</li>
                        <li><strong><a href="http://xinminshi.<?php echo $host_top?>" target="_blank">新民</a></strong>|</li>
                        <li><strong><a href="http://xinjiang.<?php echo $host_top?>" target="_blank">新疆</a></strong>|</li>
                        <li><strong><a href="http://xinganqu.<?php echo $host_top?>" target="_blank">兴安</a></strong>|</li>
                        <li><strong><a href="http://xichengqu.<?php echo $host_top?>" target="_blank">西城</a></strong>|</li>
                        <li><strong><a href="http://xingchengshi.<?php echo $host_top?>" target="_blank">兴城</a></strong>|</li>
                        <li><strong><a href="http://xiangchengshi.<?php echo $host_top?>" target="_blank">项城</a></strong>|</li>
                        <li><strong><a href="http://xiaogan.<?php echo $host_top?>" target="_blank">孝感</a></strong>|</li>
                        <li><strong><a href="http://xintaishi.<?php echo $host_top?>" target="_blank">新泰</a></strong>|</li>
                        <li><strong><a href="http://xuancheng.<?php echo $host_top?>" target="_blank">宣城</a></strong>|</li>
                        <li><strong><a href="http://xuzhou.<?php echo $host_top?>" target="_blank">徐州</a></strong>|</li>
                        <li><strong><a href="http://xiangxiangshi.<?php echo $host_top?>" target="_blank">湘乡</a></strong>|</li>
                        <li><strong><a href="http://xianqu2.<?php echo $host_top?>" target="_blank">西安</a></strong>|</li>
                        <li><strong><a href="http://xinyu.<?php echo $host_top?>" target="_blank">新余</a></strong>|</li>
                        <li><strong><a href="http://xingningshi.<?php echo $host_top?>" target="_blank">兴宁</a></strong>|</li>
                        <li><strong><a href="http://xingyishi.<?php echo $host_top?>" target="_blank">兴义</a></strong>|</li>
                        <li><strong><a href="http://xingrenxian.<?php echo $host_top?>" target="_blank">兴仁</a></strong>|</li>
                        <li><strong><a href="http://xishuangbanna.<?php echo $host_top?>" target="_blank">西双版纳</a></strong>|</li>
                        <li><strong><a href="http://xingyangshi.<?php echo $host_top?>" target="_blank">荥阳</a></strong>|</li>
                        <li><strong><a href="http://xinmishi.<?php echo $host_top?>" target="_blank">新密</a></strong>|</li>
                        <li><strong><a href="http://xinzhengshi.<?php echo $host_top?>" target="_blank">新郑</a></strong>|</li>
                        <li><strong><a href="http://xinxiang.<?php echo $host_top?>" target="_blank">新乡</a></strong>|</li>
                        <li><strong><a href="http://xianning.<?php echo $host_top?>" target="_blank">咸宁</a></strong>|</li>
                        <li><strong><a href="http://xining.<?php echo $host_top?>" target="_blank">西宁</a></strong>|</li>
                        <li><strong><a href="http://xianyang.<?php echo $host_top?>" target="_blank">咸阳</a></strong>|</li>
                        <li><strong><a href="http://xinzhou.<?php echo $host_top?>" target="_blank">忻州</a></strong>|</li>
                        <li><strong><a href="http://xinyang.<?php echo $host_top?>" target="_blank">信阳</a></strong>|</li>
                        <li><strong><a href="http://xishiqu.<?php echo $host_top?>" target="_blank">西市</a></strong>|</li>
                        <li><strong><a href="http://xuchang.<?php echo $host_top?>" target="_blank">许昌</a></strong>|</li>
                        <li><strong><a href="http://xinshiqu.<?php echo $host_top?>" target="_blank">新市</a></strong>|</li>
                        <li><strong><a href="http://xichangshi.<?php echo $host_top?>" target="_blank">西昌</a></strong>|</li>
                        <li><strong><a href="http://xiaoyishi.<?php echo $host_top?>" target="_blank">孝义</a></strong>|</li>
                        <li><strong><a href="http://xinyishi2.<?php echo $host_top?>" target="_blank">新沂</a></strong>|</li>
                        <li><strong><a href="http://xinjishi.<?php echo $host_top?>" target="_blank">辛集</a></strong>|</li>
                        <li><strong><a href="http://xinleshi.<?php echo $host_top?>" target="_blank">新乐</a></strong>|</li>
                        <li><strong><a href="http://xinyishi.<?php echo $host_top?>" target="_blank">信宜</a></strong>|</li>
                        <li><strong><a href="http://xianggelilaxian.<?php echo $host_top?>" target="_blank">香格里拉</a></strong>|</li>
                        <li><strong><a href="http://xingpingshi.<?php echo $host_top?>" target="_blank">兴平</a></strong>|</li>
                        <li><strong><a href="http://xilinguoleimeng.<?php echo $host_top?>" target="_blank">锡林郭勒盟</a></strong>|</li>
                        <li><strong><a href="http://xilinhaoteshi.<?php echo $host_top?>" target="_blank">锡林浩特</a></strong>|</li>
                        <li><strong><a href="http://xingtai.<?php echo $host_top?>" target="_blank">邢台</a></strong>|</li>
                        <li><strong><a href="http://xiantao.<?php echo $host_top?>" target="_blank">仙桃</a></strong>|</li>
                        <li><strong><a href="http://xiangxi.<?php echo $host_top?>" target="_blank">湘西</a></strong>|</li>
                        <li><strong><a href="http://xuanweishi.<?php echo $host_top?>" target="_blank">宣威</a></strong>|</li>
                        <li><strong><a href="http://xiangtan.<?php echo $host_top?>" target="_blank">湘潭</a></strong>|</li>
                        <li><strong><a href="http://shamen.<?php echo $host_top?>" target="_blank">厦门</a></strong>|</li>
                        <li><strong><a href="http://xiangyangqu23.<?php echo $host_top?>" target="_blank">襄阳</a></strong></li>
                        <li class="char">Y</li>
                        <li><strong><a href="http://yuncheng.<?php echo $host_top?>" target="_blank">运城</a></strong>|</li>
                        <li><strong><a href="http://yueyang.<?php echo $host_top?>" target="_blank">岳阳</a></strong>|</li>
                        <li><strong><a href="http://yangquan.<?php echo $host_top?>" target="_blank">阳泉</a></strong>|</li>
                        <li><strong><a href="http://yibin.<?php echo $host_top?>" target="_blank">宜宾</a></strong>|</li>
                        <li><strong><a href="http://yanshishi.<?php echo $host_top?>" target="_blank">偃师</a></strong>|</li>
                        <li><strong><a href="http://yonganshi.<?php echo $host_top?>" target="_blank">永安</a></strong>|</li>
                        <li><strong><a href="http://yangshuoxian.<?php echo $host_top?>" target="_blank">阳朔</a></strong>|</li>
                        <li><strong><a href="http://yushushi.<?php echo $host_top?>" target="_blank">榆树</a></strong>|</li>
                        <li><strong><a href="http://yingdeshi.<?php echo $host_top?>" target="_blank">英德</a></strong>|</li>
                        <li><strong><a href="http://yuchengshi.<?php echo $host_top?>" target="_blank">禹城</a></strong>|</li>
                        <li><strong><a href="http://yixingshi.<?php echo $host_top?>" target="_blank">宜兴</a></strong>|</li>
                        <li><strong><a href="http://yiwu.<?php echo $host_top?>" target="_blank">义乌</a></strong>|</li>
                        <li><strong><a href="http://yongkangshi.<?php echo $host_top?>" target="_blank">永康</a></strong>|</li>
                        <li><strong><a href="http://yanan.<?php echo $host_top?>" target="_blank">延安</a></strong>|</li>
                        <li><strong><a href="http://yuyaoshi.<?php echo $host_top?>" target="_blank">余姚</a></strong>|</li>
                        <li><strong><a href="http://yichun.<?php echo $host_top?>" target="_blank">伊春</a></strong>|</li>
                        <li><strong><a href="http://yiyang.<?php echo $host_top?>" target="_blank">益阳</a></strong>|</li>
                        <li><strong><a href="http://yaan.<?php echo $host_top?>" target="_blank">雅安</a></strong>|</li>
                        <li><strong><a href="http://yizhengshi.<?php echo $host_top?>" target="_blank">仪征</a></strong>|</li>
                        <li><strong><a href="http://yichengshi.<?php echo $host_top?>" target="_blank">宜城</a></strong>|</li>
                        <li><strong><a href="http://yunnan.<?php echo $host_top?>" target="_blank">云南</a></strong>|</li>
                        <li><strong><a href="http://yongjishi.<?php echo $host_top?>" target="_blank">永济</a></strong>|</li>
                        <li><strong><a href="http://yulin.<?php echo $host_top?>" target="_blank">玉林</a></strong>|</li>
                        <li><strong><a href="http://yongchengshi.<?php echo $host_top?>" target="_blank">永城</a></strong>|</li>
                        <li><strong><a href="http://yangjiang.<?php echo $host_top?>" target="_blank">阳江</a></strong>|</li>
                        <li><strong><a href="http://yinchuan.<?php echo $host_top?>" target="_blank">银川</a></strong>|</li>
                        <li><strong><a href="http://yingkou.<?php echo $host_top?>" target="_blank">营口</a></strong>|</li>
                        <li><strong><a href="http://yunfu.<?php echo $host_top?>" target="_blank">云浮</a></strong>|</li>
                        <li><strong><a href="http://yingchengshi.<?php echo $host_top?>" target="_blank">应城</a></strong>|</li>
                        <li><strong><a href="http://yushuxian.<?php echo $host_top?>" target="_blank">玉树</a></strong>|</li>
                        <li><strong><a href="http://yanzhoushi.<?php echo $host_top?>" target="_blank">兖州</a></strong>|</li>
                        <li><strong><a href="http://yizhoushi.<?php echo $host_top?>" target="_blank">宜州</a></strong>|</li>
                        <li><strong><a href="http://yancheng.<?php echo $host_top?>" target="_blank">盐城</a></strong>|</li>
                        <li><strong><a href="http://yuanjiangshi.<?php echo $host_top?>" target="_blank">沅江</a></strong>|</li>
                        <li><strong><a href="http://leqingshi.<?php echo $host_top?>" target="_blank">乐清</a></strong>|</li>
                        <li><strong><a href="http://yimashi.<?php echo $host_top?>" target="_blank">义马</a></strong>|</li>
                        <li><strong><a href="http://yichang.<?php echo $host_top?>" target="_blank">宜昌</a></strong>|</li>
                        <li><strong><a href="http://yingtan.<?php echo $host_top?>" target="_blank">鹰潭</a></strong>|</li>
                        <li><strong><a href="http://yangzhongshi.<?php echo $host_top?>" target="_blank">扬中</a></strong>|</li>
                        <li><strong><a href="http://yantai.<?php echo $host_top?>" target="_blank">烟台</a></strong>|</li>
                        <li><strong><a href="http://yiningshi.<?php echo $host_top?>" target="_blank">伊宁</a></strong>|</li>
                        <li><strong><a href="http://yuanpingshi.<?php echo $host_top?>" target="_blank">原平</a></strong>|</li>
                        <li><strong><a href="http://yumenshi.<?php echo $host_top?>" target="_blank">玉门</a></strong>|</li>
                        <li><strong><a href="http://yangchunshi.<?php echo $host_top?>" target="_blank">阳春</a></strong>|</li>
                        <li><strong><a href="http://yanbian.<?php echo $host_top?>" target="_blank">延边</a></strong>|</li>
                        <li><strong><a href="http://yanjishi.<?php echo $host_top?>" target="_blank">延吉</a></strong>|</li>
                        <li><strong><a href="http://yichun2.<?php echo $host_top?>" target="_blank">宜春</a></strong>|</li>
                        <li><strong><a href="http://yuzhoushi.<?php echo $host_top?>" target="_blank">禹州</a></strong>|</li>
                        <li><strong><a href="http://yuxi.<?php echo $host_top?>" target="_blank">玉溪</a></strong>|</li>
                        <li><strong><a href="http://yidoushi.<?php echo $host_top?>" target="_blank">宜都</a></strong>|</li>
                        <li><strong><a href="http://yangzhou.<?php echo $host_top?>" target="_blank">扬州</a></strong>|</li>
                        <li><strong><a href="http://yulin2.<?php echo $host_top?>" target="_blank">榆林</a></strong>|</li>
                        <li><strong><a href="http://yongzhou.<?php echo $host_top?>" target="_blank">永州</a></strong>|</li>
                        <li><strong><a href="http://yakeshishi.<?php echo $host_top?>" target="_blank">牙克石</a></strong></li>
                        <li class="char">Z</li>
                        <li><strong><a href="http://ziyang.<?php echo $host_top?>" target="_blank">资阳</a></strong>|</li>
                        <li><strong><a href="http://zhejiang.<?php echo $host_top?>" target="_blank">浙江</a></strong>|</li>
                        <li><strong><a href="http://zhongxiangshi.<?php echo $host_top?>" target="_blank">钟祥</a></strong>|</li>
                        <li><strong><a href="http://zhangshushi.<?php echo $host_top?>" target="_blank">樟树</a></strong>|</li>
                        <li><strong><a href="http://zhumadian.<?php echo $host_top?>" target="_blank">驻马店</a></strong>|</li>
                        <li><strong><a href="http://zengchengqu.<?php echo $host_top?>" target="_blank">增城</a></strong>|</li>
                        <li><strong><a href="http://zhangjiagangshi.<?php echo $host_top?>" target="_blank">张家港</a></strong>|</li>
                        <li><strong><a href="http://zaoyangshi.<?php echo $host_top?>" target="_blank">枣阳</a></strong>|</li>
                        <li><strong><a href="http://zhenjiang.<?php echo $host_top?>" target="_blank">镇江</a></strong>|</li>
                        <li><strong><a href="http://zhuhai.<?php echo $host_top?>" target="_blank">珠海</a></strong>|</li>
                        <li><strong><a href="http://zigong.<?php echo $host_top?>" target="_blank">自贡</a></strong>|</li>
                        <li><strong><a href="http://zhuchengshi.<?php echo $host_top?>" target="_blank">诸城</a></strong>|</li>
                        <li><strong><a href="http://zhuangheshi.<?php echo $host_top?>" target="_blank">庄河</a></strong>|</li>
                        <li><strong><a href="http://zunyi.<?php echo $host_top?>" target="_blank">遵义</a></strong>|</li>
                        <li><strong><a href="http://zhaoqing.<?php echo $host_top?>" target="_blank">肇庆</a></strong>|</li>
                        <li><strong><a href="http://zhaodongshi.<?php echo $host_top?>" target="_blank">肇东</a></strong>|</li>
                        <li><strong><a href="http://zhuzhou.<?php echo $host_top?>" target="_blank">株洲</a></strong>|</li>
                        <li><strong><a href="http://zhuozhoushi.<?php echo $host_top?>" target="_blank">涿州</a></strong>|</li>
                        <li><strong><a href="http://zibo.<?php echo $host_top?>" target="_blank">淄博</a></strong>|</li>
                        <li><strong><a href="http://zhangzhou.<?php echo $host_top?>" target="_blank">漳州</a></strong>|</li>
                        <li><strong><a href="http://zhangjiakou.<?php echo $host_top?>" target="_blank">张家口</a></strong>|</li>
                        <li><strong><a href="http://zhongshan.<?php echo $host_top?>" target="_blank">中山</a></strong>|</li>
                        <li><strong><a href="http://zhoushan.<?php echo $host_top?>" target="_blank">舟山</a></strong>|</li>
                        <li><strong><a href="http://zhangye.<?php echo $host_top?>" target="_blank">张掖</a></strong>|</li>
                        <li><strong><a href="http://zhangpingshi.<?php echo $host_top?>" target="_blank">漳平</a></strong>|</li>
                        <li><strong><a href="http://zhaotong.<?php echo $host_top?>" target="_blank">昭通</a></strong>|</li>
                        <li><strong><a href="http://zhujishi.<?php echo $host_top?>" target="_blank">诸暨</a></strong>|</li>
                        <li><strong><a href="http://zhangqiushi.<?php echo $host_top?>" target="_blank">章丘</a></strong>|</li>
                        <li><strong><a href="http://zouchengshi.<?php echo $host_top?>" target="_blank">邹城</a></strong>|</li>
                        <li><strong><a href="http://zhoukou.<?php echo $host_top?>" target="_blank">周口</a></strong>|</li>
                        <li><strong><a href="http://zhangjiajie.<?php echo $host_top?>" target="_blank">张家界</a></strong>|</li>
                        <li><strong><a href="http://zaozhuang.<?php echo $host_top?>" target="_blank">枣庄</a></strong>|</li>
                        <li><strong><a href="http://zhanjiang.<?php echo $host_top?>" target="_blank">湛江</a></strong>|</li>
                        <li><strong><a href="http://zoupingxian.<?php echo $host_top?>" target="_blank">邹平</a></strong>|</li>
                        <li><strong><a href="http://zhijiangshi.<?php echo $host_top?>" target="_blank">枝江</a></strong>|</li>
                        <li><strong><a href="http://zixingshi.<?php echo $host_top?>" target="_blank">资兴</a></strong>|</li>
                        <li><strong><a href="http://zunhuashi.<?php echo $host_top?>" target="_blank">遵化</a></strong>|</li>
                        <li><strong><a href="http://zhengzhou.<?php echo $host_top?>" target="_blank">郑州</a></strong>|</li>
                        <li><strong><a href="http://zhongwei.<?php echo $host_top?>" target="_blank">中卫</a></strong>|</li>
                        <li><strong><a href="http://zhaoyuanshi.<?php echo $host_top?>" target="_blank">招远</a></strong>|</li>
                        <li><strong><a href="http://zhalantunshi.<?php echo $host_top?>" target="_blank">扎兰屯</a></strong></li>
                        <li class="char">@</li>
                        <?php echo LoadTmplContent('friend_2', 'frd0xvxs', 31536000, false, true)?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- 企业-->
    <div class="fz_index_tit">
        <ul class="fz_index_titlist">
            <li class="fz_index_titlist_cur fzcomnav fzhotcomnav" onclick="fz_index_show('hot','com');"><a>名企招聘<i class="fz_index_titlist_line"></i></a></li>
            <li class="fzcomnav fzrzcomnav" onclick="fz_index_show('rz','com');"><a>认证企业<i class="fz_index_titlist_line"></i></a></li>
            <li class="fzcomnav fznewcomnav" onclick="fz_index_show('new','com');"><a>最新企业<i class="fz_index_titlist_line"></i></a></li>
        </ul>
    </div>
    <div class="fz_index_jobbox">
        <ul class="fz_index_comlist hotcom">
            <?php echo LoadTmplContent('com_list_x', 'cl011', 432000, false, true)?>
        </ul>
        <ul class="fz_index_comlist rzcom none">
            <?php echo LoadTmplContent('com_list_x', 'cl012', 604800, false, true)?>
        </ul>
        <ul class="fz_index_comlist newcom none">
            <?php echo LoadTmplContent('com_list_x', 'cl013', 777600, false, true)?>
        </ul>
        <div class="fz_look_more_box"><span class="fz_look_more">查看更多企业</span></div>
    </div>

    <!-- 职位-->
    <div class="fz_index_tit">
        <ul class="fz_index_titlist">
            <li class="fz_index_titlist_cur fzjobnav fzhotjobnav" onclick="fz_index_show('hot','job');"><a>热门职位<i class="fz_index_titlist_line"></i></a></li>
            <li class=" fzjobnav fzrecjobnav" onclick="fz_index_show('rec','job');"><a>紧急职位<i class="fz_index_titlist_line"></i></a></li>
            <li class=" fzjobnav fznewjobnav" onclick="fz_index_show('new','job');"><a>最新职位<i class="fz_index_titlist_line"></i></a></li>
        </ul>
    </div>
    <div class="fz_index_jobbox">
        <ul class="fz_index_joblist  hotjob">
            <?php echo LoadTmplContent('job_list_x', 'jl011', 518400, false, true)?>
        </ul>
        <ul class="fz_index_joblist recjob none">
            <?php echo LoadTmplContent('job_list_x', 'jl012', 691200, false, true)?>
        </ul>
        <ul class="fz_index_joblist newjob none">
            <?php echo LoadTmplContent('job_list_x', 'jl013', 864000, false, true)?>
        </ul>
        <div class="fz_look_more_box"><span class="fz_look_more">查看更多职位</span></div>
    </div>

    <div class="index_zl_box">
        <div class="new_index_tit">
            <span class="new_index_tit_list new_index_tit_cur">友情链接<i class="new_index_tit_line"></i></span>
        </div>
        <div class="index_link_box fl">
            <div class="golang friend friend repeat"></div>
        </div>
    </div>
</div>


<div id="bg"></div>
<script>
    function goTopEx(){
        var obj=document.getElementById("goTopBtn");
        function getScrollTop(){
            return document.documentElement.scrollTop;
        }
        function setScrollTop(value){
            document.documentElement.scrollTop=value;
        }
        window.onscroll=function(){getScrollTop()>0?obj.style.display="":obj.style.display="none";}
        obj.onclick=function(){
            var goTop=setInterval(scrollMove,10);
            function scrollMove(){
                setScrollTop(getScrollTop()/1.1);
                if(getScrollTop()<1)clearInterval(goTop);
            }
        }
    }
</script>
<div class="clear"></div>
<div id="goTopBtn" class="png none" ><img  border=0 src="http://www.<?php echo $host_top?>/images/lanren_top.png" class="png"></div>
<script type=text/javascript>goTopEx();</script>
<style>
    #goTopBtn {
        POSITION: fixed;
        TEXT-ALIGN: center;
        WIDTH: 47px;
        BOTTOM:3px;
        HEIGHT: 78px;
        FONT-SIZE: 12px;
        CURSOR: pointer;
        RIGHT:  40px;
        _position: absolute;
        _right: 40;
        _position:absolute;
        _bottom:auto;
        _top:expression(eval(document.documentElement.scrollTop+document.documentElement.clientHeight-this.offsetHeight-(parseInt(this.currentStyle.marginTop,10)||15)-(parseInt(this.currentStyle.marginBottom,10)||15)));
        _background:url(http://www.<?php echo $host_top?>/app/template/default/images/lanren_top.png) no-repeat
    }
    *html{
        background-image:url(about:blank);
        background-attachment:fixed;
    }
</style>
</div>
<script src="https://cdn.bootcdn.net/ajax/libs/jquery/1.8.1/jquery.min.js" language="javascript"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layui/2.6.8/layui.min.js"></script>
<script src="http://<?php echo $host_domain?>/js/public.js" language="javascript"></script>
<script src="http://<?php echo $host_domain?>/js/index.js" language="javascript"></script>
<script src="http://<?php echo $host_domain?>/js/reg_ajax.js" type="text/javascript"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/slidesjs/3.0/jquery.slides.min.js" type="text/javascript"></script>
<script src="http://<?php echo $host_domain?>/js/phpyun_layer.js"></script>

<script type="text/javascript">
    layui.use(['carousel', 'flow'], function () {//layui 轮播  test1 test2
        var carousel = layui.carousel;
        var flow = layui.flow;
        flow.lazyimg();
        carousel.render({
            elem: '#test1',
            width: '850px',
            height: '350px'
        });

        carousel.render({
            elem: '#test2',
            width: '290px',
            height: '190px',
            indicator: 'none'//指示器属性；隐藏：none，容器内部：inside，容器外部：outside；
        });
    });

</script>
<script>
    var weburl="http://www.<?php echo $host_top?>",
        user_sqintegrity="60",
        integral_pricename='积分',
        pricename='积分',
        code_web='注册会员,前台登录,店铺招聘,职场提问',
        code_kind='1';
</script>

<div class="hp_foot fl">
    <div class="w1000">
        <div class="hp_foot_wt fl">
            <div class="hp_foot_pho fl">
                <dl>
                    <dt></dt>
                    <dd>客服服务热线</dd>
                    <dd class="hp_foot_pho_nmb"><?php echo $tit?></dd>
                    <dd></dd>
                </dl>
            </div>
            <div class="hp_foot_wh fl">
                <i class="hp_foot_wh_lline"></i>
                <i class="hp_foot_wh_rline"></i>
                <dl>
                    <dt>关于我们</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="关于我们">关于我们</a></li>
                            <li><a href="javascript:" title="注册协议">注册协议</a></li>
                            <li><a href="javascript:" title="法律声明">法律声明</a></li>
                            <li><a href="javascript:" title="经营资源">经营资源</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>产品与服务</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="招聘会">招聘会</a></li>
                            <li><a href="javascript:" title="店铺招聘">店铺招聘</a></li>
                            <li><a href="javascript:" title="普工专区">普工专区</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>收费与推广</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="银行帐户">银行帐户</a></li>
                            <li><a href="javascript:" title="品牌推广">品牌推广</a></li>
                            <li><a href="javascript:" title="收费标准">收费标准</a></li>
                            <li><a href="javascript:" title="广告投放">广告投放</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>网站特色</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="排行榜">排行榜</a></li>
                            <li><a href="javascript:" title="求职测评">求职测评</a></li>
                            <li><a href="javascript:" title="地图搜索">地图搜索</a></li>
                            <li><a href="javascript:" title="订阅服务">订阅服务</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>咨询反馈</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="客服中心">客服中心</a></li>
                            <li><a href="javascript:" title="常见问题">常见问题</a></li>
                            <li><a href="javascript:" title="友情链接">友情链接</a></li>
                            <li><a href="javascript:" title="职场指南">职场指南</a></li>
                        </ul>
                    </dd>
                </dl>
            </div>
        </div>
    </div>
    <div class="clear"></div>
    <div class="hp_foot_bt">
        <div class="hp_foot_bt_c">
            <p><?php echo $tit?> Copyright C 20092014 All Rights Reserved 版权所有 鑫潮人力资源服务 <i class="hp_foot_bt_cr">
                </i></p>
            <p>地址： EMAIL：admin@admin.com</p>
            <p>Powered by PHPYun.</p>
            <div style="color:#999">
            <?php echo LoadTmplContent('footer_rand', '', 0, false, false)?>
            </div>
        </div>
    </div>
</div>

<div class="go-top dn" id="go-top">
    <a href="javascript:;" class="go"></a>
</div>

<div class="clear"></div>
<div id="uclogin"></div>

<script>
    function fz_index_show(type, utype) {
        $(".fz" + utype + "nav").removeClass('fz_index_titlist_cur');
        $(".fz" + type + utype + "nav").addClass('fz_index_titlist_cur');
        $(".fz_index_" + utype + "list").hide();
        $("." + type + utype).show();
    }
    $(function(){
        $(window).on('scroll',function(){
            var st = $(document).scrollTop();
            if( st>0 ){
                if( $('#main-container').length != 0  ){
                    var w = $(window).width(),mw = $('#main-container').width();
                    if( (w-mw)/2 > 70 )
                        $('#go-top').css({'left':(w-mw)/2+mw+20});
                    else{
                        $('#go-top').css({'left':'auto'});
                    }
                }
                $('#go-top').fadeIn(function(){
                    $(this).removeClass('dn');
                });
            }else{
                $('#go-top').fadeOut(function(){
                    $(this).addClass('dn');
                });
            }
        });
        $('#go-top .go').on('click',function(){
            $('html,body').animate({'scrollTop':0},500);
        });

        $('#go-top .uc-2vm').hover(function(){
            $('#go-top .uc-2vm-pop').removeClass('dn');
        },function(){
            $('#go-top .uc-2vm-pop').addClass('dn');
        });

        //获取分站信息
        if($('#substation_city_id').length == 1){
            var indexdirurl = '';

            if($('#indexdir').val()!=''){
                indexdirurl = '&indexdir='+$('#indexdir').val();
            }
            $.get(weburl+"/index.php?m=ajax&c=Site&type=ajax"+indexdirurl,function(data){
                $('#substation_city_id').html(data);
            });
        }
    });
</script>
</body>
</html>
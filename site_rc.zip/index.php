<?php

include_once('inc.func.php');

header('Access-Control-Allow-Origin: *');

if (isset($_GET['m']) === true && $_GET['m'] === 'cron') {
    exit;
}

//m=ajax&c=Site&type=ajax
if (isset($_GET['m'], $_GET['c'], $_GET['type']) === true && $_GET['m'] === 'ajax' && $_GET['c'] === 'Site' && $_GET['type'] === 'ajax') {
    exit('<span class="hp_head_ft_city_x">全国站</span><span class="hp_head_ft_city_qh">【切换城市】</span>');
}

$host_top = HostTop();
$host_domain = $_SERVER['HTTP_HOST'];
$host_name = '';
if ($host_top != $host_domain) {
    $host_name = str_replace($host_top, '', $host_domain);
    $host_name = rtrim($host_name, '.');
}

// web name
$web_name = StoreGet('web_name1', true);
if ($web_name === '') {
    $web_name = RandWord('cy')[0] . RandWord('hy')[0] . '人才招聘网';
    StoreSet('web_name1', $web_name);
}

// title
$key = 'tit1-' . md5($_SERVER['REQUEST_URI']);
$tit = StoreGet($key);
if ($tit === '') {
    if ($host_name === '' || $host_name === 'www') {
        if ($_SERVER['REQUEST_URI'] == "/" || $_SERVER['REQUEST_URI'] == "") {
            $tit = $web_name;
        } else {
            $tit = RandWord('company')[0] . $web_name;
        }
    } else {
        $search = [];
        foreach (SearchKV('domain_all', $host_name . '.x.com') as $val) {
            $search = $val;
        }
        if (count($search) === 0) {
            $tit = RandWord('company')[0] . $web_name;
        } else {
            $search = explode(' ', $search[0]);
            $tit = $search[2] . $web_name;
        }
    }
    StoreSet($key, $tit);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
    <meta name="keywords" content="<?php echo $tit?>"/>
    <meta name="description" content="<?php echo $tit?>"/>
    <link href="http://<?php echo $host_domain?>/css/index.css" rel="stylesheet" type="text/css"/>
    <link href="http://<?php echo $host_domain?>/css/css.css" rel="stylesheet" type="text/css"/>
    <link href="http://<?php echo $host_domain?>/css/layui.css" rel="stylesheet" type="text/css"/>
    <title><?php echo $tit?></title>
    <style type="text/css">
        #footer {margin-bottom: 50px;padding-top: 5px; text-align: center; line-height: 2em;}
        #footer .footerFuncCity {width: 98%;padding-top: 20px;padding-bottom: 20px;}
        #footer .footerFuncCity ul li a {color: #666;}
        .clearfix {zoom: 1; display: block;}
        .footerFuncCity{margin: 0 auto; width: 950px; padding: 20px;}
        .footerFuncCity .char {color: #1787FB; font: bold 14px/20px "arial"; margin-left: 8px;}
        .footerFuncCity li {height: 30px;}
        .footerFuncCity li {float: left; color: #b0b0b0; height: 20px; line-height: 20px; white-space: nowrap; padding: 5px 0px; font-size: 14px;}
        .footerFuncCity strong{font-style: normal; font-weight: 400;}
        .footerFuncCity a {outline: none; padding: 0 8px; color: #2A2A2A; font-family: Microsoft YaHei;}
    </style>
</head>

<body class="body_bg">
<div class="yun_new_top">
    <div class="yun_new_cont">
        <div class="yun_new_left">
            <span class="fl">
              <span class="yun_new_left_city" id="substation_city_id">
                <span class="hp_head_ft_city_x">全国站</span>
                <span class="hp_head_ft_city_qh">【<a href="http://<?php echo $host_domain?>/">切换城市</a>】</span>
              </span>
              <input type="hidden" id="indexdir" value="">
            </span>
        </div>
        <div class="yun_new_right" id="login_head_div">
            <span class="yun_new_right_we"><a href="http://<?php echo $host_top?>"><?php echo $tit?>欢迎您！</a></span>
        </div>
    </div>
</div>
<!--top end-->
<div class="hp_head hp_head_box">
    <div class="w1200">
        <div class="hp_head_ft fl">
            <div class="phpyun_logo fl">
                <a href="http://www.<?php echo $host_top?>" title="<?php echo $tit?>最新招聘求职信息">
                    <img src="http://<?php echo $host_domain?>/css/logo.png" alt="<?php echo $tit?>" />
                </a>
            </div>
        </div>
        <div class="yun_header_nav_box">
            <ul>
                <li>
                    <a href="http://<?php echo $host_top?>">首页</a>
                    <i class="yun_new_headernav_list_line"></i>
                </li>
                <?php echo LoadTmplContent('top', 'top_navs_v1', 2592000, true, true)?>
            </ul>
        </div>
    </div>
</div>
<!-- 分站首页-->
<div class="w1200">
    <div class="clear"></div>
    <!-- 搜索-->
    <div class="fz_index_search">
        <form action="http://job.<?php echo $host_top?>/"
              method="get" onsubmit="return search_keyword(this);" id="index_search_form">
            <input type="hidden"  value="job" id="m" />
            <input type="hidden" name="c" value="search" id="search"/>

            <div class="fz_index_search_select">
                <span class="" id="search_name">职位</span>
                <div class="yunHeaderSearch_list_box fz_index_search_select_box none">
                    <a href="javascript:void(0)"
                       onclick="top_search('job', '找工作', 'http://job.<?php echo $host_top?>/', '1', 'job'); $('#search').attr('name', 'c');">找工作</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('resume', '找人才', 'http://resume.<?php echo $host_top?>/', '1', 'resume'); $('#search').attr('name', 'c');">
                        找人才</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('tiny', '普工简历', 'http://tiny.<?php echo $host_top?>/', '1', 'tiny'); $('#search').attr('name', '');">普工简历</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('article', '新闻', 'http://article.<?php echo $host_top?>/', '1', 'article');"
                       class="none">新闻</a>
                    <a href="javascript:void(0)"
                       onclick="top_search('once', '店铺招聘', 'http://once.<?php echo $host_top?>/', '1', 'once'); $('#search').attr('name', '');">店铺招聘</a>
                </div>
            </div>
            <div class="fz_index_search_textbox">
                <input class="fz_index_search_text" type="text" name="keyword" value="" placeholder="请输入职位关键词，如：java ,销售代表，行政助理等">
            </div>
            <input class="fz_index_search_bth" type="submit" value="搜索"/>
        </form>

    </div>
    <div class="fz_index_tag">热门搜索：
    </div>
    <div class="clear"></div>

    <!-- 幻灯片-->
    <div class="fz_hd">
        <div class="" id="ban">
            <div class="layui-carousel" id="test1" lay-filter="test1">
                <div carousel-item="">
                    <span><img src='/images/14970247553.jpg'></span>
                    <span><img src='/images/14992057095.png'></span>
                </div>
            </div>
        </div>
    </div>
    <div class="clear"></div>

    <!-- 职场资讯-->
    <div class="index_zl_box">
        <div class="new_index_tit">
            <span class="new_index_tit_list new_index_tit_cur"><?php echo $tit?><i class="new_index_tit_line"></i></span>
        </div>
        <div style="padding-top: 30px; padding-left: 15px;">
            <?php echo $tit?>是为广大用户提供最新人才招聘信息的网站。找工作的你，招聘人才的企业信息供您选择，<?php echo LoadTmplContent('body', 'body_news', 2592000, false, false)?>每天都有各类人才招聘信息更新，我们都会审核有效性，欢迎您使用<?php echo $tit?>。

        </div>
    </div>

    <!-- 企业-->
    <div class="fz_index_tit">
        <ul class="fz_index_titlist">
            <li class="fz_index_titlist_cur fzcomnav fzhotcomnav" onclick="fz_index_show('hot','com');"><a>名企招聘<i class="fz_index_titlist_line"></i></a></li>
            <li class="fzcomnav fzrzcomnav" onclick="fz_index_show('rz','com');"><a>认证企业<i class="fz_index_titlist_line"></i></a></li>
            <li class="fzcomnav fznewcomnav" onclick="fz_index_show('new','com');"><a>最新企业<i class="fz_index_titlist_line"></i></a></li>
        </ul>
    </div>
    <div class="fz_index_jobbox">
        <ul class="fz_index_comlist hotcom">
            <?php echo LoadTmplContent('com_list_x', 'cl011', 432000, false, true)?>
        </ul>
        <ul class="fz_index_comlist rzcom none">
            <?php echo LoadTmplContent('com_list_x', 'cl012', 604800, false, true)?>
        </ul>
        <ul class="fz_index_comlist newcom none">
            <?php echo LoadTmplContent('com_list_x', 'cl013', 777600, false, true)?>
        </ul>
        <div class="fz_look_more_box"><span class="fz_look_more">查看更多企业</span></div>
    </div>

    <!-- 职位-->
    <div class="fz_index_tit">
        <ul class="fz_index_titlist">
            <li class="fz_index_titlist_cur fzjobnav fzhotjobnav" onclick="fz_index_show('hot','job');"><a>热门职位<i class="fz_index_titlist_line"></i></a></li>
            <li class=" fzjobnav fzrecjobnav" onclick="fz_index_show('rec','job');"><a>紧急职位<i class="fz_index_titlist_line"></i></a></li>
            <li class=" fzjobnav fznewjobnav" onclick="fz_index_show('new','job');"><a>最新职位<i class="fz_index_titlist_line"></i></a></li>
        </ul>
    </div>
    <div class="fz_index_jobbox">
        <ul class="fz_index_joblist  hotjob">
            <?php echo LoadTmplContent('job_list_x', 'jl011', 518400, false, true)?>
        </ul>
        <ul class="fz_index_joblist recjob none">
            <?php echo LoadTmplContent('job_list_x', 'jl012', 691200, false, true)?>
        </ul>
        <ul class="fz_index_joblist newjob none">
            <?php echo LoadTmplContent('job_list_x', 'jl013', 864000, false, true)?>
        </ul>
        <div class="fz_look_more_box"><span class="fz_look_more">查看更多职位</span></div>
    </div>

    <div class="index_zl_box">
        <div class="new_index_tit">
            <span class="new_index_tit_list new_index_tit_cur"><?php echo $tit?>区分站<i class="new_index_tit_line"></i></span>
            <a href="http://www.<?php echo $host_top?>/" class="new_index_tit_more">查看更多</a>
        </div>
        <div class="index_link_box fl">
            <div id="footer">
                <div class="footerFuncCity clearfix">
                    <ul>
                        <?php echo LoadTmplContent('friend_2_rc', 'fr_2_rc_001', 31500000, false, false)?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="index_zl_box">
        <div class="new_index_tit">
            <span class="new_index_tit_list new_index_tit_cur">友情链接<i class="new_index_tit_line"></i></span>
        </div>
        <div class="index_link_box fl">
            <div class="golang friend friend repeat"></div>
        </div>
    </div>
</div>


<div id="bg"></div>
<script>
    function goTopEx(){
        var obj=document.getElementById("goTopBtn");
        function getScrollTop(){
            return document.documentElement.scrollTop;
        }
        function setScrollTop(value){
            document.documentElement.scrollTop=value;
        }
        window.onscroll=function(){getScrollTop()>0?obj.style.display="":obj.style.display="none";}
        obj.onclick=function(){
            var goTop=setInterval(scrollMove,10);
            function scrollMove(){
                setScrollTop(getScrollTop()/1.1);
                if(getScrollTop()<1)clearInterval(goTop);
            }
        }
    }
</script>
<div class="clear"></div>
<div id="goTopBtn" class="png none" ><img  border=0 src="http://www.<?php echo $host_top?>/images/lanren_top.png" class="png"></div>
<script type=text/javascript>goTopEx();</script>
<style>
    #goTopBtn {
        POSITION: fixed;
        TEXT-ALIGN: center;
        WIDTH: 47px;
        BOTTOM:3px;
        HEIGHT: 78px;
        FONT-SIZE: 12px;
        CURSOR: pointer;
        RIGHT:  40px;
        _position: absolute;
        _right: 40;
        _position:absolute;
        _bottom:auto;
        _top:expression(eval(document.documentElement.scrollTop+document.documentElement.clientHeight-this.offsetHeight-(parseInt(this.currentStyle.marginTop,10)||15)-(parseInt(this.currentStyle.marginBottom,10)||15)));
        _background:url(http://www.<?php echo $host_top?>/app/template/default/images/lanren_top.png) no-repeat
    }
    *html{
        background-image:url(about:blank);
        background-attachment:fixed;
    }
</style>
</div>
<script src="https://cdn.bootcdn.net/ajax/libs/jquery/1.8.1/jquery.min.js" language="javascript"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/layui/2.6.8/layui.min.js"></script>
<script src="http://<?php echo $host_domain?>/js/public.js" language="javascript"></script>
<script src="http://<?php echo $host_domain?>/js/index.js" language="javascript"></script>
<script src="http://<?php echo $host_domain?>/js/reg_ajax.js" type="text/javascript"></script>
<script src="https://cdn.bootcdn.net/ajax/libs/slidesjs/3.0/jquery.slides.min.js" type="text/javascript"></script>
<script src="http://<?php echo $host_domain?>/js/phpyun_layer.js"></script>

<script type="text/javascript">
    layui.use(['carousel', 'flow'], function () {//layui 轮播  test1 test2
        var carousel = layui.carousel;
        var flow = layui.flow;
        flow.lazyimg();
        carousel.render({
            elem: '#test1',
            width: '850px',
            height: '350px'
        });

        carousel.render({
            elem: '#test2',
            width: '290px',
            height: '190px',
            indicator: 'none'//指示器属性；隐藏：none，容器内部：inside，容器外部：outside；
        });
    });

</script>
<script>
    var weburl="http://www.<?php echo $host_top?>",
        user_sqintegrity="60",
        integral_pricename='积分',
        pricename='积分',
        code_web='注册会员,前台登录,店铺招聘,职场提问',
        code_kind='1';
</script>

<div class="hp_foot fl">
    <div class="w1000">
        <div class="hp_foot_wt fl">
            <div class="hp_foot_pho fl">
                <dl>
                    <dt></dt>
                    <dd>客服服务热线</dd>
                    <dd class="hp_foot_pho_nmb"><?php echo $tit?></dd>
                    <dd></dd>
                </dl>
            </div>
            <div class="hp_foot_wh fl">
                <i class="hp_foot_wh_lline"></i>
                <i class="hp_foot_wh_rline"></i>
                <dl>
                    <dt>关于我们</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="关于我们">关于我们</a></li>
                            <li><a href="javascript:" title="注册协议">注册协议</a></li>
                            <li><a href="javascript:" title="法律声明">法律声明</a></li>
                            <li><a href="javascript:" title="经营资源">经营资源</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>产品与服务</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="招聘会">招聘会</a></li>
                            <li><a href="javascript:" title="店铺招聘">店铺招聘</a></li>
                            <li><a href="javascript:" title="普工专区">普工专区</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>收费与推广</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="银行帐户">银行帐户</a></li>
                            <li><a href="javascript:" title="品牌推广">品牌推广</a></li>
                            <li><a href="javascript:" title="收费标准">收费标准</a></li>
                            <li><a href="javascript:" title="广告投放">广告投放</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>网站特色</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="排行榜">排行榜</a></li>
                            <li><a href="javascript:" title="求职测评">求职测评</a></li>
                            <li><a href="javascript:" title="地图搜索">地图搜索</a></li>
                            <li><a href="javascript:" title="订阅服务">订阅服务</a></li>
                        </ul>
                    </dd>
                </dl>
                <dl>
                    <dt>咨询反馈</dt>
                    <dd>
                        <ul>
                            <li><a href="javascript:" title="客服中心">客服中心</a></li>
                            <li><a href="javascript:" title="常见问题">常见问题</a></li>
                            <li><a href="javascript:" title="友情链接">友情链接</a></li>
                            <li><a href="javascript:" title="职场指南">职场指南</a></li>
                        </ul>
                    </dd>
                </dl>
            </div>
        </div>
    </div>
    <div class="clear"></div>
    <div class="hp_foot_bt">
        <div class="hp_foot_bt_c">
            <p><?php echo $tit?> Copyright C 20092014 All Rights Reserved 版权所有 鑫潮人力资源服务 <i class="hp_foot_bt_cr">
                </i></p>
            <p>地址： EMAIL：admin@admin.com</p>
            <p>				</p>
            <p>Powered by PHPYun.</p>
        </div>
    </div>
</div>

<div class="go-top dn" id="go-top">
    <a href="javascript:;" class="go"></a>
</div>

<div class="clear"></div>
<div id="uclogin"></div>

<script>
    function fz_index_show(type, utype) {
        $(".fz" + utype + "nav").removeClass('fz_index_titlist_cur');
        $(".fz" + type + utype + "nav").addClass('fz_index_titlist_cur');
        $(".fz_index_" + utype + "list").hide();
        $("." + type + utype).show();
    }
    $(function(){
        $(window).on('scroll',function(){
            var st = $(document).scrollTop();
            if( st>0 ){
                if( $('#main-container').length != 0  ){
                    var w = $(window).width(),mw = $('#main-container').width();
                    if( (w-mw)/2 > 70 )
                        $('#go-top').css({'left':(w-mw)/2+mw+20});
                    else{
                        $('#go-top').css({'left':'auto'});
                    }
                }
                $('#go-top').fadeIn(function(){
                    $(this).removeClass('dn');
                });
            }else{
                $('#go-top').fadeOut(function(){
                    $(this).addClass('dn');
                });
            }
        });
        $('#go-top .go').on('click',function(){
            $('html,body').animate({'scrollTop':0},500);
        });

        $('#go-top .uc-2vm').hover(function(){
            $('#go-top .uc-2vm-pop').removeClass('dn');
        },function(){
            $('#go-top .uc-2vm-pop').addClass('dn');
        });

        //获取分站信息
        if($('#substation_city_id').length == 1){
            var indexdirurl = '';

            if($('#indexdir').val()!=''){
                indexdirurl = '&indexdir='+$('#indexdir').val();
            }
            $.get(weburl+"/index.php?m=ajax&c=Site&type=ajax"+indexdirurl,function(data){
                $('#substation_city_id').html(data);
            });
        }
    });
</script>
</body>
</html>
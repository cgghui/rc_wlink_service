/*  file:0  */

var js_version = '8bc5ac7db6a36f99';

//From Gmail.js

var agt = navigator.userAgent.toLowerCase();
var is_op = (agt.indexOf("opera") != -1);
var is_ie = (agt.indexOf("msie") != -1) && document.all && !is_op;
if(!is_ie && agt.indexOf('trident/') != -1 && agt.indexOf(' rv:') != -1){ /* ie11 */
    is_ie = true;
}
var is_ie5 = (agt.indexOf("msie 5") != -1) && document.all && !is_op;
var is_ie7 = (agt.indexOf("msie 7") != -1) && document.all && !is_op;
var is_mac = (agt.indexOf("mac") != -1);
var is_gk = (agt.indexOf("gecko") != -1);
var is_sf = (agt.indexOf("safari") != -1);
var is_safari = (agt.indexOf("safari") != -1);
var is_wk = (agt.indexOf("applewebkit") != -1);
var is_nav = !is_ie && !is_safari && (agt.indexOf("mozilla") != -1);
var FIRST_BUTTON = (is_safari || is_ie) ? 1 : 0;
var is_xp = ((agt.indexOf("windows nt 5.1") != -1)
	     || (agt.indexOf("windows xp") != -1));
var is_2k = ((agt.indexOf("windows nt 5.0") != -1)
	     || (agt.indexOf("windows 2000") != -1));

var is_win7 = (agt.indexOf("windows nt 6.1") != -1);
var is_win8 = (agt.indexOf("windows nt 6.3") != -1);

var _maq = _maq || []; // mipang access queue

function AssertTrue(expr)
{
    if (!expr) {
	DumpError("Assertion failed.\n");
	throw "Assertion failed.";
    }
}


function AssertEquals(val1, val2)
{
    if (val1 != val2) {
	DumpError("AssertEquals failed: <" + val1 + "> != <" + val2 + ">");
	throw "Assertion failed.";
    }
}
function AssertNumArgs(num)
{
    var caller = AssertNumArgs.caller;
    if (caller && caller.arguments.length != num) {
	DumpError("Wrong number of arguments!");
    }
}
function SetCookie(name, value, expires_ms)
{
    var date = new Date();
    var now = date.getTime();
    date.setTime(now + expires_ms);
    document.cookie =
	name + "=" + value + ";path=/;expires=" + date.toGMTString() + "; domain=.mipang.com";
}

function GetCookie(name)
{
    var cookie = String(document.cookie);
    var pos = cookie.indexOf(name + "=");
    if (pos != -1) {
	var end = cookie.indexOf(";", pos);
	return cookie.substring(pos + name.length + 1,
				end == -1 ? cookie.length : end);
    }
    return "";
}

function Now()
{
    return (new Date()).getTime();
}

function GetElement(win, id)
{
    return win.document.getElementById(id);
}

function SetInnerHTML(win, id, html)
{
    try {
	GetElement(win, id).innerHTML = html;
    }
    catch(ex) {
	DumpException(ex, "Cannot set inner HTML: " + id);
    }
}
function GetInnerHTML(win, id)
{
    try {
	return GetElement(win, id).innerHTML;
    }
    catch(ex) {
	DumpException(ex, "Cannot get inner HTML: " + id);
	return "";
    }
}
function ClearInnerHTML(win, id)
{
    try {
	GetElement(win, id).innerHTML = "";
    }
    catch(ex) {
	DumpException(ex, "Cannot set inner HTML: " + id);
    }
}
function SetCssStyle(win, id, name, value)
{
    try {
	var elem = GetElement(win, id);
	if (elem) {
	    elem.style[name] = value;
	}
    }
    catch(ex) {
	DumpException(ex);
    }
}
function ShowElement(el, show)
{
    el.style.display = show ? "" : "none";
}

function ShowBlockElement(el, show)
{
    el.style.display = show ? "block" : "none";
}

function SetButtonText(button, text)
{
    button.childNodes[0].nodeValue = text;
}

function AppendNewElement(win, parent, tag)
{
    var e = win.document.createElement(tag);
    parent.appendChild(e);
    return e;
}
function InsertNewElement(win, parent, tag)
{
    var e = win.document.createElement(tag);
    if(parent.hasChildNodes())
	parent.insertBefore(e,parent.firstChild);
    else
	parent.appendChild(e);
    return e;
}

function CreateDIV(win, id)
{
    var div = GetElement(win, id);
    if (!div) {
	var div = AppendNewElement(win, win.document.body, "div");
	div.id = id;
    }
    return div;
}
function CreateDIV2(win, id)
{
    var div = GetElement(win, id);
    if (!div) {
	var div = InsertNewElement(win, win.document.body, "div");
	div.id = id;
    }
    return div;
}

function CreateIFRAME(win, id, url)
{
    var iframe = GetElement(win, id);
    if (!iframe) {
	var div = AppendNewElement(win, win.document.body, "div");
	div.innerHTML =
	    "<iframe id=" + id + " name=" + id + " src=" + url +
	    "></iframe>";
	iframe = GetElement(win, id);
    }
    return iframe;
}

function HasClass(el, cl)
{
    if (el.className == null) {
	return false;
    }
    var classes = el.className.split(" ");
    for (var i = 0; i < classes.length; i++) {
	if (classes[i] == cl) {
	    return true;
	}
    }
    return false;
}

function AddClass(el, cl)
{
    if (HasClass(el, cl)) {
	return;
    }
    el.className += " " + cl;
}
function RemoveClass(el, cl)
{
    if (el.className == null) {
	return;
    }
    var classes = el.className.split(" ");
    var result =[];
    for (var i = 0; i < classes.length; i++) {
	if (classes[i] != cl) {
	    result[result.length] = classes[i];
	}
    }
    el.className = result.join(" ");
}


function GetPageOffsetLeft(el)
{
    var x = el.offsetLeft;
    if (el.offsetParent != null) {
	x += GetPageOffsetLeft(el.offsetParent);
    }
    return x;
}

function GetPageOffsetTop(el)
{
    var y = el.offsetTop;
    if (el.offsetParent != null) {
	y += GetPageOffsetTop(el.offsetParent);
    }
    return y;
}

function GetPageOffset(el)
{
    var x = el.offsetLeft;
    var y = el.offsetTop;
    if (el.offsetParent != null) {
	var pos = GetPageOffset(el.offsetParent);
	x += pos.x;
	y += pos.y;
    }
    return {
  x:x, y:y};
}
function GetPageOffsetRight(el)
{
    return GetPageOffsetLeft(el) + el.offsetWidth;
}

function GetPageOffsetBottom(el)
{
    return GetPageOffsetTop(el) + el.offsetHeight;
}

function GetScrollTop(win)
{
    var doc = win.document;
    var body = doc.documentElement ? doc.documentElement : doc.body;
    return is_ie ? body.scrollTop : win.pageYOffset;
}
function GetScrollLeft(win)
{
    var doc = win.document;
    var body = doc.documentElement ? doc.documentElement : doc.body;
    return is_ie ? body.scrollLeft : win.pageXOffset;
}

function ScrollTo(win, el, position)
{
    var y = GetPageOffsetTop(el);
    y -= GetWindowHeight(win) * position;
    win.scrollTo(0, y);
}

function ScrollIntoView(win, el, alignment)
{
    var el_top = GetPageOffsetTop(el);
    var el_bottom = el_top + el.offsetHeight;
    var win_top = GetScrollTop(win);
    var win_height = GetWindowHeight(win);
    var win_bottom = win_top + win_height;
    if (el_top < win_top || el_bottom > win_bottom) {
	var scrollto_y;
	if (alignment == 'b') {
	    scrollto_y = el_bottom - win_height + 5;
	} else {
	    if (alignment == 'm') {
		scrollto_y = (el_top + el_bottom) / 2 - win_height / 2;
	    } else {
		scrollto_y = el_top - 5;
	    }
	}
	Debug("Scrolling to " + scrollto_y);
	win.scrollTo(0, scrollto_y);
    }
}

//get window size.
function GetWindowWidth(win)
{
    var doc = win.document;
    var body = doc.documentElement ? doc.documentElement : doc.body;
    return is_ie ? body.clientWidth : win.innerWidth;
}

function GetWindowHeight(win)
{
    var doc = win.document;
    var body = doc.documentElement ? doc.documentElement : doc.body;
    return is_ie ? body.clientHeight : win.innerHeight;
}

function GetAvailScreenWidth()
{
    return screen.availWidth;
}

function GetAvailScreenHeight()
{
    return screen.availHeight;
}

function GetNiceWindowHeight(win)
{
    return Math.floor(0.88 * GetAvailScreenHeight());
}
function GetCenteringLeft(width)
{
    return Math.floor((screen.availWidth - width) / 2);
}

function GetCenteringTop(height)
{
    return Math.floor((screen.availHeight - height) / 2);
}
//open new Window.
function OpenInternalWindow(win, url, name, features)
{
    return OpenExternalWindow(win, U_MakeUnique(url), name, features);
}

function OpenExternalWindow(win, url, name, features)
{
    var newwin = _OpenWindowHelper(top, url, name, features);
    if (!newwin) {
	newwin = _OpenWindowHelper(win, url, name, features);
    }
    if (!newwin) {
	alert
	    ('Grrr! A popup blocker may be preventing Gmail from opening the page. If you have a popup blocker, try disabling it to open the window.');
    } else {
	newwin.focus();
    }
    return newwin;
}

function _OpenWindowHelper(win, url, name, features)
{
    var newwin;
    if (features) {
	newwin = win.open(url, name, features);
    } else {
	if (name) {
	    newwin = win.open(url, name);
	} else {
	    newwin = win.open(url);
	}
    }
    return newwin;
}

function CloseWindow(win)
{
    win.top.close();
}

function Popup(win, url, name, width, height, do_center)
{
    if (!height) {
	height = Math.floor(GetWindowHeight(win.top) * 0.88);
    }
    if (!width) {
	width = Math.min(GetAvailScreenWidth(), height);
    }
    var features =
	"resizable=yes,scrollbars=yes,width=" + width + ",height=" +
	height;
    if (do_center) {
	features +=
	    ",left=" + GetCenteringLeft(width) + "," + "top=" +
	    GetCenteringTop(height);
    }
    return OpenInternalWindow(win, url, name, features);
}




//string stuff
function HtmlEscape(str){
	if(typeof str != 'string')
		str = String(str);
    return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;");
}
function QuoteEscape(str){
    return HtmlEscape(str);//.replace(/\"/g,"&quot;");
}
function CollapseWhitespace(str){
    return str.replace(/\s+/g," ").replace(/^ /,"").replace(/ $/,"");
}
function StripNewlines(str){
    return str.replace(/[\r\n]/g," ");
}
function NormalizeSpaces(str){
    return str.replace(/[ \t]+/g," ").replace(/\xa0/g," ");
}

function StripHtmlTags(str){
	return str.replace(/<[^><]*(>|$)/g," ").replace(/(&[^&]{2,5}(;|$))+/g," ").replace(/^\s+/,"");
}

function StrSafeInline(str){
	return HtmlEscape(str).replace(/\\/g,/*'&#92;'*/'\\\\').replace(/(\r\n?|\n)/g,'\\n').replace(/\'/g,'\\\'');
}

function UrlEncode(str){
    return encodeURIComponent(str);
}
function Trim(str){
    return str.replace(/^\s+/,"").replace(/\s+$/,"");
}
function EndsWith(str, suffix){
    return (str.lastIndexOf(suffix)==(str.length-suffix.length));
}
function IsEmpty(str)
{
    return CollapseWhitespace(str) == "";
}

function IsLetterOrDigit(ch)
{
    return ((ch >= "a" && ch <= "z") || (ch >= "A" && ch <= "Z")
	    || (ch >= '0' && ch <= '9'));
}

function IsSpace(ch)
{
    return (" \t\r\n".indexOf(ch) >= 0);
}

var eol_re_=/\r\n?/g;
function ConvertEOLToLF(str)
{
    return str.replace(eol_re_, "\n");
}

function HtmlEscapeInsertWbrs(str, n, chars_to_break_after,
			      chars_to_break_before)
{
    AssertNumArgs(4);
	if(typeof str != 'string')
		str = String(str);
	
    var out = '';
    var strpos = 0;
    var spc = 0;
    for (var i = 1; i < str.length; ++i) {
	var prev_char = str.charAt(i - 1);
	var next_char = str.charAt(i);
	if (IsSpace(next_char)) {
	    spc = i;
	} else {
	    if (i - spc == n
		|| chars_to_break_after.indexOf(prev_char) != -1
		|| chars_to_break_before.indexOf(next_char) != -1) {
		out += HtmlEscape(str.substring(strpos, i)) + '<wbr>';
		strpos = i;
		spc = i;
	    }
	}
    }
    out += HtmlEscape(str.substr(strpos));
    return out;
}

function GetCursorPos(win, textfield)
{
    if (IsDefined(textfield.selectionEnd)) {
	return textfield.selectionEnd;
    } else {
	if (win.document.selection && win.document.selection.createRange) {
	    var tr = win.document.selection.createRange();
	    var tr2 = tr.duplicate();
	    tr2.moveToElementText(textfield);
	    tr2.setEndPoint("EndToStart", tr);
	    var cursor = tr2.text.length;
	    if (cursor > textfield.value.length) {
		return -1;
	    }
	    return cursor;
	} else {
	    Debug("Unable to get cursor position for: " +
		  navigator.userAgent);
	    return textfield.value.length;
	}
    }
}
function SetCursorPos(win, textfield, pos)
{
    if (IsDefined(textfield.selectionEnd)
	&& IsDefined(textfield.selectionStart)) {
	textfield.selectionStart = pos;
	textfield.selectionEnd = pos;
    } else {
	if (win.document.selection && textfield.createTextRange) {
	    var sel = textfield.createTextRange();
	    sel.collapse(true);
	    sel.move("character", pos);
	    sel.select();
	}
    }
}


function Map()
{
}

Map.prototype.get = function(key)
{
    return this[':' + key];
};

Map.prototype.put = function(key, value)
{
    this[':' + key] = value;
};

Map.prototype.remove = function(key)
{
    delete this[':' + key];
};
function Set(array)
{
    if (array) {
	for (var i = 0; i < array.length; i++) {
	    this.add(array[i]);
	}
    }
}

Set.prototype.add = function(entry)
{
    this[':' + entry] = 1;
};

Set.prototype.remove = function(entry)
{
    delete this[':' + entry];
};

Set.prototype.contains = function(entry)
{
    return (this[':' + entry] == 1);
};
function FindInArray(array, x)
{
    for (var i = 0; i < array.length; i++) {
	if (array[i] == x) {
	    return i;
	}
    }
    return -1;
}

function InsertArray(array, x)
{
    if (FindInArray(array, x) == -1) {
	array[array.length] = x;
    }
}
function DeleteArrayElement(array, x)
{
    var i = 0;
    while (i < array.length && array[i] != x)
	i++;
    array.splice(i, 1);
}

function CloneObject(x)
{
    if ((typeof x) == "object") {
	var y =[];
	for (var i in x) {
	    y[i] = CloneObject(x[i]);
	}
	return y;
    }
    return x;
}

function PrintArray(array)
{
    AssertEquals(array.length, PrintArray.arguments.length * 2 - 1);
    var idx = 1;
    for (var i = 1; i < PrintArray.arguments.length; i++) {
	array[idx] = PrintArray.arguments[i];
	idx += 2;
    }
    return array.join("");
}


function ImageHtml(url, attributes)
{
    return "<img " + attributes + " src=" + url + ">";
}
function FormatJSLink(desc, js, classname)
{
    return '<span class="' + classname + '" onclick="' + js + '">' + desc +
	'</span>';
}

function FormatIDLink(desc, id, underline)
{
    return "<span class=" + (underline ? "lk" : "l") + ' id="' + id +
	'">' + desc + "</span>";
}

function FormatURLLink(desc, url, extra)
{
    return '<a href="' + url + '" class=' + "lk" +
	' onclick="return top.MPLINK(window,this,event)" ' +
	(extra ? extra : '') + '>' + desc + "</a>";
}

function MakeId3(idprefix, m, n)
{
    return idprefix + m + "_" + n;
}

function IsDefined(value)
{
    return (typeof value) != 'undefined';
}


function XmlHttpCreate()
{
    var xmlhttp = null;
    if (is_ie) {
	var control = (is_ie5) ? "Microsoft.XMLHTTP" : "Msxml2.XMLHTTP";
	try {
	    xmlhttp = new ActiveXObject(control);
	}
	catch(e) {
	    DumpException(e);
	    alert
		("You need to enable active scripting and activeX controls.");
	}
    } else {
	xmlhttp = new XMLHttpRequest();
	if (!xmlhttp) {
	    alert("XMLHttpRequest is not supported on this browser.");
	}
    }
    return xmlhttp;
}

function XmlHttpSend(xmlhttp, data)
{
    try {
	xmlhttp.send(data);
    }
    catch(e) {
	DumpException(e);
	if (e.number == -2146697208.000000) {
	    alert
		("Please make sure the 'Languages..' setting for your Internet Explorer is not empty.");
	}
    }
}
function XmlHttpGET(xmlhttp, url, handler,noUniqUrl)
{
    /**AssertNumArgs(3);**/

    if(!noUniqUrl)
	url = U_MakeUnique(url);

    Debug("Server request: GET " + url);
    xmlhttp.onreadystatechange = handler;
    xmlhttp.open("GET", url, true);
    XmlHttpSend(xmlhttp, null);
}

function XmlHttpPOST(xmlhttp, url, data, handler)
{
    AssertNumArgs(4);
    Debug("Server request: POST " + url);
    xmlhttp.onreadystatechange = handler;
	//alert(url);
    xmlhttp.open("POST", url, true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    XmlHttpSend(xmlhttp, data);
}



//URL opt...
function U_Param(key, value)
{
    return "&" + key + "=" + UrlEncode(value);
}

function U_FirstParam(key, value)
{
    return "?" + key + "=" + UrlEncode(value);
}

function U_AppendParam(url, key, value)
{
    if (url.indexOf('?') < 0) {
	return url + U_FirstParam(key, value);
    } else {
	return url + U_Param(key, value);
    }
}function U_MakeUnique(url)
{
    if (url.indexOf('?') < 0) {
	return url;
    }
    var rand_str =
	js_version + Math.round(Math.random() * 2147483648.000000);
    return U_AppendParam(url, "zx", rand_str);
}


/////DEBUG.........
function DB_WriteDebugMsg()
{
}
function Debug(str)
{
    DB_WriteDebugMsg(str, 0);
}

function DumpError(str)
{
    try {
	throw str;
    }
    catch(e) {
	DumpException(e);
    }
}
function DumpException(e, msg)
{
    var error =
	"Javascript exception: " + (msg ? msg : "") + " " + e + "\n";
    for (var i in e) {
	//error += i + ": " + e[i] + " | ";
    }
	error+='\n';
    error += DB_GetStackTrace(DumpException.caller);
    alert(error);
 /*   DB_WriteDebugMsg(error, 1);
    DB_SendJSReport(error);
	*/
}

function DumpObj(obj,prefix)
{
    prefix = prefix || '';
    var s = '';
    for(var x in obj){
	if(typeof obj[x] == 'object'){
	    s += prefix + x + ' = \n' + DumpObj(obj[x],prefix+'... ');
	}else
	    s += prefix + x + ' = '+obj[x] + '\n';
    }
    return s;
}


function DB_GetFunctionName(fn){
    //return String(fn).substr(0,200);
    var m=/function (\w+)/.exec(String(fn));
    if(m){return m[1];
    }
    return "";
}
function DB_GetStackTrace(fn)
{
    try {
	if (is_nav) {
	    return Error().stack;
	}
	if (!fn) {
	    return "";
	}
	var x = "\- " + DB_GetFunctionName(fn) + "(";
	for (var i = 0; i < fn.arguments.length; i++) {
	    if (i > 0) {
		x += ", ";
	    }
	    var arg = String(fn.arguments[i]);
	    if (arg.length > 40) {
		arg = arg.substr(0, 40) + "...";
	    }
	    x += arg;
	}
	x += ")\n";
	x += DB_GetStackTrace(fn.caller);
	return x;
    }
    catch(ex) {
	return "[Cannot get stack trace]: " + ex + "\n";
    }
}




function getEventSrc(e){
	if (e){ return e.target; }
	if (window.event){ return window.event.srcElement; }
	return null;
}

function EV_GetEventTarget(e)
{
    var src = e.srcElement ? e.srcElement : e.target;
    if (is_safari && src && src.nodeType == 3) {
	src = src.parentNode;
    }
    return src;
}


function EV_GetKeyCode(e)
{
    return is_ie ? e.keyCode : e.which;
}

function EV_GetKeyChar(e)
{
    var keycode = EV_GetKeyCode(e);
    if (is_ie && e.ctrlKey) {
	keycode += 64;
    }
    return String.fromCharCode(keycode).toLowerCase();
}

function EV_GetMouseXPos(win, e)
{
    var doc = win.document;
    var body = doc.documentElement ? doc.documentElement : doc.body;
    return is_ie ? (e.x + body.scrollLeft) : e.pageX;
}
function EV_GetMouseYPos(win, e)
{
    var doc = win.document;
    var body = doc.documentElement ? doc.documentElement : doc.body;
    return is_ie ? (e.y + body.scrollTop) : e.pageY;
}



var EV_Attach=function(o,a,f,i){
    i = !(!i);
    if(o.addEventListener){
	o.addEventListener(a,f,i);
    }else if(o.attachEvent){
	o.attachEvent("on"+a,f);
    }
};

var EV_Detach=function(o,a,f,i)
{
    i = !(!i);
    if(o.removeEventListener){
	o.removeEventListener(a,f,i);
    }else if(o.detachEvent){
	o.detachEvent("on"+a,f);
    }
};


var _ge = function(id) {
    return GetElement(window,id);
};


var _pi = function(str) {
	return parseInt(str);
};


var _re_email = /^[0-9a-zA-Z]+(\.?[0-9a-zA-Z_\-]+)*@([0-9a-zA-Z]+[0-9a-zA-Z_\-]*\.?)*[0-9a-zA-Z]+[0-9a-zA-Z_\-]*$/ ;



///From Flick js....


// EXTEND BUILT IN OBJECTS

if (!Array.prototype.push) {
	Array.prototype.push = function() {
		var i = 0, b = this.length, a = arguments;
		for (i; i<a.length; i++) this[b+i] = a[i];
		return this.length;
	}
}

if (!Array.prototype.pop) {
	Array.prototype.pop = function() {
		var  b = this[this.length-1];
		this.length--;
		return b;
	}
}

if(!Array.prototype.merge){
    /** to be fixed
    Array.prototype.merge = function(){
	var i = 0, b = this.length, a = arguments;
	for (i; i<a.length; i++) ;
	return this;
    };
    **/
}

if(!String.prototype.chop){
	String.prototype.chop = function() {
		return this;
	}
}

function trim(s) {
  while (s.substring(0,1) == ' ') {
    s = s.substring(1,s.length);
  }
  while (s.substring(s.length-1,s.length) == ' ') {
    s = s.substring(0,s.length-1);
  }
  return s;
}

if(!String.prototype.nl2br){
	String.prototype.nl2br = function() {
		return this.split('\n').join('<br \/>\n');
	}
}
if(!String.prototype.replaceFast){
	String.prototype.replaceFast = function(find,replace) {
		return this.split(find).join(replace);
	}
}
if(!String.prototype.escapeForXML){
	String.prototype.escapeForXML = function() {
		return this.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;');
	}
}
if(!String.prototype.escapeForDisplay){
	String.prototype.escapeForDisplay = function() {
		return this.replace('<', '&lt;');
	}
}
if(!String.prototype.truncate_with_ellipses){
	String.prototype.truncate_with_ellipses = function(chars_allowed) {
		var t = this;
		if (t.length > chars_allowed-3) {
			t = t.substr(0, chars_allowed-3)+'...'
		}
		return t;
	}
}

if(!String.prototype.UrlEncode){
	String.prototype.UrlEncode = function() {
   	 return encodeURIComponent(this);
	}
}




function okForXMLHTTPREQUESTandResponseXML(){
	if (global_fakeOperaXMLHttpRequestSupport) return false; // this is set in xmlhtttprequest.js
	return okForXMLHTTPREQUEST();
}

function okForXMLHTTPREQUEST(){
	if (!window.XMLHttpRequest) return false;
	if (navigator.appVersion.toLowerCase().indexOf("mac") > 0 && navigator.userAgent.indexOf('MSIE') > 0 && navigator.userAgent.indexOf('Opera') == -1) return false;
	return true;
}

function escape_utf8(data) {

	if (data == '' || data == null){
		return '';
	}
	data = data.toString();
	var buffer = '';
	for(var i=0; i<data.length; i++){
		var c = data.charCodeAt(i);
		var bs = new Array();

		if (c > 0x10000){
			// 4 bytes
			bs[0] = 0xF0 | ((c & 0x1C0000) >>> 18);
			bs[1] = 0x80 | ((c & 0x3F000) >>> 12);
			bs[2] = 0x80 | ((c & 0xFC0) >>> 6);
			bs[3] = 0x80 | (c & 0x3F);

		}else if (c > 0x800){
			// 3 bytes
			bs[0] = 0xE0 | ((c & 0xF000) >>> 12);
			bs[1] = 0x80 | ((c & 0xFC0) >>> 6);
			bs[2] = 0x80 | (c & 0x3F);

		}else if (c > 0x80){
			// 2 bytes
			bs[0] = 0xC0 | ((c & 0x7C0) >>> 6);
			bs[1] = 0x80 | (c & 0x3F);

		}else{
			// 1 byte
			bs[0] = c;
		}

		for(var j=0; j<bs.length; j++){
			var b = bs[j];
			var hex = nibble_to_hex((b & 0xF0) >>> 4) + nibble_to_hex(b & 0x0F);
			buffer += '%'+hex;
		}
	}

	return buffer;
}

function nibble_to_hex(nibble){
	var chars = '0123456789ABCDEF';
	return chars.charAt(nibble);
}




// findPosX & findPosY courtesy PPK
// http://www.quirksmode.org/js/findpos.html
function findPosX(obj) {
	var curleft = 0;
	if (obj.offsetParent) {
		while (obj.offsetParent) {
			curleft += obj.offsetLeft
			obj = obj.offsetParent;
		}
	}
	else if (obj.x) curleft += obj.x;
	return curleft;
}

function findPosY(obj) {
	var curtop = 0;
	if (obj.offsetParent) {
		while (obj.offsetParent) {
			curtop += obj.offsetTop
			obj = obj.offsetParent;
		}
	}
	else if (obj.y) curtop += obj.y;
	return curtop;
}

 document.getElementsByClass = function (needle, tagName) {
 	if (!tagName) tagName = '*';
	var my_array = document.getElementsByTagName(tagName);
	var retvalue = new Array();
	var i;	 
	var j;

	for (i = 0, j = 0; i < my_array.length; i++) { 	 
		var c = " " + my_array[i].className + " "; 	 
		if (c.indexOf(" " + needle + " ") != -1) retvalue[j++] = my_array[i]; 	 
   }	
   return retvalue;
}



if (!Array.prototype.push) {
	Array.prototype.push = function() {
		var i = 0, b = this.length, a = arguments;
		for (i; i<a.length; i++) this[b+i] = a[i];
		return this.length;
	}
}

if (!Array.prototype.pop) {
	Array.prototype.pop = function() {
		var  b = this[this.length-1];
		this.length--;
		return b;
	}
}


function setCookie(name, value, days) {
	var expires = '';
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		expires = '; expires='+date.toGMTString();
	}
	document.cookie = name+'='+value+expires+'; path=/';
}

function getCookie(name) {
	var nameEQ = name + '=';
	var ca = document.cookie.split(';');
	for(var i=0; i<ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ') c = c.substring(1, c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
	}
	return null;
}

function deleteCookie(name) {
	SetCookie(name, '', -1);
}

set_rgb = function(prop, r, g, b) {
	this.style[prop] = 'rgb('+r+', '+g+', '+b+')';
}

set_color_rgb = function(r, g, b) {
	set_rgb.call(this, 'color', r, g, b);
}










///////////////////
// my funcs....
////////////////////////////


function isLeapYear(year)
{
    var d = new Date(year,2,1,0,0,0,0);
    d.setTime(d.getTime() - 100);
    return d.getDate() == 29;
}

function htmlencode(str){
	var s = HtmlEscape(str);
	s = s.replace(/  /g,"&nbsp; ");
	s = s.replace(/\t/g,"&nbsp; &nbsp; &nbsp; &nbsp; ");
	s = s.replace(/\n/g,"<br/>");
	return s;
}

function ResizeTextarea(a,row){
    if(!a){return}
    if(!row)
	row=5;
    var b=a.value.split("\n");
    var c=is_ie?1:0;
    c+=b.length;
    var d=a.cols;
    if(d<=20){d=40}
    for(var e=0;e<b.length;e++){
	if(b[e].length>=d){
	    c+=Math.ceil(b[e].length/d)
	}
    }
    c=Math.max(c,row);
    if(c!=a.rows){
	a.rows=c;
    }
}











function getFirstNodeValue(el,tagName)
{
	var node = el.getElementsByTagName(tagName)[0];
	return getNodeValue(node);
}

function getNodeValue(node)
{
	if(node && node.hasChildNodes()){
		//return node.firstChild.nodeValue;
		var s="" 
		//Mozilla has many textnodes with a size of 4096 chars each instead of one large one.
		//They all need to be concatenated.
		for(var j=0;j<node.childNodes.length;j++){
			s+=new String(node.childNodes.item(j).nodeValue);
		}
		return s;	
	}else
		return "";
}

function getParentNodeByTagName(e,tag,minDeep,maxDeep)
{
	try{
	if(!maxDeep)
		maxDeep=50;
	if(!minDeep)
		minDeep=0;
	if(minDeep>=maxDeep)
		return null;
	var i=0;
	while( (e=e.parentNode) && (e.tagName.toLowerCase() != tag.toLowerCase() || minDeep>i ) && i<maxDeep){		
		i++;
	}
	if(e && i < maxDeep)
		return e;
	else 
		return null;	
	}catch(e){return null;}
}

function getParentNodeByName(e,name,minDeep,maxDeep)
{
	try{
	if(!maxDeep)
		maxDeep=50;
	if(!minDeep)
		minDeep=0;
	if(minDeep>=maxDeep)
		return null;
	var i=0;
	while( (e=e.parentNode) && i<maxDeep){		
		if(e.getAttribute('name') && String(e.getAttribute('name')) == name ){
			if(i>=minDeep){
				break;
			}
		}
		i++;
	}
	if(e && i < maxDeep)
		return e;
	else 
		return null;	
	}catch(e){return null;}
}


/*disable the Enter Key event ,just for IE.*/
function form_disable_EnterKey(Event,f)
{
try{	
	var fe = _ge(f);
	var es = fe.getElementsByTagName('input');
	for(var i=0;i<es.length;i++){
		var e=es[i];
		if(e.type=='text'){
			e.onkeydown = function(){
				if(!Event)
					Event = window.event;
				if(Event.keyCode==13) Event.returnValue=false;
			};
		}
	}
}catch(e){}
}


function CopyArray(arr)
{
	var n=[];
	if(!arr || !arr.length)
		return n;
	for(var i=0;i<arr.length;i++){
		n[i] = arr[i];		
	}	
	return n;
}





/*////////////////// XmlHttpRequest /////////////////////*/

// IE support
if (window.ActiveXObject && !window.XMLHttpRequest) {
  window.XMLHttpRequest = function() {
    return new ActiveXObject((navigator.userAgent.toLowerCase().indexOf('msie 5') != -1) ? 'Microsoft.XMLHTTP' : 'Msxml2.XMLHTTP');
  };
}
// Gecko support
/* ;-) */
// Opera support
global_fakeOperaXMLHttpRequestSupport = false;

// ActiveXObject emulation
if (0 && !window.ActiveXObject && window.XMLHttpRequest) {
  window.ActiveXObject = function(type) {
    switch (type.toLowerCase()) {
      case 'microsoft.xmlhttp':
      case 'msxml2.xmlhttp':
        return new XMLHttpRequest();
    }
    return null;
  };
}



function SendReq4XML(url,data,callback,cb_argsObj,debug)
{
	var xmlhttp = XmlHttpCreate();
	
    var handler =
	function(){
        try {
            if (4 == xmlhttp.readyState && 200 == xmlhttp.status) {
				if(debug) 
					alert('Length:'+xmlhttp.responseText.length+"\n"+xmlhttp.responseText);
				//alert(xmlhttp.responseText.length);
				if(cb_argsObj)
					callback(xmlhttp.responseXML,cb_argsObj);
				else
					callback(xmlhttp.responseXML);
            }
        }
		catch(exx) {
			DumpException(exx);
		}
    };	
	XmlHttpPOST(xmlhttp, url, data, handler);			
}


///////////////////////////
// my funcs....
function XmlHttpGetError(rsXML)
{
	//arg1 is a XML FROMAT result
	try{
		var err = rsXML.documentElement.getElementsByTagName('error')[0];
		if(err){
			var code = getFirstNodeValue(err,'code');
			var desc = getFirstNodeValue(err,'desc');
			var error = new Object();
			error.code=code;
			error.desc=desc;
			return error;
		}
	}catch(e){
		//DumpException(e);
		return null;
	}
	return null;
}


///////////////////////////////////////////////////
/// My APIs... TOBE UPGRADE Later...
///////////////////////////////////////////////////
var MyAPI = {};
MyAPI.callMethod = function(APIMethod, params, listener, CBParams/*callback {args}*/,APIURL, attempts, server,method,cache/* get(method) cache */) {
	if (typeof params != 'object') params = {}; // because we are going to stick a few things in even if no params are passed
	params.method = APIMethod; // see? And this also makes sure a method parameter is not passed
	
	var url = '/service/api';
	if(APIURL) url = APIURL;
	if (server) url = server + url;
	
	var data = 'APIv=0.1';
	
	for (var p in params) {
		if (p=='RESTURL') continue;
		if(p=='RAW_QUERY'){
			data+='&'+params[p];
			continue;
		}
		params[p] = params[p];
		//params_keyA.push(p);
		data+= '&'+p+'='+UrlEncode(params[p]);//escape_utf8(params[p]);
	}

	params.RESTURL = data; // again. we stick this in here because we pass params to the callback, and it might want to see the URL
	
	//alert(data);
	
	var attempts = (attempts == undefined) ? 1 : attempts;
	
	var req = XmlHttpCreate();
	
	if (!req){
		return ;
	}
	
	var callback = function() {
		//alert(req.readyState+'/'+req.status);
		if (4 == req.readyState ){
			if( 200 == req.status ){
				if( typeof MyAPI == 'object') 
				MyAPI.handleResponse(req.responseXML, APIMethod, params, req.responseText, listener,CBParams);
			}else{
				if( 0 || //req.responseText == '' &&
					attempts<2
					) {
					attempts++;
					req.abort();
					MyAPI.callMethod(APIMethod, params, listener, CBParams,APIURL, attempts, server);
				} 			
			}
		}
	};

	if(url.indexOf('/service/proxy/') != 0){

	    // fix vhost
	    if(url.indexOf('/') == 0 && typeof MIPANG != 'undefined' && typeof MIPANG.location !='undefined' ){

		url = MIPANG.location.scheme + '://'+MIPANG.location.main_host + url;

	    }


	    if(typeof MIPANG != 'undefined' && typeof MIPANG.location != 'undefined' && MIPANG.location.main_host != MIPANG.location.current_host){
		url = '/service/proxy/*/'+url;
	    }

	    //alert(url);

	}

	if(method && method=='GET')
	    XmlHttpGET(req,url,callback,cache);
	else
	    XmlHttpPOST(req,url,data,callback);		
};

MyAPI.getCallBackName = function (dotted) {
	return dotted.split('.').join('_')+'_onLoad';
};

MyAPI.handleResponse = function(responseXML, APIMethod, params, responseText, listener,CBParams) {
	var success = {code:0,desc:''};
	
	if (!responseXML) { //OPERA!
		if(responseText.indexOf('stat="ok"') > -1){
			success.code = 0;
			success.desc = '';
		}else{
			success.code = 888;
			success.desc = responseText;
		}
	} else {
		var err = XmlHttpGetError(responseXML);
		if(!err){
			if(responseXML.documentElement && responseXML.documentElement.getAttribute('code') ){
				success.code = responseXML.documentElement.getAttribute('code')*1;
				success.desc = success.code==0?'SUCCESS':responseText;
			}else{
				success.code = 888; // Error Msg.
				success.desc = responseText;
			}
		}
		if(err){
			success = err;
		}
	}
//	success.desc = responseText;
	//writeAPIDebug(responseText);
	if(!listener) return;
	
	listener = (listener) ? listener : this;
	listener[this.getCallBackName(APIMethod)](success, responseXML, responseText, params,CBParams);
};


/** func add **/





/** misc */
if(!window.__handle_uid)
    window.__handle_uid=1000;
function ExportHandle(obj,prefix)
{
    if(!obj) return;
    if(!prefix)
	prefix = 'ObjectHandle';
    obj.handle_str = '__'+prefix+'_'+(new Date()).getTime()+(++window.__handle_uid);
    window[obj.handle_str] = obj;
}

var MP_DOM_onLoad = new Map();/*not used*/
var MP_DOM_onLoad2 = [];
window.__mp_dom_onload_count = (new Date()).getTime();
window.__mp_dom_loaded_done = false;
function onloadRegister2(fn)
{
    if(window.__mp_dom_loaded_done){
	try{
	    fn();
	}catch(ex){}
	return;
    }
    /* keep old code work */
    var fkey = '_dom_onload_fn_'+(window.__mp_dom_onload_count++);
    MP_DOM_onLoad.put(fkey,fn);
    /* new method  */
    MP_DOM_onLoad2.push(fn);
}
/*run the registered fun,new method*/
function onloadRegisterHandlerNotify(){
    var i,len=MP_DOM_onLoad2.length;
    for(i=0;i<len;i++){
	try{
	    MP_DOM_onLoad2[i]();
	}catch(ex){}
    }
}
var onloadRegisterHandler = onloadRegister2;
onloadRegisterHandler(function(){ window.__mp_dom_loaded_done = true; }); /*keep this first push*/

/** for blog thumb image detect **/
var __blog_thumb_ban_url_set = new Set();
__blog_thumb_ban_url_set.add('http://imgcache.qq.com/qzone_v4/b.gif');
var __blog_thumb_ban_url_list = [
				 'imgcache.qq.com/qzone_v4/b.gif',
				 '/qzone_v4/b.gif',
				 'imgcache.qq.com/ac/b.gif',
				 'imgcache.qq.com/qzone/em/'
				 ];
function __blog_thumb_ban_url_test(url)
{
    var list = __blog_thumb_ban_url_list;
    for(var i = 0;i < list.length; i++){
	if(String(url).indexOf(list[i]) != -1)
	    return true;
    }
    return false;
    /**
       return (__blog_thumb_ban_url_list.contains(url));
    **/
}

try{ /**client timestamp*/
SetCookie('_tsc',new Date().getTime(),3600*24*365*1000);
}catch(ex){}



/** simple tpl render **/

/** data:{item:string}**/
function simple_tpl_render(tpl,data,dropempty)
{
    return tpl.replace(/\[%([^%]+)%\]/g,
		function(a,b){
		    if( b in data){
			return data[b];
		    }
		    if(dropempty) return '';

		    return a;
		}
	);
}

/** css dynamic append **/
var __mp_dcss_pool = new Map();
function MP_appendCssText(index,cssText){
    
    var st = document.createElement('style');
    st.setAttribute('type','text/css');
    
    onloadRegisterHandler(function(){
	    document.getElementsByTagName('head')[0].appendChild(st);

	    var ibox = __mp_dcss_pool.get(index);
	    
	    var oCss = '';
	    if(ibox){
		oCss = ibox.innerHTML;
		
		document.getElementsByTagName('head')[0].removeChild(ibox);
	    }
    
	    if(st.styleSheet){
		st.styleSheet.cssText = oCss + cssText;
	    }else{
		st.appendChild(document.createTextNode(oCss + cssText));
	    }
	    
    
	    ibox = st;
	    __mp_dcss_pool.put(index,ibox);

	});

}

function MP_SetCssText(index,cssText){
    
    var st = document.createElement('style');
    st.setAttribute('type','text/css');

    cssText = cssText ? cssText : '';
    
    onloadRegisterHandler(function(){
	    document.getElementsByTagName('head')[0].appendChild(st);

	    var ibox = __mp_dcss_pool.get(index);
	    
	    var oCss = '';
	    if(ibox){
		document.getElementsByTagName('head')[0].removeChild(ibox);
	    }
    
	    if(st.styleSheet){
		st.styleSheet.cssText = oCss + cssText;
	    }else{
		st.appendChild(document.createTextNode(oCss + cssText));
	    }
	    
    
	    ibox = st;
	    __mp_dcss_pool.put(index,ibox);

	});

}


/** regexp **/
function regexp_escape(str)
{
    return str.replace(/([\^*+\-\$\\\{\}\(\)\[\]\#?\.])/g,"\\$1")
}



/* mipang namespace */
if(typeof(MIPANG) == 'undefined'){
    var MIPANG = {};
}

/* --- page function --- */


function __PPUW(url)
{
    return Popup(window, url, 'PhotoUploadWindow_'+(new Date()).getTime(), 600, GetAvailScreenHeight(window)-40);
}
/* browser check */
MIPANG._bc=function()
{
    try{
	var agt = navigator.userAgent.toLowerCase();
	var is_op = (agt.indexOf("opera") != -1);
	var is_ie = (agt.indexOf("msie") != -1) && document.all && !is_op;
	var is_ie5 = (agt.indexOf("msie 5") != -1) && document.all && !is_op;
	if((is_ie && is_ie5)) document.write('<div style="color:#ffffff;background-color:red;">很抱歉，你正在使用的IE浏览器版本较低。目前我们仅保证在IE6/7和<a href="http://www.mozilla.com/firefox/" style="color:#ffffff;font-weight:bold;">FireFox</a>下工作正常。</div>');
    }catch(e){}
};



/* fireEvent my test version */
function MP_fireEvent(element,event){
    if(document.createEvent){
	// dispatch for firefox + others
	var evt = document.createEvent("HTMLEvents");
	evt.initEvent(event, true, true ); // event type,bubbling,cancelable
	return !element.dispatchEvent(evt);
    }
    else{
	// dispatch for IE
	var evt = document.createEventObject();
	return element.fireEvent('on'+event,evt);
    }
}


/* mipang cps client */
function __mp_write_cps_cookie(cpsid,cpsaid,url,fromUrl)
{
try{
var uri = new URI('http://cps.mipang.com/trace');

uri.setQueryData({
url:url,
from_url:fromUrl,
cpsid:cpsid,
aid:cpsaid,
rdr:'image',
__ut:(new Date()).getTime()
});


var x = document.createElement('div');
x.setAttribute('style','');
x.style['height'] = '0';
x.style['overflow'] = 'hidden';
x.innerHTML = '<img src="'+uri._toString()+'"/>';
document.body.appendChild(x);
	/**
	(new Image(1,1)).src = uri._toString();
	**/

}catch(ex){}
}
onloadRegisterHandler(function(){
    
    try{
	
	/* 
	 * CPS params:
	 * @_mipang_cps_id
	 * @_mipang_cps_aid
	 */
	
	var uri = URI();
	var q = uri.getQueryData();

	if(typeof q._mipang_cps_id == 'undefined'){ 
	    _cps_trace_seo();
	    return;
	}
	
	var cpsid = q._mipang_cps_id;
	
	var cpsaid = typeof q._mipang_cps_aid  == 'undefined' ? 0 : q._mipang_cps_aid;
	
	var nq = q;

	for(var x in nq){
	    if(x.match(/^_mipang_cps_/))
		delete nq[x];
	}

	uri.setQueryData(nq);

	var from_url = document.referrer ? document.referrer : '';

        __mp_write_cps_cookie(cpsid,cpsaid,uri._toString(),from_url);
 
    }catch(ex){  }
});


/* trace seo source*/
function _cps_trace_seo(){

    var cookie_cps = GetCookie('__mcps');

    //alert(cookie_cps);
    if(cookie_cps) return;
    //return;
    var referer = document.referrer;
    //alert(typeof referer);
    var r=String(referer);
    //http://www.google.cn/search?hl=zh-CN&newwindow=1&q=%E6%99%AE%E9%99%80%E5%B1%B1%E6%97%85%E6%B8%B8&aq=f&aqi=g10&aql=&oq=
    //http://www.google.com/search?hl=en&source=hp&q=%E6%99%AE%E9%99%80%E5%B1%B1%E6%97%85%E6%B8%B8&aq=f&aqi=&aql=&oq=
    //http://www.google.com.hk/search?hl=en&source=hp&q=%E6%99%AE%E9%99%80%E5%B1%B1%E6%97%85%E6%B8%B8&aq=f&aqi=&aql=&oq=
    //http://www.baidu.com/s?wd=%C6%D5%CD%D3%C9%BD%C2%C3%D3%CE
    //http://www.baidu.com/s?tn=site888_2_pg&lm=-1&word=%B6%AB%D6%C1%CC%EC%C6%F8%D4%A4%B1%A8?14ca450f4318ae4884ec819e9addba76=4680726efac54593a1363482f6ad087b
    //http://www.baidu.com/s?tn=site888_2_pg&bs=%C3%F7%B9%E2%CC%EC%C6%F8%D4%A4%B1%A8&f=8&wd=%C3%F7%B9%E2%CC%EC%C6%F8%D4%A4%B1%A8%C3%D7%C5%D6%CD%F8
    //http://www.baidu.com/baidu?tn=fishdesk_pg&ct=134217728&word=%B9%B2%C7%E0%B3%C7+%CC%EC%C6%F8


    var cps_id = 0;

    // google
    if(
       (
r.match(/^https?:\/\/[^\.]+\.google\.[a-z]{2,2}\/(search|url)/)
|| r.match(/^https?:\/\/[^\.]+\.google\.com\/(search|url)/)
|| r.match(/^https?:\/\/[^\.]+\.google\.com\.[a-z]{2,2}\/(search|url)/)
	)
       &&
       r.match(/[\?&]q=/)
       ){
	
	//alert('Google');
	cps_id = 23;
    }else if(
	     (
	      r.match(/^http:\/\/www\.baidu\.com\/s\?/)
	      || r.match(/^http:\/\/www\.baidu\.com\/baidu\?/)
	      )
	     && r.match(/[\?&](word|wd)=/)
	     ){
	//alert('Baidu');
	cps_id = 24;

    }else if( r.match(/^http:\/\/www\.soso\.com\/q\?/) && r.match(/[\?&]w=/)){
	cps_id = 81;
    }else if( r.match(/^http:\/\/www\.sogou\.com\/web\?/) && r.match(/[\?&]query=/)){
	cps_id = 82;
    }else if( r.match(/^http:\/\/[a-zA-Z0-9]+\.bing\.com\/search\?/) && r.match(/[\?&]q=/)){
	cps_id = 83;
    }else if(
	r.match(/^http:\/\/ganji\.com/)
	|| r.match(/^http:\/\/[^\/]+\.ganji\.com/)
    ){
	cps_id = 51;
    }else if(r.match(/^http:\/\/kaixin001\.com/)
	     || r.match(/^http:\/\/[^\/]+\.kaixin001\.com/)){
	cps_id = 54;
    }else if(r.match(/^http:\/\/douban\.com/)
	     || r.match(/^http:\/\/[^\/]+\.douban\.com/)){
	cps_id = 55;
    }else if(r.match(/^http:\/\/weibo\.com/)
	     || r.match(/^http:\/\/t\.sina\.com\.cn/)
             || r.match(/^http:\/\/([^\/]+\.)*weibo\.com/)){
	cps_id = 52;
    }else if(r.match(/^http:\/\/t\.qq\.com/)){
	cps_id = 53;
    }else if(r.match(/^http:\/\/t\.sohu\.com/)){
	cps_id = 56;
    }else if(r.match(/^http:\/\/t\.163\.com/)){
	cps_id = 57;
    }else if(r.match(/^http:\/\/([^\/]+\.)*renren\.com/)){
	cps_id = 58;
    }else if(r.match(/^http:\/\/([^\/]+\.)*58\.com/)){
	cps_id = 59;
    }else if(r.match(/^http:\/\/([^\/]+\.)*baixing\.com/)){
	cps_id = 60;
    }else if(r.match(/^http:\/\/([^\/]+\.)*travelzoo\.com/)){
	cps_id = 61;
    }else if(r.match(/^http:\/\/hao\.360\.cn/)){
	cps_id = 62;
    }else if(r.match(/^http:\/\/hap\d+\.ucweb\.com\.cn/)){
	cps_id = 63;
    }else if(r.match(/^http:\/\/www\.2345\.com/)
	     || r.match(/^http:\/\/www\.9991\.com/)){
	cps_id = 68;
    }else if(r.match(/^http:\/\/jf\.sdo\.com/)){
	cps_id = 67;
    }else if(r.match(/^http:\/\/www\.hao123\.com/)){
	cps_id = 78;
    }else if(r.match(/^http:\/\/(www\.)?tao123\.com/)){
	cps_id = 79;
    }else if(r.match(/^http:\/\/www\.1616\.com/)
	     || r.match(/^http:\/\/www\.7999\.com/)){
	cps_id = 80;
    }else if(r.match(/^http:\/\/dou\.pps\.tv/)){
        cps_id = 88;
    }else if(r.match(/^http:\/\/[^\/]+\.alipay\.com/)){
        cps_id = 89;
    }else if(r.match(/^http:\/\/[^\/]+\.so\.com/)){
        cps_id = 98;
    }else if(r.match(/^http:\/\/[^\/]+\.mafengwo\.cn/)){
        cps_id = 102;
    }else if(r.match(/^http:\/\/[^\/]+\.qyer\.com/)){
        cps_id = 103;
    }else if(r.match(/^http:\/\/go\.360\.cn/)){
        cps_id = 104;
    }else if(r.match(/^http:\/\/[^\/]*lvxing\.fm/)){
        cps_id = 105;
    }
    
    if(!cps_id) return;
    //alert(r);

    //alert(cps_id);

    var uri = new URI();

    __mp_write_cps_cookie(cps_id,0,uri._toString(),r);
    
}

/* ' implement body resize event, based on Prototype */
onloadRegisterHandler(function(){

    if(!is_ie && Prototype && Event){

	window.__oBW = window.__oBH = 0;
	
	window.__xfire=function(el,evttype) {
	    if (document.createEvent) {
		var evt = document.createEvent('HTMLEvents');
		evt.initEvent( evttype, false, false);
		el.dispatchEvent(evt);
	    } else if (document.createEventObject) {
		el.fireEvent('on' + evttype);
	    }
	};

	window.__xfireRS=function(){
	    Event.fire(window,'resize');
	    window.__xfire(window,'resize');
	};

	window.__oBW_ck=function(){
	    
	    var W = $(document.body).getWidth();
	    var H = $(document.body).getHeight();
	    
	    if(W != window.__oBW || H != window.__oBH){
	
		window.__xfireRS();
		
		window.__oBW = W;
		window.__oBH = H;

		/* fix bug */
		setTimeout(window.__xfireRS,100);
		setTimeout(window.__xfireRS,200);
		setTimeout(window.__xfireRS,400);
		setTimeout(window.__xfireRS,800);
	    }

	    setTimeout(window['__oBW_ck'],250);

	};

	setTimeout(window['__oBW_ck'],250);
    }


});


/*  file:1  */
/**
 * Copyright 2006-2008  Mipang.com.
 * All Rights Reserved.
 */


function SmartInputText(el,params)
{

    if(typeof params != 'object') params = {};

    var EXT = el;this.EL = EXT;
    if(!EXT || EXT.tagName.toLowerCase() != 'input' || (EXT.type != 'text' && EXT.type != 'password'))
	return;

    if(!EXT.v) EXT.v = EXT.value;
    if(!EXT.style) EXT.setAttribute('style','');
    if(!EXT.fc){
	if(EXT.style.color) EXT.fc=EXT.style.color;	
	else EXT.fc = '#000000';
    }
	
    try{
	/**init*/
	EXT.style.border="0px";
	EXT.style.padding="0 1px";
	
	/**draw a table*/
	var t = document.createElement('table');
	t.cellPadding="0";
	t.cellSpacing="0";
	t.border="0";
	t.setAttribute('style','');
	t.style.display="inline";

	if(!params.novalign)
	    t.style.verticalAlign='bottom';
	if(params.valign)
	    t.style.verticalAlign=params.valign;

	var r=t.insertRow(0);
	var td=r.insertCell(0);
	td.setAttribute('style','');
	td.style.padding="0px";
	td.style.border="1px solid #7f9db9";
	var div = document.createElement('div');
	div.setAttribute('style','');
	div.style.border="1px solid #fff";
	td.appendChild(div);
	

	
	var ep =EXT.parentNode;
	var ni = EXT;
	ep.replaceChild(t,EXT);
	div.appendChild(ni);
	
	
	}catch(e){}
	
    /**attach event;*/
    EXT.onfocus = function(){
	if(EXT.value==EXT.v && !params.notip)
	    EXT.value='';
	else
	    EXT.select();
	try{
	    var b1 = EXT.parentNode;
	    var b2 = b1.parentNode;
	    b1.style.borderColor="#d1fdcd";
	    b2.style.borderColor="#54ce43";
	    EXT.style.color='#000';
	    
	}catch(e){}
    };
	
    EXT.onblur = function(){
	if(String(EXT.value).replace(/^\s*/g,'').replace(/\s*$/g,'')=='')
	    EXT.value = EXT.v;		
	try{
	    var b1 = EXT.parentNode;
	    var b2 = b1.parentNode;
	    b1.style.borderColor="#fff";
	    b2.style.borderColor="#7f9db9";
	    EXT.style.color = EXT.fc;
	}catch(e){}
    };

}

/*
 * JS for site search box 
 */

function SiteSearch(params)
{
    this.EXT={};
    this.handle_str = '_MP_SiteSearch_';
    window[this.handle_str] = this;

    try{
	this.main_url = MIPANG.location.scheme + '://' + MIPANG.location.main_host;
    }catch(ex){
	this.main_url = '';
    }
    this.init(params);
}
SiteSearch.prototype.init=function(params)
{
    var EXT = this.EXT;
    var _this = this;

    EXT.tip = '站内搜索...';
    EXT.els = {
	site_s:_ge('site_s'),
	site_s_q:_ge('site_s_q_id'),
	site_s_t:_ge('site_s_t_id'),
	site_s_t_title:_ge('_s_t_list'),
	site_s_btn:_ge('site_s_btn_id'),
	site_s_f:_ge('site_s_f')
    };
    EXT.st = {st_default:0};
    if(params && params.st && params.st.length){
	EXT.st.pool = params.st;
	if(params.st_default || params.st_default){
	    EXT.st['st_default'] = params.st_default;
	}
    }
    EXT.st.current = EXT.st.st_default;

    if(EXT.els.site_s_q.value == ''){
	EXT.els.site_s_q.value = EXT.tip;
    }
    AddClass(EXT.els.site_s,'site_s_inactive');

    EXT.els.site_s_q.onfocus=function(){
	AddClass(EXT.els.site_s,'site_s_active');
	try{this.select();}catch(e){}
	try{
	    if(this.value==EXT.tip){
		this.value='';
	    }else{
	    }
	}catch(ex){}
    };

    /** not used*/
    var q_onenter = function(e){
	e = e||window.event;
	var keycode = EV_GetKeyCode(e);
	if(keycode == 13){
	    /**enter*/
	    var el = EV_GetEventTarget(e);
	    if(el.id && el.id==EXT.els.site_s_q.id)
		_this.go();
	}
    };

    /**this.EV_Attach(window,'keyup',q_onenter);*/
    /** submit by form ,enter key */
    EXT.els.site_s_f.onsubmit=function(e){
	var q = Trim(_ge('site_s_q_id').value);
	var t = EXT.st.pool[EXT.st.current][0];
	if(q && q.length){
	    var f_q = _ge('_ss_f_q');
	    var f_t = _ge('_ss_f_t');
	    if(!f_q){
		f_q = document.createElement('input');
		f_q.id = '_ss_f_q';
		f_q.type='hidden';
		f_q.name='q';
		this.appendChild(f_q);
	    }
	    if(!f_t){
		f_t = document.createElement('input');
		f_t.id = '_ss_f_t';
		f_t.type='hidden';
		f_t.name='t';
		this.appendChild(f_t);
	    }
	    f_q.value = q;
	    f_t.value = t;
	    
	    return true;
	}
	return false;
    };

    EXT.els.site_s_q.onblur=function(){
	RemoveClass(EXT.els.site_s,'site_s_active');

	try{
	if(this.value == ''){
	    this.value = EXT.tip;
	}else{
	}
	}catch(ex){}
    };
    
    EXT.els.site_s_btn.onclick=function(){
	_this.go();
    };

    this._setEvent_r(EXT.els.site_s_t,'onmouseover',this.type_list_show);
    
    /** 
    var b_onclick=function(e){
	e = e || window.event;
	var el = EV_GetEventTarget(e);
	var tl = _ge('site_s_t_list_box');
	if(!tl) return;
	var loop=4;
	while(el && loop--){
	    if(el.id && el.id == tl.id){
		return;
	    }
	    el = el.parentNode;
	}
	_this.type_list_hide();
    };

    this.EV_Attach(document.body,'click',b_onclick);
    */
};
SiteSearch.prototype._setEvent_r=function(el,en,f){
    /** set Recursive */
    while(el){
	try{el[en] = f;}catch(e){}
	if(el.hasChildNodes()){
	    for(var i=0;i<el.childNodes.length;i++){
		this._setEvent_r(el.childNodes[i],en,f);
	    }
	}
	return;
    }
    return;
};
SiteSearch.prototype.type_list_show=function(e){
    var _this = window['_MP_SiteSearch_'];
    var EXT = _this.EXT;
    
    if(EXT._tl_hide_timestamp && (new Date()).getTime() - EXT._tl_hide_timestamp < 100)
	return;

    if(!EXT._tl_show)
	EXT._tl_show = true;
    else
	return;

    var div = CreateDIV2(window,'site_s_t_list_box');
    if(!div.style) div.setAttribute('style','');
    var ds = div.style;
    var t_offset = GetPageOffset(EXT.els.site_s_t);
    ds.top = (t_offset.y-1)+'px';
    ds.left = (t_offset.x-EXT.els.site_s_btn.offsetWidth)+'px'
    ds.display = '';
    var h=[];
    for(var i=0;i<EXT.st.pool.length;i++){
	var t = EXT.st.pool[i];
	var d = EXT.st.st_default;
	h.push('<span class="tl'+(i+1 == EXT.st.pool.length?' tl_last':'')+(d==i?' tl_sel':'')+'" onmouseover="javascript:AddClass(this,\'tl_hover\');" onmouseout="javascript:RemoveClass(this,\'tl_hover\');" onclick="javascript:window.'+_this.handle_str+'.pre_go('+i+');">'+HtmlEscape(t[1])+'</span>');

    }
    div.innerHTML = h.join('');
    ShowElement(div,true);

    /**EV attach*/
    if(!div.ev_attached){
	var div_onmouseover=function(e){
	    e = e || window.event;
	    if(!_this.EXT._tl_show) return;
	    var el = EV_GetEventTarget(e);
	    var tl = _ge('site_s_t_list_box');
	    if(!tl) return;
	    var loop=4;
	    while(el && loop--){
		if(el.id && (el.id == tl.id || el.id == EXT.els.site_s_t.id)){
		    return;
		}
		el = el.parentNode;
	    }
	    _this.type_list_hide();
	};
	_this.EV_Attach(document.body,'mouseover',div_onmouseover);
	div.ev_attached=true;
    }
};
SiteSearch.prototype.type_list_hide=function(){
    ShowElement(_ge('site_s_t_list_box'),false);
    this.EXT._tl_show = false;
    this.EXT._tl_hide_timestamp = (new Date()).getTime();
};
SiteSearch.prototype.go=function(){
    var EXT = this.EXT;
    var q = String(EXT.els.site_s_q.value);
    if(q && q.length){
	var url = this.main_url+'/search?t='+EXT.st.pool[EXT.st.current][0]+'&q='+UrlEncode(q);
	var r =	window.open(url,'_blank');
	/**
	if(!r)
	    EXT.els.site_s_f.submit();
	*/
	if(!r)
	    top.location.href = url;
	if(!r){
	    var fake = CreateDIV2(window,'site_s_fake_form');
	    if(!fake.style) fake.setAttribute('style','');
	    var fs=fake.style;
	    fs.position='absolute';
	    fs.left=fs.top='-1000px';
	    fs.width=fs.height='1px';
	    fake.innerHTML = '<form action="'+this.main_url+'/search" method="get"><input name="t" type="hidden" value="'+EXT.st.pool[EXT.st.current][0]+'"/><input name="q" type="hidden" value="'+HtmlEscape(q)+'" /><input type="submit" value="Submit" /></form>';
	    setTimeout(function(){
		    var ff=_ge('site_s_fake_form');
		    var f=ff.getElementsByTagName('form')[0];
		    f.setAttribute('target','ssblank');
		    setTimeout(function(){f.submit();},200);
		},100);
	}
    }

};
SiteSearch.prototype.pre_go=function(t){
    var EXT = this.EXT;
    EXT.st.current=t;
    EXT.els.site_s_t_title.innerHTML = HtmlEscape(EXT.st.pool[t][1]);
    this.type_list_hide();
    this.go();
};
SiteSearch.prototype.EV_Attach=function(o,a,f,i){
    i = !(!i);
    if(o.addEventListener){
	o.addEventListener(a,f,i);
    }else if(o.attachEvent){
	o.attachEvent("on"+a,f);
    }
};


/** down menu **/

function mp_down_menu()
{
    this.__name__ = 'mp_down_menu_' + gen_unique();
    this.zIndex = 50;/* default zindex **/
    this.menuID = 'mpDMbox';
}
mp_down_menu.prototype.set_context=function(el,options)
{
    this.context = el;
    this.context_options = options || {};
    return this;
};
mp_down_menu.prototype.set_list=function(list)
{
    /**list::[] **/
    this.list = list;
    return this;
};
mp_down_menu.prototype.set_options=function(options)
{
    for(x in options)
	this[x] = options[x];
    
    return this;
};
mp_down_menu.prototype.init=function()
{
    onloadRegisterHandler(function(){ this.__init(); }.bind(this));
    return this;
}
mp_down_menu.prototype.__init=function()
{

    if(this.context[this.__name__ + 'onclick'])
	return this;

    this.__init_css();

    var container = document.createElement('div');
    container.id = this.__name__ + '_container_' + gen_unique();
    container.setAttribute('style','');
    container.style.position = 'absolute';
    container.style.zIndex = this.zIndex;
    container.style.left = container.style.top = '-1000px';
    container.style.display = 'none';

    this.container = container;

    

    addEventBase(this.container,'click',function(e){
	    stopPropagation(e);
	},this.__name__+'_container_onclick');

    

    onloadRegisterHandler(function(){
	    document.body.appendChild(this.container);
	}.bind(this));


    var iframe = document.createElement('iframe');
    iframe.id = this.__name__ + '_iframe_' + gen_unique();
    iframe.frameBorder='0';
    iframe.setAttribute('style','');
    iframe.style.position = 'absolute';
    iframe.style.zIndex = this.zIndex-1;
    iframe.style.left = this.container.style.top = '-1000px';
    iframe.style.display='none';

    /**filter:alpha(opacity=0);*/
    if("opacity" in iframe.style){
	iframe.style.opacity=0;
    }else if("MozOpacity" in iframe.style){
	iframe.style.MozOpacity=0;
    }else if("filter" in iframe.style){
	iframe.style.filter="alpha(opacity=0)";
    }
    this.iframe = iframe;

    onloadRegisterHandler(function(){
	    document.body.appendChild(this.iframe);
	}.bind(this));


    addEventBase(this.context,'click',function(e){
	    this.show();
	stopPropagation(e);
	return false;
	}.bind(this),this.__name__+'_context_onclick');


    this.context[this.__name__ + 'onclick'] = true;

    addEventBase(document,'click',function(e){
	    this.hide();
	}.bind(this),this.__name__+'_body_onclick');

    return this;
};
mp_down_menu.prototype.hide=function()
{

    this.container.style.display = 'none';
    this.iframe.style.display = 'none';

    this.container.style.top = this.container.style.left = '-1000px';
    this.iframe.style.top = this.iframe.style.left = '-1000px';

    return this;
};
mp_down_menu.prototype.show=function()
{
    
    set_inner_html(this.container,this.__gen_html());

    this.container.style.display = '';
    this.iframe.style.display = '';

    this.position_fix();

    return this;
};

mp_down_menu.prototype.position_fix = function()
{
    var cp = GetPageOffset(this.context);
    var cw = this.context.offsetWidth;
    var ch = this.context.offsetHeight;
    
    var mw = this.container.offsetWidth;
    var mh = this.container.offsetHeight;

    this.container.style.top = this.iframe.style.top = (cp.y + ch + 2) + 'px';
    if(typeof this.context_options != 'undefined' &&
       typeof this.context_options.align != 'undefined' &&
       this.context_options.align == 'right' ){
	this.container.style.left = this.iframe.style.left = (cp.x + cw - mw) + 'px';
    }else{
	this.container.style.left = this.iframe.style.left = cp.x + 'px';
    }

    this.iframe.style.width = mw + 'px';
    this.iframe.style.height = mh + 'px';
    
    return this;
};

mp_down_menu.prototype.__gen_html=function()
{
    var html = '<div id="'+this.menuID+'">';
    
    for(var i=0;i<this.list.length;i++){
	var a = this.list[i];
	html+= '<div class="mItem"'
	    +' onmouseover="javascript:this.className=\'mItem mItemMO\';return false;"'
	    +' onmouseout="javascript:this.className=\'mItem\';return false;">'+a+'</div>';
    }
    html += '</div>';
    return html;
};
mp_down_menu.prototype.__init_css=function()
{
    var css = this.css || null;

    if(!css){
	/** default css **/
	css = '#mpDMbox { background-color:#ebf4fa;border-width:1px; border-style:solid; border-color:#69f #36c #36c #69f;'
	    +' padding:3px 0;text-align:left;font-size:13px; }';
	css += '#mpDMbox .mItem { padding:0 0 1px 0; }';
	css += '#mpDMbox a { color:#36c;background-color:transparent; text-decoration:none; display:block;padding:3px 8px 2px 8px;}';
	css += '#mpDMbox a:hover { color:#36c;background-color:transparent; text-decoration:underline;}';
	css += '#mpDMbox .mItemMO { background-color:#36c;color:#fff; }';
	css += '#mpDMbox .mItemMO a, ';
	css += '#mpDMbox .mItemMO a:hover{ background-color:#36c;color:#fff;text-decoration:none; }';

    }

    MP_appendCssText(this.__name__ + '_css' ,css);
	
    return this;
};

/*  file:2  */
/* -*- coding: utf-8-unix -*- */
/* copy cookie between .mipang.com and .mipangwang.com */

function __mp_cookie_copy_between_2domains()
{
    var validCookieNames = new Set(
		["cookie_session"
		 ,"_mcka"
		 ,"_tsc","_tss"
		 ,"__mcps"
		 ,"PYNSUID"
		 ,"isFromTB"
		 ,"isFromAL"
		 ,"isFromQQ"
		 ,"isFromQQCB"
		 ,"PHPSESSID"
		 //,"_utma"
		 //,"_utmb"
		 //,"_utmc"
		 //,"_utmz"
		 ,"_MVICC"
		]);
    var inValidCookieNames = new Set(
		["__utma",
		 "__utmc",
		 "__utmz"
		]);
    
    //alert(document.cookie);

    var ckchunk = String(document.cookie).split(';');
    var cknames = [];
    var i;
    var hasLoginCookie = false;
    for(i=0;ckchunk && ckchunk.length && i<ckchunk.length;i++){
		
		var cv = Trim(ckchunk[i]).split('=');
		
		// copy all cookies
		if(!validCookieNames.contains(cv[0])) continue;


		if(inValidCookieNames.contains(cv[0])) continue;
		
		cknames.push([cv[0],cv[1]]);

		if(cv[0] == "cookie_session")
			hasLoginCookie = true;
    }

    if(!hasLoginCookie){
		cknames.push(["cookie_session","0_0"]);
    }

    //alert(cknames);

    
    var cHx = String(document.location.href).match(/^https?:\/\/([^\/]+).*/);

    if(!cHx) return;
    var cHost = cHx[1];

    var tHost = "www.mipangwang.com";
    var tDomain = ".mipangwang.com";

    if(cHost.indexOf("test.mipang.com") != -1){
		tHost = "test.mipangwang.com";
		tDomain = ".mipangwang.com";
    }else if(cHost.indexOf("mipang.com") != -1){
		tHost = "www.mipangwang.com";
		tDomain = ".mipangwang.com";
    }else if(cHost.indexOf("test.mipangwang.com") != -1){
		tHost = "nukq.test.mipang.com";
		tDomain = ".mipang.com";
    }else if(cHost.indexOf(".mipangwang.com") != -1){
		tHost = "www.mipang.com";
		tDomain = ".mipang.com";
    }
    
    //alert(tDomain);
    
    if(document.body && "http:" == document.location.protocol){
		var hash = [],i;
		
		for(i=0;i<cknames.length;i++){
			hash.push(cknames[i][0] + '=' + cknames[i][1]);
		}

		//alert(hash.join("&"));
		
		var x = document.createElement('div');
		x.setAttribute('style','');
		x.style.height="0";
		x.style.overflow="hidden";
		x.innerHTML = '<iframe src="http://'+tHost+'/js/cookiecopy.html#'+hash.join('&')+'"></iframe>';
		document.body.appendChild(x);
    }

}

onloadRegisterHandler(function(){try{__mp_cookie_copy_between_2domains();}catch(Ex){}});

/*  file:3  */
/*  Prototype JavaScript framework, version 1.6.1
 *  (c) 2005-2009 Sam Stephenson
 *
 *  Prototype is freely distributable under the terms of an MIT-style license.
 *  For details, see the Prototype web site: http://www.prototypejs.org/
 *
 *--------------------------------------------------------------------------*/

var Prototype = {
  Version: '1.6.1',

  Browser: (function(){
    var ua = navigator.userAgent;
    var isOpera = Object.prototype.toString.call(window.opera) == '[object Opera]';
    return {
      IE:             !!window.attachEvent && !isOpera,
      Opera:          isOpera,
      WebKit:         ua.indexOf('AppleWebKit/') > -1,
      Gecko:          ua.indexOf('Gecko') > -1 && ua.indexOf('KHTML') === -1,
      MobileSafari:   /Apple.*Mobile.*Safari/.test(ua)
    }
  })(),

  BrowserFeatures: {
    XPath: !!document.evaluate,
    SelectorsAPI: !!document.querySelector,
    ElementExtensions: (function() {
      var constructor = window.Element || window.HTMLElement;
      return !!(constructor && constructor.prototype);
    })(),
    SpecificElementExtensions: (function() {
      if (typeof window.HTMLDivElement !== 'undefined')
        return true;

      var div = document.createElement('div');
      var form = document.createElement('form');
      var isSupported = false;

      if (div['__proto__'] && (div['__proto__'] !== form['__proto__'])) {
        isSupported = true;
      }

      div = form = null;

      return isSupported;
    })()
  },

  ScriptFragment: '<script[^>]*>([\\S\\s]*?)<\/script>',
  JSONFilter: /^\/\*-secure-([\s\S]*)\*\/\s*$/,

  emptyFunction: function() { },
  K: function(x) { return x }
};

if (Prototype.Browser.MobileSafari)
  Prototype.BrowserFeatures.SpecificElementExtensions = false;


var Abstract = { };


var Try = {
  these: function() {
    var returnValue;

    for (var i = 0, length = arguments.length; i < length; i++) {
      var lambda = arguments[i];
      try {
        returnValue = lambda();
        break;
      } catch (e) { }
    }

    return returnValue;
  }
};

/* Based on Alex Arnell's inheritance implementation. */

var Class = (function() {
  function subclass() {};
  function create() {
    var parent = null, properties = $A(arguments);
    if (Object.isFunction(properties[0]))
      parent = properties.shift();

    function klass() {
      this.initialize.apply(this, arguments);
    }

    Object.extend(klass, Class.Methods);
    klass.superclass = parent;
    klass.subclasses = [];

    if (parent) {
      subclass.prototype = parent.prototype;
      klass.prototype = new subclass;
      parent.subclasses.push(klass);
    }

    for (var i = 0; i < properties.length; i++)
      klass.addMethods(properties[i]);

    if (!klass.prototype.initialize)
      klass.prototype.initialize = Prototype.emptyFunction;

    klass.prototype.constructor = klass;
    return klass;
  }

  function addMethods(source) {
    var ancestor   = this.superclass && this.superclass.prototype;
    var properties = Object.keys(source);

    if (!Object.keys({ toString: true }).length) {
      if (source.toString != Object.prototype.toString)
        properties.push("toString");
      if (source.valueOf != Object.prototype.valueOf)
        properties.push("valueOf");
    }

    for (var i = 0, length = properties.length; i < length; i++) {
      var property = properties[i], value = source[property];
      if (ancestor && Object.isFunction(value) &&
          value.argumentNames().first() == "$super") {
        var method = value;
        value = (function(m) {
          return function() { return ancestor[m].apply(this, arguments); };
        })(property).wrap(method);

        value.valueOf = method.valueOf.bind(method);
        value.toString = method.toString.bind(method);
      }
      this.prototype[property] = value;
    }

    return this;
  }

  return {
    create: create,
    Methods: {
      addMethods: addMethods
    }
  };
})();
(function() {

  var _toString = Object.prototype.toString;

  function extend(destination, source) {
    for (var property in source)
      destination[property] = source[property];
    return destination;
  }

  function inspect(object) {
    try {
      if (isUndefined(object)) return 'undefined';
      if (object === null) return 'null';
      return object.inspect ? object.inspect() : String(object);
    } catch (e) {
      if (e instanceof RangeError) return '...';
      throw e;
    }
  }

  function toJSON(object) {
    var type = typeof object;
    switch (type) {
      case 'undefined':
      case 'function':
      case 'unknown': return;
      case 'boolean': return object.toString();
    }

    if (object === null) return 'null';
    if (object.toJSON) return object.toJSON();
    if (isElement(object)) return;

    var results = [];
    for (var property in object) {
      var value = toJSON(object[property]);
      if (!isUndefined(value))
        results.push(property.toJSON() + ': ' + value);
    }

    return '{' + results.join(', ') + '}';
  }

  function toQueryString(object) {
    return $H(object).toQueryString();
  }

  function toHTML(object) {
    return object && object.toHTML ? object.toHTML() : String.interpret(object);
  }

  function keys(object) {
    var results = [];
    for (var property in object)
      results.push(property);
    return results;
  }

  function values(object) {
    var results = [];
    for (var property in object)
      results.push(object[property]);
    return results;
  }

  function clone(object) {
    return extend({ }, object);
  }

  function isElement(object) {
    return !!(object && object.nodeType == 1);
  }

  function isArray(object) {
    return _toString.call(object) == "[object Array]";
  }


  function isHash(object) {
    return object instanceof Hash;
  }

  function isFunction(object) {
    return typeof object === "function";
  }

  function isString(object) {
    return _toString.call(object) == "[object String]";
  }

  function isNumber(object) {
    return _toString.call(object) == "[object Number]";
  }

  function isUndefined(object) {
    return typeof object === "undefined";
  }

  extend(Object, {
    extend:        extend,
    inspect:       inspect,
    toJSON:        toJSON,
    toQueryString: toQueryString,
    toHTML:        toHTML,
    keys:          keys,
    values:        values,
    clone:         clone,
    isElement:     isElement,
    isArray:       isArray,
    isHash:        isHash,
    isFunction:    isFunction,
    isString:      isString,
    isNumber:      isNumber,
    isUndefined:   isUndefined
  });
})();
Object.extend(Function.prototype, (function() {
  var slice = Array.prototype.slice;

  function update(array, args) {
    var arrayLength = array.length, length = args.length;
    while (length--) array[arrayLength + length] = args[length];
    return array;
  }

  function merge(array, args) {
    array = slice.call(array, 0);
    return update(array, args);
  }

  function argumentNames() {
    var names = this.toString().match(/^[\s\(]*function[^(]*\(([^)]*)\)/)[1]
      .replace(/\/\/.*?[\r\n]|\/\*(?:.|[\r\n])*?\*\//g, '')
      .replace(/\s+/g, '').split(',');
    return names.length == 1 && !names[0] ? [] : names;
  }

  function bind(context) {
    if (arguments.length < 2 && Object.isUndefined(arguments[0])) return this;
    var __method = this, args = slice.call(arguments, 1);
    return function() {
      var a = merge(args, arguments);
      return __method.apply(context, a);
    }
  }

  function bindAsEventListener(context) {
    var __method = this, args = slice.call(arguments, 1);
    return function(event) {
      var a = update([event || window.event], args);
      return __method.apply(context, a);
    }
  }

  function curry() {
    if (!arguments.length) return this;
    var __method = this, args = slice.call(arguments, 0);
    return function() {
      var a = merge(args, arguments);
      return __method.apply(this, a);
    }
  }

  function delay(timeout) {
    var __method = this, args = slice.call(arguments, 1);
    timeout = timeout * 1000
    return window.setTimeout(function() {
      return __method.apply(__method, args);
    }, timeout);
  }

  function defer() {
    var args = update([0.01], arguments);
    return this.delay.apply(this, args);
  }

  function wrap(wrapper) {
    var __method = this;
    return function() {
      var a = update([__method.bind(this)], arguments);
      return wrapper.apply(this, a);
    }
  }

  function methodize() {
    if (this._methodized) return this._methodized;
    var __method = this;
    return this._methodized = function() {
      var a = update([this], arguments);
      return __method.apply(null, a);
    };
  }

  return {
    argumentNames:       argumentNames,
    bind:                bind,
    bindAsEventListener: bindAsEventListener,
    curry:               curry,
    delay:               delay,
    defer:               defer,
    wrap:                wrap,
    methodize:           methodize
  }
})());


Date.prototype.toJSON = function() {
  return '"' + this.getUTCFullYear() + '-' +
    (this.getUTCMonth() + 1).toPaddedString(2) + '-' +
    this.getUTCDate().toPaddedString(2) + 'T' +
    this.getUTCHours().toPaddedString(2) + ':' +
    this.getUTCMinutes().toPaddedString(2) + ':' +
    this.getUTCSeconds().toPaddedString(2) + 'Z"';
};


RegExp.prototype.match = RegExp.prototype.test;

RegExp.escape = function(str) {
  return String(str).replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');
};
var PeriodicalExecuter = Class.create({
  initialize: function(callback, frequency) {
    this.callback = callback;
    this.frequency = frequency;
    this.currentlyExecuting = false;

    this.registerCallback();
  },

  registerCallback: function() {
    this.timer = setInterval(this.onTimerEvent.bind(this), this.frequency * 1000);
  },

  execute: function() {
    this.callback(this);
  },

  stop: function() {
    if (!this.timer) return;
    clearInterval(this.timer);
    this.timer = null;
  },

  onTimerEvent: function() {
    if (!this.currentlyExecuting) {
      try {
        this.currentlyExecuting = true;
        this.execute();
        this.currentlyExecuting = false;
      } catch(e) {
        this.currentlyExecuting = false;
        throw e;
      }
    }
  }
});
Object.extend(String, {
  interpret: function(value) {
    return value == null ? '' : String(value);
  },
  specialChar: {
    '\b': '\\b',
    '\t': '\\t',
    '\n': '\\n',
    '\f': '\\f',
    '\r': '\\r',
    '\\': '\\\\'
  }
});

Object.extend(String.prototype, (function() {

  function prepareReplacement(replacement) {
    if (Object.isFunction(replacement)) return replacement;
    var template = new Template(replacement);
    return function(match) { return template.evaluate(match) };
  }

  function gsub(pattern, replacement) {
    var result = '', source = this, match;
    replacement = prepareReplacement(replacement);

    if (Object.isString(pattern))
      pattern = RegExp.escape(pattern);

    if (!(pattern.length || pattern.source)) {
      replacement = replacement('');
      return replacement + source.split('').join(replacement) + replacement;
    }

    while (source.length > 0) {
      if (match = source.match(pattern)) {
        result += source.slice(0, match.index);
        result += String.interpret(replacement(match));
        source  = source.slice(match.index + match[0].length);
      } else {
        result += source, source = '';
      }
    }
    return result;
  }

  function sub(pattern, replacement, count) {
    replacement = prepareReplacement(replacement);
    count = Object.isUndefined(count) ? 1 : count;

    return this.gsub(pattern, function(match) {
      if (--count < 0) return match[0];
      return replacement(match);
    });
  }

  function scan(pattern, iterator) {
    this.gsub(pattern, iterator);
    return String(this);
  }

  function truncate(length, truncation) {
    length = length || 30;
    truncation = Object.isUndefined(truncation) ? '...' : truncation;
    return this.length > length ?
      this.slice(0, length - truncation.length) + truncation : String(this);
  }

  function strip() {
    return this.replace(/^\s+/, '').replace(/\s+$/, '');
  }

  function stripTags() {
    return this.replace(/<\w+(\s+("[^"]*"|'[^']*'|[^>])+)?>|<\/\w+>/gi, '');
  }

  function stripScripts() {
    return this.replace(new RegExp(Prototype.ScriptFragment, 'img'), '');
  }

  function extractScripts() {
    var matchAll = new RegExp(Prototype.ScriptFragment, 'img');
    var matchOne = new RegExp(Prototype.ScriptFragment, 'im');
    return (this.match(matchAll) || []).map(function(scriptTag) {
      return (scriptTag.match(matchOne) || ['', ''])[1];
    });
  }

  function evalScripts() {
    return this.extractScripts().map(function(script) { return eval(script) });
  }

  function escapeHTML() {
    return this.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  function unescapeHTML() {
    return this.stripTags().replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
  }


  function toQueryParams(separator) {
    var match = this.strip().match(/([^?#]*)(#.*)?$/);
    if (!match) return { };

    return match[1].split(separator || '&').inject({ }, function(hash, pair) {
      if ((pair = pair.split('='))[0]) {
        var key = decodeURIComponent(pair.shift());
        var value = pair.length > 1 ? pair.join('=') : pair[0];
        if (value != undefined) value = decodeURIComponent(value);

        if (key in hash) {
          if (!Object.isArray(hash[key])) hash[key] = [hash[key]];
          hash[key].push(value);
        }
        else hash[key] = value;
      }
      return hash;
    });
  }

  function toArray() {
    return this.split('');
  }

  function succ() {
    return this.slice(0, this.length - 1) +
      String.fromCharCode(this.charCodeAt(this.length - 1) + 1);
  }

  function times(count) {
    return count < 1 ? '' : new Array(count + 1).join(this);
  }

  function camelize() {
    var parts = this.split('-'), len = parts.length;
    if (len == 1) return parts[0];

    var camelized = this.charAt(0) == '-'
      ? parts[0].charAt(0).toUpperCase() + parts[0].substring(1)
      : parts[0];

    for (var i = 1; i < len; i++)
      camelized += parts[i].charAt(0).toUpperCase() + parts[i].substring(1);

    return camelized;
  }

  function capitalize() {
    return this.charAt(0).toUpperCase() + this.substring(1).toLowerCase();
  }

  function underscore() {
    return this.replace(/::/g, '/')
               .replace(/([A-Z]+)([A-Z][a-z])/g, '$1_$2')
               .replace(/([a-z\d])([A-Z])/g, '$1_$2')
               .replace(/-/g, '_')
               .toLowerCase();
  }

  function dasherize() {
    return this.replace(/_/g, '-');
  }

  function inspect(useDoubleQuotes) {
    var escapedString = this.replace(/[\x00-\x1f\\]/g, function(character) {
      if (character in String.specialChar) {
        return String.specialChar[character];
      }
      return '\\u00' + character.charCodeAt().toPaddedString(2, 16);
    });
    if (useDoubleQuotes) return '"' + escapedString.replace(/"/g, '\\"') + '"';
    return "'" + escapedString.replace(/'/g, '\\\'') + "'";
  }

  function toJSON() {
    return this.inspect(true);
  }

  function unfilterJSON(filter) {
    return this.replace(filter || Prototype.JSONFilter, '$1');
  }

  function isJSON() {
    var str = this;
    if (str.blank()) return false;
    str = this.replace(/\\./g, '@').replace(/"[^"\\\n\r]*"/g, '');
    return (/^[,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]*$/).test(str);
  }

  function evalJSON(sanitize) {
    var json = this.unfilterJSON();
    try {
      if (!sanitize || json.isJSON()) return eval('(' + json + ')');
    } catch (e) { }
    throw new SyntaxError('Badly formed JSON string: ' + this.inspect());
  }

  function include(pattern) {
    return this.indexOf(pattern) > -1;
  }

  function startsWith(pattern) {
    return this.indexOf(pattern) === 0;
  }

  function endsWith(pattern) {
    var d = this.length - pattern.length;
    return d >= 0 && this.lastIndexOf(pattern) === d;
  }

  function empty() {
    return this == '';
  }

  function blank() {
    return /^\s*$/.test(this);
  }

  function interpolate(object, pattern) {
    return new Template(this, pattern).evaluate(object);
  }

  return {
    gsub:           gsub,
    sub:            sub,
    scan:           scan,
    truncate:       truncate,
    strip:          String.prototype.trim ? String.prototype.trim : strip,
    stripTags:      stripTags,
    stripScripts:   stripScripts,
    extractScripts: extractScripts,
    evalScripts:    evalScripts,
    escapeHTML:     escapeHTML,
    unescapeHTML:   unescapeHTML,
    toQueryParams:  toQueryParams,
    parseQuery:     toQueryParams,
    toArray:        toArray,
    succ:           succ,
    times:          times,
    camelize:       camelize,
    capitalize:     capitalize,
    underscore:     underscore,
    dasherize:      dasherize,
    inspect:        inspect,
    toJSON:         toJSON,
    unfilterJSON:   unfilterJSON,
    isJSON:         isJSON,
    evalJSON:       evalJSON,
    include:        include,
    startsWith:     startsWith,
    endsWith:       endsWith,
    empty:          empty,
    blank:          blank,
    interpolate:    interpolate
  };
})());

var Template = Class.create({
  initialize: function(template, pattern) {
    this.template = template.toString();
    this.pattern = pattern || Template.Pattern;
  },

  evaluate: function(object) {
    if (object && Object.isFunction(object.toTemplateReplacements))
      object = object.toTemplateReplacements();

    return this.template.gsub(this.pattern, function(match) {
      if (object == null) return (match[1] + '');

      var before = match[1] || '';
      if (before == '\\') return match[2];

      var ctx = object, expr = match[3];
      var pattern = /^([^.[]+|\[((?:.*?[^\\])?)\])(\.|\[|$)/;
      match = pattern.exec(expr);
      if (match == null) return before;

      while (match != null) {
        var comp = match[1].startsWith('[') ? match[2].replace(/\\\\]/g, ']') : match[1];
        ctx = ctx[comp];
        if (null == ctx || '' == match[3]) break;
        expr = expr.substring('[' == match[3] ? match[1].length : match[0].length);
        match = pattern.exec(expr);
      }

      return before + String.interpret(ctx);
    });
  }
});
Template.Pattern = /(^|.|\r|\n)(#\{(.*?)\})/;

var $break = { };

var Enumerable = (function() {
  function each(iterator, context) {
    var index = 0;
    try {
      this._each(function(value) {
        iterator.call(context, value, index++);
      });
    } catch (e) {
      if (e != $break) throw e;
    }
    return this;
  }

  function eachSlice(number, iterator, context) {
    var index = -number, slices = [], array = this.toArray();
    if (number < 1) return array;
    while ((index += number) < array.length)
      slices.push(array.slice(index, index+number));
    return slices.collect(iterator, context);
  }

  function all(iterator, context) {
    iterator = iterator || Prototype.K;
    var result = true;
    this.each(function(value, index) {
      result = result && !!iterator.call(context, value, index);
      if (!result) throw $break;
    });
    return result;
  }

  function any(iterator, context) {
    iterator = iterator || Prototype.K;
    var result = false;
    this.each(function(value, index) {
      if (result = !!iterator.call(context, value, index))
        throw $break;
    });
    return result;
  }

  function collect(iterator, context) {
    iterator = iterator || Prototype.K;
    var results = [];
    this.each(function(value, index) {
      results.push(iterator.call(context, value, index));
    });
    return results;
  }

  function detect(iterator, context) {
    var result;
    this.each(function(value, index) {
      if (iterator.call(context, value, index)) {
        result = value;
        throw $break;
      }
    });
    return result;
  }

  function findAll(iterator, context) {
    var results = [];
    this.each(function(value, index) {
      if (iterator.call(context, value, index))
        results.push(value);
    });
    return results;
  }

  function grep(filter, iterator, context) {
    iterator = iterator || Prototype.K;
    var results = [];

    if (Object.isString(filter))
      filter = new RegExp(RegExp.escape(filter));

    this.each(function(value, index) {
      if (filter.match(value))
        results.push(iterator.call(context, value, index));
    });
    return results;
  }

  function include(object) {
    if (Object.isFunction(this.indexOf))
      if (this.indexOf(object) != -1) return true;

    var found = false;
    this.each(function(value) {
      if (value == object) {
        found = true;
        throw $break;
      }
    });
    return found;
  }

  function inGroupsOf(number, fillWith) {
    fillWith = Object.isUndefined(fillWith) ? null : fillWith;
    return this.eachSlice(number, function(slice) {
      while(slice.length < number) slice.push(fillWith);
      return slice;
    });
  }

  function inject(memo, iterator, context) {
    this.each(function(value, index) {
      memo = iterator.call(context, memo, value, index);
    });
    return memo;
  }

  function invoke(method) {
    var args = $A(arguments).slice(1);
    return this.map(function(value) {
      return value[method].apply(value, args);
    });
  }

  function max(iterator, context) {
    iterator = iterator || Prototype.K;
    var result;
    this.each(function(value, index) {
      value = iterator.call(context, value, index);
      if (result == null || value >= result)
        result = value;
    });
    return result;
  }

  function min(iterator, context) {
    iterator = iterator || Prototype.K;
    var result;
    this.each(function(value, index) {
      value = iterator.call(context, value, index);
      if (result == null || value < result)
        result = value;
    });
    return result;
  }

  function partition(iterator, context) {
    iterator = iterator || Prototype.K;
    var trues = [], falses = [];
    this.each(function(value, index) {
      (iterator.call(context, value, index) ?
        trues : falses).push(value);
    });
    return [trues, falses];
  }

  function pluck(property) {
    var results = [];
    this.each(function(value) {
      results.push(value[property]);
    });
    return results;
  }

  function reject(iterator, context) {
    var results = [];
    this.each(function(value, index) {
      if (!iterator.call(context, value, index))
        results.push(value);
    });
    return results;
  }

  function sortBy(iterator, context) {
    return this.map(function(value, index) {
      return {
        value: value,
        criteria: iterator.call(context, value, index)
      };
    }).sort(function(left, right) {
      var a = left.criteria, b = right.criteria;
      return a < b ? -1 : a > b ? 1 : 0;
    }).pluck('value');
  }

  function toArray() {
    return this.map();
  }

  function zip() {
    var iterator = Prototype.K, args = $A(arguments);
    if (Object.isFunction(args.last()))
      iterator = args.pop();

    var collections = [this].concat(args).map($A);
    return this.map(function(value, index) {
      return iterator(collections.pluck(index));
    });
  }

  function size() {
    return this.toArray().length;
  }

  function inspect() {
    return '#<Enumerable:' + this.toArray().inspect() + '>';
  }









  return {
    each:       each,
    eachSlice:  eachSlice,
    all:        all,
    every:      all,
    any:        any,
    some:       any,
    collect:    collect,
    map:        collect,
    detect:     detect,
    findAll:    findAll,
    select:     findAll,
    filter:     findAll,
    grep:       grep,
    include:    include,
    member:     include,
    inGroupsOf: inGroupsOf,
    inject:     inject,
    invoke:     invoke,
    max:        max,
    min:        min,
    partition:  partition,
    pluck:      pluck,
    reject:     reject,
    sortBy:     sortBy,
    toArray:    toArray,
    entries:    toArray,
    zip:        zip,
    size:       size,
    inspect:    inspect,
    find:       detect
  };
})();
function $A(iterable) {
  if (!iterable) return [];
  if ('toArray' in Object(iterable)) return iterable.toArray();
  var length = iterable.length || 0, results = new Array(length);
  while (length--) results[length] = iterable[length];
  return results;
}

function $w(string) {
  if (!Object.isString(string)) return [];
  string = string.strip();
  return string ? string.split(/\s+/) : [];
}

Array.from = $A;


(function() {
  var arrayProto = Array.prototype,
      slice = arrayProto.slice,
      _each = arrayProto.forEach; // use native browser JS 1.6 implementation if available

  function each(iterator) {
    for (var i = 0, length = this.length; i < length; i++)
      iterator(this[i]);
  }
  if (!_each) _each = each;

  function clear() {
    this.length = 0;
    return this;
  }

  function first() {
    return this[0];
  }

  function last() {
    return this[this.length - 1];
  }

  function compact() {
    return this.select(function(value) {
      return value != null;
    });
  }

  function flatten() {
    return this.inject([], function(array, value) {
      if (Object.isArray(value))
        return array.concat(value.flatten());
      array.push(value);
      return array;
    });
  }

  function without() {
    var values = slice.call(arguments, 0);
    return this.select(function(value) {
      return !values.include(value);
    });
  }

  function reverse(inline) {
    return (inline !== false ? this : this.toArray())._reverse();
  }

  function uniq(sorted) {
    return this.inject([], function(array, value, index) {
      if (0 == index || (sorted ? array.last() != value : !array.include(value)))
        array.push(value);
      return array;
    });
  }

  function intersect(array) {
    return this.uniq().findAll(function(item) {
      return array.detect(function(value) { return item === value });
    });
  }


  function clone() {
    return slice.call(this, 0);
  }

  function size() {
    return this.length;
  }

  function inspect() {
    return '[' + this.map(Object.inspect).join(', ') + ']';
  }

  function toJSON() {
    var results = [];
    this.each(function(object) {
      var value = Object.toJSON(object);
      if (!Object.isUndefined(value)) results.push(value);
    });
    return '[' + results.join(', ') + ']';
  }

  function indexOf(item, i) {
    i || (i = 0);
    var length = this.length;
    if (i < 0) i = length + i;
    for (; i < length; i++)
      if (this[i] === item) return i;
    return -1;
  }

  function lastIndexOf(item, i) {
    i = isNaN(i) ? this.length : (i < 0 ? this.length + i : i) + 1;
    var n = this.slice(0, i).reverse().indexOf(item);
    return (n < 0) ? n : i - n - 1;
  }

  function concat() {
    var array = slice.call(this, 0), item;
    for (var i = 0, length = arguments.length; i < length; i++) {
      item = arguments[i];
      if (Object.isArray(item) && !('callee' in item)) {
        for (var j = 0, arrayLength = item.length; j < arrayLength; j++)
          array.push(item[j]);
      } else {
        array.push(item);
      }
    }
    return array;
  }

  Object.extend(arrayProto, Enumerable);

  if (!arrayProto._reverse)
    arrayProto._reverse = arrayProto.reverse;

  Object.extend(arrayProto, {
    _each:     _each,
    clear:     clear,
    first:     first,
    last:      last,
    compact:   compact,
    flatten:   flatten,
    without:   without,
    reverse:   reverse,
    uniq:      uniq,
    intersect: intersect,
    clone:     clone,
    toArray:   clone,
    size:      size,
    inspect:   inspect,
    toJSON:    toJSON
  });

  var CONCAT_ARGUMENTS_BUGGY = (function() {
    return [].concat(arguments)[0][0] !== 1;
  })(1,2)

  if (CONCAT_ARGUMENTS_BUGGY) arrayProto.concat = concat;

  if (!arrayProto.indexOf) arrayProto.indexOf = indexOf;
  if (!arrayProto.lastIndexOf) arrayProto.lastIndexOf = lastIndexOf;
})();
function $H(object) {
  return new Hash(object);
};

var Hash = Class.create(Enumerable, (function() {
  function initialize(object) {
    this._object = Object.isHash(object) ? object.toObject() : Object.clone(object);
  }

  function _each(iterator) {
    for (var key in this._object) {
      var value = this._object[key], pair = [key, value];
      pair.key = key;
      pair.value = value;
      iterator(pair);
    }
  }

  function set(key, value) {
    return this._object[key] = value;
  }

  function get(key) {
    if (this._object[key] !== Object.prototype[key])
      return this._object[key];
  }

  function unset(key) {
    var value = this._object[key];
    delete this._object[key];
    return value;
  }

  function toObject() {
    return Object.clone(this._object);
  }

  function keys() {
    return this.pluck('key');
  }

  function values() {
    return this.pluck('value');
  }

  function index(value) {
    var match = this.detect(function(pair) {
      return pair.value === value;
    });
    return match && match.key;
  }

  function merge(object) {
    return this.clone().update(object);
  }

  function update(object) {
    return new Hash(object).inject(this, function(result, pair) {
      result.set(pair.key, pair.value);
      return result;
    });
  }

  function toQueryPair(key, value) {
    if (Object.isUndefined(value)) return key;
    return key + '=' + encodeURIComponent(String.interpret(value));
  }

  function toQueryString() {
    return this.inject([], function(results, pair) {
      var key = encodeURIComponent(pair.key), values = pair.value;

      if (values && typeof values == 'object') {
        if (Object.isArray(values))
          return results.concat(values.map(toQueryPair.curry(key)));
      } else results.push(toQueryPair(key, values));
      return results;
    }).join('&');
  }

  function inspect() {
    return '#<Hash:{' + this.map(function(pair) {
      return pair.map(Object.inspect).join(': ');
    }).join(', ') + '}>';
  }

  function toJSON() {
    return Object.toJSON(this.toObject());
  }

  function clone() {
    return new Hash(this);
  }

  return {
    initialize:             initialize,
    _each:                  _each,
    set:                    set,
    get:                    get,
    unset:                  unset,
    toObject:               toObject,
    toTemplateReplacements: toObject,
    keys:                   keys,
    values:                 values,
    index:                  index,
    merge:                  merge,
    update:                 update,
    toQueryString:          toQueryString,
    inspect:                inspect,
    toJSON:                 toJSON,
    clone:                  clone
  };
})());

Hash.from = $H;
Object.extend(Number.prototype, (function() {
  function toColorPart() {
    return this.toPaddedString(2, 16);
  }

  function succ() {
    return this + 1;
  }

  function times(iterator, context) {
    $R(0, this, true).each(iterator, context);
    return this;
  }

  function toPaddedString(length, radix) {
    var string = this.toString(radix || 10);
    return '0'.times(length - string.length) + string;
  }

  function toJSON() {
    return isFinite(this) ? this.toString() : 'null';
  }

  function abs() {
    return Math.abs(this);
  }

  function round() {
    return Math.round(this);
  }

  function ceil() {
    return Math.ceil(this);
  }

  function floor() {
    return Math.floor(this);
  }

  return {
    toColorPart:    toColorPart,
    succ:           succ,
    times:          times,
    toPaddedString: toPaddedString,
    toJSON:         toJSON,
    abs:            abs,
    round:          round,
    ceil:           ceil,
    floor:          floor
  };
})());

function $R(start, end, exclusive) {
  return new ObjectRange(start, end, exclusive);
}

var ObjectRange = Class.create(Enumerable, (function() {
  function initialize(start, end, exclusive) {
    this.start = start;
    this.end = end;
    this.exclusive = exclusive;
  }

  function _each(iterator) {
    var value = this.start;
    while (this.include(value)) {
      iterator(value);
      value = value.succ();
    }
  }

  function include(value) {
    if (value < this.start)
      return false;
    if (this.exclusive)
      return value < this.end;
    return value <= this.end;
  }

  return {
    initialize: initialize,
    _each:      _each,
    include:    include
  };
})());



var Ajax = {
  getTransport: function() {
    return Try.these(
      function() {return new XMLHttpRequest()},
      function() {return new ActiveXObject('Msxml2.XMLHTTP')},
      function() {return new ActiveXObject('Microsoft.XMLHTTP')}
    ) || false;
  },

  activeRequestCount: 0
};

Ajax.Responders = {
  responders: [],

  _each: function(iterator) {
    this.responders._each(iterator);
  },

  register: function(responder) {
    if (!this.include(responder))
      this.responders.push(responder);
  },

  unregister: function(responder) {
    this.responders = this.responders.without(responder);
  },

  dispatch: function(callback, request, transport, json) {
    this.each(function(responder) {
      if (Object.isFunction(responder[callback])) {
        try {
          responder[callback].apply(responder, [request, transport, json]);
        } catch (e) { }
      }
    });
  }
};

Object.extend(Ajax.Responders, Enumerable);

Ajax.Responders.register({
  onCreate:   function() { Ajax.activeRequestCount++ },
  onComplete: function() { Ajax.activeRequestCount-- }
});
Ajax.Base = Class.create({
  initialize: function(options) {
    this.options = {
      method:       'post',
      asynchronous: true,
      contentType:  'application/x-www-form-urlencoded',
      encoding:     'UTF-8',
      parameters:   '',
      evalJSON:     true,
      evalJS:       true
    };
    Object.extend(this.options, options || { });

    this.options.method = this.options.method.toLowerCase();

    if (Object.isString(this.options.parameters))
      this.options.parameters = this.options.parameters.toQueryParams();
    else if (Object.isHash(this.options.parameters))
      this.options.parameters = this.options.parameters.toObject();
  }
});
Ajax.Request = Class.create(Ajax.Base, {
  _complete: false,

  initialize: function($super, url, options) {
    $super(options);
    this.transport = Ajax.getTransport();
    this.request(url);
  },

  request: function(url) {
    this.url = url;
    this.method = this.options.method;
    var params = Object.clone(this.options.parameters);

    if (!['get', 'post'].include(this.method)) {
      params['_method'] = this.method;
      this.method = 'post';
    }

    this.parameters = params;

    if (params = Object.toQueryString(params)) {
      if (this.method == 'get')
        this.url += (this.url.include('?') ? '&' : '?') + params;
      else if (/Konqueror|Safari|KHTML/.test(navigator.userAgent))
        params += '&_=';
    }

    try {
      var response = new Ajax.Response(this);
      if (this.options.onCreate) this.options.onCreate(response);
      Ajax.Responders.dispatch('onCreate', this, response);

      this.transport.open(this.method.toUpperCase(), this.url,
        this.options.asynchronous);

      if (this.options.asynchronous) this.respondToReadyState.bind(this).defer(1);

      this.transport.onreadystatechange = this.onStateChange.bind(this);
      this.setRequestHeaders();

      this.body = this.method == 'post' ? (this.options.postBody || params) : null;
      this.transport.send(this.body);

      /* Force Firefox to handle ready state 4 for synchronous requests */
      if (!this.options.asynchronous && this.transport.overrideMimeType)
        this.onStateChange();

    }
    catch (e) {
      this.dispatchException(e);
    }
  },

  onStateChange: function() {
    var readyState = this.transport.readyState;
    if (readyState > 1 && !((readyState == 4) && this._complete))
      this.respondToReadyState(this.transport.readyState);
  },

  setRequestHeaders: function() {
    var headers = {
      'X-Requested-With': 'XMLHttpRequest',
      'X-Prototype-Version': Prototype.Version,
      'Accept': 'text/javascript, text/html, application/xml, text/xml, */*'
    };

    if (this.method == 'post') {
      headers['Content-type'] = this.options.contentType +
        (this.options.encoding ? '; charset=' + this.options.encoding : '');

      /* Force "Connection: close" for older Mozilla browsers to work
       * around a bug where XMLHttpRequest sends an incorrect
       * Content-length header. See Mozilla Bugzilla #246651.
       */
      if (this.transport.overrideMimeType &&
          (navigator.userAgent.match(/Gecko\/(\d{4})/) || [0,2005])[1] < 2005)
            headers['Connection'] = 'close';
    }

    if (typeof this.options.requestHeaders == 'object') {
      var extras = this.options.requestHeaders;

      if (Object.isFunction(extras.push))
        for (var i = 0, length = extras.length; i < length; i += 2)
          headers[extras[i]] = extras[i+1];
      else
        $H(extras).each(function(pair) { headers[pair.key] = pair.value });
    }

    for (var name in headers)
      this.transport.setRequestHeader(name, headers[name]);
  },

  success: function() {
    var status = this.getStatus();
    return !status || (status >= 200 && status < 300);
  },

  getStatus: function() {
    try {
      return this.transport.status || 0;
    } catch (e) { return 0 }
  },

  respondToReadyState: function(readyState) {
    var state = Ajax.Request.Events[readyState], response = new Ajax.Response(this);

    if (state == 'Complete') {
      try {
        this._complete = true;
        (this.options['on' + response.status]
         || this.options['on' + (this.success() ? 'Success' : 'Failure')]
         || Prototype.emptyFunction)(response, response.headerJSON);
      } catch (e) {
        this.dispatchException(e);
      }

      var contentType = response.getHeader('Content-type');
      if (this.options.evalJS == 'force'
          || (this.options.evalJS && this.isSameOrigin() && contentType
          && contentType.match(/^\s*(text|application)\/(x-)?(java|ecma)script(;.*)?\s*$/i)))
        this.evalResponse();
    }

    try {
      (this.options['on' + state] || Prototype.emptyFunction)(response, response.headerJSON);
      Ajax.Responders.dispatch('on' + state, this, response, response.headerJSON);
    } catch (e) {
      this.dispatchException(e);
    }

    if (state == 'Complete') {
      this.transport.onreadystatechange = Prototype.emptyFunction;
    }
  },

  isSameOrigin: function() {
    var m = this.url.match(/^\s*https?:\/\/[^\/]*/);
    return !m || (m[0] == '#{protocol}//#{domain}#{port}'.interpolate({
      protocol: location.protocol,
      domain: document.domain,
      port: location.port ? ':' + location.port : ''
    }));
  },

  getHeader: function(name) {
    try {
      return this.transport.getResponseHeader(name) || null;
    } catch (e) { return null; }
  },

  evalResponse: function() {
    try {
      return eval((this.transport.responseText || '').unfilterJSON());
    } catch (e) {
      this.dispatchException(e);
    }
  },

  dispatchException: function(exception) {
    (this.options.onException || Prototype.emptyFunction)(this, exception);
    Ajax.Responders.dispatch('onException', this, exception);
  }
});

Ajax.Request.Events =
  ['Uninitialized', 'Loading', 'Loaded', 'Interactive', 'Complete'];








Ajax.Response = Class.create({
  initialize: function(request){
    this.request = request;
    var transport  = this.transport  = request.transport,
        readyState = this.readyState = transport.readyState;

    if((readyState > 2 && !Prototype.Browser.IE) || readyState == 4) {
      this.status       = this.getStatus();
      this.statusText   = this.getStatusText();
      this.responseText = String.interpret(transport.responseText);
      this.headerJSON   = this._getHeaderJSON();
    }

    if(readyState == 4) {
      var xml = transport.responseXML;
      this.responseXML  = Object.isUndefined(xml) ? null : xml;
      this.responseJSON = this._getResponseJSON();
    }
  },

  status:      0,

  statusText: '',

  getStatus: Ajax.Request.prototype.getStatus,

  getStatusText: function() {
    try {
      return this.transport.statusText || '';
    } catch (e) { return '' }
  },

  getHeader: Ajax.Request.prototype.getHeader,

  getAllHeaders: function() {
    try {
      return this.getAllResponseHeaders();
    } catch (e) { return null }
  },

  getResponseHeader: function(name) {
    return this.transport.getResponseHeader(name);
  },

  getAllResponseHeaders: function() {
    return this.transport.getAllResponseHeaders();
  },

  _getHeaderJSON: function() {
    var json = this.getHeader('X-JSON');
    if (!json) return null;
    json = decodeURIComponent(escape(json));
    try {
      return json.evalJSON(this.request.options.sanitizeJSON ||
        !this.request.isSameOrigin());
    } catch (e) {
      this.request.dispatchException(e);
    }
  },

  _getResponseJSON: function() {
    var options = this.request.options;
    if (!options.evalJSON || (options.evalJSON != 'force' &&
      !(this.getHeader('Content-type') || '').include('application/json')) ||
        this.responseText.blank())
          return null;
    try {
      return this.responseText.evalJSON(options.sanitizeJSON ||
        !this.request.isSameOrigin());
    } catch (e) {
      this.request.dispatchException(e);
    }
  }
});

Ajax.Updater = Class.create(Ajax.Request, {
  initialize: function($super, container, url, options) {
    this.container = {
      success: (container.success || container),
      failure: (container.failure || (container.success ? null : container))
    };

    options = Object.clone(options);
    var onComplete = options.onComplete;
    options.onComplete = (function(response, json) {
      this.updateContent(response.responseText);
      if (Object.isFunction(onComplete)) onComplete(response, json);
    }).bind(this);

    $super(url, options);
  },

  updateContent: function(responseText) {
    var receiver = this.container[this.success() ? 'success' : 'failure'],
        options = this.options;

    if (!options.evalScripts) responseText = responseText.stripScripts();

    if (receiver = $(receiver)) {
      if (options.insertion) {
        if (Object.isString(options.insertion)) {
          var insertion = { }; insertion[options.insertion] = responseText;
          receiver.insert(insertion);
        }
        else options.insertion(receiver, responseText);
      }
      else receiver.update(responseText);
    }
  }
});

Ajax.PeriodicalUpdater = Class.create(Ajax.Base, {
  initialize: function($super, container, url, options) {
    $super(options);
    this.onComplete = this.options.onComplete;

    this.frequency = (this.options.frequency || 2);
    this.decay = (this.options.decay || 1);

    this.updater = { };
    this.container = container;
    this.url = url;

    this.start();
  },

  start: function() {
    this.options.onComplete = this.updateComplete.bind(this);
    this.onTimerEvent();
  },

  stop: function() {
    this.updater.options.onComplete = undefined;
    clearTimeout(this.timer);
    (this.onComplete || Prototype.emptyFunction).apply(this, arguments);
  },

  updateComplete: function(response) {
    if (this.options.decay) {
      this.decay = (response.responseText == this.lastText ?
        this.decay * this.options.decay : 1);

      this.lastText = response.responseText;
    }
    this.timer = this.onTimerEvent.bind(this).delay(this.decay * this.frequency);
  },

  onTimerEvent: function() {
    this.updater = new Ajax.Updater(this.container, this.url, this.options);
  }
});



function $(element) {
  if (arguments.length > 1) {
    for (var i = 0, elements = [], length = arguments.length; i < length; i++)
      elements.push($(arguments[i]));
    return elements;
  }
  if (Object.isString(element))
    element = document.getElementById(element);
  return Element.extend(element);
}

if (Prototype.BrowserFeatures.XPath) {
  document._getElementsByXPath = function(expression, parentElement) {
    var results = [];
    var query = document.evaluate(expression, $(parentElement) || document,
      null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    for (var i = 0, length = query.snapshotLength; i < length; i++)
      results.push(Element.extend(query.snapshotItem(i)));
    return results;
  };
}

/*--------------------------------------------------------------------------*/

if (!window.Node) var Node = { };

if (!Node.ELEMENT_NODE) {
  Object.extend(Node, {
    ELEMENT_NODE: 1,
    ATTRIBUTE_NODE: 2,
    TEXT_NODE: 3,
    CDATA_SECTION_NODE: 4,
    ENTITY_REFERENCE_NODE: 5,
    ENTITY_NODE: 6,
    PROCESSING_INSTRUCTION_NODE: 7,
    COMMENT_NODE: 8,
    DOCUMENT_NODE: 9,
    DOCUMENT_TYPE_NODE: 10,
    DOCUMENT_FRAGMENT_NODE: 11,
    NOTATION_NODE: 12
  });
}


(function(global) {

  var SETATTRIBUTE_IGNORES_NAME = (function(){
    var elForm = document.createElement("form");
    var elInput = document.createElement("input");
    var root = document.documentElement;
    elInput.setAttribute("name", "test");
    elForm.appendChild(elInput);
    root.appendChild(elForm);
    var isBuggy = elForm.elements
      ? (typeof elForm.elements.test == "undefined")
      : null;
    root.removeChild(elForm);
    elForm = elInput = null;
    return isBuggy;
  })();

  var element = global.Element;
  global.Element = function(tagName, attributes) {
    attributes = attributes || { };
    tagName = tagName.toLowerCase();
    var cache = Element.cache;
    if (SETATTRIBUTE_IGNORES_NAME && attributes.name) {
      tagName = '<' + tagName + ' name="' + attributes.name + '">';
      delete attributes.name;
      return Element.writeAttribute(document.createElement(tagName), attributes);
    }
    if (!cache[tagName]) cache[tagName] = Element.extend(document.createElement(tagName));
    return Element.writeAttribute(cache[tagName].cloneNode(false), attributes);
  };
  Object.extend(global.Element, element || { });
  if (element) global.Element.prototype = element.prototype;
})(this);

Element.cache = { };
Element.idCounter = 1;

Element.Methods = {
  visible: function(element) {
    return $(element).style.display != 'none';
  },

  toggle: function(element) {
    element = $(element);
    Element[Element.visible(element) ? 'hide' : 'show'](element);
    return element;
  },


  hide: function(element) {
    element = $(element);
    element.style.display = 'none';
    return element;
  },

  show: function(element) {
    element = $(element);
    element.style.display = '';
    return element;
  },

  remove: function(element) {
    element = $(element);
    element.parentNode.removeChild(element);
    return element;
  },

  update: (function(){

    var SELECT_ELEMENT_INNERHTML_BUGGY = (function(){
      var el = document.createElement("select"),
          isBuggy = true;
      el.innerHTML = "<option value=\"test\">test</option>";
      if (el.options && el.options[0]) {
        isBuggy = el.options[0].nodeName.toUpperCase() !== "OPTION";
      }
      el = null;
      return isBuggy;
    })();

    var TABLE_ELEMENT_INNERHTML_BUGGY = (function(){
      try {
        var el = document.createElement("table");
        if (el && el.tBodies) {
          el.innerHTML = "<tbody><tr><td>test</td></tr></tbody>";
          var isBuggy = typeof el.tBodies[0] == "undefined";
          el = null;
          return isBuggy;
        }
      } catch (e) {
        return true;
      }
    })();

    var SCRIPT_ELEMENT_REJECTS_TEXTNODE_APPENDING = (function () {
      var s = document.createElement("script"),
          isBuggy = false;
      try {
        s.appendChild(document.createTextNode(""));
        isBuggy = !s.firstChild ||
          s.firstChild && s.firstChild.nodeType !== 3;
      } catch (e) {
        isBuggy = true;
      }
      s = null;
      return isBuggy;
    })();

    function update(element, content) {
      element = $(element);

      if (content && content.toElement)
        content = content.toElement();

      if (Object.isElement(content))
        return element.update().insert(content);

      content = Object.toHTML(content);

      var tagName = element.tagName.toUpperCase();

      if (tagName === 'SCRIPT' && SCRIPT_ELEMENT_REJECTS_TEXTNODE_APPENDING) {
        element.text = content;
        return element;
      }

      if (SELECT_ELEMENT_INNERHTML_BUGGY || TABLE_ELEMENT_INNERHTML_BUGGY) {
        if (tagName in Element._insertionTranslations.tags) {
          while (element.firstChild) {
            element.removeChild(element.firstChild);
          }
          Element._getContentFromAnonymousElement(tagName, content.stripScripts())
            .each(function(node) {
              element.appendChild(node)
            });
        }
        else {
          element.innerHTML = content.stripScripts();
        }
      }
      else {
        element.innerHTML = content.stripScripts();
      }

      content.evalScripts.bind(content).defer();
      return element;
    }

    return update;
  })(),

  replace: function(element, content) {
    element = $(element);
    if (content && content.toElement) content = content.toElement();
    else if (!Object.isElement(content)) {
      content = Object.toHTML(content);
      var range = element.ownerDocument.createRange();
      range.selectNode(element);
      content.evalScripts.bind(content).defer();
      content = range.createContextualFragment(content.stripScripts());
    }
    element.parentNode.replaceChild(content, element);
    return element;
  },

  insert: function(element, insertions) {
    element = $(element);

    if (Object.isString(insertions) || Object.isNumber(insertions) ||
        Object.isElement(insertions) || (insertions && (insertions.toElement || insertions.toHTML)))
          insertions = {bottom:insertions};

    var content, insert, tagName, childNodes;

    for (var position in insertions) {
      content  = insertions[position];
      position = position.toLowerCase();
      insert = Element._insertionTranslations[position];

      if (content && content.toElement) content = content.toElement();
      if (Object.isElement(content)) {
        insert(element, content);
        continue;
      }

      content = Object.toHTML(content);

      tagName = ((position == 'before' || position == 'after')
        ? element.parentNode : element).tagName.toUpperCase();

      childNodes = Element._getContentFromAnonymousElement(tagName, content.stripScripts());

      if (position == 'top' || position == 'after') childNodes.reverse();
      childNodes.each(insert.curry(element));

      content.evalScripts.bind(content).defer();
    }

    return element;
  },

  wrap: function(element, wrapper, attributes) {
    element = $(element);
    if (Object.isElement(wrapper))
      $(wrapper).writeAttribute(attributes || { });
    else if (Object.isString(wrapper)) wrapper = new Element(wrapper, attributes);
    else wrapper = new Element('div', wrapper);
    if (element.parentNode)
      element.parentNode.replaceChild(wrapper, element);
    wrapper.appendChild(element);
    return wrapper;
  },

  inspect: function(element) {
    element = $(element);
    var result = '<' + element.tagName.toLowerCase();
    $H({'id': 'id', 'className': 'class'}).each(function(pair) {
      var property = pair.first(), attribute = pair.last();
      var value = (element[property] || '').toString();
      if (value) result += ' ' + attribute + '=' + value.inspect(true);
    });
    return result + '>';
  },

  recursivelyCollect: function(element, property) {
    element = $(element);
    var elements = [];
    while (element = element[property])
      if (element.nodeType == 1)
        elements.push(Element.extend(element));
    return elements;
  },

  ancestors: function(element) {
    return Element.recursivelyCollect(element, 'parentNode');
  },

  descendants: function(element) {
    return Element.select(element, "*");
  },

  firstDescendant: function(element) {
    element = $(element).firstChild;
    while (element && element.nodeType != 1) element = element.nextSibling;
    return $(element);
  },

  immediateDescendants: function(element) {
    if (!(element = $(element).firstChild)) return [];
    while (element && element.nodeType != 1) element = element.nextSibling;
    if (element) return [element].concat($(element).nextSiblings());
    return [];
  },

  previousSiblings: function(element) {
    return Element.recursivelyCollect(element, 'previousSibling');
  },

  nextSiblings: function(element) {
    return Element.recursivelyCollect(element, 'nextSibling');
  },

  siblings: function(element) {
    element = $(element);
    return Element.previousSiblings(element).reverse()
      .concat(Element.nextSiblings(element));
  },

  match: function(element, selector) {
    if (Object.isString(selector))
      selector = new Selector(selector);
    return selector.match($(element));
  },

  up: function(element, expression, index) {
    element = $(element);
    if (arguments.length == 1) return $(element.parentNode);
    var ancestors = Element.ancestors(element);
    return Object.isNumber(expression) ? ancestors[expression] :
      Selector.findElement(ancestors, expression, index);
  },

  down: function(element, expression, index) {
    element = $(element);
    if (arguments.length == 1) return Element.firstDescendant(element);
    return Object.isNumber(expression) ? Element.descendants(element)[expression] :
      Element.select(element, expression)[index || 0];
  },

  previous: function(element, expression, index) {
    element = $(element);
    if (arguments.length == 1) return $(Selector.handlers.previousElementSibling(element));
    var previousSiblings = Element.previousSiblings(element);
    return Object.isNumber(expression) ? previousSiblings[expression] :
      Selector.findElement(previousSiblings, expression, index);
  },

  next: function(element, expression, index) {
    element = $(element);
    if (arguments.length == 1) return $(Selector.handlers.nextElementSibling(element));
    var nextSiblings = Element.nextSiblings(element);
    return Object.isNumber(expression) ? nextSiblings[expression] :
      Selector.findElement(nextSiblings, expression, index);
  },


  select: function(element) {
    var args = Array.prototype.slice.call(arguments, 1);
    return Selector.findChildElements(element, args);
  },

  adjacent: function(element) {
    var args = Array.prototype.slice.call(arguments, 1);
    return Selector.findChildElements(element.parentNode, args).without(element);
  },

  identify: function(element) {
    element = $(element);
    var id = Element.readAttribute(element, 'id');
    if (id) return id;
    do { id = 'anonymous_element_' + Element.idCounter++ } while ($(id));
    Element.writeAttribute(element, 'id', id);
    return id;
  },

  readAttribute: function(element, name) {
    element = $(element);
    if (Prototype.Browser.IE) {
      var t = Element._attributeTranslations.read;
      if (t.values[name]) return t.values[name](element, name);
      if (t.names[name]) name = t.names[name];
      if (name.include(':')) {
        return (!element.attributes || !element.attributes[name]) ? null :
         element.attributes[name].value;
      }
    }
    return element.getAttribute(name);
  },

  writeAttribute: function(element, name, value) {
    element = $(element);
    var attributes = { }, t = Element._attributeTranslations.write;

    if (typeof name == 'object') attributes = name;
    else attributes[name] = Object.isUndefined(value) ? true : value;

    for (var attr in attributes) {
      name = t.names[attr] || attr;
      value = attributes[attr];
      if (t.values[attr]) name = t.values[attr](element, value);
      if (value === false || value === null)
        element.removeAttribute(name);
      else if (value === true)
        element.setAttribute(name, name);
      else element.setAttribute(name, value);
    }
    return element;
  },

  getHeight: function(element) {
    return Element.getDimensions(element).height;
  },

  getWidth: function(element) {
    return Element.getDimensions(element).width;
  },

  classNames: function(element) {
    return new Element.ClassNames(element);
  },

  hasClassName: function(element, className) {
    if (!(element = $(element))) return;
    var elementClassName = element.className;
    return (elementClassName.length > 0 && (elementClassName == className ||
      new RegExp("(^|\\s)" + className + "(\\s|$)").test(elementClassName)));
  },

  addClassName: function(element, className) {
    if (!(element = $(element))) return;
    if (!Element.hasClassName(element, className))
      element.className += (element.className ? ' ' : '') + className;
    return element;
  },

  removeClassName: function(element, className) {
    if (!(element = $(element))) return;
    element.className = element.className.replace(
      new RegExp("(^|\\s+)" + className + "(\\s+|$)"), ' ').strip();
    return element;
  },

  toggleClassName: function(element, className) {
    if (!(element = $(element))) return;
    return Element[Element.hasClassName(element, className) ?
      'removeClassName' : 'addClassName'](element, className);
  },

  cleanWhitespace: function(element) {
    element = $(element);
    var node = element.firstChild;
    while (node) {
      var nextNode = node.nextSibling;
      if (node.nodeType == 3 && !/\S/.test(node.nodeValue))
        element.removeChild(node);
      node = nextNode;
    }
    return element;
  },

  empty: function(element) {
    return $(element).innerHTML.blank();
  },

  descendantOf: function(element, ancestor) {
    element = $(element), ancestor = $(ancestor);

    if (element.compareDocumentPosition)
      return (element.compareDocumentPosition(ancestor) & 8) === 8;

    if (ancestor.contains)
      return ancestor.contains(element) && ancestor !== element;

    while (element = element.parentNode)
      if (element == ancestor) return true;

    return false;
  },

  scrollTo: function(element) {
    element = $(element);
    var pos = Element.cumulativeOffset(element);
    window.scrollTo(pos[0], pos[1]);
    return element;
  },

  getStyle: function(element, style) {
    element = $(element);
    style = style == 'float' ? 'cssFloat' : style.camelize();
    var value = element.style[style];
    if (!value || value == 'auto') {
      var css = document.defaultView.getComputedStyle(element, null);
      value = css ? css[style] : null;
    }
    if (style == 'opacity') return value ? parseFloat(value) : 1.0;
    return value == 'auto' ? null : value;
  },

  getOpacity: function(element) {
    return $(element).getStyle('opacity');
  },

  setStyle: function(element, styles) {
    element = $(element);
    var elementStyle = element.style, match;
    if (Object.isString(styles)) {
      element.style.cssText += ';' + styles;
      return styles.include('opacity') ?
        element.setOpacity(styles.match(/opacity:\s*(\d?\.?\d*)/)[1]) : element;
    }
    for (var property in styles)
      if (property == 'opacity') element.setOpacity(styles[property]);
      else
        elementStyle[(property == 'float' || property == 'cssFloat') ?
          (Object.isUndefined(elementStyle.styleFloat) ? 'cssFloat' : 'styleFloat') :
            property] = styles[property];

    return element;
  },

  setOpacity: function(element, value) {
    element = $(element);
    element.style.opacity = (value == 1 || value === '') ? '' :
      (value < 0.00001) ? 0 : value;
    return element;
  },

  getDimensions: function(element) {
    element = $(element);
    var display = Element.getStyle(element, 'display');
    if (display != 'none' && display != null) // Safari bug
      return {width: element.offsetWidth, height: element.offsetHeight};

    var els = element.style;
    var originalVisibility = els.visibility;
    var originalPosition = els.position;
    var originalDisplay = els.display;
    els.visibility = 'hidden';
    if (originalPosition != 'fixed') // Switching fixed to absolute causes issues in Safari
      els.position = 'absolute';
    els.display = 'block';
    var originalWidth = element.clientWidth;
    var originalHeight = element.clientHeight;
    els.display = originalDisplay;
    els.position = originalPosition;
    els.visibility = originalVisibility;
    return {width: originalWidth, height: originalHeight};
  },

  makePositioned: function(element) {
    element = $(element);
    var pos = Element.getStyle(element, 'position');
    if (pos == 'static' || !pos) {
      element._madePositioned = true;
      element.style.position = 'relative';
      if (Prototype.Browser.Opera) {
        element.style.top = 0;
        element.style.left = 0;
      }
    }
    return element;
  },

  undoPositioned: function(element) {
    element = $(element);
    if (element._madePositioned) {
      element._madePositioned = undefined;
      element.style.position =
        element.style.top =
        element.style.left =
        element.style.bottom =
        element.style.right = '';
    }
    return element;
  },

  makeClipping: function(element) {
    element = $(element);
    if (element._overflow) return element;
    element._overflow = Element.getStyle(element, 'overflow') || 'auto';
    if (element._overflow !== 'hidden')
      element.style.overflow = 'hidden';
    return element;
  },

  undoClipping: function(element) {
    element = $(element);
    if (!element._overflow) return element;
    element.style.overflow = element._overflow == 'auto' ? '' : element._overflow;
    element._overflow = null;
    return element;
  },

  cumulativeOffset: function(element) {
    var valueT = 0, valueL = 0;
    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;
      element = element.offsetParent;
    } while (element);
    return Element._returnOffset(valueL, valueT);
  },

  positionedOffset: function(element) {
    var valueT = 0, valueL = 0;
    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;
      element = element.offsetParent;
      if (element) {
        if (element.tagName.toUpperCase() == 'BODY') break;
        var p = Element.getStyle(element, 'position');
        if (p !== 'static') break;
      }
    } while (element);
    return Element._returnOffset(valueL, valueT);
  },

  absolutize: function(element) {
    element = $(element);
    if (Element.getStyle(element, 'position') == 'absolute') return element;

    var offsets = Element.positionedOffset(element);
    var top     = offsets[1];
    var left    = offsets[0];
    var width   = element.clientWidth;
    var height  = element.clientHeight;

    element._originalLeft   = left - parseFloat(element.style.left  || 0);
    element._originalTop    = top  - parseFloat(element.style.top || 0);
    element._originalWidth  = element.style.width;
    element._originalHeight = element.style.height;

    element.style.position = 'absolute';
    element.style.top    = top + 'px';
    element.style.left   = left + 'px';
    element.style.width  = width + 'px';
    element.style.height = height + 'px';
    return element;
  },

  relativize: function(element) {
    element = $(element);
    if (Element.getStyle(element, 'position') == 'relative') return element;

    element.style.position = 'relative';
    var top  = parseFloat(element.style.top  || 0) - (element._originalTop || 0);
    var left = parseFloat(element.style.left || 0) - (element._originalLeft || 0);

    element.style.top    = top + 'px';
    element.style.left   = left + 'px';
    element.style.height = element._originalHeight;
    element.style.width  = element._originalWidth;
    return element;
  },

  cumulativeScrollOffset: function(element) {
    var valueT = 0, valueL = 0;
    do {
      valueT += element.scrollTop  || 0;
      valueL += element.scrollLeft || 0;
      element = element.parentNode;
    } while (element);
    return Element._returnOffset(valueL, valueT);
  },

  getOffsetParent: function(element) {
    if (element.offsetParent) return $(element.offsetParent);
    if (element == document.body) return $(element);

    while ((element = element.parentNode) && element != document.body)
      if (Element.getStyle(element, 'position') != 'static')
        return $(element);

    return $(document.body);
  },

  viewportOffset: function(forElement) {
    var valueT = 0, valueL = 0;

    var element = forElement;
    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;

      if (element.offsetParent == document.body &&
        Element.getStyle(element, 'position') == 'absolute') break;

    } while (element = element.offsetParent);

    element = forElement;
    do {
      if (!Prototype.Browser.Opera || (element.tagName && (element.tagName.toUpperCase() == 'BODY'))) {
        valueT -= element.scrollTop  || 0;
        valueL -= element.scrollLeft || 0;
      }
    } while (element = element.parentNode);

    return Element._returnOffset(valueL, valueT);
  },

  clonePosition: function(element, source) {
    var options = Object.extend({
      setLeft:    true,
      setTop:     true,
      setWidth:   true,
      setHeight:  true,
      offsetTop:  0,
      offsetLeft: 0
    }, arguments[2] || { });

    source = $(source);
    var p = Element.viewportOffset(source);

    element = $(element);
    var delta = [0, 0];
    var parent = null;
    if (Element.getStyle(element, 'position') == 'absolute') {
      parent = Element.getOffsetParent(element);
      delta = Element.viewportOffset(parent);
    }

    if (parent == document.body) {
      delta[0] -= document.body.offsetLeft;
      delta[1] -= document.body.offsetTop;
    }

    if (options.setLeft)   element.style.left  = (p[0] - delta[0] + options.offsetLeft) + 'px';
    if (options.setTop)    element.style.top   = (p[1] - delta[1] + options.offsetTop) + 'px';
    if (options.setWidth)  element.style.width = source.offsetWidth + 'px';
    if (options.setHeight) element.style.height = source.offsetHeight + 'px';
    return element;
  }
};

Object.extend(Element.Methods, {
  getElementsBySelector: Element.Methods.select,

  childElements: Element.Methods.immediateDescendants
});

Element._attributeTranslations = {
  write: {
    names: {
      className: 'class',
      htmlFor:   'for'
    },
    values: { }
  }
};

if (Prototype.Browser.Opera) {
  Element.Methods.getStyle = Element.Methods.getStyle.wrap(
    function(proceed, element, style) {
      switch (style) {
        case 'left': case 'top': case 'right': case 'bottom':
          if (proceed(element, 'position') === 'static') return null;
        case 'height': case 'width':
          if (!Element.visible(element)) return null;

          var dim = parseInt(proceed(element, style), 10);

          if (dim !== element['offset' + style.capitalize()])
            return dim + 'px';

          var properties;
          if (style === 'height') {
            properties = ['border-top-width', 'padding-top',
             'padding-bottom', 'border-bottom-width'];
          }
          else {
            properties = ['border-left-width', 'padding-left',
             'padding-right', 'border-right-width'];
          }
          return properties.inject(dim, function(memo, property) {
            var val = proceed(element, property);
            return val === null ? memo : memo - parseInt(val, 10);
          }) + 'px';
        default: return proceed(element, style);
      }
    }
  );

  Element.Methods.readAttribute = Element.Methods.readAttribute.wrap(
    function(proceed, element, attribute) {
      if (attribute === 'title') return element.title;
      return proceed(element, attribute);
    }
  );
}

else if (Prototype.Browser.IE) {
  Element.Methods.getOffsetParent = Element.Methods.getOffsetParent.wrap(
    function(proceed, element) {
      element = $(element);
      try { element.offsetParent }
      catch(e) { return $(document.body) }
      var position = element.getStyle('position');
      if (position !== 'static') return proceed(element);
      element.setStyle({ position: 'relative' });
      var value = proceed(element);
      element.setStyle({ position: position });
      return value;
    }
  );

  $w('positionedOffset viewportOffset').each(function(method) {
    Element.Methods[method] = Element.Methods[method].wrap(
      function(proceed, element) {
        element = $(element);
        try { element.offsetParent }
        catch(e) { return Element._returnOffset(0,0) }
        var position = element.getStyle('position');
        if (position !== 'static') return proceed(element);
        var offsetParent = element.getOffsetParent();
        if (offsetParent && offsetParent.getStyle('position') === 'fixed')
          offsetParent.setStyle({ zoom: 1 });
        element.setStyle({ position: 'relative' });
        var value = proceed(element);
        element.setStyle({ position: position });
        return value;
      }
    );
  });

  Element.Methods.cumulativeOffset = Element.Methods.cumulativeOffset.wrap(
    function(proceed, element) {
      try { element.offsetParent }
      catch(e) { return Element._returnOffset(0,0) }
      return proceed(element);
    }
  );

  Element.Methods.getStyle = function(element, style) {
    element = $(element);
    style = (style == 'float' || style == 'cssFloat') ? 'styleFloat' : style.camelize();
    var value = element.style[style];
    if (!value && element.currentStyle) value = element.currentStyle[style];

    if (style == 'opacity') {
      if (value = (element.getStyle('filter') || '').match(/alpha\(opacity=(.*)\)/))
        if (value[1]) return parseFloat(value[1]) / 100;
      return 1.0;
    }

    if (value == 'auto') {
      if ((style == 'width' || style == 'height') && (element.getStyle('display') != 'none'))
        return element['offset' + style.capitalize()] + 'px';
      return null;
    }
    return value;
  };

  Element.Methods.setOpacity = function(element, value) {
    function stripAlpha(filter){
      return filter.replace(/alpha\([^\)]*\)/gi,'');
    }
    element = $(element);
    var currentStyle = element.currentStyle;
    if ((currentStyle && !currentStyle.hasLayout) ||
      (!currentStyle && element.style.zoom == 'normal'))
        element.style.zoom = 1;

    var filter = element.getStyle('filter'), style = element.style;
    if (value == 1 || value === '') {
      (filter = stripAlpha(filter)) ?
        style.filter = filter : style.removeAttribute('filter');
      return element;
    } else if (value < 0.00001) value = 0;
    style.filter = stripAlpha(filter) +
      'alpha(opacity=' + (value * 100) + ')';
    return element;
  };

  Element._attributeTranslations = (function(){

    var classProp = 'className';
    var forProp = 'for';

    var el = document.createElement('div');

    el.setAttribute(classProp, 'x');

    if (el.className !== 'x') {
      el.setAttribute('class', 'x');
      if (el.className === 'x') {
        classProp = 'class';
      }
    }
    el = null;

    el = document.createElement('label');
    el.setAttribute(forProp, 'x');
    if (el.htmlFor !== 'x') {
      el.setAttribute('htmlFor', 'x');
      if (el.htmlFor === 'x') {
        forProp = 'htmlFor';
      }
    }
    el = null;

    return {
      read: {
        names: {
          'class':      classProp,
          'className':  classProp,
          'for':        forProp,
          'htmlFor':    forProp
        },
        values: {
          _getAttr: function(element, attribute) {
            return element.getAttribute(attribute);
          },
          _getAttr2: function(element, attribute) {
            return element.getAttribute(attribute, 2);
          },
          _getAttrNode: function(element, attribute) {
            var node = element.getAttributeNode(attribute);
            return node ? node.value : "";
          },
          _getEv: (function(){

            var el = document.createElement('div');
            el.onclick = Prototype.emptyFunction;
            var value = el.getAttribute('onclick');
            var f;

            if (String(value).indexOf('{') > -1) {
              f = function(element, attribute) {
                attribute = element.getAttribute(attribute);
                if (!attribute) return null;
                attribute = attribute.toString();
                attribute = attribute.split('{')[1];
                attribute = attribute.split('}')[0];
                return attribute.strip();
              };
            }
            else if (value === '') {
              f = function(element, attribute) {
                attribute = element.getAttribute(attribute);
                if (!attribute) return null;
                return attribute.strip();
              };
            }
            el = null;
            return f;
          })(),
          _flag: function(element, attribute) {
            return $(element).hasAttribute(attribute) ? attribute : null;
          },
          style: function(element) {
            return element.style.cssText.toLowerCase();
          },
          title: function(element) {
            return element.title;
          }
        }
      }
    }
  })();

  Element._attributeTranslations.write = {
    names: Object.extend({
      cellpadding: 'cellPadding',
      cellspacing: 'cellSpacing'
    }, Element._attributeTranslations.read.names),
    values: {
      checked: function(element, value) {
        element.checked = !!value;
      },

      style: function(element, value) {
        element.style.cssText = value ? value : '';
      }
    }
  };

  Element._attributeTranslations.has = {};

  $w('colSpan rowSpan vAlign dateTime accessKey tabIndex ' +
      'encType maxLength readOnly longDesc frameBorder').each(function(attr) {
    Element._attributeTranslations.write.names[attr.toLowerCase()] = attr;
    Element._attributeTranslations.has[attr.toLowerCase()] = attr;
  });

  (function(v) {
    Object.extend(v, {
      href:        v._getAttr2,
      src:         v._getAttr2,
      type:        v._getAttr,
      action:      v._getAttrNode,
      disabled:    v._flag,
      checked:     v._flag,
      readonly:    v._flag,
      multiple:    v._flag,
      onload:      v._getEv,
      onunload:    v._getEv,
      onclick:     v._getEv,
      ondblclick:  v._getEv,
      onmousedown: v._getEv,
      onmouseup:   v._getEv,
      onmouseover: v._getEv,
      onmousemove: v._getEv,
      onmouseout:  v._getEv,
      onfocus:     v._getEv,
      onblur:      v._getEv,
      onkeypress:  v._getEv,
      onkeydown:   v._getEv,
      onkeyup:     v._getEv,
      onsubmit:    v._getEv,
      onreset:     v._getEv,
      onselect:    v._getEv,
      onchange:    v._getEv
    });
  })(Element._attributeTranslations.read.values);

  if (Prototype.BrowserFeatures.ElementExtensions) {
    (function() {
      function _descendants(element) {
        var nodes = element.getElementsByTagName('*'), results = [];
        for (var i = 0, node; node = nodes[i]; i++)
          if (node.tagName !== "!") // Filter out comment nodes.
            results.push(node);
        return results;
      }

      Element.Methods.down = function(element, expression, index) {
        element = $(element);
        if (arguments.length == 1) return element.firstDescendant();
        return Object.isNumber(expression) ? _descendants(element)[expression] :
          Element.select(element, expression)[index || 0];
      }
    })();
  }

}

else if (Prototype.Browser.Gecko && /rv:1\.8\.0/.test(navigator.userAgent)) {
  Element.Methods.setOpacity = function(element, value) {
    element = $(element);
    element.style.opacity = (value == 1) ? 0.999999 :
      (value === '') ? '' : (value < 0.00001) ? 0 : value;
    return element;
  };
}

else if (Prototype.Browser.WebKit) {
  Element.Methods.setOpacity = function(element, value) {
    element = $(element);
    element.style.opacity = (value == 1 || value === '') ? '' :
      (value < 0.00001) ? 0 : value;

    if (value == 1)
      if(element.tagName.toUpperCase() == 'IMG' && element.width) {
        element.width++; element.width--;
      } else try {
        var n = document.createTextNode(' ');
        element.appendChild(n);
        element.removeChild(n);
      } catch (e) { }

    return element;
  };

  Element.Methods.cumulativeOffset = function(element) {
    var valueT = 0, valueL = 0;
    do {
      valueT += element.offsetTop  || 0;
      valueL += element.offsetLeft || 0;
      if (element.offsetParent == document.body)
        if (Element.getStyle(element, 'position') == 'absolute') break;

      element = element.offsetParent;
    } while (element);

    return Element._returnOffset(valueL, valueT);
  };
}

if ('outerHTML' in document.documentElement) {
  Element.Methods.replace = function(element, content) {
    element = $(element);

    if (content && content.toElement) content = content.toElement();
    if (Object.isElement(content)) {
      element.parentNode.replaceChild(content, element);
      return element;
    }

    content = Object.toHTML(content);
    var parent = element.parentNode, tagName = parent.tagName.toUpperCase();

    if (Element._insertionTranslations.tags[tagName]) {
      var nextSibling = element.next();
      var fragments = Element._getContentFromAnonymousElement(tagName, content.stripScripts());
      parent.removeChild(element);
      if (nextSibling)
        fragments.each(function(node) { parent.insertBefore(node, nextSibling) });
      else
        fragments.each(function(node) { parent.appendChild(node) });
    }
    else element.outerHTML = content.stripScripts();

    content.evalScripts.bind(content).defer();
    return element;
  };
}

Element._returnOffset = function(l, t) {
  var result = [l, t];
  result.left = l;
  result.top = t;
  return result;
};

Element._getContentFromAnonymousElement = function(tagName, html) {
  var div = new Element('div'), t = Element._insertionTranslations.tags[tagName];
  if (t) {
    div.innerHTML = t[0] + html + t[1];
    t[2].times(function() { div = div.firstChild });
  } else div.innerHTML = html;
  return $A(div.childNodes);
};

Element._insertionTranslations = {
  before: function(element, node) {
    element.parentNode.insertBefore(node, element);
  },
  top: function(element, node) {
    element.insertBefore(node, element.firstChild);
  },
  bottom: function(element, node) {
    element.appendChild(node);
  },
  after: function(element, node) {
    element.parentNode.insertBefore(node, element.nextSibling);
  },
  tags: {
    TABLE:  ['<table>',                '</table>',                   1],
    TBODY:  ['<table><tbody>',         '</tbody></table>',           2],
    TR:     ['<table><tbody><tr>',     '</tr></tbody></table>',      3],
    TD:     ['<table><tbody><tr><td>', '</td></tr></tbody></table>', 4],
    SELECT: ['<select>',               '</select>',                  1]
  }
};

(function() {
  var tags = Element._insertionTranslations.tags;
  Object.extend(tags, {
    THEAD: tags.TBODY,
    TFOOT: tags.TBODY,
    TH:    tags.TD
  });
})();

Element.Methods.Simulated = {
  hasAttribute: function(element, attribute) {
    attribute = Element._attributeTranslations.has[attribute] || attribute;
    var node = $(element).getAttributeNode(attribute);
    return !!(node && node.specified);
  }
};

Element.Methods.ByTag = { };

Object.extend(Element, Element.Methods);

(function(div) {

  if (!Prototype.BrowserFeatures.ElementExtensions && div['__proto__']) {
    window.HTMLElement = { };
    window.HTMLElement.prototype = div['__proto__'];
    Prototype.BrowserFeatures.ElementExtensions = true;
  }

  div = null;

})(document.createElement('div'))

Element.extend = (function() {

  function checkDeficiency(tagName) {
    if (typeof window.Element != 'undefined') {
      var proto = window.Element.prototype;
      if (proto) {
        var id = '_' + (Math.random()+'').slice(2);
        var el = document.createElement(tagName);
        proto[id] = 'x';
        var isBuggy = (el[id] !== 'x');
        delete proto[id];
        el = null;
        return isBuggy;
      }
    }
    return false;
  }

  function extendElementWith(element, methods) {
    for (var property in methods) {
      var value = methods[property];
      if (Object.isFunction(value) && !(property in element))
        element[property] = value.methodize();
    }
  }

  var HTMLOBJECTELEMENT_PROTOTYPE_BUGGY = checkDeficiency('object');

  if (Prototype.BrowserFeatures.SpecificElementExtensions) {
    if (HTMLOBJECTELEMENT_PROTOTYPE_BUGGY) {
      return function(element) {
        if (element && typeof element._extendedByPrototype == 'undefined') {
          var t = element.tagName;
          if (t && (/^(?:object|applet|embed)$/i.test(t))) {
            extendElementWith(element, Element.Methods);
            extendElementWith(element, Element.Methods.Simulated);
            extendElementWith(element, Element.Methods.ByTag[t.toUpperCase()]);
          }
        }
        return element;
      }
    }
    return Prototype.K;
  }

  var Methods = { }, ByTag = Element.Methods.ByTag;

  var extend = Object.extend(function(element) {
    if (!element || typeof element._extendedByPrototype != 'undefined' ||
        element.nodeType != 1 || element == window) return element;

    var methods = Object.clone(Methods),
        tagName = element.tagName.toUpperCase();

    if (ByTag[tagName]) Object.extend(methods, ByTag[tagName]);

    extendElementWith(element, methods);

    element._extendedByPrototype = Prototype.emptyFunction;
    return element;

  }, {
    refresh: function() {
      if (!Prototype.BrowserFeatures.ElementExtensions) {
        Object.extend(Methods, Element.Methods);
        Object.extend(Methods, Element.Methods.Simulated);
      }
    }
  });

  extend.refresh();
  return extend;
})();

Element.hasAttribute = function(element, attribute) {
  if (element.hasAttribute) return element.hasAttribute(attribute);
  return Element.Methods.Simulated.hasAttribute(element, attribute);
};

Element.addMethods = function(methods) {
  var F = Prototype.BrowserFeatures, T = Element.Methods.ByTag;

  if (!methods) {
    Object.extend(Form, Form.Methods);
    Object.extend(Form.Element, Form.Element.Methods);
    Object.extend(Element.Methods.ByTag, {
      "FORM":     Object.clone(Form.Methods),
      "INPUT":    Object.clone(Form.Element.Methods),
      "SELECT":   Object.clone(Form.Element.Methods),
      "TEXTAREA": Object.clone(Form.Element.Methods)
    });
  }

  if (arguments.length == 2) {
    var tagName = methods;
    methods = arguments[1];
  }

  if (!tagName) Object.extend(Element.Methods, methods || { });
  else {
    if (Object.isArray(tagName)) tagName.each(extend);
    else extend(tagName);
  }

  function extend(tagName) {
    tagName = tagName.toUpperCase();
    if (!Element.Methods.ByTag[tagName])
      Element.Methods.ByTag[tagName] = { };
    Object.extend(Element.Methods.ByTag[tagName], methods);
  }

  function copy(methods, destination, onlyIfAbsent) {
    onlyIfAbsent = onlyIfAbsent || false;
    for (var property in methods) {
      var value = methods[property];
      if (!Object.isFunction(value)) continue;
      if (!onlyIfAbsent || !(property in destination))
        destination[property] = value.methodize();
    }
  }

  function findDOMClass(tagName) {
    var klass;
    var trans = {
      "OPTGROUP": "OptGroup", "TEXTAREA": "TextArea", "P": "Paragraph",
      "FIELDSET": "FieldSet", "UL": "UList", "OL": "OList", "DL": "DList",
      "DIR": "Directory", "H1": "Heading", "H2": "Heading", "H3": "Heading",
      "H4": "Heading", "H5": "Heading", "H6": "Heading", "Q": "Quote",
      "INS": "Mod", "DEL": "Mod", "A": "Anchor", "IMG": "Image", "CAPTION":
      "TableCaption", "COL": "TableCol", "COLGROUP": "TableCol", "THEAD":
      "TableSection", "TFOOT": "TableSection", "TBODY": "TableSection", "TR":
      "TableRow", "TH": "TableCell", "TD": "TableCell", "FRAMESET":
      "FrameSet", "IFRAME": "IFrame"
    };
    if (trans[tagName]) klass = 'HTML' + trans[tagName] + 'Element';
    if (window[klass]) return window[klass];
    klass = 'HTML' + tagName + 'Element';
    if (window[klass]) return window[klass];
    klass = 'HTML' + tagName.capitalize() + 'Element';
    if (window[klass]) return window[klass];

    var element = document.createElement(tagName);
    var proto = element['__proto__'] || element.constructor.prototype;
    element = null;
    return proto;
  }

  var elementPrototype = window.HTMLElement ? HTMLElement.prototype :
   Element.prototype;

  if (F.ElementExtensions) {
    copy(Element.Methods, elementPrototype);
    copy(Element.Methods.Simulated, elementPrototype, true);
  }

  if (F.SpecificElementExtensions) {
    for (var tag in Element.Methods.ByTag) {
      var klass = findDOMClass(tag);
      if (Object.isUndefined(klass)) continue;
      copy(T[tag], klass.prototype);
    }
  }

  Object.extend(Element, Element.Methods);
  delete Element.ByTag;

  if (Element.extend.refresh) Element.extend.refresh();
  Element.cache = { };
};


document.viewport = {

  getDimensions: function() {
    return { width: this.getWidth(), height: this.getHeight() };
  },

  getScrollOffsets: function() {
    return Element._returnOffset(
      window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft,
      window.pageYOffset || document.documentElement.scrollTop  || document.body.scrollTop);
  }
};

(function(viewport) {
  var B = Prototype.Browser, doc = document, element, property = {};

  function getRootElement() {
    if (B.WebKit && !doc.evaluate)
      return document;

    if (B.Opera && window.parseFloat(window.opera.version()) < 9.5)
      return document.body;

    return document.documentElement;
  }

  function define(D) {
    if (!element) element = getRootElement();

    property[D] = 'client' + D;

    viewport['get' + D] = function() { return element[property[D]] };
    return viewport['get' + D]();
  }

  viewport.getWidth  = define.curry('Width');

  viewport.getHeight = define.curry('Height');
})(document.viewport);


Element.Storage = {
  UID: 1
};

Element.addMethods({
  getStorage: function(element) {
    if (!(element = $(element))) return;

    var uid;
    if (element === window) {
      uid = 0;
    } else {
      if (typeof element._prototypeUID === "undefined")
        element._prototypeUID = [Element.Storage.UID++];
      uid = element._prototypeUID[0];
    }

    if (!Element.Storage[uid])
      Element.Storage[uid] = $H();

    return Element.Storage[uid];
  },

  store: function(element, key, value) {
    if (!(element = $(element))) return;

    if (arguments.length === 2) {
      Element.getStorage(element).update(key);
    } else {
      Element.getStorage(element).set(key, value);
    }

    return element;
  },

  retrieve: function(element, key, defaultValue) {
    if (!(element = $(element))) return;
    var hash = Element.getStorage(element), value = hash.get(key);

    if (Object.isUndefined(value)) {
      hash.set(key, defaultValue);
      value = defaultValue;
    }

    return value;
  },

  clone: function(element, deep) {
    if (!(element = $(element))) return;
    var clone = element.cloneNode(deep);
    clone._prototypeUID = void 0;
    if (deep) {
      var descendants = Element.select(clone, '*'),
          i = descendants.length;
      while (i--) {
        descendants[i]._prototypeUID = void 0;
      }
    }
    return Element.extend(clone);
  }
});
/* Portions of the Selector class are derived from Jack Slocum's DomQuery,
 * part of YUI-Ext version 0.40, distributed under the terms of an MIT-style
 * license.  Please see http://www.yui-ext.com/ for more information. */

var Selector = Class.create({
  initialize: function(expression) {
    this.expression = expression.strip();

    if (this.shouldUseSelectorsAPI()) {
      this.mode = 'selectorsAPI';
    } else if (this.shouldUseXPath()) {
      this.mode = 'xpath';
      this.compileXPathMatcher();
    } else {
      this.mode = "normal";
      this.compileMatcher();
    }

  },

  shouldUseXPath: (function() {

    var IS_DESCENDANT_SELECTOR_BUGGY = (function(){
      var isBuggy = false;
      if (document.evaluate && window.XPathResult) {
        var el = document.createElement('div');
        el.innerHTML = '<ul><li></li></ul><div><ul><li></li></ul></div>';

        var xpath = ".//*[local-name()='ul' or local-name()='UL']" +
          "//*[local-name()='li' or local-name()='LI']";

        var result = document.evaluate(xpath, el, null,
          XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);

        isBuggy = (result.snapshotLength !== 2);
        el = null;
      }
      return isBuggy;
    })();

    return function() {
      if (!Prototype.BrowserFeatures.XPath) return false;

      var e = this.expression;

      if (Prototype.Browser.WebKit &&
       (e.include("-of-type") || e.include(":empty")))
        return false;

      if ((/(\[[\w-]*?:|:checked)/).test(e))
        return false;

      if (IS_DESCENDANT_SELECTOR_BUGGY) return false;

      return true;
    }

  })(),

  shouldUseSelectorsAPI: function() {
    if (!Prototype.BrowserFeatures.SelectorsAPI) return false;

    if (Selector.CASE_INSENSITIVE_CLASS_NAMES) return false;

    if (!Selector._div) Selector._div = new Element('div');

    try {
      Selector._div.querySelector(this.expression);
    } catch(e) {
      return false;
    }

    return true;
  },

  compileMatcher: function() {
    var e = this.expression, ps = Selector.patterns, h = Selector.handlers,
        c = Selector.criteria, le, p, m, len = ps.length, name;

    if (Selector._cache[e]) {
      this.matcher = Selector._cache[e];
      return;
    }

    this.matcher = ["this.matcher = function(root) {",
                    "var r = root, h = Selector.handlers, c = false, n;"];

    while (e && le != e && (/\S/).test(e)) {
      le = e;
      for (var i = 0; i<len; i++) {
        p = ps[i].re;
        name = ps[i].name;
        if (m = e.match(p)) {
          this.matcher.push(Object.isFunction(c[name]) ? c[name](m) :
            new Template(c[name]).evaluate(m));
          e = e.replace(m[0], '');
          break;
        }
      }
    }

    this.matcher.push("return h.unique(n);\n}");
    eval(this.matcher.join('\n'));
    Selector._cache[this.expression] = this.matcher;
  },

  compileXPathMatcher: function() {
    var e = this.expression, ps = Selector.patterns,
        x = Selector.xpath, le, m, len = ps.length, name;

    if (Selector._cache[e]) {
      this.xpath = Selector._cache[e]; return;
    }

    this.matcher = ['.//*'];
    while (e && le != e && (/\S/).test(e)) {
      le = e;
      for (var i = 0; i<len; i++) {
        name = ps[i].name;
        if (m = e.match(ps[i].re)) {
          this.matcher.push(Object.isFunction(x[name]) ? x[name](m) :
            new Template(x[name]).evaluate(m));
          e = e.replace(m[0], '');
          break;
        }
      }
    }

    this.xpath = this.matcher.join('');
    Selector._cache[this.expression] = this.xpath;
  },

  findElements: function(root) {
    root = root || document;
    var e = this.expression, results;

    switch (this.mode) {
      case 'selectorsAPI':
        if (root !== document) {
          var oldId = root.id, id = $(root).identify();
          id = id.replace(/([\.:])/g, "\\$1");
          e = "#" + id + " " + e;
        }

        results = $A(root.querySelectorAll(e)).map(Element.extend);
        root.id = oldId;

        return results;
      case 'xpath':
        return document._getElementsByXPath(this.xpath, root);
      default:
       return this.matcher(root);
    }
  },

  match: function(element) {
    this.tokens = [];

    var e = this.expression, ps = Selector.patterns, as = Selector.assertions;
    var le, p, m, len = ps.length, name;

    while (e && le !== e && (/\S/).test(e)) {
      le = e;
      for (var i = 0; i<len; i++) {
        p = ps[i].re;
        name = ps[i].name;
        if (m = e.match(p)) {
          if (as[name]) {
            this.tokens.push([name, Object.clone(m)]);
            e = e.replace(m[0], '');
          } else {
            return this.findElements(document).include(element);
          }
        }
      }
    }

    var match = true, name, matches;
    for (var i = 0, token; token = this.tokens[i]; i++) {
      name = token[0], matches = token[1];
      if (!Selector.assertions[name](element, matches)) {
        match = false; break;
      }
    }

    return match;
  },

  toString: function() {
    return this.expression;
  },

  inspect: function() {
    return "#<Selector:" + this.expression.inspect() + ">";
  }
});

if (Prototype.BrowserFeatures.SelectorsAPI &&
 document.compatMode === 'BackCompat') {
  Selector.CASE_INSENSITIVE_CLASS_NAMES = (function(){
    var div = document.createElement('div'),
     span = document.createElement('span');

    div.id = "prototype_test_id";
    span.className = 'Test';
    div.appendChild(span);
    var isIgnored = (div.querySelector('#prototype_test_id .test') !== null);
    div = span = null;
    return isIgnored;
  })();
}

Object.extend(Selector, {
  _cache: { },

  xpath: {
    descendant:   "//*",
    child:        "/*",
    adjacent:     "/following-sibling::*[1]",
    laterSibling: '/following-sibling::*',
    tagName:      function(m) {
      if (m[1] == '*') return '';
      return "[local-name()='" + m[1].toLowerCase() +
             "' or local-name()='" + m[1].toUpperCase() + "']";
    },
    className:    "[contains(concat(' ', @class, ' '), ' #{1} ')]",
    id:           "[@id='#{1}']",
    attrPresence: function(m) {
      m[1] = m[1].toLowerCase();
      return new Template("[@#{1}]").evaluate(m);
    },
    attr: function(m) {
      m[1] = m[1].toLowerCase();
      m[3] = m[5] || m[6];
      return new Template(Selector.xpath.operators[m[2]]).evaluate(m);
    },
    pseudo: function(m) {
      var h = Selector.xpath.pseudos[m[1]];
      if (!h) return '';
      if (Object.isFunction(h)) return h(m);
      return new Template(Selector.xpath.pseudos[m[1]]).evaluate(m);
    },
    operators: {
      '=':  "[@#{1}='#{3}']",
      '!=': "[@#{1}!='#{3}']",
      '^=': "[starts-with(@#{1}, '#{3}')]",
      '$=': "[substring(@#{1}, (string-length(@#{1}) - string-length('#{3}') + 1))='#{3}']",
      '*=': "[contains(@#{1}, '#{3}')]",
      '~=': "[contains(concat(' ', @#{1}, ' '), ' #{3} ')]",
      '|=': "[contains(concat('-', @#{1}, '-'), '-#{3}-')]"
    },
    pseudos: {
      'first-child': '[not(preceding-sibling::*)]',
      'last-child':  '[not(following-sibling::*)]',
      'only-child':  '[not(preceding-sibling::* or following-sibling::*)]',
      'empty':       "[count(*) = 0 and (count(text()) = 0)]",
      'checked':     "[@checked]",
      'disabled':    "[(@disabled) and (@type!='hidden')]",
      'enabled':     "[not(@disabled) and (@type!='hidden')]",
      'not': function(m) {
        var e = m[6], p = Selector.patterns,
            x = Selector.xpath, le, v, len = p.length, name;

        var exclusion = [];
        while (e && le != e && (/\S/).test(e)) {
          le = e;
          for (var i = 0; i<len; i++) {
            name = p[i].name
            if (m = e.match(p[i].re)) {
              v = Object.isFunction(x[name]) ? x[name](m) : new Template(x[name]).evaluate(m);
              exclusion.push("(" + v.substring(1, v.length - 1) + ")");
              e = e.replace(m[0], '');
              break;
            }
          }
        }
        return "[not(" + exclusion.join(" and ") + ")]";
      },
      'nth-child':      function(m) {
        return Selector.xpath.pseudos.nth("(count(./preceding-sibling::*) + 1) ", m);
      },
      'nth-last-child': function(m) {
        return Selector.xpath.pseudos.nth("(count(./following-sibling::*) + 1) ", m);
      },
      'nth-of-type':    function(m) {
        return Selector.xpath.pseudos.nth("position() ", m);
      },
      'nth-last-of-type': function(m) {
        return Selector.xpath.pseudos.nth("(last() + 1 - position()) ", m);
      },
      'first-of-type':  function(m) {
        m[6] = "1"; return Selector.xpath.pseudos['nth-of-type'](m);
      },
      'last-of-type':   function(m) {
        m[6] = "1"; return Selector.xpath.pseudos['nth-last-of-type'](m);
      },
      'only-of-type':   function(m) {
        var p = Selector.xpath.pseudos; return p['first-of-type'](m) + p['last-of-type'](m);
      },
      nth: function(fragment, m) {
        var mm, formula = m[6], predicate;
        if (formula == 'even') formula = '2n+0';
        if (formula == 'odd')  formula = '2n+1';
        if (mm = formula.match(/^(\d+)$/)) // digit only
          return '[' + fragment + "= " + mm[1] + ']';
        if (mm = formula.match(/^(-?\d*)?n(([+-])(\d+))?/)) { // an+b
          if (mm[1] == "-") mm[1] = -1;
          var a = mm[1] ? Number(mm[1]) : 1;
          var b = mm[2] ? Number(mm[2]) : 0;
          predicate = "[((#{fragment} - #{b}) mod #{a} = 0) and " +
          "((#{fragment} - #{b}) div #{a} >= 0)]";
          return new Template(predicate).evaluate({
            fragment: fragment, a: a, b: b });
        }
      }
    }
  },

  criteria: {
    tagName:      'n = h.tagName(n, r, "#{1}", c);      c = false;',
    className:    'n = h.className(n, r, "#{1}", c);    c = false;',
    id:           'n = h.id(n, r, "#{1}", c);           c = false;',
    attrPresence: 'n = h.attrPresence(n, r, "#{1}", c); c = false;',
    attr: function(m) {
      m[3] = (m[5] || m[6]);
      return new Template('n = h.attr(n, r, "#{1}", "#{3}", "#{2}", c); c = false;').evaluate(m);
    },
    pseudo: function(m) {
      if (m[6]) m[6] = m[6].replace(/"/g, '\\"');
      return new Template('n = h.pseudo(n, "#{1}", "#{6}", r, c); c = false;').evaluate(m);
    },
    descendant:   'c = "descendant";',
    child:        'c = "child";',
    adjacent:     'c = "adjacent";',
    laterSibling: 'c = "laterSibling";'
  },

  patterns: [
    { name: 'laterSibling', re: /^\s*~\s*/ },
    { name: 'child',        re: /^\s*>\s*/ },
    { name: 'adjacent',     re: /^\s*\+\s*/ },
    { name: 'descendant',   re: /^\s/ },

    { name: 'tagName',      re: /^\s*(\*|[\w\-]+)(\b|$)?/ },
    { name: 'id',           re: /^#([\w\-\*]+)(\b|$)/ },
    { name: 'className',    re: /^\.([\w\-\*]+)(\b|$)/ },
    { name: 'pseudo',       re: /^:((first|last|nth|nth-last|only)(-child|-of-type)|empty|checked|(en|dis)abled|not)(\((.*?)\))?(\b|$|(?=\s|[:+~>]))/ },
    { name: 'attrPresence', re: /^\[((?:[\w-]+:)?[\w-]+)\]/ },
    { name: 'attr',         re: /\[((?:[\w-]*:)?[\w-]+)\s*(?:([!^$*~|]?=)\s*((['"])([^\4]*?)\4|([^'"][^\]]*?)))?\]/ }
  ],

  assertions: {
    tagName: function(element, matches) {
      return matches[1].toUpperCase() == element.tagName.toUpperCase();
    },

    className: function(element, matches) {
      return Element.hasClassName(element, matches[1]);
    },

    id: function(element, matches) {
      return element.id === matches[1];
    },

    attrPresence: function(element, matches) {
      return Element.hasAttribute(element, matches[1]);
    },

    attr: function(element, matches) {
      var nodeValue = Element.readAttribute(element, matches[1]);
      return nodeValue && Selector.operators[matches[2]](nodeValue, matches[5] || matches[6]);
    }
  },

  handlers: {
    concat: function(a, b) {
      for (var i = 0, node; node = b[i]; i++)
        a.push(node);
      return a;
    },

    mark: function(nodes) {
      var _true = Prototype.emptyFunction;
      for (var i = 0, node; node = nodes[i]; i++)
        node._countedByPrototype = _true;
      return nodes;
    },

    unmark: (function(){

      var PROPERTIES_ATTRIBUTES_MAP = (function(){
        var el = document.createElement('div'),
            isBuggy = false,
            propName = '_countedByPrototype',
            value = 'x'
        el[propName] = value;
        isBuggy = (el.getAttribute(propName) === value);
        el = null;
        return isBuggy;
      })();

      return PROPERTIES_ATTRIBUTES_MAP ?
        function(nodes) {
          for (var i = 0, node; node = nodes[i]; i++)
            node.removeAttribute('_countedByPrototype');
          return nodes;
        } :
        function(nodes) {
          for (var i = 0, node; node = nodes[i]; i++)
            node._countedByPrototype = void 0;
          return nodes;
        }
    })(),

    index: function(parentNode, reverse, ofType) {
      parentNode._countedByPrototype = Prototype.emptyFunction;
      if (reverse) {
        for (var nodes = parentNode.childNodes, i = nodes.length - 1, j = 1; i >= 0; i--) {
          var node = nodes[i];
          if (node.nodeType == 1 && (!ofType || node._countedByPrototype)) node.nodeIndex = j++;
        }
      } else {
        for (var i = 0, j = 1, nodes = parentNode.childNodes; node = nodes[i]; i++)
          if (node.nodeType == 1 && (!ofType || node._countedByPrototype)) node.nodeIndex = j++;
      }
    },

    unique: function(nodes) {
      if (nodes.length == 0) return nodes;
      var results = [], n;
      for (var i = 0, l = nodes.length; i < l; i++)
        if (typeof (n = nodes[i])._countedByPrototype == 'undefined') {
          n._countedByPrototype = Prototype.emptyFunction;
          results.push(Element.extend(n));
        }
      return Selector.handlers.unmark(results);
    },

    descendant: function(nodes) {
      var h = Selector.handlers;
      for (var i = 0, results = [], node; node = nodes[i]; i++)
        h.concat(results, node.getElementsByTagName('*'));
      return results;
    },

    child: function(nodes) {
      var h = Selector.handlers;
      for (var i = 0, results = [], node; node = nodes[i]; i++) {
        for (var j = 0, child; child = node.childNodes[j]; j++)
          if (child.nodeType == 1 && child.tagName != '!') results.push(child);
      }
      return results;
    },

    adjacent: function(nodes) {
      for (var i = 0, results = [], node; node = nodes[i]; i++) {
        var next = this.nextElementSibling(node);
        if (next) results.push(next);
      }
      return results;
    },

    laterSibling: function(nodes) {
      var h = Selector.handlers;
      for (var i = 0, results = [], node; node = nodes[i]; i++)
        h.concat(results, Element.nextSiblings(node));
      return results;
    },

    nextElementSibling: function(node) {
      while (node = node.nextSibling)
        if (node.nodeType == 1) return node;
      return null;
    },

    previousElementSibling: function(node) {
      while (node = node.previousSibling)
        if (node.nodeType == 1) return node;
      return null;
    },

    tagName: function(nodes, root, tagName, combinator) {
      var uTagName = tagName.toUpperCase();
      var results = [], h = Selector.handlers;
      if (nodes) {
        if (combinator) {
          if (combinator == "descendant") {
            for (var i = 0, node; node = nodes[i]; i++)
              h.concat(results, node.getElementsByTagName(tagName));
            return results;
          } else nodes = this[combinator](nodes);
          if (tagName == "*") return nodes;
        }
        for (var i = 0, node; node = nodes[i]; i++)
          if (node.tagName.toUpperCase() === uTagName) results.push(node);
        return results;
      } else return root.getElementsByTagName(tagName);
    },

    id: function(nodes, root, id, combinator) {
      var targetNode = $(id), h = Selector.handlers;

      if (root == document) {
        if (!targetNode) return [];
        if (!nodes) return [targetNode];
      } else {
        if (!root.sourceIndex || root.sourceIndex < 1) {
          var nodes = root.getElementsByTagName('*');
          for (var j = 0, node; node = nodes[j]; j++) {
            if (node.id === id) return [node];
          }
        }
      }

      if (nodes) {
        if (combinator) {
          if (combinator == 'child') {
            for (var i = 0, node; node = nodes[i]; i++)
              if (targetNode.parentNode == node) return [targetNode];
          } else if (combinator == 'descendant') {
            for (var i = 0, node; node = nodes[i]; i++)
              if (Element.descendantOf(targetNode, node)) return [targetNode];
          } else if (combinator == 'adjacent') {
            for (var i = 0, node; node = nodes[i]; i++)
              if (Selector.handlers.previousElementSibling(targetNode) == node)
                return [targetNode];
          } else nodes = h[combinator](nodes);
        }
        for (var i = 0, node; node = nodes[i]; i++)
          if (node == targetNode) return [targetNode];
        return [];
      }
      return (targetNode && Element.descendantOf(targetNode, root)) ? [targetNode] : [];
    },

    className: function(nodes, root, className, combinator) {
      if (nodes && combinator) nodes = this[combinator](nodes);
      return Selector.handlers.byClassName(nodes, root, className);
    },

    byClassName: function(nodes, root, className) {
      if (!nodes) nodes = Selector.handlers.descendant([root]);
      var needle = ' ' + className + ' ';
      for (var i = 0, results = [], node, nodeClassName; node = nodes[i]; i++) {
        nodeClassName = node.className;
        if (nodeClassName.length == 0) continue;
        if (nodeClassName == className || (' ' + nodeClassName + ' ').include(needle))
          results.push(node);
      }
      return results;
    },

    attrPresence: function(nodes, root, attr, combinator) {
      if (!nodes) nodes = root.getElementsByTagName("*");
      if (nodes && combinator) nodes = this[combinator](nodes);
      var results = [];
      for (var i = 0, node; node = nodes[i]; i++)
        if (Element.hasAttribute(node, attr)) results.push(node);
      return results;
    },

    attr: function(nodes, root, attr, value, operator, combinator) {
      if (!nodes) nodes = root.getElementsByTagName("*");
      if (nodes && combinator) nodes = this[combinator](nodes);
      var handler = Selector.operators[operator], results = [];
      for (var i = 0, node; node = nodes[i]; i++) {
        var nodeValue = Element.readAttribute(node, attr);
        if (nodeValue === null) continue;
        if (handler(nodeValue, value)) results.push(node);
      }
      return results;
    },

    pseudo: function(nodes, name, value, root, combinator) {
      if (nodes && combinator) nodes = this[combinator](nodes);
      if (!nodes) nodes = root.getElementsByTagName("*");
      return Selector.pseudos[name](nodes, value, root);
    }
  },

  pseudos: {
    'first-child': function(nodes, value, root) {
      for (var i = 0, results = [], node; node = nodes[i]; i++) {
        if (Selector.handlers.previousElementSibling(node)) continue;
          results.push(node);
      }
      return results;
    },
    'last-child': function(nodes, value, root) {
      for (var i = 0, results = [], node; node = nodes[i]; i++) {
        if (Selector.handlers.nextElementSibling(node)) continue;
          results.push(node);
      }
      return results;
    },
    'only-child': function(nodes, value, root) {
      var h = Selector.handlers;
      for (var i = 0, results = [], node; node = nodes[i]; i++)
        if (!h.previousElementSibling(node) && !h.nextElementSibling(node))
          results.push(node);
      return results;
    },
    'nth-child':        function(nodes, formula, root) {
      return Selector.pseudos.nth(nodes, formula, root);
    },
    'nth-last-child':   function(nodes, formula, root) {
      return Selector.pseudos.nth(nodes, formula, root, true);
    },
    'nth-of-type':      function(nodes, formula, root) {
      return Selector.pseudos.nth(nodes, formula, root, false, true);
    },
    'nth-last-of-type': function(nodes, formula, root) {
      return Selector.pseudos.nth(nodes, formula, root, true, true);
    },
    'first-of-type':    function(nodes, formula, root) {
      return Selector.pseudos.nth(nodes, "1", root, false, true);
    },
    'last-of-type':     function(nodes, formula, root) {
      return Selector.pseudos.nth(nodes, "1", root, true, true);
    },
    'only-of-type':     function(nodes, formula, root) {
      var p = Selector.pseudos;
      return p['last-of-type'](p['first-of-type'](nodes, formula, root), formula, root);
    },

    getIndices: function(a, b, total) {
      if (a == 0) return b > 0 ? [b] : [];
      return $R(1, total).inject([], function(memo, i) {
        if (0 == (i - b) % a && (i - b) / a >= 0) memo.push(i);
        return memo;
      });
    },

    nth: function(nodes, formula, root, reverse, ofType) {
      if (nodes.length == 0) return [];
      if (formula == 'even') formula = '2n+0';
      if (formula == 'odd')  formula = '2n+1';
      var h = Selector.handlers, results = [], indexed = [], m;
      h.mark(nodes);
      for (var i = 0, node; node = nodes[i]; i++) {
        if (!node.parentNode._countedByPrototype) {
          h.index(node.parentNode, reverse, ofType);
          indexed.push(node.parentNode);
        }
      }
      if (formula.match(/^\d+$/)) { // just a number
        formula = Number(formula);
        for (var i = 0, node; node = nodes[i]; i++)
          if (node.nodeIndex == formula) results.push(node);
      } else if (m = formula.match(/^(-?\d*)?n(([+-])(\d+))?/)) { // an+b
        if (m[1] == "-") m[1] = -1;
        var a = m[1] ? Number(m[1]) : 1;
        var b = m[2] ? Number(m[2]) : 0;
        var indices = Selector.pseudos.getIndices(a, b, nodes.length);
        for (var i = 0, node, l = indices.length; node = nodes[i]; i++) {
          for (var j = 0; j < l; j++)
            if (node.nodeIndex == indices[j]) results.push(node);
        }
      }
      h.unmark(nodes);
      h.unmark(indexed);
      return results;
    },

    'empty': function(nodes, value, root) {
      for (var i = 0, results = [], node; node = nodes[i]; i++) {
        if (node.tagName == '!' || node.firstChild) continue;
        results.push(node);
      }
      return results;
    },

    'not': function(nodes, selector, root) {
      var h = Selector.handlers, selectorType, m;
      var exclusions = new Selector(selector).findElements(root);
      h.mark(exclusions);
      for (var i = 0, results = [], node; node = nodes[i]; i++)
        if (!node._countedByPrototype) results.push(node);
      h.unmark(exclusions);
      return results;
    },

    'enabled': function(nodes, value, root) {
      for (var i = 0, results = [], node; node = nodes[i]; i++)
        if (!node.disabled && (!node.type || node.type !== 'hidden'))
          results.push(node);
      return results;
    },

    'disabled': function(nodes, value, root) {
      for (var i = 0, results = [], node; node = nodes[i]; i++)
        if (node.disabled) results.push(node);
      return results;
    },

    'checked': function(nodes, value, root) {
      for (var i = 0, results = [], node; node = nodes[i]; i++)
        if (node.checked) results.push(node);
      return results;
    }
  },

  operators: {
    '=':  function(nv, v) { return nv == v; },
    '!=': function(nv, v) { return nv != v; },
    '^=': function(nv, v) { return nv == v || nv && nv.startsWith(v); },
    '$=': function(nv, v) { return nv == v || nv && nv.endsWith(v); },
    '*=': function(nv, v) { return nv == v || nv && nv.include(v); },
    '~=': function(nv, v) { return (' ' + nv + ' ').include(' ' + v + ' '); },
    '|=': function(nv, v) { return ('-' + (nv || "").toUpperCase() +
     '-').include('-' + (v || "").toUpperCase() + '-'); }
  },

  split: function(expression) {
    var expressions = [];
    expression.scan(/(([\w#:.~>+()\s-]+|\*|\[.*?\])+)\s*(,|$)/, function(m) {
      expressions.push(m[1].strip());
    });
    return expressions;
  },

  matchElements: function(elements, expression) {
    var matches = $$(expression), h = Selector.handlers;
    h.mark(matches);
    for (var i = 0, results = [], element; element = elements[i]; i++)
      if (element._countedByPrototype) results.push(element);
    h.unmark(matches);
    return results;
  },

  findElement: function(elements, expression, index) {
    if (Object.isNumber(expression)) {
      index = expression; expression = false;
    }
    return Selector.matchElements(elements, expression || '*')[index || 0];
  },

  findChildElements: function(element, expressions) {
    expressions = Selector.split(expressions.join(','));
    var results = [], h = Selector.handlers;
    for (var i = 0, l = expressions.length, selector; i < l; i++) {
      selector = new Selector(expressions[i].strip());
      h.concat(results, selector.findElements(element));
    }
    return (l > 1) ? h.unique(results) : results;
  }
});

if (Prototype.Browser.IE) {
  Object.extend(Selector.handlers, {
    concat: function(a, b) {
      for (var i = 0, node; node = b[i]; i++)
        if (node.tagName !== "!") a.push(node);
      return a;
    }
  });
}

function $$() {
  return Selector.findChildElements(document, $A(arguments));
}

var Form = {
  reset: function(form) {
    form = $(form);
    form.reset();
    return form;
  },

  serializeElements: function(elements, options) {
    if (typeof options != 'object') options = { hash: !!options };
    else if (Object.isUndefined(options.hash)) options.hash = true;
    var key, value, submitted = false, submit = options.submit;

    var data = elements.inject({ }, function(result, element) {
      if (!element.disabled && element.name) {
        key = element.name; value = $(element).getValue();
        if (value != null && element.type != 'file' && (element.type != 'submit' || (!submitted &&
            submit !== false && (!submit || key == submit) && (submitted = true)))) {
          if (key in result) {
            if (!Object.isArray(result[key])) result[key] = [result[key]];
            result[key].push(value);
          }
          else result[key] = value;
        }
      }
      return result;
    });

    return options.hash ? data : Object.toQueryString(data);
  }
};

Form.Methods = {
  serialize: function(form, options) {
    return Form.serializeElements(Form.getElements(form), options);
  },

  getElements: function(form) {
    var elements = $(form).getElementsByTagName('*'),
        element,
        arr = [ ],
        serializers = Form.Element.Serializers;
    for (var i = 0; element = elements[i]; i++) {
      arr.push(element);
    }
    return arr.inject([], function(elements, child) {
      if (serializers[child.tagName.toLowerCase()])
        elements.push(Element.extend(child));
      return elements;
    })
  },

  getInputs: function(form, typeName, name) {
    form = $(form);
    var inputs = form.getElementsByTagName('input');

    if (!typeName && !name) return $A(inputs).map(Element.extend);

    for (var i = 0, matchingInputs = [], length = inputs.length; i < length; i++) {
      var input = inputs[i];
      if ((typeName && input.type != typeName) || (name && input.name != name))
        continue;
      matchingInputs.push(Element.extend(input));
    }

    return matchingInputs;
  },

  disable: function(form) {
    form = $(form);
    Form.getElements(form).invoke('disable');
    return form;
  },

  enable: function(form) {
    form = $(form);
    Form.getElements(form).invoke('enable');
    return form;
  },

  findFirstElement: function(form) {
    var elements = $(form).getElements().findAll(function(element) {
      return 'hidden' != element.type && !element.disabled;
    });
    var firstByIndex = elements.findAll(function(element) {
      return element.hasAttribute('tabIndex') && element.tabIndex >= 0;
    }).sortBy(function(element) { return element.tabIndex }).first();

    return firstByIndex ? firstByIndex : elements.find(function(element) {
      return /^(?:input|select|textarea)$/i.test(element.tagName);
    });
  },

  focusFirstElement: function(form) {
    form = $(form);
    form.findFirstElement().activate();
    return form;
  },

  request: function(form, options) {
    form = $(form), options = Object.clone(options || { });

    var params = options.parameters, action = form.readAttribute('action') || '';
    if (action.blank()) action = window.location.href;
    options.parameters = form.serialize(true);

    if (params) {
      if (Object.isString(params)) params = params.toQueryParams();
      Object.extend(options.parameters, params);
    }

    if (form.hasAttribute('method') && !options.method)
      options.method = form.method;

    return new Ajax.Request(action, options);
  }
};

/*--------------------------------------------------------------------------*/


Form.Element = {
  focus: function(element) {
    $(element).focus();
    return element;
  },

  select: function(element) {
    $(element).select();
    return element;
  }
};

Form.Element.Methods = {

  serialize: function(element) {
    element = $(element);
    if (!element.disabled && element.name) {
      var value = element.getValue();
      if (value != undefined) {
        var pair = { };
        pair[element.name] = value;
        return Object.toQueryString(pair);
      }
    }
    return '';
  },

  getValue: function(element) {
    element = $(element);
    var method = element.tagName.toLowerCase();
    return Form.Element.Serializers[method](element);
  },

  setValue: function(element, value) {
    element = $(element);
    var method = element.tagName.toLowerCase();
    Form.Element.Serializers[method](element, value);
    return element;
  },

  clear: function(element) {
    $(element).value = '';
    return element;
  },

  present: function(element) {
    return $(element).value != '';
  },

  activate: function(element) {
    element = $(element);
    try {
      element.focus();
      if (element.select && (element.tagName.toLowerCase() != 'input' ||
          !(/^(?:button|reset|submit)$/i.test(element.type))))
        element.select();
    } catch (e) { }
    return element;
  },

  disable: function(element) {
    element = $(element);
    element.disabled = true;
    return element;
  },

  enable: function(element) {
    element = $(element);
    element.disabled = false;
    return element;
  }
};

/*--------------------------------------------------------------------------*/

var Field = Form.Element;

var $F = Form.Element.Methods.getValue;

/*--------------------------------------------------------------------------*/

Form.Element.Serializers = {
  input: function(element, value) {
    switch (element.type.toLowerCase()) {
      case 'checkbox':
      case 'radio':
        return Form.Element.Serializers.inputSelector(element, value);
      default:
        return Form.Element.Serializers.textarea(element, value);
    }
  },

  inputSelector: function(element, value) {
    if (Object.isUndefined(value)) return element.checked ? element.value : null;
    else element.checked = !!value;
  },

  textarea: function(element, value) {
    if (Object.isUndefined(value)) return element.value;
    else element.value = value;
  },

  select: function(element, value) {
    if (Object.isUndefined(value))
      return this[element.type == 'select-one' ?
        'selectOne' : 'selectMany'](element);
    else {
      var opt, currentValue, single = !Object.isArray(value);
      for (var i = 0, length = element.length; i < length; i++) {
        opt = element.options[i];
        currentValue = this.optionValue(opt);
        if (single) {
          if (currentValue == value) {
            opt.selected = true;
            return;
          }
        }
        else opt.selected = value.include(currentValue);
      }
    }
  },

  selectOne: function(element) {
    var index = element.selectedIndex;
    return index >= 0 ? this.optionValue(element.options[index]) : null;
  },

  selectMany: function(element) {
    var values, length = element.length;
    if (!length) return null;

    for (var i = 0, values = []; i < length; i++) {
      var opt = element.options[i];
      if (opt.selected) values.push(this.optionValue(opt));
    }
    return values;
  },

  optionValue: function(opt) {
    return Element.extend(opt).hasAttribute('value') ? opt.value : opt.text;
  }
};

/*--------------------------------------------------------------------------*/


Abstract.TimedObserver = Class.create(PeriodicalExecuter, {
  initialize: function($super, element, frequency, callback) {
    $super(callback, frequency);
    this.element   = $(element);
    this.lastValue = this.getValue();
  },

  execute: function() {
    var value = this.getValue();
    if (Object.isString(this.lastValue) && Object.isString(value) ?
        this.lastValue != value : String(this.lastValue) != String(value)) {
      this.callback(this.element, value);
      this.lastValue = value;
    }
  }
});

Form.Element.Observer = Class.create(Abstract.TimedObserver, {
  getValue: function() {
    return Form.Element.getValue(this.element);
  }
});

Form.Observer = Class.create(Abstract.TimedObserver, {
  getValue: function() {
    return Form.serialize(this.element);
  }
});

/*--------------------------------------------------------------------------*/

Abstract.EventObserver = Class.create({
  initialize: function(element, callback) {
    this.element  = $(element);
    this.callback = callback;

    this.lastValue = this.getValue();
    if (this.element.tagName.toLowerCase() == 'form')
      this.registerFormCallbacks();
    else
      this.registerCallback(this.element);
  },

  onElementEvent: function() {
    var value = this.getValue();
    if (this.lastValue != value) {
      this.callback(this.element, value);
      this.lastValue = value;
    }
  },

  registerFormCallbacks: function() {
    Form.getElements(this.element).each(this.registerCallback, this);
  },

  registerCallback: function(element) {
    if (element.type) {
      switch (element.type.toLowerCase()) {
        case 'checkbox':
        case 'radio':
          Event.observe(element, 'click', this.onElementEvent.bind(this));
          break;
        default:
          Event.observe(element, 'change', this.onElementEvent.bind(this));
          break;
      }
    }
  }
});

Form.Element.EventObserver = Class.create(Abstract.EventObserver, {
  getValue: function() {
    return Form.Element.getValue(this.element);
  }
});

Form.EventObserver = Class.create(Abstract.EventObserver, {
  getValue: function() {
    return Form.serialize(this.element);
  }
});
(function() {

  var Event = {
    KEY_BACKSPACE: 8,
    KEY_TAB:       9,
    KEY_RETURN:   13,
    KEY_ESC:      27,
    KEY_LEFT:     37,
    KEY_UP:       38,
    KEY_RIGHT:    39,
    KEY_DOWN:     40,
    KEY_DELETE:   46,
    KEY_HOME:     36,
    KEY_END:      35,
    KEY_PAGEUP:   33,
    KEY_PAGEDOWN: 34,
    KEY_INSERT:   45,

    cache: {}
  };

  var docEl = document.documentElement;
  var MOUSEENTER_MOUSELEAVE_EVENTS_SUPPORTED = 'onmouseenter' in docEl
    && 'onmouseleave' in docEl;

  var _isButton;
  if (Prototype.Browser.IE) {
    var buttonMap = { 0: 1, 1: 4, 2: 2 };
    _isButton = function(event, code) {
      return event.button === buttonMap[code];
    };
  } else if (Prototype.Browser.WebKit) {
    _isButton = function(event, code) {
      switch (code) {
        case 0: return event.which == 1 && !event.metaKey;
        case 1: return event.which == 1 && event.metaKey;
        default: return false;
      }
    };
  } else {
    _isButton = function(event, code) {
      return event.which ? (event.which === code + 1) : (event.button === code);
    };
  }

  function isLeftClick(event)   { return _isButton(event, 0) }

  function isMiddleClick(event) { return _isButton(event, 1) }

  function isRightClick(event)  { return _isButton(event, 2) }

  function element(event) {
    event = Event.extend(event);

    var node = event.target, type = event.type,
     currentTarget = event.currentTarget;

    if (currentTarget && currentTarget.tagName) {
      if (type === 'load' || type === 'error' ||
        (type === 'click' && currentTarget.tagName.toLowerCase() === 'input'
          && currentTarget.type === 'radio'))
            node = currentTarget;
    }

    if (node.nodeType == Node.TEXT_NODE)
      node = node.parentNode;

    return Element.extend(node);
  }

  function findElement(event, expression) {
    var element = Event.element(event);
    if (!expression) return element;
    var elements = [element].concat(element.ancestors());
    return Selector.findElement(elements, expression, 0);
  }

  function pointer(event) {
    return { x: pointerX(event), y: pointerY(event) };
  }

  function pointerX(event) {
    var docElement = document.documentElement,
     body = document.body || { scrollLeft: 0 };

    return event.pageX || (event.clientX +
      (docElement.scrollLeft || body.scrollLeft) -
      (docElement.clientLeft || 0));
  }

  function pointerY(event) {
    var docElement = document.documentElement,
     body = document.body || { scrollTop: 0 };

    return  event.pageY || (event.clientY +
       (docElement.scrollTop || body.scrollTop) -
       (docElement.clientTop || 0));
  }


  function stop(event) {
    Event.extend(event);
    event.preventDefault();
    event.stopPropagation();

    event.stopped = true;
  }

  Event.Methods = {
    isLeftClick: isLeftClick,
    isMiddleClick: isMiddleClick,
    isRightClick: isRightClick,

    element: element,
    findElement: findElement,

    pointer: pointer,
    pointerX: pointerX,
    pointerY: pointerY,

    stop: stop
  };


  var methods = Object.keys(Event.Methods).inject({ }, function(m, name) {
    m[name] = Event.Methods[name].methodize();
    return m;
  });

  if (Prototype.Browser.IE) {
    function _relatedTarget(event) {
      var element;
      switch (event.type) {
        case 'mouseover': element = event.fromElement; break;
        case 'mouseout':  element = event.toElement;   break;
        default: return null;
      }
      return Element.extend(element);
    }

    Object.extend(methods, {
      stopPropagation: function() { this.cancelBubble = true },
      preventDefault:  function() { this.returnValue = false },
      inspect: function() { return '[object Event]' }
    });

    Event.extend = function(event, element) {
      if (!event) return false;
      if (event._extendedByPrototype) return event;

      event._extendedByPrototype = Prototype.emptyFunction;
      var pointer = Event.pointer(event);

      Object.extend(event, {
        target: event.srcElement || element,
        relatedTarget: _relatedTarget(event),
        pageX:  pointer.x,
        pageY:  pointer.y
      });

      return Object.extend(event, methods);
    };
  } else {
    Event.prototype = window.Event.prototype || document.createEvent('HTMLEvents').__proto__;
    Object.extend(Event.prototype, methods);
    Event.extend = Prototype.K;
  }

  function _createResponder(element, eventName, handler) {
    var registry = Element.retrieve(element, 'prototype_event_registry');

    if (Object.isUndefined(registry)) {
      CACHE.push(element);
      registry = Element.retrieve(element, 'prototype_event_registry', $H());
    }

    var respondersForEvent = registry.get(eventName);
    if (Object.isUndefined(respondersForEvent)) {
      respondersForEvent = [];
      registry.set(eventName, respondersForEvent);
    }

    if (respondersForEvent.pluck('handler').include(handler)) return false;

    var responder;
    if (eventName.include(":")) {
      responder = function(event) {
        if (Object.isUndefined(event.eventName))
          return false;

        if (event.eventName !== eventName)
          return false;

        Event.extend(event, element);
        handler.call(element, event);
      };
    } else {
      if (!MOUSEENTER_MOUSELEAVE_EVENTS_SUPPORTED &&
       (eventName === "mouseenter" || eventName === "mouseleave")) {
        if (eventName === "mouseenter" || eventName === "mouseleave") {
          responder = function(event) {
            Event.extend(event, element);

            var parent = event.relatedTarget;
            while (parent && parent !== element) {
              try { parent = parent.parentNode; }
              catch(e) { parent = element; }
            }

            if (parent === element) return;

            handler.call(element, event);
          };
        }
      } else {
        responder = function(event) {
          Event.extend(event, element);
          handler.call(element, event);
        };
      }
    }

    responder.handler = handler;
    respondersForEvent.push(responder);
    return responder;
  }

  function _destroyCache() {
    for (var i = 0, length = CACHE.length; i < length; i++) {
      Event.stopObserving(CACHE[i]);
      CACHE[i] = null;
    }
  }

  var CACHE = [];

  if (Prototype.Browser.IE)
    window.attachEvent('onunload', _destroyCache);

  if (Prototype.Browser.WebKit)
    window.addEventListener('unload', Prototype.emptyFunction, false);


  var _getDOMEventName = Prototype.K;

  if (!MOUSEENTER_MOUSELEAVE_EVENTS_SUPPORTED) {
    _getDOMEventName = function(eventName) {
      var translations = { mouseenter: "mouseover", mouseleave: "mouseout" };
      return eventName in translations ? translations[eventName] : eventName;
    };
  }

  function observe(element, eventName, handler) {
    element = $(element);

    var responder = _createResponder(element, eventName, handler);

    if (!responder) return element;

    if (eventName.include(':')) {
      if (element.addEventListener)
        element.addEventListener("dataavailable", responder, false);
      else {
        element.attachEvent("ondataavailable", responder);
        element.attachEvent("onfilterchange", responder);
      }
    } else {
      var actualEventName = _getDOMEventName(eventName);

      if (element.addEventListener)
        element.addEventListener(actualEventName, responder, false);
      else
        element.attachEvent("on" + actualEventName, responder);
    }

    return element;
  }

  function stopObserving(element, eventName, handler) {
    element = $(element);

    var registry = Element.retrieve(element, 'prototype_event_registry');

    if (Object.isUndefined(registry)) return element;

    if (eventName && !handler) {
      var responders = registry.get(eventName);

      if (Object.isUndefined(responders)) return element;

      responders.each( function(r) {
        Element.stopObserving(element, eventName, r.handler);
      });
      return element;
    } else if (!eventName) {
      registry.each( function(pair) {
        var eventName = pair.key, responders = pair.value;

        responders.each( function(r) {
          Element.stopObserving(element, eventName, r.handler);
        });
      });
      return element;
    }

    var responders = registry.get(eventName);

    if (!responders) return;

    var responder = responders.find( function(r) { return r.handler === handler; });
    if (!responder) return element;

    var actualEventName = _getDOMEventName(eventName);

    if (eventName.include(':')) {
      if (element.removeEventListener)
        element.removeEventListener("dataavailable", responder, false);
      else {
        element.detachEvent("ondataavailable", responder);
        element.detachEvent("onfilterchange",  responder);
      }
    } else {
      if (element.removeEventListener)
        element.removeEventListener(actualEventName, responder, false);
      else
        element.detachEvent('on' + actualEventName, responder);
    }

    registry.set(eventName, responders.without(responder));

    return element;
  }

  function fire(element, eventName, memo, bubble) {
    element = $(element);

    if (Object.isUndefined(bubble))
      bubble = true;

    if (element == document && document.createEvent && !element.dispatchEvent)
      element = document.documentElement;

    var event;
    if (document.createEvent) {
      event = document.createEvent('HTMLEvents');
      event.initEvent('dataavailable', true, true);
    } else {
      event = document.createEventObject();
      event.eventType = bubble ? 'ondataavailable' : 'onfilterchange';
    }

    event.eventName = eventName;
    event.memo = memo || { };

    if (document.createEvent)
      element.dispatchEvent(event);
    else
      element.fireEvent(event.eventType, event);

    return Event.extend(event);
  }


  Object.extend(Event, Event.Methods);

  Object.extend(Event, {
    fire:          fire,
    observe:       observe,
    stopObserving: stopObserving
  });

  Element.addMethods({
    fire:          fire,

    observe:       observe,

    stopObserving: stopObserving
  });

  Object.extend(document, {
    fire:          fire.methodize(),

    observe:       observe.methodize(),

    stopObserving: stopObserving.methodize(),

    loaded:        false
  });

  if (window.Event) Object.extend(window.Event, Event);
  else window.Event = Event;
})();

(function() {
  /* Support for the DOMContentLoaded event is based on work by Dan Webb,
     Matthias Miller, Dean Edwards, John Resig, and Diego Perini. */

  var timer;

  function fireContentLoadedEvent() {
    if (document.loaded) return;
    if (timer) window.clearTimeout(timer);
    document.loaded = true;
    document.fire('dom:loaded');
  }

  function checkReadyState() {
    if (document.readyState === 'complete') {
      document.stopObserving('readystatechange', checkReadyState);
      fireContentLoadedEvent();
    }
  }

  function pollDoScroll() {
    try { document.documentElement.doScroll('left'); }
    catch(e) {
      timer = pollDoScroll.defer();
      return;
    }
    fireContentLoadedEvent();
  }

  if (document.addEventListener) {
    document.addEventListener('DOMContentLoaded', fireContentLoadedEvent, false);
  } else {
    document.observe('readystatechange', checkReadyState);
    if (window == top)
      timer = pollDoScroll.defer();
  }

  Event.observe(window, 'load', fireContentLoadedEvent);
})();

Element.addMethods();

/*------------------------------- DEPRECATED -------------------------------*/

Hash.toQueryString = Object.toQueryString;

var Toggle = { display: Element.toggle };

Element.Methods.childOf = Element.Methods.descendantOf;

var Insertion = {
  Before: function(element, content) {
    return Element.insert(element, {before:content});
  },

  Top: function(element, content) {
    return Element.insert(element, {top:content});
  },

  Bottom: function(element, content) {
    return Element.insert(element, {bottom:content});
  },

  After: function(element, content) {
    return Element.insert(element, {after:content});
  }
};

var $continue = new Error('"throw $continue" is deprecated, use "return" instead');

var Position = {
  includeScrollOffsets: false,

  prepare: function() {
    this.deltaX =  window.pageXOffset
                || document.documentElement.scrollLeft
                || document.body.scrollLeft
                || 0;
    this.deltaY =  window.pageYOffset
                || document.documentElement.scrollTop
                || document.body.scrollTop
                || 0;
  },

  within: function(element, x, y) {
    if (this.includeScrollOffsets)
      return this.withinIncludingScrolloffsets(element, x, y);
    this.xcomp = x;
    this.ycomp = y;
    this.offset = Element.cumulativeOffset(element);

    return (y >= this.offset[1] &&
            y <  this.offset[1] + element.offsetHeight &&
            x >= this.offset[0] &&
            x <  this.offset[0] + element.offsetWidth);
  },

  withinIncludingScrolloffsets: function(element, x, y) {
    var offsetcache = Element.cumulativeScrollOffset(element);

    this.xcomp = x + offsetcache[0] - this.deltaX;
    this.ycomp = y + offsetcache[1] - this.deltaY;
    this.offset = Element.cumulativeOffset(element);

    return (this.ycomp >= this.offset[1] &&
            this.ycomp <  this.offset[1] + element.offsetHeight &&
            this.xcomp >= this.offset[0] &&
            this.xcomp <  this.offset[0] + element.offsetWidth);
  },

  overlap: function(mode, element) {
    if (!mode) return 0;
    if (mode == 'vertical')
      return ((this.offset[1] + element.offsetHeight) - this.ycomp) /
        element.offsetHeight;
    if (mode == 'horizontal')
      return ((this.offset[0] + element.offsetWidth) - this.xcomp) /
        element.offsetWidth;
  },


  cumulativeOffset: Element.Methods.cumulativeOffset,

  positionedOffset: Element.Methods.positionedOffset,

  absolutize: function(element) {
    Position.prepare();
    return Element.absolutize(element);
  },

  relativize: function(element) {
    Position.prepare();
    return Element.relativize(element);
  },

  realOffset: Element.Methods.cumulativeScrollOffset,

  offsetParent: Element.Methods.getOffsetParent,

  page: Element.Methods.viewportOffset,

  clone: function(source, target, options) {
    options = options || { };
    return Element.clonePosition(target, source, options);
  }
};

/*--------------------------------------------------------------------------*/

if (!document.getElementsByClassName) document.getElementsByClassName = function(instanceMethods){
  function iter(name) {
    return name.blank() ? null : "[contains(concat(' ', @class, ' '), ' " + name + " ')]";
  }

  instanceMethods.getElementsByClassName = Prototype.BrowserFeatures.XPath ?
  function(element, className) {
    className = className.toString().strip();
    var cond = /\s/.test(className) ? $w(className).map(iter).join('') : iter(className);
    return cond ? document._getElementsByXPath('.//*' + cond, element) : [];
  } : function(element, className) {
    className = className.toString().strip();
    var elements = [], classNames = (/\s/.test(className) ? $w(className) : null);
    if (!classNames && !className) return elements;

    var nodes = $(element).getElementsByTagName('*');
    className = ' ' + className + ' ';

    for (var i = 0, child, cn; child = nodes[i]; i++) {
      if (child.className && (cn = ' ' + child.className + ' ') && (cn.include(className) ||
          (classNames && classNames.all(function(name) {
            return !name.toString().blank() && cn.include(' ' + name + ' ');
          }))))
        elements.push(Element.extend(child));
    }
    return elements;
  };

  return function(className, parentElement) {
    return $(parentElement || document.body).getElementsByClassName(className);
  };
}(Element.Methods);

/*--------------------------------------------------------------------------*/

Element.ClassNames = Class.create();
Element.ClassNames.prototype = {
  initialize: function(element) {
    this.element = $(element);
  },

  _each: function(iterator) {
    this.element.className.split(/\s+/).select(function(name) {
      return name.length > 0;
    })._each(iterator);
  },

  set: function(className) {
    this.element.className = className;
  },

  add: function(classNameToAdd) {
    if (this.include(classNameToAdd)) return;
    this.set($A(this).concat(classNameToAdd).join(' '));
  },

  remove: function(classNameToRemove) {
    if (!this.include(classNameToRemove)) return;
    this.set($A(this).without(classNameToRemove).join(' '));
  },

  toString: function() {
    return $A(this).join(' ');
  }
};

Object.extend(Element.ClassNames.prototype, Enumerable);

/*--------------------------------------------------------------------------*/


/*  file:4  */
/** funs from fb **/
function gen_unique(){
    return++gen_unique._counter;
}

gen_unique._counter=0;

function ge(id){
    if(typeof(id)=='undefined'){
	return null;
    }
    var obj;
    if(typeof(id)=='string'){
	obj=document.getElementById(id);
	if(!(ua.ie()>=7)){
	    return obj;
	}

	if(!obj){
	    return null;
	}else if(typeof(obj.id)=='string'&&obj.id==id){
	    return obj;
	}else{
	    var candidates=document.getElementsByName(id);
	    if(!candidates||!candidates.length){
		return null;
	    }
	    var maybe=[];
	    for(var ii=0;ii<candidates.length;ii++){
		var c=candidates[ii];
		if(!c.id&&id){
		    continue;
		}
		if(typeof(c.id)=='string'&&c.id!=id){
		    continue;
		}

		maybe.push(candidates[ii]);
	    }
	    if(maybe.length!=1){
		return null;
	    }
	    return maybe[0];
	}
    }else{
	return id;
    }
    return null;
}


function show(){
    for(var i=0;i<arguments.length;i++){
	var element=ge(arguments[i]);
	if(element&&element.style)
	    element.style.display='';
    }
    return false;
}

function hide(){
    for(var i=0;i<arguments.length;i++){
	var element=ge(arguments[i]);
	if(element&&element.style)
	    element.style.display='none';
    }
    return false;
}
function shown(el){
    el=ge(el);
    return(el.style.display!='none');
}

function toggle(){
    for(var i=0;i<arguments.length;i++){
	var element=$(arguments[i]);
	element.style.display=get_style(element,"display")=='block'?'none':'block';
    }
    return false;
}
function is_descendent(base_obj,target_id){
    var target_obj=ge(target_id);
    if(base_obj==null)
	return;
    while(base_obj!=target_obj){
	if(base_obj.parentNode){
	    base_obj=base_obj.parentNode;
	}else{
	    return false;
	}
    }
    return true;
}
function get_style(object,prop){
    function hyphenate(prop){
	return prop.replace(/[A-Z]/g,function(match){
		return'-'+match.toLowerCase();
	    }
	    );
    }
    if(window.getComputedStyle){
	return window.getComputedStyle(object,null).getPropertyValue(hyphenate(prop));
    }
    if(document.defaultView&&document.defaultView.getComputedStyle){
	var computedStyle=document.defaultView.getComputedStyle(object,null);
	if(computedStyle)
	    return computedStyle.getPropertyValue(hyphenate(prop));
	if(prop=="display")
	    return"none";
    }
    if(object.currentStyle){
	return object.currentStyle[prop];
    }
    return object.style[prop];
}



function remove_node(node){
    if(node.removeNode){
	node.removeNode(true);
    }else{
	for(var ii=node.childNodes.length-1;ii>=0;ii--){
	    remove_node(node.childNodes[ii]);
	}
	node.parentNode.removeChild(node);
    }
    return null;
}

function create_hidden_input(name,value){
    var new_input=document.createElement('input');
    new_input.name=name;
    new_input.id=name;
    new_input.value=value;
    new_input.type='hidden';
    return new_input;
}

function has_css_class_name(elem,cname){
    return(elem&&cname)?new RegExp('\\b'+trim(cname)+'\\b').test(elem.className):false;
}
function swap_css_class_name(elements,class1,class2){
    for(var i=0;i<elements.length;i++){
	var element=ge(elements[i]);
	if(element.className.indexOf(class1)!=-1){
	    element.className=element.className.replace(class1,class2);
	}else{
	    element.className=element.className.replace(class2,class1);
	}
    }
}

function add_css_class_name(elem,cname){
    if(elem&&cname){
	if(elem.className){
	    if(has_css_class_name(elem,cname)){
		return false;
	    }else{
		elem.className+=' '+trim(cname);
		return true;
	    }
	}else{
	    elem.className=cname;
	    return true;
	}
    }else{return false;}
}

function remove_css_class_name(elem,cname){
    if(elem&&cname&&elem.className){
	cname=trim(cname);
	var old=elem.className;
	elem.className=elem.className.replace(new RegExp('\\b'+cname+'\\b'),'');
	return elem.className!=old;
    }else{
	return false;
    }
}

function toggle_css_class_name(elem,cname){
    if(has_css_class_name(elem,cname)){
	remove_css_class_name(elem,cname);
    }else{
	add_css_class_name(elem,cname);
    }
}

function set_inner_html(obj,html){
    var dummy='<span style="display:none">&nbsp</span>';
    html=html.replace('<style',dummy+'<style');
    html=html.replace('<STYLE',dummy+'<STYLE');
    html=html.replace('<script',dummy+'<script');
    html=html.replace('<SCRIPT',dummy+'<SCRIPT');
    obj.innerHTML=html;
    eval_inner_js(obj);
    addSafariLabelSupport(obj);
}
function eval_inner_js(obj){
    var scripts=obj.getElementsByTagName('script');
    for(var i=0;i<scripts.length;i++){
	if(scripts[i].src){
	    var script=document.createElement('script');
	    script.type='text/javascript';
	    script.src=scripts[i].src;
	    if(document.body.firstChild)
		document.body.insertBefore(script,document.body.firstChild);
	    else
		document.body.appendChild(script);
	}else{
	    try{
		eval_global(scripts[i].innerHTML);
	    }catch(e){
		if(typeof console!='undefined'){
		    console.error(e);
		}
	    }
	}
    }
}
function eval_global(js){
    var obj=document.createElement('script');
    obj.type='text/javascript';
    try{obj.innerHTML=js;
    }catch(e){obj.text=js;
    }
    if(document.body.firstChild)
	document.body.insertBefore(obj,document.body.firstChild);
    else
	document.body.appendChild(obj);
}
var KEYS={
    BACKSPACE:8,
    TAB:9,
    RETURN:13,
    ESC:27,
    SPACE:32,
    LEFT:37,
    UP:38,
    RIGHT:39,
    DOWN:40,
    DELETE:46
};
var KeyCodes={
    Left:63234,
    Right:63235
};
function mouseX(event)
{
    return event.pageX
	||(event.clientX+
	   (document.documentElement.scrollLeft||document.body.scrollLeft)
	   );
}

function mouseY(event)
{
    return event.pageY
	||(event.clientY+
	   (document.documentElement.scrollTop||document.body.scrollTop)
	   );
}
function pageScrollX()
{
    return document.body.scrollLeft||document.documentElement.scrollLeft;
}
function pageScrollY()
{
    return document.body.scrollTop||document.documentElement.scrollTop;
}
function elementX(obj){
    if(ua.safari()<500&&obj.tagName=='TR'){
	obj=obj.firstChild;
    }
    var left=obj.offsetLeft;
    var op=obj.offsetParent;
    while(obj.parentNode&&document.body!=obj.parentNode){
	obj=obj.parentNode;
	left-=obj.scrollLeft;
	if(op==obj){
	    if(ua.safari()<500&&obj.tagName=='TR'){
		left+=obj.firstChild.offsetLeft;
	    }else{
		left+=obj.offsetLeft;
	    }
	    op=obj.offsetParent;
	}
    }
    return left;
}
function elementY(obj){
    if(ua.safari()<500&&obj.tagName=='TR'){
	obj=obj.firstChild;
    }
    var top=obj.offsetTop;
    var op=obj.offsetParent;
    while(obj.parentNode&&document.body!=obj.parentNode){
	obj=obj.parentNode;
	top-=obj.scrollTop;
	if(op==obj){
	    if(ua.safari()<500&&obj.tagName=='TR'){
		top+=obj.firstChild.offsetTop;
	    }else{
		top+=obj.offsetTop;
	    }
	    op=obj.offsetParent;
	}
    }
    return top;
}

function get_all_form_inputs(root_element){
    var FORM_INPUT_TAG_NAMES={
	'input':1,
	'select':1,
	'textarea':1,
	'button':1
    };
    root_element=root_element||document;
    var ret=[];
    for(var tag_name in FORM_INPUT_TAG_NAMES){
	var elements=root_element.getElementsByTagName(tag_name);
	for(var i=0;i<elements.length;++i){
	    ret.push(elements[i]);
	}
    }
    return ret;
}
function get_form_select_value(select){
    return select.options[select.selectedIndex].value;
}
function set_form_select_value(select,value){
    for(var i=0;i<select.options.length;++i){
	if(select.options[i].value==value){
	    select.selectedIndex=i;
	    break;
	}
    }
}
function get_form_attr(form,attr){
    var val=form[attr];
    if(typeof val=='object'&&val.tagName=='INPUT'){
	var pn=val.parentNode
	    ,ns=val.nextSibling
	    ,node=val;
	pn.removeChild(node);
	val=form[attr];
	ns?pn.insertBefore(node,ns):pn.appendChild(node);
    }
    return val;
}
function serialize_form_helper(data,name,value){
    var match=/([^\]]+)\[([^\]]*)\](.*)/.exec(name);
    if(match){
	data[match[1]]=data[match[1]]||{};
	if(match[2]==''){
	    var i=0;
	    while(data[match[1]][i]!=undefined){i++;}
	}else{i=match[2];}
	
	if(match[3]==''){
	    data[match[1]][i]=value;
	}else{
	    serialize_form_helper(
				  data[match[1]],
				  i.concat(match[3]),
				  value);
	}
    }else{data[name]=value;}
}
function serialize_form(obj){
    var data={};
    var elements=obj.tagName=='FORM'?obj.elements:get_all_form_inputs(obj);

    for(var i=elements.length-1;i>=0;i--){
	if(elements[i].name&&!elements[i].disabled){
	    if(!(elements[i].type=='radio'
		 ||elements[i].type=='checkbox')
	       ||elements[i].checked
	       ||(!elements[i].type||elements[i].type=='text'
		  ||elements[i].type=='password'
		  ||elements[i].type=='hidden'
		  ||elements[i].tagName=='TEXTAREA'
		  ||elements[i].tagName=='SELECT')
	       ){
		serialize_form_helper(data,elements[i].name,elements[i].value);
	    }
	}
    }
    return data;
}
function is_button(element){
    var tagName=element.tagName.toUpperCase();
    if(tagName=='BUTTON'){return true;}
    if(tagName=='INPUT'&&element.type){
	var type=element.type.toUpperCase();
	return type=='BUTTON'||type=='SUBMIT';
    }
    return false;
}
function autogrow_textarea(obj){
    var padding=15;
    var shadow_div_id='shadow_'+obj.id;
    var shadow_div;
    if(!(shadow_div=ge(shadow_div_id))){
	shadow_div=document.createElement('div');
	shadow_div.id=shadow_div_id;
	shadow_div.style.position="absolute";
	shadow_div.style.left="-10000px";
	shadow_div.style.top="-10000px";
	shadow_div.fontSize=get_style(obj,'fontSize')+'px';
	shadow_div.style.width=parseInt(obj.clientWidth-8)+'px';
	obj.setAttribute('startHeight',obj.clientHeight);
	obj.parentNode.appendChild(shadow_div);
    }
    var clientHeight=obj.clientHeight;
    shadow_div.innerHTML=htmlspecialchars(obj.value).replace(/[\n]/g,'<br />&nbsp;');
    var shadowHeight=shadow_div.clientHeight;
    var to_height;
    var startHeight=obj.getAttribute('startHeight');
    if(shadowHeight<startHeight){
	to_height=startHeight;
    }else{
	to_height=shadowHeight+padding;
    }
    if(to_height&&to_height!=clientHeight){
	obj.style.height=to_height+'px';
    }
}
function addEventBase(obj,type,fn,name_hash)
{
    if(obj.addEventListener)
	obj.addEventListener(type,fn,false);
    else if(obj.attachEvent){
	obj["e"+type+fn+name_hash]=fn;
	obj[type+fn+name_hash]=function(){
	    obj["e"+type+fn+name_hash](window.event);
	}
	obj.attachEvent("on"+type,obj[type+fn+name_hash]);
    }
}
function removeEventBase(obj,type,fn,name_hash)
{
    if(obj.removeEventListener)
	obj.removeEventListener(type,fn,false);
    else if(obj.detachEvent){
	obj.detachEvent("on"+type,obj[type+fn+name_hash]);
	obj[type+fn+name_hash]=null;
	obj["e"+type+fn+name_hash]=null;
    }
}
function placeholderSetup(id){
    var el=ge(id);
    if(!el)return;
    if(el.type=='search')
	return;
    var ph=el.getAttribute("placeholder");
    if(!ph||ph=="")
	return;
    if(el.value==ph)
	el.value="";
    el.is_focused=(el.value!="");
    if(!el.is_focused){
	el.value=ph;
	el.style.color='#777';
	el.is_focused=0;
    }
    addEventBase(el,'focus',placeholderFocus);
    addEventBase(el,'blur',placeholderBlur);
}
function placeholderFocus(){
    if(!this.is_focused){
	this.is_focused=1;
	this.value='';
	this.style.color='#000';
	var rs=this.getAttribute("radioselect");
	if(rs&&rs!=""){
	    var re=document.getElementById(rs);
	    if(!re){return;}
	    if(re.type!='radio')return;
	    re.checked=true;
	}
    }
}
function placeholderBlur(){
    var ph=this.getAttribute("placeholder")
	if(this.is_focused&&ph&&this.value==""){
	    this.is_focused=0;
	    this.value=ph;
	    this.style.color='#777';
	}
}
function placeholderGetValue(id){
    var el=ge(id);
    if(!el){return;}
    return el.getAttribute("placeholder");
}
function getFlashPlayer(){
    goURI('http://adobe.com/go/getflashplayer');return false;
}



function hover_tooltip(object,hover_link,hover_class,offsetX,offsetY){
    if(object.tooltip){
	var tooltip=object.previousSibling;
	tooltip.style.display='block';
	return;
    }else{
	object.parentNode.style.position="relative";
	var tooltip=document.createElement('div');
	tooltip.className="tooltip_pro "+hover_class;
	tooltip.style.left=-9999+'px';
	tooltip.style.display='block';
	tooltip.innerHTML='<div class="tooltip_text"><span>'+hover_link+'</span></div>'
	    +'<div class="tooltip_pointer"></div>';
	object.parentNode.insertBefore(tooltip,object);
	while(tooltip.firstChild.firstChild.offsetWidth<=0){1;}
	var TOOLTIP_PADDING=16;
	var offsetWidth=tooltip.firstChild.firstChild.offsetWidth+TOOLTIP_PADDING;
	tooltip.style.width=offsetWidth+'px';
	tooltip.style.display='none';
	tooltip.style.left=offsetX+object.offsetLeft
	    -((offsetWidth-6-object.offsetWidth)/2)+'px';
	tooltip.style.top=offsetY+'px';
	tooltip.style.display='block';
	object.tooltip=true;
	object.onmouseout=function(e){
	    hover_clear_tooltip(object)
	};
    }
}
function hover_clear_tooltip(object){
    var tooltip=object.previousSibling;
    tooltip.style.display='none';
}
function addSafariLabelSupport(base){
    if(ua.safari()<500){
	var labels=(base||document.body).getElementsByTagName("label");
	for(i=0;i<labels.length;i++){
	    labels[i].addEventListener('click',addLabelAction,true);
	}
    }
}
function addLabelAction(event){
    var id=this.getAttribute('for');
    var item=null;
    if(id){
	item=document.getElementById(id);
    }else{
	item=this.getElementsByTagName('input')[0];
    }
    if(!item||event.srcElement==item){
	return;
    }
    if(item.type=='checkbox'){
	item.checked=!item.checked;
    }else if(item.type=='radio'){
	var radios=document.getElementsByTagName('input');
	for(i=0;i<radios.length;i++){
	    if(radios[i].name==item.name&&radios[i].form==item.form){
		radios.checked=false;
	    }
	}
	item.checked=true;
    }else{
	item.focus();
    }
    if(item.onclick){
	item.onclick(event);
    }
}
function escapeURI(u)
{
    if(encodeURIComponent){return encodeURIComponent(u);}
    if(escape){return escape(u);}
}
function goURI(href){window.location.href=href;}
function is_email(email){
    return/^[\w!.%+]+@[\w]+(?:\.[\w]+)+$/.test(email);
}
function getViewportWidth(){
    var width=0;
    if(document.documentElement&&document.documentElement.clientWidth){
	width=document.documentElement.clientWidth;
    }
    else if(document.body&&document.body.clientWidth){
	width=document.body.clientWidth;
    }
    else if(window.innerWidth){
	width=window.innerWidth-18;
    }
    return width;
};
function getViewportHeight(){
    var height=0;
    if(window.innerHeight){height=window.innerHeight-18;}
    else if(document.documentElement&&document.documentElement.clientHeight){
	height=document.documentElement.clientHeight;
    }
    else if(document.body&&document.body.clientHeight){height=document.body.clientHeight;
    }
    return height;
};

function getPageScrollHeight(){
    var height;
    if(typeof(window.pageYOffset)=='number'){
	height=window.pageYOffset;
    }else if(document.body&&document.body.scrollTop){
	height=document.body.scrollTop;
    }else if(document.documentElement&&document.documentElement.scrollTop){
	height=document.documentElement.scrollTop;
    }
    if(isNaN(height))
	return 0;
    return height;
};

function getRadioFormValue(obj){
    for(i=0;i<obj.length;i++){
	if(obj[i].checked){
	    return obj[i].value;
	}
    }
    return null;
}
function getTableRowShownDisplayProperty(){
    if(ua.ie()){
	return'inline';
    }else{
	return'table-row';
    }
}
function showTableRow()
{
    for(var i=0;i<arguments.length;i++){
	var element=ge(arguments[i]);
	if(element&&element.style)
	    element.style.display=getTableRowShownDisplayProperty();
    }
    return false;
}
function getParentRow(el){
    el=ge(el);
    while(el.tagName&&el.tagName!="TR"){el=el.parentNode;}
    return el;
}
function stopPropagation(e){
    if(!e)
	var e=window.event;
    e.cancelBubble=true;
    if(e.stopPropagation){e.stopPropagation();}
}

function adjustImage(obj,stop_word,max){
    var pn=obj.parentNode;
    if(stop_word==null)
	stop_word='note_content';
    if(max==null){
	while(pn.className.indexOf(stop_word)==-1)
	    pn=pn.parentNode;
	if(pn.offsetWidth)
	    max=pn.offsetWidth;
	else
	    max=400;
    }
    if(navigator.userAgent.indexOf('AppleWebKit/4')==-1){
	obj.style.position='absolute';
	obj.style.left=obj.style.top='-32000px';
    }
    obj.className=obj.className.replace('img_loading','img_ready');
    if(obj.width>max){
	if(window.ActiveXObject && !ua.firefox() && !ua.safari()){
	    try{
		var img_div=document.createElement('div');
		img_div.style.filter='progid:DXImageTransform.Microsoft.AlphaImageLoader(src="'
		    +obj.src.replace('"','%22')
		    +'", sizingMethod="scale")';
		img_div.style.width=max+'px';
		img_div.style.height=((max/obj.width)*obj.height)+'px';
		if(obj.parentNode.tagName=='A')
		    img_div.style.cursor='pointer';
		obj.parentNode.insertBefore(img_div,obj);
		obj.removeNode(true);
	    }
	    catch(e){obj.style.width=max+'px';}
	}
	else
	    obj.style.width=max+'px';
    }
    obj.style.left=obj.style.top=obj.style.position='';
}
function imageConstrainSize(src,maxX,maxY,placeholderid){
    var image=new Image();
    image.onload=function(){
	if(image.width>0&&image.height>0){
	    var width=image.width;
	    var height=image.height;
	    if(width>maxX||height>maxY){
		var desired_ratio=maxY/maxX;
		var actual_ratio=height/width;
		if(actual_ratio>desired_ratio){
		    width=width*(maxY/height);
		    height=maxY;
		}else{
		    height=height*(maxX/width);
		    width=maxX;
		}
	    }
	    var placeholder=ge(placeholderid);
	    var newimage=document.createElement('img');
	    newimage.src=src;
	    newimage.width=width;
	    newimage.height=height;
	    placeholder.parentNode.insertBefore(newimage,placeholder);
	    placeholder.parentNode.removeChild(placeholder);
	}
    }
    image.src=src;
}
function set_opacity(obj,opacity){
    try{
	obj.style.opacity=(opacity==1?'':opacity);
	obj.style.filter=(opacity==1?'':'alpha(opacity='+opacity*100+')');
    }
    catch(e){}
}
function get_opacity(obj){
    var opacity=get_style(obj,'filter');
    var val=null;
    if(opacity&&(val=/(\d+(?:\.\d+)?)/.exec(opacity))){
	return parseFloat(val.pop())/100;
    }else if(opacity=get_style(obj,'opacity')){
	return parseFloat(opacity);
    }else{return 1;}
}
function get_caret_position(obj){
    obj.focus();
    if(document.selection){
	if(obj.tagName=='INPUT'){
	    var range=document.selection.createRange();
	    return{
		start:-range.moveStart('character',-obj.value.length),
		    end:-range.moveEnd('character',-obj.value.length)
		    };
	}else if(obj.tagName=='TEXTAREA'){
	    var range=document.selection.createRange();
	    var range2=range.duplicate();
	    range2.moveToElementText(obj);
	    range2.setEndPoint('StartToEnd',range);
	    var end=obj.value.length-range2.text.length;
	    range2.setEndPoint('StartToStart',range);
	    return{
		start:obj.value.length-range2.text.length,
		    end:end
		    };
	}else{
	    return{
		start:undefined,
		    end:undefined
		    };
	}
    }else{
	return{
	    start:obj.selectionStart,
		end:obj.selectionEnd
		};
    }
}
function set_caret_position(obj,start,end){
    if(document.selection){
	if(obj.tagName=='TEXTAREA'){
	    var i=obj.value.indexOf("\r",0);
	    while(i!=-1&&i<end){
		end--;
		if(i<start){start--;}
		i=obj.value.indexOf("\r",i+1);
	    }
	}
	var range=obj.createTextRange();
	range.collapse(true);
	range.moveStart('character',start);
	if(end!=undefined){
	    range.moveEnd('character',end-start);
	}
	range.select();
    }else{
	obj.selectionStart=start;
	var sel_end=end==undefined?start:end;
	obj.selectionEnd=Math.min(sel_end,obj.value.length);
	obj.focus();
    }
}

function array_indexOf(arr,val,index){
    if(!index){index=0;}
    for(var i=index;i<arr.length;i++){
	if(arr[i]==val){return i;}
    }
    return-1;
}
var ua={
    ie:function(){return this._ie;},
    firefox:function(){return this._firefox;},
    opera:function(){return this._opera;},
    safari:function(){return this._safari;},
    windows:function(){return this._windows;},
    osx:function(){return this._osx;},
    populate:function(){
	var agent=/(?:MSIE.(\d+\.\d+))|(?:(?:Firefox|GranParadiso).(\d+\.\d+))|(?:Opera.(\d+\.\d+))|(?:AppleWebKit.(\d+(?:\.\d+)?))/.exec(navigator.userAgent);
	var os=/(Mac OS X;)|(Windows;)/.exec(navigator.userAgent);
	if(agent){
	    ua._ie=agent[1]?parseFloat(agent[1]):NaN;
	    ua._firefox=agent[2]?parseFloat(agent[2]):NaN;
	    ua._opera=agent[3]?parseFloat(agent[3]):NaN;
	    ua._safari=agent[4]?parseFloat(agent[4]):NaN;
	}else{
	    ua._ie=ua._firefox=ua._opera=ua._safari=NaN;
	}
	if(os){
	    ua._osx=!!os[1];
	    ua._windows=!!os[2];
	}else{
	    ua._osx=ua._windows=false;
	}
    },
    adjustBehaviors:function(){
	onloadRegister(addSafariLabelSupport);
	if(ua.ie()<7){
	    try{
		document.execCommand('BackgroundImageCache',false,true);
	    }catch(ignored){}
	}
    }
};
function is_scalar(v){
    switch(typeof(v)){
    case'string':
    case'number':
    case'null':
    case'boolean':
	return true;
    }
    return false;
}
function is_node(o){
    if(typeof(Node)=='undefined'){
	Node=null;
    }
    try{
	return o&&((Node!=undefined&&o instanceof Node)||o.nodeName);
    }catch(ignored){return false;}
}
var DOM={
    setText:function(el,text){
	if(ua.firefox()){
	    el.textContent=text;
	}else{
	    el.innerText=text;
	}
    },
    getText:function(el){
	if(ua.firefox()){
	    return el.textContent;
	}else{
	    return el.innerText;
	}
    },
    setContent:function(el,content){
	if(ua.ie()){
	    for(var ii=el.childNodes.length-1;ii>=0;--ii){
		DOM.remove(el.childNodes[ii]);
	    }
	}else{
	    el.innerHTML='';
	}
	if(is_scalar(content)){
	    content=document.createTextNode(content);
	    el.appendChild(content);
	}else if(is_node(content)){
	    el.appendChild(content);
	}else if(content instanceof Array){
	    for(var ii=0;ii<content.length;ii++){
		var node=content[ii];
		if(!is_node(node)){
		    node=document.createTextNode(node);
		}
		el.appendChild(node);
	    }
	}else{
	}
    },
    remove:function(el){
	return remove_node(el);
    }
};
var CSS={
    removeClass:function(element,className){
	return remove_css_class_name(element,className);
    },
    addClass:function(element,className){
	return add_css_class_name(element,className);
    },
    setClass:function(element,className){
	element.className=className;
	return CSS;
    },
    Cursor:{
	kGrabbable:'grabbable',
	kGrabbing:'grabbing',
	kEditable:'editable',
	set:function(element,name){
	    element=element||document.body;
	    switch(name){
	    case CSS.Cursor.kEditable:
		name='text';
		break;
	    case CSS.Cursor.kGrabbable:
		if(ua.firefox()){
		    name='-moz-grab';
		}else{name='move';}
		break;
	    case CSS.Cursor.kGrabbing:
		if(ua.firefox()){
		    name='-moz-grabbing';
		}else{name='move';}
		break;
	    }
	    element.style.cursor=name;
	}
    }
};

if(Object.prototype.eval){
    window.eval=Object.prototype.eval;
}
delete Object.prototype.eval;
delete Object.prototype.valueOf;
/*Array.prototype.forEach=null;*/
/*Array.prototype.every=null;*/
/*Array.prototype.map=null;*/
/*Array.prototype.some=null;*/
/*Array.prototype.reduce=null;*/
/*Array.prototype.reduceRight=null;*/
/*Array.prototype.filter=null;*/
Array.prototype.sort=(function(sort){
	return function(callback){
	    return(this==window)
	    ?null
	    :(callback
	      ?sort.call(this,function(a,b){
		      return callback(a,b)})
	      :sort.call(this)
	      );
	}
    }
    )(Array.prototype.sort);
Array.prototype.reverse=(function(reverse){
	return function(){
	    return(this==window)
	    ?null
	    :reverse.call(this);
	}
    }
    )(Array.prototype.reverse);
Array.prototype.concat=(function(concat){
	return function(){
	    return(this==window)
	    ?null
	    :concat.apply(this,arguments);
	}
    })(Array.prototype.concat);
Array.prototype.slice=(function(slice){
	return function(){
	    return(this==window)
	    ?null
	    :slice.apply(this,arguments);
	}
    })(Array.prototype.slice);
Function.prototype.class_extend=function(superclass){
    var superprototype=__metaprototype(superclass,0);
    var subprototype=__metaprototype(this,superprototype.prototype.__level+1);
    subprototype.parent=superprototype;
}
function __metaprototype(obj,level){
    if(obj.__metaprototype){return obj.__metaprototype;}
    var metaprototype=new Function();
    metaprototype.construct=__metaprototype_construct;
    metaprototype.prototype.construct=__metaprototype_wrap(obj,level,true);
    metaprototype.prototype.__level=level;
    metaprototype.base=obj;
    obj.prototype.parent=metaprototype;
    obj.__metaprototype=metaprototype;
    return metaprototype;
}
function __metaprototype_construct(instance){
    __metaprototype_init(instance.parent);
    var parents=[];
    var obj=instance;
    while(obj.parent){
	parents.push(new_obj=new obj.parent());
	new_obj.__instance=instance;
	obj=obj.parent;
    }
    instance.parent=parents[1];
    parents.reverse();
    parents.pop();
    instance.__parents=parents;
    instance.__instance=instance;
    return instance.parent.construct.apply(instance.parent,arguments);
}
var aiert;
if(!aiert){
    aiert=alert;
}
function __metaprototype_init(metaprototype){
    if(metaprototype.initialized)
	return;
    var base=metaprototype.base.prototype;
    if(metaprototype.parent){
	__metaprototype_init(metaprototype.parent);
	var parent_prototype=metaprototype.parent.prototype;
	for(i in parent_prototype){
	    if(i!='__level'&&i!='construct'&&base[i]===undefined){
		base[i]=metaprototype.prototype[i]=parent_prototype[i];
	    }
	}
    }
    metaprototype.initialized=true;
    var level=metaprototype.prototype.__level;
    for(i in base){
	if(i!='parent'){
	    base[i]=metaprototype.prototype[i]=__metaprototype_wrap(base[i],level);
	}
    }
}
function __metaprototype_wrap(method,level,shift){
    if(typeof method!='function'||method.__prototyped){return method;}
    var func=function(){
	var instance=this.__instance;
	if(instance){
	    var old_parent=instance.parent;
	    instance.parent=level?instance.__parents[level-1]:null;
	    if(shift){
		var args=[];
		for(var i=1;i<arguments.length;i++){args.push(arguments[i]);}
		var ret=method.apply(instance,args);
	    }else{
		var ret=method.apply(instance,arguments);
	    }
	    instance.parent=old_parent;
	    return ret;
	}else{
	    return method.apply(this,arguments);
	}
    }
    func.__prototyped=true;
    return func;
}
function clearCookie(cookieName){
    document.cookie=cookieName+"=; expires=Mon, 26 Jul 1997 05:00:00 GMT; path=/; domain=.mipang.com";
}
function do_post(url){
    var pieces=/(^([^?])+)\??(.*)$/.exec(url);
    var form=document.createElement('form');
    form.action=pieces[1];
    form.method='post';
    form.style.display='none';
    var sparam=/([\w]+)(?:=([^&]+)|&|$)/g;
    var param=null;
    if(ge('post_form_id'))
	pieces[3]+='&post_form_id='+$('post_form_id').value;
    while(param=sparam.exec(pieces[3])){
	var input=document.createElement('input');
	input.type='hidden';
	input.name=param[1];
	input.value=param[2];
	form.appendChild(input);
    }
    document.body.appendChild(form);
    form.submit();
    return false;
}
function dynamic_post(url,params){
    var form=document.createElement('form');
    form.action=url;
    form.method='POST';
    form.style.display='none';
    if(ge('post_form_id')){
	params['post_form_id']=$('post_form_id').value;
    }
    for(var param in params){
	var input=document.createElement('input');
	input.type='hidden';
	input.name=param;
	input.value=params[param];
	form.appendChild(input);
    }
    document.body.appendChild(form);
    form.submit();
    return false;
}
function query_param_get(param_name){
    var params=window.location.search.split('&')||[];
    for(var i=0;i<params.length;i++){
	if(params[i]==param_name){return'';}
	else if(params[i].indexOf(param_name+'=')){return params[i].split('=')[1];}
    }
    return null;
}
function anchor_set(anchor){
    window.location=window.location.href.split('#')[0]+'#'+anchor;
}
function anchor_get(){
    return window.location.href.split('#')[1]||null;
}
function event_get(e){return e||window.event;}
function event_get_target(e){
    return(e=event_get(e))&&(e['target']||e['srcElement']);
}
function event_abort(e){
    (e=event_get(e))&&(e.cancelBubble=true)&&e.stopPropagation&&e.stopPropagation();
    return false;
}
function event_prevent(e){
    (e=event_get(e))&&!(e.returnValue=false)&&e.preventDefault&&e.preventDefault();
    return false;
}
function event_get_keypress_keycode(event){
    switch(event.keyCode){
    case 63232:return 38;
    case 63233:return 40;
    case 63234:return 37;
    case 63235:return 39;
    case 63272:
    case 63273:
    case 63275:return null;
    case 63276:return 33;
    case 63277:return 34;
    }
    if(event.shiftKey){
	switch(event.keyCode){
	case 33:
	case 34:
	case 37:
	case 38:
	case 39:
	case 40:return null;
	}
    }else{return event.keyCode;}
}
function env_get(k){
    return typeof(window['Env'])!='undefined'&&Env[k];
}
function chain(u,v){
    var calls=[];
    for(var ii=0;ii<arguments.length;ii++){
	calls.push(arguments[ii]);
    }
    return function(){
	for(var ii=0;ii<calls.length;ii++){
	    if(calls[ii]&&calls[ii].apply(null,arguments)===false){
		return false;
	    }
	}
	return true;
    }
}
function onloadRegister(handler){
    window.loaded?_runHook(handler):_addHook('onloadhooks',handler);
}
function onafterloadRegister(handler){
    window.loaded?_runHook(handler):_addHook('onafterloadhooks',handler);
}
function onbeforeunloadRegister(handler){_addHook('onbeforeunloadhooks',handler);}
function onunloadRegister(handler){_addHook('onunloadhooks',handler);}
function _onloadHook(){_runHooks('onloadhooks');window.loaded=true;}
function _runHook(handler){try{handler();}catch(ex){
    }
}
function _runHooks(hooks){
    var isbeforeunload=(hooks=='onbeforeunloadhooks');
    var warn=null;
    do{
	var h=window[hooks];
	if(!isbeforeunload){
	    window[hooks]=null;
	}
	if(!h){break;}
	for(var ii=0;ii<h.length;ii++){
	    try{
		if(isbeforeunload){
		    warn=warn||h[ii]();
		}else{
		    h[ii]();
		}
	    }catch(ex){
	    }
	}
	if(isbeforeunload){break;}
    }while(window[hooks]);
    if(isbeforeunload){
	if(warn){return warn;}else{window.loaded=false;}
    }
}
function _addHook(hooks,handler){(window[hooks]?window[hooks]:(window[hooks]=[])).push(handler);}
function _bootstrapEventHandlers(){
    if(document.addEventListener){
	if(ua.safari()){
	    var timeout=setInterval(function(){
		    if(/loaded|complete/.test(document.readyState)){
			_onloadHook();
			clearTimeout(timeout);
		    }
		},10);
	}else{
	    document.addEventListener("DOMContentLoaded",_onloadHook,true);
	}
    }else{
	var src='javascript:void(0)';
	if(window.location.protocol=='https:'){
	    src='//:';
	}
	document.write('<script onreadystatechange="if (this.readyState==\'complete\') {'
		       +'this.parentNode.removeChild(this);_onloadHook();}" defer="defer" '
		       +'src="'+src+'"><\/script\>');
    }
    window.onload=chain(window.onload
			,function(){
			    _onloadHook();
			    _runHooks('afterloadhooks');
			}
			);
    window.onbeforeunload=function(){
	return _runHooks('onbeforeunloadhooks');
    };
    window.onunload=chain(window.onunload,function(){_runHooks('onunloadhooks');});
}
function iterTraverseDom(root,visitCb){
    var c=root,n=null;
    var it=0;
    do{
	n=c.firstChild;
	if(!n){
	    if(visitCb(c)==false)
		return;
	    n=c.nextSibling;
	}
	if(!n){
	    var tmp=c;
	    do{
		n=tmp.parentNode;
		if(n==root)
		    break;
		if(visitCb(n)==false)
		    return;
		tmp=n;
		n=n.nextSibling;
	    }while(!n);
	}
	c=n;
    }while(c!=root);
}
function prependChild(parent,elem){
    if(parent.firstChild){
	parent.insertBefore(elem,parent.firstChild);
    }else{
	parent.appendChild(elem);
    }
}
ua.populate();
_bootstrapEventHandlers();
ua.adjustBehaviors();
/**
if(navigator
   &&navigator.userAgent
   &&navigator.userAgent.indexOf('Firefox/1.0')==-1
   &&!/Netscape\/[1-8]\./.test(navigator.userAgent)){
    document.domain='mipang.com';
}
**/
////////////////////////


// extend

function bind(obj,method){
    var args=[];
    for(var ii=2;ii<arguments.length;ii++){
	args.push(arguments[ii]);
    }
    return function(){
	var _obj=obj||this;
	var _args=args.slice();
	for(var jj=0;jj<arguments.length;jj++){
	    _args.push(arguments[jj]);
	}
	if(typeof(method)=="string"){
	    if(_obj[method]){
		return _obj[method].apply(_obj,_args);
	    }
	}else{
	    return method.apply(_obj,_args);
	}
    }
}
function copy_properties(u,v){

    return Object.extend(u,v);
}

var Util={
    isDevelopmentEnvironment:function(){
	return env_get('dev');
    },
    warn:function(){
	Util.log(sprintf.apply(null,arguments),'warn');
    },
    error:function(){
	Util.log(sprintf.apply(null,arguments),'error');
    },
    log:function(msg,type){
	if(Util.isDevelopmentEnvironment()){
	    var written=false;
	    if(typeof(window['TabConsole'])!='undefined'){
		var con=TabConsole.getInstance();
		if(con){
		    con.log(msg,type);
		    written=true;
		}
	    }
	    if(typeof(console)!="undefined"&&console.error){
		console.error(msg);
		written=true;
	    }
	    if(!written&&type!='deprecated'){
		aiert(msg);
	    }
	}else{
	    if(type=='error'){
		msg+='\n\n'+Util.stack();
		(typeof(window['debug_rlog'])=='function')&&debug_rlog(msg);
	    }
	}
    },
    deprecated:function(what){
	if(!Util._deprecatedThings[what]){
	    Util._deprecatedThings[what]=true;
	    var msg=sprintf('Deprecated: %q is deprecated.\n\n%s',what,Util.whyIsThisDeprecated(what));
	    Util.log(msg,'deprecated');
	}
    },
    stack:function(){
	try{
	    try{
		({}).llama();
	    }catch(e){
		if(e.stack){
		    var stack=[];
		    var trace=[];
		    var regex=/^([^@]+)@(.+)$/mg;
		    var line=regex.exec(e.stack);
		    do{
			stack.push([line[1],line[2]]);
		    }while(line=regex.exec());
		    for(var i=0;i<stack.length;i++){
			trace.push('#'+i+' '+stack[i][0]+' @ '+(stack[i+1]?stack[i+1][1]:'?'));
		    }
		    return trace.join('\n');
		}else{
		    var trace=[];
		    var pos=arguments.callee;
		    var stale=[];
		    while(pos){
			for(var i=0;i<stale.length;i++){
			    if(stale[i]==pos){
				trace.push('#'+trace.length+' ** recursion ** @ ?');
				return trace.join('\n');
			    }
			}
			stale.push(pos);
			var args=[];
			for(var i=0;i<pos.arguments.length;i++){
			    if(pos.arguments[i]instanceof Function){
				var func=/function ?([^(]*)/.exec(pos.arguments[i].toString()).pop(); //)
						     args.push(func?func:'anonymous');
			    }else if(pos.arguments[i]instanceof Array){
				    args.push('Array');
			    }else if(pos.arguments[i]instanceof Object){
				    args.push('Object');
			    }else if(typeof pos.arguments[i]=='string'){
				    args.push('"'+pos.arguments[i].replace(/("|\\)/g,'\\$1')+'"'); //'
			    }else{args.push(pos.arguments[i]);
			    }
		       }
		       trace.push('#'+trace.length+' '+/function?([^(]*)/.exec(pos).pop()+'('+args.join(', ')+') @ ?');
		       if(trace.length>100)
			   break;
		       pos=pos.caller;
		  }
		  return trace.join('\n');
					      }
	}
 }catch(e){return'No stack trace available';}
		},
			    whyIsThisDeprecated:function(what){
			    return Util._deprecatedBecause[what.toLowerCase()]||'No additional information is available about this deprecation.';},
			    _deprecatedBecause:{},
			    _deprecatedThings:{}
		    };

Util._deprecatedBecause={};

var Configurable={
    getOption:function(opt){
	if(typeof(this.option[opt])=='undefined'){
	    Util.warn('Failed to get option %q; it does not exist.',opt);
	    return null;
	}
	return this.option[opt];
    },
    setOption:function(opt,v){
	if(typeof(this.option[opt])=='undefined'){
	    Util.warn('Failed to set option %q; it does not exist.',opt);
	}else{this.option[opt]=v;}
	return this;
    },
    getOptions:function(){return this.option;}
};


function URI(uri){
    if(this===window){
	return new URI(uri||window.location.href);
    }
    this.parse(uri||'');
}
copy_properties(URI,{
	expression:/(((\w+):\/\/)([^\/:]*)(:(\d+))?)?([^#?]*)(\?([^#]*))?(#(.*))?/,
	explodeQuery:function(q){
	    if(!q){return{};}
	    var ii,t,r={};
	    q=q.split('&');
	    for(ii=0,l=q.length;ii<l;ii++){
		t=q[ii].split('=');
		r[decodeURIComponent(t[0])]=(typeof(t[1])=='undefined')?'':decodeURIComponent(t[1]);
	    }
	    return r;
	},
	implodeQuery:function(obj,name){
	    name=name||'';
	    var r=[];
	    if(obj instanceof Array){
		for(var ii=0;ii<obj.length;ii++){
		    try{
			r.push(URI.implodeQuery(obj[ii],name?name+'['+ii+']':ii));
		    }catch(ignored){}
		}
	    }else if(typeof(obj)=='object'){
		if(is_node(obj)){
		    r.push('{node}');
		}else{
		    for(var k in obj){
			try{
			    r.push(URI.implodeQuery(obj[k],name?name+'['+k+']':k));
			}catch(ignored){}
		    }
		}
	    }else if(name&&name.length){
		r.push(encodeURIComponent(name)+'='+encodeURIComponent(obj));
	    }else{r.push(encodeURIComponent(obj));}
	    return r.join('&');
	}
    });
copy_properties(URI.prototype,{
	parse:function(uri){
	    var m=uri.toString().match(URI.expression);
	    copy_properties(this,{
		    protocol:m[3]||'',
			domain:m[4]||'',
			port:m[6]||'',
			path:m[7]||'',
			query:URI.explodeQuery(m[9]||''),
			fragment:m[11]||''
			});
	    return this;
	},
	    setProtocol:function(p){
	    this.protocol=p;
	    return this;
	},
	    getProtocol:function(){
	    return this.protocol;
	},
	    setQueryData:function(o){
	    this.query=o;
	    return this;
	},
	    addQueryData:function(o){
	    return this.setQueryData(copy_properties(this.query,o));
	},
	    getQueryData:function(){
	    return this.query;
	},
	    setFragment:function(f){
	    this.fragment=f;
	    return this;
	},

	    getFragment:function(){
	    return this.fragment;
	},
	    setDomain:function(d){
	    this.domain=d;
	    return this;
	},
	    getDomain:function(){
	    return this.domain;
	},
	    setPort:function(p){
	    this.port=p;
	    return this;
	},
	    getPort:function(){
	    return this.port;
	},
	    setPath:function(p){
	    this.path=p;
	    return this;
	},
	    getPath:function(){
	    return this.path;
	},
    toString:function(){ /* Bug in IE */
	    var r='';
	    var q=URI.implodeQuery(this.query);
	    this.protocol&&(r+=this.protocol+'://');
	    this.domain&&(r+=this.domain);
	    this.port&&(r+=':'+this.port);
	    if(this.domain&&!this.path){r+='/';}
	    this.path&&(r+=this.path);
	    q&&(r+='?'+q);
	    this.fragment&&(r+='#'+this.fragment);
	    return r;
	},
    _toString:function(){
	    var r='';
	    var q=URI.implodeQuery(this.query);
	    this.protocol&&(r+=this.protocol+'://');
	    this.domain&&(r+=this.domain);
	    this.port&&(r+=':'+this.port);
	    if(this.domain&&!this.path){r+='/';}
	    this.path&&(r+=this.path);
	    q&&(r+='?'+q);
	    this.fragment&&(r+='#'+this.fragment);
	    return r;
	},
	    isSameOrigin:function(asThisURI){
	    var uri=asThisURI||window.location.href;
	    if(!(uri instanceof URI)){uri=new URI(uri.toString());}
	    if(this.getProtocol()&&this.getProtocol()!=uri.getProtocol()){return false;}
	    if(this.getDomain()&&this.getDomain()!=uri.getDomain()){return false;}
	    return true;
	},
	    coerceToSameOrigin:function(targetURI){
	    var uri=targetURI||window.location.href;
	    if(!(uri instanceof URI)){uri=new URI(uri.toString());}
	    if(this.isSameOrigin(uri)){return true;}
	    if(this.getProtocol()!=uri.getProtocol()){return false;}
	    var dst=uri.getDomain().split('.');
	    var src=this.getDomain().split('.');
	    if(dst.pop()=='com'&&src.pop()=='com'){
		if(dst.pop()=='facebook'&&src.pop()=='facebook'){
		    this.setDomain(uri.getDomain());
		    return true;
		}
	    }
	    return false;
	}
    });

function EventController(eventResponderObject){
    copy_properties(this,{
	    queue:[],
		ready:false,
		responder:eventResponderObject
		});
};

copy_properties(EventController.prototype,{
	startQueue:function(){
	    this.ready=true;
	    this.dispatchEvents();
	    return this;
	},
	    pauseQueue:function(){
	    this.ready=false;
	    return this;
	},
	    addEvent:function(event){
	    if(event.toLowerCase()!==event){
	    }
	    var args=[];
	    for(var ii=1;ii<arguments.length;ii++){args.push(arguments[ii]);}
	    this.queue.push({type:event,args:args});if(this.ready){this.dispatchEvents();}
	    return event_abort(event_get(arguments[1]));
	},
	    dispatchEvents:function(){
	    if(!this.responder){
	    }
	    for(var ii=0;ii<this.queue.length;ii++){
		var evtName='on'+this.queue[ii].type;
		if(typeof(this.responder[evtName])!='function'&&typeof(this.responder[evtName])!='null'){
		}else{
		    if(this.responder[evtName]){
			this.responder[evtName].apply(this.responder,this.queue[ii].args);
		    }
		}
	    }
	    this.queue=[];
	}
    });


/// deprecated


function extend(u,v){
    return copy_properties(u,v);
}
var ajaxLoadIndicatorRefCount=0;
function ajaxShowLoadIndicator()
{
    indicatorDiv=ge('ajaxLoadIndicator');
    if(!indicatorDiv){
	indicatorDiv=document.createElement("div");
	indicatorDiv.id='ajaxLoadIndicator';
	indicatorDiv.innerHTML='Loading';
	indicatorDiv.className='ajaxLoadIndicator';
	document.body.appendChild(indicatorDiv);
    }
    indicatorDiv.style.top=(5+pageScrollY())+'px';
    indicatorDiv.style.left=(5+pageScrollX())+'px';
    indicatorDiv.style.display='block';
    ajaxLoadIndicatorRefCount++;
}
function ajaxHideLoadIndicator()
{
    ajaxLoadIndicatorRefCount--;
    if(ajaxLoadIndicatorRefCount==0)
	$('ajaxLoadIndicator').style.display='';
}
function fbAjax(doneHandler,failHandler)
{
    newAjax=this;
    this.onDone=doneHandler;
    this.onFail=failHandler;
    this.transport=this.getTransport();
    this.transport.onreadystatechange=ajaxTrampoline(this);
}
fbAjax.prototype.get=function(uri,query,force_sync)
{

    /* fix url, proxy to main host */
    
    if( typeof MIPANG != 'undefined' && typeof MIPANG.location != 'undefined' && MIPANG.location.main_host != MIPANG.location.current_host){
	
	if(uri.indexOf('http') != 0){
	    uri = MIPANG.location.scheme+'://'+MIPANG.location.main_host + uri;
	}

	uri = '/service/proxy/*/'+uri;
	
    }

    force_sync=force_sync||false;
    if(query&&(typeof query!='string')){
	query=URI.implodeQuery(query);
    }
    fullURI=uri+(query?('?'+query):'');
    this.transport.open('GET',fullURI,!force_sync);
    this.transport.send('');
};

fbAjax.prototype.post=function(uri,data,force_sync,no_post_form_id)
{
    
    /* fix url, proxy to main host */
    
    if( typeof MIPANG != 'undefined' && typeof MIPANG.location != 'undefined' && MIPANG.location.main_host != MIPANG.location.current_host){
	
	if(uri.indexOf('http') != 0){
	    uri = MIPANG.location.scheme+'://'+MIPANG.location.main_host + uri;
	}

	uri = '/service/proxy/*/'+uri;
	
    }


    force_sync=force_sync||false;
    no_post_form_id=no_post_form_id||false;
    if(data&&(typeof data!='string')){
	data=URI.implodeQuery(data);
    }
    if(!no_post_form_id){
	var post_form_id=ge('post_form_id');
	if(post_form_id){
	    data+='&post_form_id='+post_form_id.value;
	}
    }
    this.transport.open('POST',uri,!force_sync);
    this.transport.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    this.transport.send(data);
};
fbAjax.prototype.stateDispatch=function()
{
    try{
	if(this.transport.readyState==1&&this.showLoad)
	    ajaxShowLoadIndicator();
	if(this.transport.readyState==4){
	    if(this.showLoad)
		ajaxHideLoadIndicator();
	    if(this.transport.status>=200&&this.transport.status<300&&this.transport.responseText.length>0){
		try{
		    if(this.onDone)
			this.onDone(this,this.transport.responseText);
		}catch(tempError){
		    console?console.error(tempError):false;
		}
	    }else{
		try{
		    if(this.onFail)
			this.onFail(this);
		}catch(tempError){
		    console?console.error(tempError):false;
		}
	    }
	}
    }catch(error){
	if(this.onFail)
	    this.onFail(this);
    }
};
fbAjax.prototype.getTransport=function()
{
    var ajax=null;
    try{
	ajax=new XMLHttpRequest();
    }
    catch(e){ajax=null;}
    try{if(!ajax)ajax=new ActiveXObject("Msxml2.XMLHTTP");}
    catch(e){ajax=null;}
    try{if(!ajax)ajax=new ActiveXObject("Microsoft.XMLHTTP");}
    catch(e){ajax=null;}
    return ajax;
};
function ajaxTrampoline(ajaxObject)
{
    return function(){
	ajaxObject.stateDispatch();
    };
}
function same_place(rootEl,dynamic_dialog){
    //Util.deprecated('dynamicdialog');
    if(rootEl=ge(rootEl)){
	if(elementY(rootEl)+20==elementY(dynamic_dialog))
	    return true;
    }
    return false;
}
function move_here(rootEl,el){
    //Util.deprecated('dynamicdialog');
    var x=getViewportWidth()/2-120;
    var y=elementY(rootEl)+20;
    el.style.left=x+"px";
    el.style.top=y+"px";
}


// async


function AsyncRequest(){
    var dispatchResponse=bind(this,function(asyncResponse){
	    try{
		this.handler(asyncResponse);
	    }catch(exception){
		Util.error('The user supplied handler function for an AsyncRequest to URI %q '
		   +'threw an exception: %x. (This is not a problem with AsyncRequest, it '
		   +'is a problem with the callback, which failed to catch the exception.)',this.uri,exception);
	    }
	});

    var dispatchErrorResponse=bind(this,function(asyncResponse,isTransport){
	    try{
		if(isTransport){
		    this.transportErrorHandler(asyncResponse);
		}else{
		    this.errorHandler(asyncResponse);
		}
	    }catch(exception){
		Util.error('Async error handler threw an exception for URI %q, when processing a '
		   +'%d error: %s.',this.uri,asyncResponse.getError(),exception);
	    }
	});

    var invokeResponseHandler=bind(this,function(){
	    var r=new AsyncResponse();
	    if(this.handler){
		try{
		    var shield="for (;;);";
		    var shieldlen=shield.length;
		    if(this.transport.responseText.length<=shieldlen){
			if(!this.getOption('suppressErrorAlerts')){
			    Util.error('AsyncResponse returned with shorter length than required.');
			}
			throw"AsyncResponse too short.";
		    }
		    var text=this.transport.responseText;
		    var offset=0;
		    while(text.charAt(offset)==" "||text.charAt(offset)=="\n"){offset++;}
		    if(offset&&text.substring(offset,offset+shieldlen)==shield){
			Util.error('Response for request to endpoint %q seems to be valid, but was '
			   +'preceeded by whitespace. (This probably means that someone '
			   +'committed whitespace in a header file.)',this.uri);
		    }
		    var safeResponse=text.substring(offset+shieldlen);
		    if(!this.getOption('suppressEvaluation')){
			var response;
			eval('response = ('+safeResponse+')');
			if(typeof(response.payload)=='undefined'
			   ||typeof(response.error)=='undefined'
			   ||typeof(response.errorDescription)=='undefined'
			   ||typeof(response.errorSummary)=='undefined'){
			    Util.warn('AsyncRequest to endpoint %q returned a JSON response, but it '
			          +'is not properly formatted. The endpoint needs to provide a '
			          +'response including both error and payload information; use '
			          +'the AsyncResponse PHP class to do this easily.',this.uri);
			    r.payload=response;
			}else{
			    copy_properties(r,response);
			}
		    }else{r.payload=this.transport;}
		    if(r.getError()){
			dispatchErrorResponse(r);
		    }else{
			dispatchResponse(r);
		    }
		}catch(exception){
		    var desc='An error occurred during a request to a remote server. '
			+'This failure may be temporary, try repeating the request.';

		    if(Util.isDevelopmentEnvironment()){
		    if(this.transport.responseText==''){
		        desc=sprintf('An error occurred when making an AsyncRequest to %q. '
		    		 +'The server returned an empty response.',this.uri);
		    }else{
		        desc=sprintf('An error occurred when decoding the JSON payload of the '
		    		 +'AsyncResponse associated with an AsyncRequest to %q. The '
		    		 +'server returned <a href="javascript:aiert(%e);">a garbled '
		    		 +'response</a>, then Javascript threw an exception: %x.',
		    		 this.uri,this.transport.responseText,exception);
		    }
		    }
		    copy_properties(r,
				    {
					error:1000,
					    errorSummary:'Data Error',
					    errorDescription:desc
					    });
		    if(this.transportErrorHandler){
			dispatchErrorResponse(r,true);
		    }else{
			Util.error('Something bad happened; provide a transport error handler for '
			   +'complete details.');
		    }
		}
	    }
	});
    
    var invokeErrorHandler=bind(this,function(explicitError){
	    if(!window.loaded){return;}
	    var r=new AsyncResponse();
	    var err;
	    try{
		err=explicitError||this.transport.status||1001;
	    }catch(ex){err=1001;}
	    try{
		if(this.responseText==''){err=1002;}
	    }catch(ignore){}
	    if(this.transportErrorHandler){
		var desc=sprintf('Transport error (#%d) while retrieving data from endpoint %q: %s',
				 err,this.uri,AsyncRequest.getHTTPErrorDescription(err));
		if(!this.getOption('suppressErrorAlerts')){
		    Util.error(desc);
		}
		copy_properties(r,
    {error:err,errorSummary:AsyncRequest.getHTTPErrorSummary(err),errorDescription:desc});
		
		dispatchErrorResponse(r,true);
	    }else{
		Util.error('Async request to %q failed with a %d error, but there was no error '
		   +'handler available to deal with it.',this.uri,err);
	    }
	});

    var onStateChange=function(){
	try{
	    if(this.transport.readyState==4){
		if(this.transport.status>=200&&this.transport.status<300){
		    invokeResponseHandler();
		}else{
		    if(ua.safari()&&(typeof(this.transport.status)=='undefined')){
			invokeErrorHandler(1002);
		    }else{invokeErrorHandler();}
		}
		delete this.transport;
	    }
	}catch(exception){
	    if(!window.loaded){return;}
	    delete this.transport;
	    if(this.remainingRetries){
		--this.remainingRetries;
		this.send(true);
	    }else{
		if(!this.getOption('suppressErrorAlerts')){
		    Util.error('AsyncRequest exception when attempting to handle a state change: %x.',exception);
		}
		invokeErrorHandler(1001);
	    }
	}
    };
    
    copy_properties(this,
		    {
			onstatechange:onStateChange,
			    transport:null,
			    method:'POST',
			    uri:'',
			    handler:null,
			    errorHandler:ErrorDialog.showAsyncError,
			    transportErrorHandler:ErrorDialog.showAsyncError,
			    data:{},
			    readOnly:false,
			    writeRequiredParams:[],/*'post_form_id'],*/
			    remainingRetries:0,
			    option:{
			    asynchronous:true,
				suppressErrorHandlerWarning:false,
				suppressEvaluation:false,
				suppressErrorAlerts:false,
				retries:1}
		    });
    return this;
}
copy_properties(AsyncRequest,
		{
		    getHTTPErrorSummary:function(errCode){
			return AsyncRequest._getHTTPError(errCode).summary;
		    },
			getHTTPErrorDescription:function(errCode){
			return AsyncRequest._getHTTPError(errCode).description;
		    },
			pingURI:function(uri,data,synchronous){
			return new AsyncRequest().setURI(uri)
			    .setData(data).setOption('asynchronous',!synchronous)
			    .setOption('suppressErrorHandlerWarning',true).send();
		    },
			_getHTTPError:function(errCode){
			var e=AsyncRequest._HTTPErrors[errCode]
			    ||AsyncRequest._HTTPErrors[errCode-(errCode%100)]
			    ||{
			    summary:'HTTP Error',
			    description:'Unknown HTTP error #'+errCode
			};
			return e;
		    },
			_HTTPErrors:{
			400:{summary:'Bad Request',description:'Bad HTTP request.'},
			    401:{summary:'Unauthorized',description:'Not authorized.'},
			    403:{summary:'Forbidden',description:'Access forbidden.'},
			    404:{summary:'Not Found',description:'Web address does not exist.'},
			    1000:{summary:'Bad Response',description:'Invalid response.'},
			    1001:{summary:'No Network',description:'A network error occurred. Check that you are connected to the '+'internet.'},
			    1002:{summary:'No Data',description:'The server did not return a response.'}
		    }
		});
copy_properties(AsyncRequest.prototype,
		{
		    setMethod:function(m){
			this.method=m.toString().toUpperCase();
			return this;
		    },
			getMethod:function(){return this.method;},
			setData:function(obj){
			this.data=obj;
			return this;
		    },
			getData:function(){return this.data;},
			setURI:function(uri){
			if(!(new URI(uri)).isSameOrigin()){
			    Util.error('Asynchronous requests must specify relative URIs (like %q); this '
			           +'ensures they conform to the Same Origin Policy (see %q). The '
			           +'provided absolute URI (%q) is invalid, use a relative URI instead.'
			           ,'/path/to/endpoint.php'
			           ,'http://www.mozilla.org/projects/security/components/same-origin.html',uri);
			    return;
			}
			this.uri=uri;return this;
		    },
			getURI:function(){return this.uri;},
			setHandler:function(fn){
			if(typeof(fn)!='function'){
			    Util.error('AsyncRequest response handlers must be functions. Pass a function, '+'or use bind() to build one.');
			}else{this.handler=fn;}
			return this;
		    },
			getHandler:function(){return this.handler;},
			setErrorHandler:function(fn){
			if(typeof(fn)!='function'){
			    Util.error('AsyncRequest error handlers must be functions. Pass a function, or '+'use bind() to build one.');
			}else{this.errorHandler=fn;}
			return this;
		    },
			setTransportErrorHandler:function(fn){
			this.transportErrorHandler=fn;
			return this;
		    },
			getErrorHandler:function(){return this.handler;},
			setReadOnly:function(readOnly){
			if(typeof(readOnly)!='boolean'){
			    Util.error('AsyncRequest readOnly value must be a boolean.');
			}else{this.readOnly=readOnly;}
			return this;
		    },
			getReadOnly:function(){
			return this.readOnly;
		    },
			specifiesWriteRequiredParams:function(){
			var specifiesWriteRequiredParams=true;
			for(var i=0;i<this.writeRequiredParams.length;i++){
			    var param=this.writeRequiredParams[i];
			    if(typeof(this.data[param])=='undefined'){
				var e=ge(param);
				if(e&&typeof(e.value)!='undefined'){
				    this.data[param]=e.value;
				}else{
				    specifiesWriteRequiredParams=false;
				    break;
				}
			    }
			}
			return specifiesWriteRequiredParams;
		    },

			setOption:function(opt,v){
			if(typeof(this.option[opt])!='undefined'){
			    this.option[opt]=v;
			}else{
			    Util.warn('AsyncRequest option %q does not exist; request to set it was ignored.',opt);
			}
			return this;
		    },

			getOption:function(opt){
			if(typeof(this.option[opt])=='undefined'){
			    Util.warn('AsyncRequest option %q does not exist, get request failed.',opt);
			}
			return this.option[opt];
		    },

			send:function(isRetry){
			isRetry=isRetry||false;
			if(!this.uri){
			    Util.error('Attempt to dispatch an AsyncRequest without an endpoint URI! This is '+'all sorts of silly and impossible, so the request failed.');return false;
			}
			if(!this.errorHandler&&!this.getOption('suppressErrorHandlerWarning')){
			    Util.warn('Dispatching an AsyncRequest that does not have an error handler. '
			          +'You SHOULD supply one, or use AsyncRequest.pingURI(). If this '
			          +'omission is intentional and well-considered, set the %q option to '
			          +'suppress this warning.','suppressErrorHandlerWarning');
			}
			if(!this.getReadOnly()){
			    if(!this.specifiesWriteRequiredParams()){
				Util.error('You are making a POST request without one or more of the required '
				   +'parameters: %s. Requests which modify data and do not verify the '
				   +'request origin through parameter validation are vulnerable to CSRF '
				   +'attacks. You should either specify values for these parameters '
				   +'explicitly by using setData(), put them in the page as inputs, or '
				   +'mark this request as safe and idempotent by using setReadOnly(). '
				   +'Consult the setReadOnly() documentation for more information.',
				   this.writeRequiredParams.join(','));
				return false;
			    }
			    if(this.method!='POST'){
				Util.error('You are making a GET request which modifies data; this violates '
				   +'the HTTP spec and is generally a bad idea. Either change this '
				   +'request to use POST or use setReadOnly() to mark the request as '
				   +'idempotent and appropriate for HTTP GET. Consult the setReadOnly() '
				   +'documentation for more information.');
				return false;
			    }
			}
			if(this.transport){
			    Util.error('You must wait for an AsyncRequest to complete before sending another '
			           +'request with the same object. To send two simultaneous requests, '
			           +'create a second AsyncRequest object.');
			    return false;
			}
			var uri;
			var query=URI.implodeQuery(this.data);
			if(this.method=='GET'){
			    uri=this.uri+(query?'?'+query:'');
			    query='';
			    uri+=(uri.indexOf('?')!=-1?'&':'?')+'_uts'+((new Date()).getTime());
			}else{
			    uri=this.uri;
			}
			    
			    /* fix url, proxy to main host */
    
			    if( typeof MIPANG != 'undefined' && typeof MIPANG.location != 'undefined' && MIPANG.location.main_host != MIPANG.location.current_host){
	
				if(uri.indexOf('http') != 0){
				    uri = MIPANG.location.scheme+'://'+MIPANG.location.main_host + uri;
				}
				
				uri = '/service/proxy/*/'+uri;
				
			    }

			var transport=Try.these(
						function(){
						    return new XMLHttpRequest();
						},
						function(){
						    return new ActiveXObject("Msxml2.XMLHTTP");
						},
						function(){
						    return new ActiveXObject("Microsoft.XMLHTTP");
						})
			    ||null;
			if(!transport){
			    Util.error('Unable to build XMLHTTPRequest transport.');
			    return;
			}
			transport.onreadystatechange=bind(this,'onstatechange');
			if(!isRetry){
			    this.remainingRetries=0;
			    if(this.getReadOnly()){
				this.remainingRetries=this.getOption('retries');
			    }
			}
			this.transport=transport;
			this.transport.open(this.method,uri,this.getOption('asynchronous'));
			if(this.method=='POST'&&!this.setHeader){
			    this.setHeader=true;
			    this.transport.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			    /**this.transport.setRequestHeader('Content-Length',query.length);**/
			}
			this.transport.send(query);
			return true;
		    }
		});
function AsyncResponse(){
    copy_properties(this,{
	    error:0,
		errorSummary:null,
		errorDescription:null,
		payload:null
		}
	);
    return this;
}
copy_properties(AsyncResponse.prototype,{
	getPayload:function(){return this.payload;},
	    getError:function(){return this.error;},
	    getErrorSummary:function(){return this.errorSummary;},
	    getErrorDescription:function(){return this.errorDescription;}
    });


//string

function htmlspecialchars(text){
    if(typeof(text)=='undefined'||!text.toString){return'';}
    if(text===false){return'0';}else if(text===true){return'1';}
    return text.toString().replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#039;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); // '"
}
var htmlize=htmlspecialchars;
function escape_js_quotes(text){
    if(typeof(text)=='undefined'||!text.toString){return'';}
    return text.toString().replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/\r/g,'\\r').replace(/"/g,'\\x22').replace(/'/g,'\\\'').replace(/</g,'\\x3c').replace(/>/g,'\\x3e').replace(/&/g,'\\x26');
//"
}
function nl2br(text){
    if(typeof(text)=='undefined'||!text.toString){return'';}
    return text.toString().replace(/\n/g,'<br />');
}


function sprintf(){
    if(arguments.length==0){
	//Util.warn('sprintf() was called with no arguments; it should be called with at '+'least one argument.');
	return'';
    }
    var args=['This is an argument vector.'];
    for(var ii=arguments.length-1;ii>0;ii--){
	if(typeof(arguments[ii])=="undefined"){
	    Util.log('You passed an undefined argument (argument '+ii+' to sprintf(). '
		     +'Pattern was: `'+(arguments[0])+'\'.','error');
	    args.push('');
	}else if(arguments[ii]===null){
	    args.push('');
	}else if(arguments[ii]===true){
	    args.push('true');
	}else if(arguments[ii]===false){
	    args.push('false');
	}else{if(!arguments[ii].toString){
		//Util.log('Argument '+(ii+1)+' to sprintf() does not have a toString() '
		// +'method. The pattern was: `'+(arguments[0])+'\'.','error');
		return'';
	    }
	    args.push(arguments[ii]);
	}
    }
    var pattern=arguments[0];
    pattern=pattern.toString().split('%');
    var patlen=pattern.length;
    var result=pattern[0];
    for(var ii=1;ii<patlen;ii++){
	if(args.length==0){
	    //Util.log('Not enough arguments were provide to sprintf(). The pattern was: '+'`'
	    //+(arguments[0])+'\'.','error');
	    return'';
	}
	if(!pattern[ii].length){result+="%";continue;}
	var p=0;
	var m=0;
	var r='';
	var padChar=' ';
	var padSize=null;
	var maxSize=null;
	var rawPad='';
	var pos=0;

	if(m=pattern[ii].match(/^('.)?(?:(-?\d+\.)?(-?\d+)?)/)){ //'
	    if(m[2]!==undefined&&m[2].length){
		padSize=parseInt(rawPad=m[2]);
	    }
				  if(m[3]!==undefined&&m[3].length){
				      if(padSize!==null){
					  maxSize=parseInt(m[3]);
				      }else{
					  padSize=parseInt(rawPad=m[3]);
				      }
				  }
				  pos=m[0].length;
				  if(m[1]!==undefined&&m[1].length){
				      padChar=m[1].charAt(1);
				  }else{
				      if(rawPad.charAt(0)==0){padChar='0';}
				  }
				  }
	    switch(pattern[ii].charAt(pos)){
	    case's':
	    raw=htmlspecialchars(args.pop().toString());
	    break;
	    case'h':raw=args.pop().toString();
	    break;
	    case'd':raw=parseInt(args.pop()).toString();
	    break;
	    case'f':raw=parseFloat(args.pop()).toString();
	    break;
	    case'q':raw="`"+htmlspecialchars(args.pop().toString())+"'";
	    break;
	    case'e':raw="'"+escape_js_quotes(args.pop().toString())+"'";
	    break;
	    case'L':var list=args.pop();
	    for(var ii=0;ii<list.length;ii++){
		list[ii]="`"+htmlspecialchars(args.pop().toString())+"'";
	    }
	    if(list.length>1){
		list[list.length-1]='and '+list[list.length-1];
	    }
	    raw=list.join(', ');
	    break;
	    case'x':x=args.pop();
	    var line='?';
	    var src='?';
	    
	    try{
		if(typeof(x['line'])!='undefined'){
		    line=x.line;
		}else if(typeof(x['lineNumber'])!='undefined'){
		    line=x.lineNumber;
		}
		if(typeof(x['sourceURL'])!='undefined'){
		    src=x['sourceURL'];
		}else if(typeof(x['fileName'])!='undefined'){
		    src=s['fileName'];
		}
	    }catch(exception){}
	    var s='[An Exception]';
	    try{s=x.message||x.toString();}catch(exception){}
	    raw=s+' [at line '+line+' in '+src+']';
	    break;
	    
	    default:raw="%"+pattern[ii].charAt(pos+1);
	    break;
	    }
			       if(padSize!==null){
				   if(raw.length<Math.abs(padSize)){
				       var padding='';
				       var padlen=(Math.abs(padSize)-raw.length);
				       for(var ll=0;ll<padlen;ll++){padding+=padChar;}
				       if(padSize<0){raw+=padding;}else{raw=padding+raw;}
				   }
			       }
			       if(maxSize!==null){
				   if(raw.length>maxSize){raw=raw.substr(0,maxSize);}
			       }
			       result+=raw+pattern[ii].substring(pos+1);
			       }
	   if(args.length>1){
	       //Util.log('Too many arguments ('+(args.length-1)+' extras) were passed to '+'sprintf(). Pattern was: `'+(arguments[0])+'\'.','error');
	   }
	   return result;
	   }

String.prototype.split=(function(split){
	return function(separator,limit){
	    var flags="";
	    if(separator===null||limit===null){
		return[];
	    }else if(typeof separator=='string'){
		return split.call(this,separator,limit);
	    }else if(separator===undefined){
		return[this.toString()];
	    }else if(separator instanceof RegExp){
		if(!separator._2||!separator._1){
		    flags=separator.toString().replace(/^[\S\s]+\//,"");
		    if(!separator._1){
			if(!separator.global){
			    separator._1=new RegExp(separator.source,"g"+flags);
			}else{separator._1=1;}
		    }
		}
		separator1=separator._1==1?separator:separator._1;
		var separator2=(separator._2?separator._2:separator._2=new RegExp("^"+separator1.source+"$",flags));
		if(limit===undefined||limit<0){
		    limit=false;
		}else{
		    limit=Math.floor(limit);
		    if(!limit)return[];
		}
		var match,output=[],lastLastIndex=0,i=0;
		while((limit?i++<=limit:true)&&(match=separator1.exec(this))){
		    if((match[0].length===0)&&(separator1.lastIndex>match.index)){separator1.lastIndex--;}
		    if(separator1.lastIndex>lastLastIndex){
			if(match.length>1){
			    match[0].replace(separator2,function(){
				    for(var j=1;j<arguments.length-2;j++){
					if(arguments[j]===undefined)match[j]=undefined;
				    }
				});
			}
			output=output.concat(this.substring(lastLastIndex,match.index),
					     (match.index===this.length?[]:match.slice(1)));

			lastLastIndex=separator1.lastIndex;
		    }
		    if(match[0].length===0){separator1.lastIndex++;}
		}
		
		return(lastLastIndex===this.length)
		?(separator1.test("")?output:output.concat(""))
		:(limit?output:output.concat(this.substring(lastLastIndex)));
	    }else{
		return split.call(this,separator,limit);
	    }
	}
    })(String.prototype.split);

	//animation


function animation(obj){
    if(this==window){
	return new animation(obj);
    }else{
	this.obj=obj;
	this._reset_state();
	this.queue=[];
    }
}
animation.resolution=20;
animation.offset=0;
animation.prototype._reset_state=function(){
    this.state={attrs:{},duration:500}
};
animation.prototype.stop=function(){
    this._reset_state();
    this.queue=[];
    return this;
};
animation.prototype._build_container=function(){
    if(this.container_div){
	this._refresh_container();
	return;
    }
    var container=document.createElement('div');
    container.style.padding='0px';
    container.style.margin='0px';
    container.style.border='0px';
    var children=this.obj.childNodes;
    while(children.length){container.appendChild(children[0]);}
    this.obj.appendChild(container);
    this.obj.style.overflow='hidden';
    this.container_div=container;
    this._refresh_container();
};
animation.prototype._refresh_container=function(){
    this.container_div.style.height='auto';
    this.container_div.style.width='auto';
    this.container_div.style.height=this.container_div.offsetHeight+'px';
    this.container_div.style.width=this.container_div.offsetWidth+'px';
};
animation.prototype._destroy_container=function(){
    if(!this.container_div){return;}
    var children=this.container_div.childNodes;
    while(children.length){this.obj.appendChild(children[0]);}
    this.obj.removeChild(this.container_div);
    this.container_div=null;
};
animation.ATTR_TO=1;
animation.ATTR_BY=2;
animation.ATTR_FROM=3;
animation.prototype._attr=function(attr,value,mode){
    var auto=false;
    switch(attr){
    case'background':
	this._attr('backgroundColor',value,mode);
	return this;
    case'margin':
	value=animation.parse_group(value);
	this.attr('marginBottom',value[0],mode);
	this.attr('marginLeft',value[1],mode);
	this.attr('marginRight',value[2],mode);
	this.attr('marginTop',value[3],mode);
	return this;
    case'padding':
	value=animation.parse_group(value);
	this.attr('paddingBottom',value[0],mode);
	this.attr('paddingLeft',value[1],mode);
	this.attr('paddingRight',value[2],mode);
	this.attr('paddingTop',value[3],mode);
	return this;
    case'backgroundColor':
    case'borderColor':
    case'color':
	value=animation.parse_color(value);
	break;
    case'opacity':
	value=parseFloat(value,10);
	break;
    case'height':
    case'width':
	if(value=='auto'){
	    auto=true;
	}else{
	    value=parseInt(value);
	}
	break;
    case'borderWidth':
    case'lineHeight':
    case'fontSize':
    case'marginBottom':
    case'marginLeft':
    case'marginRight':
    case'marginTop':
    case'paddingBottom':
    case'paddingLeft':
    case'paddingRight':
    case'paddingTop':
    case'bottom':
    case'left':
    case'right':
    case'top':
    case'scrollTop':
    case'scrollLeft':
	value=parseInt(value,10);
	break;
    default:
	throw a+' is not a supported attribute!';
	break;
    }
    if(this.state.attrs[attr]===undefined){
	this.state.attrs[attr]={};
    }
    if(auto){this.state.attrs[attr].auto=true;}
    switch(mode){
    case animation.ATTR_FROM:
    this.state.attrs[attr].start=value;
    break;
    case animation.ATTR_BY:
    this.state.attrs[attr].by=true;
    case animation.ATTR_TO:
    this.state.attrs[attr].value=value;
    break;
    }
};
animation.prototype.to=function(attr,value){this._attr(attr,value,animation.ATTR_TO);return this;};
animation.prototype.by=function(attr,value){this._attr(attr,value,animation.ATTR_BY);return this;};
animation.prototype.from=function(attr,value){this._attr(attr,value,animation.ATTR_FROM);return this;};
animation.prototype.duration=function(duration){this.state.duration=duration?duration:0;return this;};
animation.prototype.checkpoint=function(distance,callback){
    if(distance===undefined){distance=1;}
    this.state.checkpoint=distance;
    this.state.checkpointcb=callback;
    this.queue.push(this.state);
    this._reset_state();
    return this;
};
animation.prototype.blind=function(){this.state.blind=true;return this;};
animation.prototype.hide=function(){this.state.hide=true;return this;};
animation.prototype.show=function(){this.state.show=true;return this;};
animation.prototype.ease=function(ease){this.state.ease=ease;return this;};
animation.prototype.go=function(){
    var time=(new Date()).getTime();
    this.queue.push(this.state);
    for(var i=0;i<this.queue.length;i++){
	this.queue[i].start=time-animation.offset;
	if(this.queue[i].checkpoint){
	    time+=this.queue[i].checkpoint*this.queue[i].duration;
	}
    }
    animation.push(this);
    return this;
};
animation.prototype._frame=function(time){
    var done=true;
    var still_needs_container=false;
    var blake_ross=false;
    for(var i=0;i<this.queue.length;i++){
	var cur=this.queue[i];
	if(cur.start>time){
	    done=false;
	    continue;
	}else if(cur.checkpointcb&&(cur.checkpoint*cur.duration+cur.start>time)){
	    this._callback(cur.checkpointcb,time-cur.start-cur.checkpoint*cur.duration);
	    cur.checkpointcb=null;
	}
	if(cur.started===undefined){
	    if(cur.show){
		this.obj.style.display='block';
	    }
	    for(var a in cur.attrs){
		if(cur.attrs[a].start!==undefined){continue;}
		switch(a){
		case'backgroundColor':
		case'borderColor':
		case'color':
		    var val=animation.parse_color(get_style(this.obj,a=='borderColor'?'borderLeftColor':a));
		    if(cur.attrs[a].by){
			cur.attrs[a].value[0]=Math.min(255,Math.max(0,cur.attrs[a].value[0]+val[0]));
			cur.attrs[a].value[1]=Math.min(255,Math.max(0,cur.attrs[a].value[1]+val[1]));
			cur.attrs[a].value[2]=Math.min(255,Math.max(0,cur.attrs[a].value[2]+val[2]));
		    }
		    break;
		case'opacity':
		    var val=get_opacity(this.obj);
		    if(cur.attrs[a].by){
			cur.attrs[a].value=Math.min(1,Math.max(0,cur.attrs[a].value+val));
		    }
		    break;
		case'height':
		case'width':
		    var val=animation['get_'+a](this.obj);
		    if(cur.attrs[a].by){cur.attrs[a].value+=val;}
		    break;
		case'scrollLeft':
		case'scrollTop':
		    var val=(this.obj==document.body?(document.documentElement||document.body):this.obj)[a];
		    if(cur.attrs[a].by){cur.attrs[a].value+=val;}
		    cur['last'+a]=val;
		    break;
		default:
		    var val=parseInt(get_style(this.obj,a),10);
		    if(cur.attrs[a].by){cur.attrs[a].value+=val;}
		    break;
		}
		cur.attrs[a].start=val;
	    }
	    if((cur.attrs.height&&cur.attrs.height.auto)
	       ||(cur.attrs.width&&cur.attrs.width.auto)
	       ){
		if(ua.firefox()<3){blake_ross=true;}
		this._destroy_container();
		for(var a in{
			height:1,width:1,
			    fontSize:1,
			    borderLeftWidth:1,borderRightWidth:1,borderTopWidth:1,borderBottomWidth:1,
			    paddingLeft:1,paddingRight:1,paddingTop:1,paddingBottom:1}
		    ){
		    if(cur.attrs[a]){
			this.obj.style[a]=cur.attrs[a].value+(typeof cur.attrs[a].value=='number'?'px':'');
		    }
		}
		if(cur.attrs.height&&cur.attrs.height.auto){cur.attrs.height.value=animation.get_height(this.obj);}
		if(cur.attrs.width&&cur.attrs.width.auto){cur.attrs.width.value=animation.get_width(this.obj);}
	    }
	    
	    cur.started=true;
	    if(cur.blind){this._build_container();}
	}
	var p=(time-cur.start)/cur.duration;
	if(p>=1){
	    p=1;
	    if(cur.hide){
		this.obj.style.display='none';
	    }
	}else{done=false;}
	if(cur.ease){p=cur.ease(p);}
	if(!still_needs_container&&p!=1&&cur.blind){still_needs_container=true;}
	if(blake_ross&&this.obj.parentNode){
	    var parentNode=this.obj.parentNode;
	    var nextChild=this.obj.nextSibling;
	    parentNode.removeChild(this.obj);
	}
	for(var a in cur.attrs){
	    switch(a){
	    case'backgroundColor':case'borderColor':case'color':
		this.obj.style[a]='rgb('+
		    animation.calc_tween(p,cur.attrs[a].start[0],cur.attrs[a].value[0],true)+','+
		    animation.calc_tween(p,cur.attrs[a].start[1],cur.attrs[a].value[1],true)+','+
		    animation.calc_tween(p,cur.attrs[a].start[2],cur.attrs[a].value[2],true)+')';
		break;
	    case'opacity':
		set_opacity(this.obj,animation.calc_tween(p,cur.attrs[a].start,cur.attrs[a].value));
		break;
	    case'height':case'width':
		this.obj.style[a]=p==1&&cur.attrs[a].auto?'auto'
		    :animation.calc_tween(p,cur.attrs[a].start,cur.attrs[a].value,true)+'px';
		break;
	    case'scrollLeft':case'scrollTop':
		var val=this.obj==document.body?document.documentElement[a]||document.body[a]:this.obj[a];
	    if(cur['last'+a]!=val){
		delete cur.attrs[a];
	    }else{
		var diff=animation.calc_tween(p,cur.attrs[a].start,cur.attrs[a].value,true)-val;
		if(a=='scrollLeft'){
		    window.scrollBy(diff,0);
		}else{window.scrollBy(0,diff);}
		cur['last'+a]=diff+val;
	    }
	    break;
	    default:
		this.obj.style[a]=animation.calc_tween(p,cur.attrs[a].start,cur.attrs[a].value,true)+'px';
		break;
	    }
	}
	if(p==1){
	    this.queue.splice(i--,1);
	    this._callback(cur.ondone,time-cur.start-cur.duration);
	}
    }
    if(blake_ross){
	parentNode[nextChild?'insertBefore':'appendChild'](this.obj,nextChild);
    }
    if(!still_needs_container&&this.container_div){this._destroy_container();}
    return!done;
};
animation.prototype.ondone=function(fn){this.state.ondone=fn;return this;};
animation.prototype._callback=function(callback,offset){
    if(callback){
	animation.offset=offset;
	callback.call(this);
	animation.offset=0;
    }
};
animation.calc_tween=function(p,v1,v2,whole){return(whole?parseInt:parseFloat)((v2-v1)*p+v1,10);};
animation.parse_color=function(color){
    var hex=/^#([a-f0-9]{1,2})([a-f0-9]{1,2})([a-f0-9]{1,2})$/i.exec(color);
    if(hex){
	return[parseInt(hex[1].length==1?hex[1]+hex[1]:hex[1],16),
	       parseInt(hex[2].length==1?hex[2]+hex[2]:hex[2],16),
	       parseInt(hex[3].length==1?hex[3]+hex[3]:hex[3],16)];
    }else{
	var rgb=/^rgba? *\(([0-9]+), *([0-9]+), *([0-9]+)(?:, *([0-9]+))?\)$/.exec(color);
	if(rgb){
	    if(rgb[4]==='0'){
		return[255,255,255];
	    }else{
		return[parseInt(rgb[1],10),
		       parseInt(rgb[2],10),
		       parseInt(rgb[3],10)];
	    }
	}else if(color=='transparent'){
	    return[255,255,255];
	}else{throw'Named color attributes are not supported.';}
    }
};
animation.parse_group=function(value){
    var value=trim(value).split(/ +/);
    if(value.length==4){
	return value;
    }else if(value.length==3){
	return[value[0],value[1],value[2],value[1]];
    }else if(value.length==2){
	return[value[0],value[1],value[0],value[1]];
    }else{return[value[0],value[0],value[0],value[0]];}
};
animation.get_height=function(obj){
    var pT=parseInt(get_style(obj,'paddingTop'),10),
    pB=parseInt(get_style(obj,'paddingBottom'),10),
    bT=parseInt(get_style(obj,'borderTopWidth'),10),
    bW=parseInt(get_style(obj,'borderBottomWidth'),10);
    return obj.offsetHeight-(pT?pT:0)-(pB?pB:0)-(bT?bT:0)-(bW?bW:0);
};
animation.get_width=function(obj){
    var pL=parseInt(get_style(obj,'paddingLeft'),10),
    pR=parseInt(get_style(obj,'paddingRight'),10),
    bL=parseInt(get_style(obj,'borderLeftWidth'),10),
    bR=parseInt(get_style(obj,'borderRightWidth'),10);
    return obj.offsetWidth-(pL?pL:0)-(pR?pR:0)-(bL?bL:0)-(bR?bR:0);
};
animation.push=function(instance){
    if(!animation.active){animation.active=[];}
    animation.active.push(instance);
    if(!animation.timeout){
	animation.timeout=setInterval(animation.animate.bind(animation),animation.resolution);
    }
};
animation.animate=function(){
    var done=true;
    var time=(new Date()).getTime();
    for(var i=0;i<animation.active.length;i++){
	if(animation.active[i]._frame(time)){
	    done=false;
	}else{
	    animation.active.splice(i--,1);
	}
    }
    if(done){
	clearInterval(animation.timeout);
	animation.timeout=null;
    }
};
animation.ease={};
animation.ease.begin=function(p){return p*p;};
animation.ease.end=function(p){p-=1;return-(p*p)+1;};
animation.ease.both=function(p){
    if(p<=0.5){
	return(p*p)*2;
    }else{
	p-=1;
	return(p*p)*-2+1;
    }
};

/*  file:5  */
/***********************/
/***** Pop Dialog ******/
/***********************/


function generic_dialog(className,modal){
    this.className=className;
    this.content=null;
    this.obj=null;
    this.popup=null;
    this.overlay=null;
    this.modal=null;
    this.iframe=null;
    this.hidden_objects=[];
    if(modal==true){
	this.modal=true;
    }
}
generic_dialog.dialog_stack=null;

generic_dialog.prototype.should_hide_objects=ua.osx();

generic_dialog.prototype.should_use_iframe=ua.ie()<7||(ua.osx()&&ua.firefox());

generic_dialog.prototype.show_dialog=function(html){
    if(!this.obj){
	this.build_dialog();
    }
    set_inner_html(this.content,html);
    if(generic_dialog.prototype.should_hide_objects){
	var imgs=this.content.getElementsByTagName('img');
	for(var i=0;i<imgs.length;i++){
	    imgs[i].onload=imgs[i].onload?function(){
		this.onload.apply(this.img,arguments);
		this.dialog.hide_objects()
	    }.bind({img:imgs[i],dialog:this,onload:imgs[i].onload})
		  :this.hide_objects.bind(this);
	}
    }
    this.show();
    this.focus_first_textbox();
    this.on_show_callback&&this.on_show_callback();
    return this;
};
    
generic_dialog.prototype.focus_first_textbox=function(){
    function focus_textbox(node){
	var is_textbox=(node.tagName=="INPUT"&&node.type.toLowerCase()=="text")||(node.tagName=="TEXTAREA");
	if(is_textbox){
	    try{
		if(elementY(node)>0&&elementX(node)>0){
		    node.focus();
		    return false;
		}
	    }catch(e){};
	}
	return true;
    }
    iterTraverseDom(this.content,focus_textbox)
}

generic_dialog.prototype.set_top=function(top){return this;}

generic_dialog.prototype.make_modal=function(){
    if(this.modal){return;}
    
    this.modal=true;
    if(ua.ie()==7){
	this.build_iframe();
    }
    this.build_overlay();
    this.reset_iframe();
}
generic_dialog.prototype.show_loading=function(loading_html){
    return this.show_dialog('<div class="dialog_loading">'+loading_html+'</div>');
}
generic_dialog.prototype.show_ajax_dialog_custom_loader=function(html,src,post_vars){
    post_vars=post_vars||false;
    this.show_loading(html);
    var myself=this;
    var ajax=new fbAjax(
		      function(obj,text){
			  myself.show_dialog(text);
		      },
		      function(obj){
			  myself.show_dialog(obj.transport.responseText);
		      }
		      );
    if(post_vars){
	ajax.post(src,post_vars);
    }else{
	ajax.get(src);
    }
    
    return this;
}

generic_dialog.prototype.show_ajax_dialog=function(src,post_vars){
    post_vars=post_vars||false;
    var load='Loading...';
    return this.show_ajax_dialog_custom_loader(load,src,post_vars);
}

generic_dialog.prototype.show_prompt=function(title,content){
    return this.show_dialog('<h2><span>'+title+'</span></h2><div class="dialog_content">'+content+'</div>');
}

generic_dialog.prototype.show_message=function(title,content,button){
    if(button==null){
	button='&nbsp;OK&nbsp;';
    }
    
    return this.show_choice(title,content,button,
			    function(){
				generic_dialog.get_dialog(this).fade_out(100)
			    }
			    );
}

generic_dialog.prototype.show_choice=function(title,content,button1,button1js,button2,button2js,buttons_msg,button3,button3js){
    var buttons='<div class="dialog_buttons" id="dialog_buttons">';
    if(typeof(buttons_msg)!='undefined'){
	buttons+='<div class="dialog_buttons_msg">';
	buttons+=buttons_msg;buttons+='</div>';
    }
    buttons+='<input class="inputsubmit" type="button" value="'+button1+'" id="dialog_button1" />';
    if(button2){
	buttons+='<input class="inputsubmit" type="button" value="'+button2+'" id="dialog_button2" />';
    }

    if(button3){
	buttons+='<input class="inputsubmit" type="button" value="'+button3+'" id="dialog_button3" />';
    }
    this.show_prompt(title,this.content_to_markup(content)+buttons);
    var inputs=this.obj.getElementsByTagName('input');
    if(button3){
	button1obj=inputs[inputs.length-3];
	button2obj=inputs[inputs.length-2];
	button3obj=inputs[inputs.length-1];
    }else if(button2){
	button1obj=inputs[inputs.length-2];
	button2obj=inputs[inputs.length-1];
    }else{
	button1obj=inputs[inputs.length-1];
    }
    
    if(button1js&&button1){
	if(typeof button1js=='string'){
	    eval('button1js = function() {'+button1js+'}');
	}
	button1obj.onclick=button1js;
    }
    if(button2js&&button2){
	if(typeof button2js=='string'){
	    eval('button2js = function() {'+button2js+'}');
	}
	button2obj.onclick=button2js;
    }
    if(button3js&&button3){
	if(typeof button3js=='string'){
	    eval('button3js = function() {'+button3js+'}');
	}
	button3obj.onclick=button3js;
    }
    if(!this.modal){
	document.onkeyup=function(e){
	    var keycode=(e&&e.which)?e.which:event.keyCode;
	    var btn2_exists=(typeof button2obj!='undefined');
	    var btn3_exists=(typeof button3obj!='undefined');
	    var is_webkit=ua.safari();
	    if(is_webkit&&keycode==13){
		button1obj.click();
	    }
	    
	    if(keycode==27){
		if(btn3_exists){
		    button3obj.click();
		}else if(btn2_exists){
		    button2obj.click();
		}else{
		    button1obj.click();
		}
	    }
	    document.onkeyup=function(){}
	}
	button1obj.focus();
    }
    return this;
};

generic_dialog.prototype.show_choice_ajax_custom_loader=
    function(
	     html,title,content_src,button1,button1js,button2,button2js,
	     buttons_msg,button3,button3js){

    this.show_loading(html);
    var handler=function(response){
	this.show_choice(title,response.getPayload(),button1,button1js,button2,button2js,
			 buttons_msg,button3,button3js);
    }.bind(this);
    new AsyncRequest().setURI(content_src).setMethod('GET').setReadOnly(true).setHandler(handler).send();
    return this;
};

generic_dialog.prototype.show_choice_ajax_post_custom_loader=
    function(
	     html,title,content_src,post_data,button1,button1js,button2,button2js,
	     buttons_msg,button3,button3js){

    this.show_loading(html);
    var handler=function(response){
	this.show_choice(title,response.getPayload(),button1,button1js,button2,button2js,
			 buttons_msg,button3,button3js);
    }.bind(this);
    new AsyncRequest().setURI(content_src).setMethod('POST').setData(URI.explodeQuery(post_data)).setHandler(handler).send();
    return this;
};


generic_dialog.prototype.show_choice_ajax=
    function(
	     title,content_src,button1,button1js,button2,button2js,
	     buttons_msg,button3,button3js){
    var load = 'Loading...';
    return this.show_choice_ajax(load,title,content_src,button1,button1js,button2,button2js,
				 buttons_msg,button3,button3js);
};

    
generic_dialog.prototype.show_form_ajax=function(title,src,button,reload_page_on_success){
    this.show_loading('Loading...');
    var form_id='dialog_ajax_form__'+gen_unique();
    var preSubmitErrorHandler=function(dialog,response){
	if(response.getError()!=true){
	    dialog.hide();
	    ErrorDialog.showAsyncError(response);
	}else{
	    dialog.show_choice(title,response.getPayload(),'Okay',
			       function(){
				   dialog.fade_out(200);
			       });
	}
    }.bind(null,this);
    var preSubmitHandler=function(dialog,response){
	var contents='<form id="'+form_id+'" onsubmit="return false;">'+response.getPayload()+'</form>';
	dialog.show_choice(title,contents,button,submitHandler,'Cancel',
			   function(){dialog.fade_out(200);
			   });
    }.bind(null,this);
    var submitHandler=function(){
	new AsyncRequest().setURI(src).setData(
					       serialize_form(ge(form_id))
					       ).setHandler(postSubmitHandler)
	.setErrorHandler(postSubmitErrorHandler).send();
    };
    var postSubmitHandler=function(dialog,response){
	dialog.show_choice(title,response.getPayload(),'Okay',
			   function(){dialog.fade_out(200);}
			   );
	if(reload_page_on_success){
	    window.location.reload();
	}else{
	    setTimeout(function(){
		    dialog.fade_out(500);
		},750);
	}
    }.bind(null,this);

    var postSubmitErrorHandler=function(dialog,response){
	if(response.getError()==1346001){
	    preSubmitHandler(response);
	}else if(response.getError()!=true){
	    ErrorDialog.showAsyncError(response);
	}else{
	    preSubmitErrorHandler(response);
	}
    }.bind(null,this);

    new AsyncRequest().setURI(src).setReadOnly(true).setHandler(preSubmitHandler)
    .setErrorHandler(preSubmitErrorHandler).send();
    return this;
}

generic_dialog.prototype.show_form=function(title,content,button,target){
    content='<form action="'+target+'" method="post">'+this.content_to_markup(content);
    var post_form_id=ge('post_form_id');
    if(post_form_id){
	content+='<input type="hidden" name="post_form_id" value="'+post_form_id.value+'" />';
    }
    content+='<div class="dialog_buttons"><input class="inputsubmit" name="confirm" type="submit" value="'+button+'" />';
    content+='<input type="hidden" name="next" value="'+htmlspecialchars(document.location.href)+'"/>';
    content+='<input class="inputsubmit" type="button" value="Cancel" onclick="generic_dialog.get_dialog(this).fade_out(100)" /></form>';
    this.show_prompt(title,content);
    return this;
}

generic_dialog.prototype.content_to_markup=function(content){
    return(typeof content=='string')?
    '<div class="dialog_body">'+content+'</div>'
    :'<div class="dialog_summary">'+content.summary+'</div><div class="dialog_body">'+content.body+'</div>';
}

generic_dialog.prototype.hide=function(temporary){
    if(this.obj){this.obj.style.display='none';}
    if(this.iframe){this.iframe.style.display='none';}
    if(this.overlay){this.overlay.style.display='none';}
    if(this.timeout){clearTimeout(this.timeout);this.timeout=null;return;}
    if(this.hidden_objects.length){
	for(var i=0,il=this.hidden_objects.length;i<il;i++){
	    this.hidden_objects[i].style.visibility='';
	}
	this.hidden_objects=[];
    }
    clearInterval(this.active_hiding);
    if(!temporary){
	if(generic_dialog.dialog_stack){
	    var stack=generic_dialog.dialog_stack;
	    for(var i=stack.length-1;i>=0;i--){
		if(stack[i]==this){
		    stack.splice(i,1);
		}
	    }
	    if(stack.length){
		stack[stack.length-1].show();
	    }
	}
	if(this.obj){
	    this.obj.parentNode.removeChild(this.obj);
	    this.obj=null;
	}
    }
    return this;
}
generic_dialog.prototype.fade_out=function(interval,timeout){
    if(!this.popup){
	return this;
    }
    
    if(!this.obj) return this;

    animation(this.obj).duration(timeout?timeout:0)
    .checkpoint().to('opacity',0).hide()
    .duration(interval?interval:350).ondone(this.hide.bind(this)).go();
    
    return this;
}
generic_dialog.prototype.show=function(){
    if(this.obj&&this.obj.style.display){
	this.obj.style.visibility='hidden';
	this.obj.style.display='';
	this.reset_dialog();
	this.obj.style.visibility='';
	this.obj.dialog=this;
    }else{
	this.reset_dialog();
    }
    this.hide_objects();
    clearInterval(this.active_hiding);
    this.active_hiding=setInterval(this.active_resize.bind(this),500);
    var stack=generic_dialog.dialog_stack?
    generic_dialog.dialog_stack:
    generic_dialog.dialog_stack=[];

    for(var i=stack.length-1;i>=0;i--){
	if(stack[i]==this){
	    stack.splice(i,1);
	}else{
	    stack[i].hide(true);
	}
    }
    stack.push(this);

    try{
	if(this.iframe){this.iframe.style.display='';}
	if(this.overlay){this.overlay.style.display='';}
    }catch(ex){}

    return this;
}
generic_dialog.prototype.enable_buttons=function(enable){
    var inputs=this.obj.getElementsByTagName('input');
    for(var i=0;i<inputs.length;i++){
	if(inputs[i].type=='button'||inputs[i].type=='submit'){
	    inputs[i].disabled=!enable;
	}
    }
}

generic_dialog.prototype.active_resize=function(){
    if(this.last_offset_height!=this.content.offsetHeight){
	this.hide_objects();
	/* dialog resize  */
	if(this.iframe)
	    this.reset_iframe();
	if(this.overlay){
	    try{
		this.reset_overlay();
	    }catch(ex){}
	}
	this.last_offset_height=this.content.offsetHeight;
    }
}

generic_dialog.prototype.hide_objects=function(){
    var objects=[];
    var ad_locs=['',0,1,2,4,5,9,3];
    for(var i=0;i<ad_locs.length;i++){
	var ad_div=ge('ad_'+ad_locs[i]);
	if(ad_div!=null){
	    objects.push(ad_div);
	    this.should_hide_objects=true;
	}
    }
    if(!this.should_hide_objects){return;}

    var rect={
	x:elementX(this.content),
	y:elementY(this.content),
	w:this.content.offsetWidth,
	h:this.content.offsetHeight
    };

    var iframes=document.getElementsByTagName('iframe');
    for(var i=0;i<iframes.length;i++){
	if(1 || iframes[i].className.indexOf('share_hide_on_dialog')!=-1){
	    objects.push(iframes[i]);
	}
    }
    var swfs=document.getElementsByTagName('embed');
    for(var i=0;i<swfs.length;i++){
	if((swfs[i].getAttribute("src").indexOf("/intern/data/swf/")==-1)
	   ||(swfs[i].getAttribute("wmode")!="transparent")){
	    objects.push(swfs[i]);
	}
    }
    
    for(var i=0;i<objects.length;i++){
	var node=objects[i].offsetHeight?objects[i]:objects[i].parentNode;
	swf_rect={
	    x:elementX(node),
	    y:elementY(node),
	    w:node.offsetWidth,
	    h:node.offsetHeight
	};
	if(!is_descendent(objects[i],this.content)
	   &&rect.y+rect.h>swf_rect.y
	   &&swf_rect.y+swf_rect.h>rect.y
	   &&rect.x+rect.w>swf_rect.x
	   &&swf_rect.x+swf_rect.w>rect.w
	   &&array_indexOf(this.hidden_objects,node)==-1){
	    this.hidden_objects.push(node);
	    node.style.visibility='hidden';
	    node.style.visibility='hidden';
	}
    }
}

generic_dialog.prototype.build_dialog=function(){
    if(!this.obj){
	this.obj=document.createElement('div');
    }

    this.obj.className='generic_dialog'+(this.className?' '+this.className:'');
    this.obj.style.display='none';
    onloadRegister(function(){
	    document.body.appendChild(this.obj);
	}.bind(this));

    if(this.should_use_iframe||(this.modal&&ua.ie()==7)){this.build_iframe();}
    
    if(!this.popup){this.popup=document.createElement('div');this.popup.className='generic_dialog_popup';}
    this.popup.style.left=this.popup.style.top='';

    this.obj.appendChild(this.popup);
    if(this.modal){this.build_overlay();}

}

generic_dialog.prototype.build_iframe=function(){
    if(!this.iframe&&!(this.iframe=ge('generic_dialog_iframe'))){
	this.iframe=document.createElement('iframe');
	this.iframe.id='generic_dialog_iframe';
	this.iframe.src= '//www.mipang.com/dummy.html';
    }

    this.iframe.frameBorder='0';
    
    if(!this.iframe.style) this.iframe.setAttribute('style','');
    this.iframe.style.display='';

    onloadRegister(function(){
	    document.body.appendChild(this.iframe);
	}.bind(this));
}

generic_dialog.prototype.build_overlay=function(){
    if(!this.overlay&&!(this.overlay=ge('generic_dialog_overlay'))){
	this.overlay=document.createElement('div');
	this.overlay.id='generic_dialog_overlay';
    }
    if(!this.overlay.style) this.overlay.setAttribute('style','');
    this.overlay.style.display='';

    if(document.body.clientHeight>document.documentElement.clientHeight){
	this.overlay.style.height=document.body.clientHeight+'px';
    }else{
	this.overlay.style.height=document.documentElement.clientHeight+'px';
    }

    onloadRegister(function(){document.body.appendChild(this.overlay);}.bind(this));
}

generic_dialog.prototype.reset_dialog=function(){
    if(!this.popup){return;}

    onloadRegister(function(){
	    this.reset_dialog_obj();
	    this.reset_iframe();
	}.bind(this));
}

generic_dialog.prototype.reset_iframe=function(){
    if(!this.should_use_iframe&&!(this.modal&&ua.ie()==7)){return;}

    if(!this.obj || this.obj.style.display=='none'){return;}

    if(this.modal){
	this.iframe.style.left='0px';
	this.iframe.style.top='0px';
	this.iframe.style.width='100%';
	if((document.body.clientHeight>document.documentElement.clientHeight)
	   &&(document.body.clientHeight<10000)){
	    this.iframe.style.height=document.body.clientHeight+'px';
	}else if((document.body.clientHeight<document.documentElement.clientHeight)
		 &&(document.documentElement.clientHeight<10000)){
	    this.iframe.style.height=document.documentElement.clientHeight+'px';
	}else{
	    this.iframe.style.height='10000px';
	}
    }else{
	this.iframe.style.left=elementX(this.frame)+'px';
	this.iframe.style.top=elementY(this.frame)+'px';
	this.iframe.style.width=this.frame.offsetWidth+'px';
	this.iframe.style.height=this.frame.offsetHeight+'px';
    }
/*    this.iframe.style.display='';*/
}

generic_dialog.prototype.reset_overlay=function(){
    if(!this.overlay || !this.obj) return;

    //return;

    var xy=document.viewport.getDimensions();
    var el,h,y;
    if($(this.obj).hasClassName("contextual_dialog")){
	/* contextual_dialog */
	el = $(this.obj).down("div.contextual_arrow");
	var el2=$(this.obj).down("div.contextual_dialog_content");
	h = el.offsetHeight+el2.offsetHeight;
	y = GetPageOffsetTop(el);
    }else{
	/* pop_dialog */
	el = $(this.obj).select('table')[0];
	h = el.offsetHeight;
	y = GetPageOffsetTop(el);
    }
    var bh = $$('body')[0].offsetHeight;

    /*alert([xy.height,h,y,bh]);*/
    var maxh = Math.max(Math.max(xy.height , y+h) ,bh);

    this.overlay.style.height=maxh+'px';
};

generic_dialog.prototype.reset_dialog_obj=function(){}
generic_dialog.get_dialog=function(obj){
    while(!obj.dialog&&obj.parentNode){
	obj=obj.parentNode;
    }
    return obj.dialog?obj.dialog:false;
}

function pop_dialog(className,callback_function,modal){
    this.top=125;
    this.parent.construct(this,className,modal);
    this.on_show_callback=callback_function;
}

pop_dialog.class_extend(generic_dialog);
pop_dialog.prototype.build_dialog=function(){
    this.parent.build_dialog();
    this.obj.className+=' pop_dialog';
    this.popup.innerHTML='<table id="pop_dialog_table" class="pop_dialog_table">'
    +'<tr><td class="pop_topleft"></td><td class="pop_border"></td><td class="pop_topright"></td></tr>'
    +'<tr><td class="pop_border"></td><td class="pop_content" id="pop_content"></td><td class="pop_border"></td></tr>'
    +'<tr><td class="pop_bottomleft"></td><td class="pop_border"></td><td class="pop_bottomright"></td></tr>'
    +'</table>';

    this.frame=this.popup.getElementsByTagName('tbody')[0];
    this.content=this.popup.getElementsByTagName('td')[4];
}

pop_dialog.prototype.reset_dialog_obj=function(){
    this.popup.style.top=(
			  document.documentElement.scrollTop?
			  document.documentElement.scrollTop:
			  document.body.scrollTop
			  )
    +this.top+'px';

    Event.observe(window,'resize',this.reset_iframe.bind(this));
    Event.observe(window,'resize',this.reset_overlay.bind(this));
    Event.observe(document.body,'scroll',this.reset_iframe.bind(this));
    Event.observe(document.body,'scroll',this.reset_overlay.bind(this));
}

pop_dialog.prototype.set_top=function(top){
    this.top=top;
    return this;
}

function contextual_dialog(className){
    this.parent.construct(this,className);
}

contextual_dialog.class_extend(generic_dialog);
contextual_dialog.prototype.set_context=function(obj){
    this.context=obj;
    return this;
}
contextual_dialog.prototype.build_dialog=function(){
    this.parent.build_dialog();
    this.obj.className+=' contextual_dialog';
    this.popup.innerHTML='<div class="contextual_arrow"><span>^_^keke1</span></div><div class="contextual_dialog_content"></div>';
    this.arrow=this.popup.getElementsByTagName('div')[0];
    this.content=this.frame=this.popup.getElementsByTagName('div')[1];
}

contextual_dialog.prototype.reset_dialog_obj=function(){
    try{

    var x=elementX(this.context);
    var center=(document.body.offsetWidth-this.popup.offsetWidth)/2;
    if(x<document.body.offsetWidth/2){
	this.arrow.className='contextual_arrow_rev';
	var left=Math.min(center,x+this.context.offsetWidth-this.arrow_padding_x);
	var arrow=x-left+this.context.offsetWidth+this.arrow_padding_x;
    }else{
	this.arrow.className='contextual_arrow';
	var left=Math.max(center,x-this.popup.offsetWidth+this.arrow_padding_x);
	var arrow=x-left-this.arrow_padding_x-this.arrow_width;
    }
    this.popup.style.top=(elementY(this.context)+this.context.offsetHeight-this.arrow.offsetHeight+this.arrow_padding_y)+'px';
    this.popup.style.left=left+'px';this.arrow.style.backgroundPosition=arrow+'px';

    }catch(ex){}
}

contextual_dialog.prototype._remove_resize_events=function(){
    if(this._scroll_events){
	for(var i=0;i<this._scroll_events.length;i++){
	    removeEventBase(this._scroll_events[i].obj,this._scroll_events[i].event,this._scroll_events[i].func);
	}
    }
    
    this._scroll_events=[];
}

contextual_dialog.prototype.show=function(){
    this._remove_resize_events();
    var obj=this.context;
    while(obj){
	if(obj.id!='content'
	   &&(obj.scrollHeight
	      &&obj.offsetHeight
	      &&obj.scrollHeight!=obj.offsetHeight)
	   ||(obj.scrollWidth
	      &&obj.offsetWidth
	      &&obj.scrollWidth!=obj.offsetWidth)
	   ){
	    var evt={
		obj:obj,
		event:'scroll',
		func:this.reset_dialog_obj.bind(this)
	    };
	    addEventBase(evt.obj,evt.event,evt.func);
	}
	obj=obj.parentNode;
    }

    var evt={
	obj:window,
	event:'resize',
	func:this.reset_dialog_obj.bind(this)
    };
    addEventBase(evt.obj,evt.event,evt.func);
    this.parent.show();
}

contextual_dialog.prototype.hide=function(){
    this._remove_resize_events();
    this.parent.hide();
}

contextual_dialog.prototype.arrow_padding_x=5;
contextual_dialog.prototype.arrow_padding_y=10;
contextual_dialog.prototype.arrow_width=13;
function ErrorDialog(){
    this.parent.construct(this,'errorDialog',null,true);
    return this;
};

ErrorDialog.class_extend(pop_dialog);

copy_properties(
		ErrorDialog.prototype,
		{
		    showError:function(title,message){
			return this.show_message(title,message);
		    }
		}
		);
copy_properties(ErrorDialog,
		{
		    showAsyncError:function(response){
			try{
			    return(new ErrorDialog())
				.showError(response.getErrorSummary(),
					   response.getErrorDescription());
			}catch(ex){
			    aiert(response);
			}
		    }
		}
		);


/*  file:6  */
/*! jQuery v1.9.1 | (c) 2005, 2012 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingURL=jquery.min.map
*/(function(e,t){var n,r,i=typeof t,o=e.document,a=e.location,s=e.jQuery,u=e.$,l={},c=[],p="1.9.1",f=c.concat,d=c.push,h=c.slice,g=c.indexOf,m=l.toString,y=l.hasOwnProperty,v=p.trim,b=function(e,t){return new b.fn.init(e,t,r)},x=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,w=/\S+/g,T=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,N=/^(?:(<[\w\W]+>)[^>]*|#([\w-]*))$/,C=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,k=/^[\],:{}\s]*$/,E=/(?:^|:|,)(?:\s*\[)+/g,S=/\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,A=/"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g,j=/^-ms-/,D=/-([\da-z])/gi,L=function(e,t){return t.toUpperCase()},H=function(e){(o.addEventListener||"load"===e.type||"complete"===o.readyState)&&(q(),b.ready())},q=function(){o.addEventListener?(o.removeEventListener("DOMContentLoaded",H,!1),e.removeEventListener("load",H,!1)):(o.detachEvent("onreadystatechange",H),e.detachEvent("onload",H))};b.fn=b.prototype={jquery:p,constructor:b,init:function(e,n,r){var i,a;if(!e)return this;if("string"==typeof e){if(i="<"===e.charAt(0)&&">"===e.charAt(e.length-1)&&e.length>=3?[null,e,null]:N.exec(e),!i||!i[1]&&n)return!n||n.jquery?(n||r).find(e):this.constructor(n).find(e);if(i[1]){if(n=n instanceof b?n[0]:n,b.merge(this,b.parseHTML(i[1],n&&n.nodeType?n.ownerDocument||n:o,!0)),C.test(i[1])&&b.isPlainObject(n))for(i in n)b.isFunction(this[i])?this[i](n[i]):this.attr(i,n[i]);return this}if(a=o.getElementById(i[2]),a&&a.parentNode){if(a.id!==i[2])return r.find(e);this.length=1,this[0]=a}return this.context=o,this.selector=e,this}return e.nodeType?(this.context=this[0]=e,this.length=1,this):b.isFunction(e)?r.ready(e):(e.selector!==t&&(this.selector=e.selector,this.context=e.context),b.makeArray(e,this))},selector:"",length:0,size:function(){return this.length},toArray:function(){return h.call(this)},get:function(e){return null==e?this.toArray():0>e?this[this.length+e]:this[e]},pushStack:function(e){var t=b.merge(this.constructor(),e);return t.prevObject=this,t.context=this.context,t},each:function(e,t){return b.each(this,e,t)},ready:function(e){return b.ready.promise().done(e),this},slice:function(){return this.pushStack(h.apply(this,arguments))},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},eq:function(e){var t=this.length,n=+e+(0>e?t:0);return this.pushStack(n>=0&&t>n?[this[n]]:[])},map:function(e){return this.pushStack(b.map(this,function(t,n){return e.call(t,n,t)}))},end:function(){return this.prevObject||this.constructor(null)},push:d,sort:[].sort,splice:[].splice},b.fn.init.prototype=b.fn,b.extend=b.fn.extend=function(){var e,n,r,i,o,a,s=arguments[0]||{},u=1,l=arguments.length,c=!1;for("boolean"==typeof s&&(c=s,s=arguments[1]||{},u=2),"object"==typeof s||b.isFunction(s)||(s={}),l===u&&(s=this,--u);l>u;u++)if(null!=(o=arguments[u]))for(i in o)e=s[i],r=o[i],s!==r&&(c&&r&&(b.isPlainObject(r)||(n=b.isArray(r)))?(n?(n=!1,a=e&&b.isArray(e)?e:[]):a=e&&b.isPlainObject(e)?e:{},s[i]=b.extend(c,a,r)):r!==t&&(s[i]=r));return s},b.extend({noConflict:function(t){return e.$===b&&(e.$=u),t&&e.jQuery===b&&(e.jQuery=s),b},isReady:!1,readyWait:1,holdReady:function(e){e?b.readyWait++:b.ready(!0)},ready:function(e){if(e===!0?!--b.readyWait:!b.isReady){if(!o.body)return setTimeout(b.ready);b.isReady=!0,e!==!0&&--b.readyWait>0||(n.resolveWith(o,[b]),b.fn.trigger&&b(o).trigger("ready").off("ready"))}},isFunction:function(e){return"function"===b.type(e)},isArray:Array.isArray||function(e){return"array"===b.type(e)},isWindow:function(e){return null!=e&&e==e.window},isNumeric:function(e){return!isNaN(parseFloat(e))&&isFinite(e)},type:function(e){return null==e?e+"":"object"==typeof e||"function"==typeof e?l[m.call(e)]||"object":typeof e},isPlainObject:function(e){if(!e||"object"!==b.type(e)||e.nodeType||b.isWindow(e))return!1;try{if(e.constructor&&!y.call(e,"constructor")&&!y.call(e.constructor.prototype,"isPrototypeOf"))return!1}catch(n){return!1}var r;for(r in e);return r===t||y.call(e,r)},isEmptyObject:function(e){var t;for(t in e)return!1;return!0},error:function(e){throw Error(e)},parseHTML:function(e,t,n){if(!e||"string"!=typeof e)return null;"boolean"==typeof t&&(n=t,t=!1),t=t||o;var r=C.exec(e),i=!n&&[];return r?[t.createElement(r[1])]:(r=b.buildFragment([e],t,i),i&&b(i).remove(),b.merge([],r.childNodes))},parseJSON:function(n){return e.JSON&&e.JSON.parse?e.JSON.parse(n):null===n?n:"string"==typeof n&&(n=b.trim(n),n&&k.test(n.replace(S,"@").replace(A,"]").replace(E,"")))?Function("return "+n)():(b.error("Invalid JSON: "+n),t)},parseXML:function(n){var r,i;if(!n||"string"!=typeof n)return null;try{e.DOMParser?(i=new DOMParser,r=i.parseFromString(n,"text/xml")):(r=new ActiveXObject("Microsoft.XMLDOM"),r.async="false",r.loadXML(n))}catch(o){r=t}return r&&r.documentElement&&!r.getElementsByTagName("parsererror").length||b.error("Invalid XML: "+n),r},noop:function(){},globalEval:function(t){t&&b.trim(t)&&(e.execScript||function(t){e.eval.call(e,t)})(t)},camelCase:function(e){return e.replace(j,"ms-").replace(D,L)},nodeName:function(e,t){return e.nodeName&&e.nodeName.toLowerCase()===t.toLowerCase()},each:function(e,t,n){var r,i=0,o=e.length,a=M(e);if(n){if(a){for(;o>i;i++)if(r=t.apply(e[i],n),r===!1)break}else for(i in e)if(r=t.apply(e[i],n),r===!1)break}else if(a){for(;o>i;i++)if(r=t.call(e[i],i,e[i]),r===!1)break}else for(i in e)if(r=t.call(e[i],i,e[i]),r===!1)break;return e},trim:v&&!v.call("\ufeff\u00a0")?function(e){return null==e?"":v.call(e)}:function(e){return null==e?"":(e+"").replace(T,"")},makeArray:function(e,t){var n=t||[];return null!=e&&(M(Object(e))?b.merge(n,"string"==typeof e?[e]:e):d.call(n,e)),n},inArray:function(e,t,n){var r;if(t){if(g)return g.call(t,e,n);for(r=t.length,n=n?0>n?Math.max(0,r+n):n:0;r>n;n++)if(n in t&&t[n]===e)return n}return-1},merge:function(e,n){var r=n.length,i=e.length,o=0;if("number"==typeof r)for(;r>o;o++)e[i++]=n[o];else while(n[o]!==t)e[i++]=n[o++];return e.length=i,e},grep:function(e,t,n){var r,i=[],o=0,a=e.length;for(n=!!n;a>o;o++)r=!!t(e[o],o),n!==r&&i.push(e[o]);return i},map:function(e,t,n){var r,i=0,o=e.length,a=M(e),s=[];if(a)for(;o>i;i++)r=t(e[i],i,n),null!=r&&(s[s.length]=r);else for(i in e)r=t(e[i],i,n),null!=r&&(s[s.length]=r);return f.apply([],s)},guid:1,proxy:function(e,n){var r,i,o;return"string"==typeof n&&(o=e[n],n=e,e=o),b.isFunction(e)?(r=h.call(arguments,2),i=function(){return e.apply(n||this,r.concat(h.call(arguments)))},i.guid=e.guid=e.guid||b.guid++,i):t},access:function(e,n,r,i,o,a,s){var u=0,l=e.length,c=null==r;if("object"===b.type(r)){o=!0;for(u in r)b.access(e,n,u,r[u],!0,a,s)}else if(i!==t&&(o=!0,b.isFunction(i)||(s=!0),c&&(s?(n.call(e,i),n=null):(c=n,n=function(e,t,n){return c.call(b(e),n)})),n))for(;l>u;u++)n(e[u],r,s?i:i.call(e[u],u,n(e[u],r)));return o?e:c?n.call(e):l?n(e[0],r):a},now:function(){return(new Date).getTime()}}),b.ready.promise=function(t){if(!n)if(n=b.Deferred(),"complete"===o.readyState)setTimeout(b.ready);else if(o.addEventListener)o.addEventListener("DOMContentLoaded",H,!1),e.addEventListener("load",H,!1);else{o.attachEvent("onreadystatechange",H),e.attachEvent("onload",H);var r=!1;try{r=null==e.frameElement&&o.documentElement}catch(i){}r&&r.doScroll&&function a(){if(!b.isReady){try{r.doScroll("left")}catch(e){return setTimeout(a,50)}q(),b.ready()}}()}return n.promise(t)},b.each("Boolean Number String Function Array Date RegExp Object Error".split(" "),function(e,t){l["[object "+t+"]"]=t.toLowerCase()});function M(e){var t=e.length,n=b.type(e);return b.isWindow(e)?!1:1===e.nodeType&&t?!0:"array"===n||"function"!==n&&(0===t||"number"==typeof t&&t>0&&t-1 in e)}r=b(o);var _={};function F(e){var t=_[e]={};return b.each(e.match(w)||[],function(e,n){t[n]=!0}),t}b.Callbacks=function(e){e="string"==typeof e?_[e]||F(e):b.extend({},e);var n,r,i,o,a,s,u=[],l=!e.once&&[],c=function(t){for(r=e.memory&&t,i=!0,a=s||0,s=0,o=u.length,n=!0;u&&o>a;a++)if(u[a].apply(t[0],t[1])===!1&&e.stopOnFalse){r=!1;break}n=!1,u&&(l?l.length&&c(l.shift()):r?u=[]:p.disable())},p={add:function(){if(u){var t=u.length;(function i(t){b.each(t,function(t,n){var r=b.type(n);"function"===r?e.unique&&p.has(n)||u.push(n):n&&n.length&&"string"!==r&&i(n)})})(arguments),n?o=u.length:r&&(s=t,c(r))}return this},remove:function(){return u&&b.each(arguments,function(e,t){var r;while((r=b.inArray(t,u,r))>-1)u.splice(r,1),n&&(o>=r&&o--,a>=r&&a--)}),this},has:function(e){return e?b.inArray(e,u)>-1:!(!u||!u.length)},empty:function(){return u=[],this},disable:function(){return u=l=r=t,this},disabled:function(){return!u},lock:function(){return l=t,r||p.disable(),this},locked:function(){return!l},fireWith:function(e,t){return t=t||[],t=[e,t.slice?t.slice():t],!u||i&&!l||(n?l.push(t):c(t)),this},fire:function(){return p.fireWith(this,arguments),this},fired:function(){return!!i}};return p},b.extend({Deferred:function(e){var t=[["resolve","done",b.Callbacks("once memory"),"resolved"],["reject","fail",b.Callbacks("once memory"),"rejected"],["notify","progress",b.Callbacks("memory")]],n="pending",r={state:function(){return n},always:function(){return i.done(arguments).fail(arguments),this},then:function(){var e=arguments;return b.Deferred(function(n){b.each(t,function(t,o){var a=o[0],s=b.isFunction(e[t])&&e[t];i[o[1]](function(){var e=s&&s.apply(this,arguments);e&&b.isFunction(e.promise)?e.promise().done(n.resolve).fail(n.reject).progress(n.notify):n[a+"With"](this===r?n.promise():this,s?[e]:arguments)})}),e=null}).promise()},promise:function(e){return null!=e?b.extend(e,r):r}},i={};return r.pipe=r.then,b.each(t,function(e,o){var a=o[2],s=o[3];r[o[1]]=a.add,s&&a.add(function(){n=s},t[1^e][2].disable,t[2][2].lock),i[o[0]]=function(){return i[o[0]+"With"](this===i?r:this,arguments),this},i[o[0]+"With"]=a.fireWith}),r.promise(i),e&&e.call(i,i),i},when:function(e){var t=0,n=h.call(arguments),r=n.length,i=1!==r||e&&b.isFunction(e.promise)?r:0,o=1===i?e:b.Deferred(),a=function(e,t,n){return function(r){t[e]=this,n[e]=arguments.length>1?h.call(arguments):r,n===s?o.notifyWith(t,n):--i||o.resolveWith(t,n)}},s,u,l;if(r>1)for(s=Array(r),u=Array(r),l=Array(r);r>t;t++)n[t]&&b.isFunction(n[t].promise)?n[t].promise().done(a(t,l,n)).fail(o.reject).progress(a(t,u,s)):--i;return i||o.resolveWith(l,n),o.promise()}}),b.support=function(){var t,n,r,a,s,u,l,c,p,f,d=o.createElement("div");if(d.setAttribute("className","t"),d.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",n=d.getElementsByTagName("*"),r=d.getElementsByTagName("a")[0],!n||!r||!n.length)return{};s=o.createElement("select"),l=s.appendChild(o.createElement("option")),a=d.getElementsByTagName("input")[0],r.style.cssText="top:1px;float:left;opacity:.5",t={getSetAttribute:"t"!==d.className,leadingWhitespace:3===d.firstChild.nodeType,tbody:!d.getElementsByTagName("tbody").length,htmlSerialize:!!d.getElementsByTagName("link").length,style:/top/.test(r.getAttribute("style")),hrefNormalized:"/a"===r.getAttribute("href"),opacity:/^0.5/.test(r.style.opacity),cssFloat:!!r.style.cssFloat,checkOn:!!a.value,optSelected:l.selected,enctype:!!o.createElement("form").enctype,html5Clone:"<:nav></:nav>"!==o.createElement("nav").cloneNode(!0).outerHTML,boxModel:"CSS1Compat"===o.compatMode,deleteExpando:!0,noCloneEvent:!0,inlineBlockNeedsLayout:!1,shrinkWrapBlocks:!1,reliableMarginRight:!0,boxSizingReliable:!0,pixelPosition:!1},a.checked=!0,t.noCloneChecked=a.cloneNode(!0).checked,s.disabled=!0,t.optDisabled=!l.disabled;try{delete d.test}catch(h){t.deleteExpando=!1}a=o.createElement("input"),a.setAttribute("value",""),t.input=""===a.getAttribute("value"),a.value="t",a.setAttribute("type","radio"),t.radioValue="t"===a.value,a.setAttribute("checked","t"),a.setAttribute("name","t"),u=o.createDocumentFragment(),u.appendChild(a),t.appendChecked=a.checked,t.checkClone=u.cloneNode(!0).cloneNode(!0).lastChild.checked,d.attachEvent&&(d.attachEvent("onclick",function(){t.noCloneEvent=!1}),d.cloneNode(!0).click());for(f in{submit:!0,change:!0,focusin:!0})d.setAttribute(c="on"+f,"t"),t[f+"Bubbles"]=c in e||d.attributes[c].expando===!1;return d.style.backgroundClip="content-box",d.cloneNode(!0).style.backgroundClip="",t.clearCloneStyle="content-box"===d.style.backgroundClip,b(function(){var n,r,a,s="padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",u=o.getElementsByTagName("body")[0];u&&(n=o.createElement("div"),n.style.cssText="border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px",u.appendChild(n).appendChild(d),d.innerHTML="<table><tr><td></td><td>t</td></tr></table>",a=d.getElementsByTagName("td"),a[0].style.cssText="padding:0;margin:0;border:0;display:none",p=0===a[0].offsetHeight,a[0].style.display="",a[1].style.display="none",t.reliableHiddenOffsets=p&&0===a[0].offsetHeight,d.innerHTML="",d.style.cssText="box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;",t.boxSizing=4===d.offsetWidth,t.doesNotIncludeMarginInBodyOffset=1!==u.offsetTop,e.getComputedStyle&&(t.pixelPosition="1%"!==(e.getComputedStyle(d,null)||{}).top,t.boxSizingReliable="4px"===(e.getComputedStyle(d,null)||{width:"4px"}).width,r=d.appendChild(o.createElement("div")),r.style.cssText=d.style.cssText=s,r.style.marginRight=r.style.width="0",d.style.width="1px",t.reliableMarginRight=!parseFloat((e.getComputedStyle(r,null)||{}).marginRight)),typeof d.style.zoom!==i&&(d.innerHTML="",d.style.cssText=s+"width:1px;padding:1px;display:inline;zoom:1",t.inlineBlockNeedsLayout=3===d.offsetWidth,d.style.display="block",d.innerHTML="<div></div>",d.firstChild.style.width="5px",t.shrinkWrapBlocks=3!==d.offsetWidth,t.inlineBlockNeedsLayout&&(u.style.zoom=1)),u.removeChild(n),n=d=a=r=null)}),n=s=u=l=r=a=null,t}();var O=/(?:\{[\s\S]*\}|\[[\s\S]*\])$/,B=/([A-Z])/g;function P(e,n,r,i){if(b.acceptData(e)){var o,a,s=b.expando,u="string"==typeof n,l=e.nodeType,p=l?b.cache:e,f=l?e[s]:e[s]&&s;if(f&&p[f]&&(i||p[f].data)||!u||r!==t)return f||(l?e[s]=f=c.pop()||b.guid++:f=s),p[f]||(p[f]={},l||(p[f].toJSON=b.noop)),("object"==typeof n||"function"==typeof n)&&(i?p[f]=b.extend(p[f],n):p[f].data=b.extend(p[f].data,n)),o=p[f],i||(o.data||(o.data={}),o=o.data),r!==t&&(o[b.camelCase(n)]=r),u?(a=o[n],null==a&&(a=o[b.camelCase(n)])):a=o,a}}function R(e,t,n){if(b.acceptData(e)){var r,i,o,a=e.nodeType,s=a?b.cache:e,u=a?e[b.expando]:b.expando;if(s[u]){if(t&&(o=n?s[u]:s[u].data)){b.isArray(t)?t=t.concat(b.map(t,b.camelCase)):t in o?t=[t]:(t=b.camelCase(t),t=t in o?[t]:t.split(" "));for(r=0,i=t.length;i>r;r++)delete o[t[r]];if(!(n?$:b.isEmptyObject)(o))return}(n||(delete s[u].data,$(s[u])))&&(a?b.cleanData([e],!0):b.support.deleteExpando||s!=s.window?delete s[u]:s[u]=null)}}}b.extend({cache:{},expando:"jQuery"+(p+Math.random()).replace(/\D/g,""),noData:{embed:!0,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:!0},hasData:function(e){return e=e.nodeType?b.cache[e[b.expando]]:e[b.expando],!!e&&!$(e)},data:function(e,t,n){return P(e,t,n)},removeData:function(e,t){return R(e,t)},_data:function(e,t,n){return P(e,t,n,!0)},_removeData:function(e,t){return R(e,t,!0)},acceptData:function(e){if(e.nodeType&&1!==e.nodeType&&9!==e.nodeType)return!1;var t=e.nodeName&&b.noData[e.nodeName.toLowerCase()];return!t||t!==!0&&e.getAttribute("classid")===t}}),b.fn.extend({data:function(e,n){var r,i,o=this[0],a=0,s=null;if(e===t){if(this.length&&(s=b.data(o),1===o.nodeType&&!b._data(o,"parsedAttrs"))){for(r=o.attributes;r.length>a;a++)i=r[a].name,i.indexOf("data-")||(i=b.camelCase(i.slice(5)),W(o,i,s[i]));b._data(o,"parsedAttrs",!0)}return s}return"object"==typeof e?this.each(function(){b.data(this,e)}):b.access(this,function(n){return n===t?o?W(o,e,b.data(o,e)):null:(this.each(function(){b.data(this,e,n)}),t)},null,n,arguments.length>1,null,!0)},removeData:function(e){return this.each(function(){b.removeData(this,e)})}});function W(e,n,r){if(r===t&&1===e.nodeType){var i="data-"+n.replace(B,"-$1").toLowerCase();if(r=e.getAttribute(i),"string"==typeof r){try{r="true"===r?!0:"false"===r?!1:"null"===r?null:+r+""===r?+r:O.test(r)?b.parseJSON(r):r}catch(o){}b.data(e,n,r)}else r=t}return r}function $(e){var t;for(t in e)if(("data"!==t||!b.isEmptyObject(e[t]))&&"toJSON"!==t)return!1;return!0}b.extend({queue:function(e,n,r){var i;return e?(n=(n||"fx")+"queue",i=b._data(e,n),r&&(!i||b.isArray(r)?i=b._data(e,n,b.makeArray(r)):i.push(r)),i||[]):t},dequeue:function(e,t){t=t||"fx";var n=b.queue(e,t),r=n.length,i=n.shift(),o=b._queueHooks(e,t),a=function(){b.dequeue(e,t)};"inprogress"===i&&(i=n.shift(),r--),o.cur=i,i&&("fx"===t&&n.unshift("inprogress"),delete o.stop,i.call(e,a,o)),!r&&o&&o.empty.fire()},_queueHooks:function(e,t){var n=t+"queueHooks";return b._data(e,n)||b._data(e,n,{empty:b.Callbacks("once memory").add(function(){b._removeData(e,t+"queue"),b._removeData(e,n)})})}}),b.fn.extend({queue:function(e,n){var r=2;return"string"!=typeof e&&(n=e,e="fx",r--),r>arguments.length?b.queue(this[0],e):n===t?this:this.each(function(){var t=b.queue(this,e,n);b._queueHooks(this,e),"fx"===e&&"inprogress"!==t[0]&&b.dequeue(this,e)})},dequeue:function(e){return this.each(function(){b.dequeue(this,e)})},delay:function(e,t){return e=b.fx?b.fx.speeds[e]||e:e,t=t||"fx",this.queue(t,function(t,n){var r=setTimeout(t,e);n.stop=function(){clearTimeout(r)}})},clearQueue:function(e){return this.queue(e||"fx",[])},promise:function(e,n){var r,i=1,o=b.Deferred(),a=this,s=this.length,u=function(){--i||o.resolveWith(a,[a])};"string"!=typeof e&&(n=e,e=t),e=e||"fx";while(s--)r=b._data(a[s],e+"queueHooks"),r&&r.empty&&(i++,r.empty.add(u));return u(),o.promise(n)}});var I,z,X=/[\t\r\n]/g,U=/\r/g,V=/^(?:input|select|textarea|button|object)$/i,Y=/^(?:a|area)$/i,J=/^(?:checked|selected|autofocus|autoplay|async|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped)$/i,G=/^(?:checked|selected)$/i,Q=b.support.getSetAttribute,K=b.support.input;b.fn.extend({attr:function(e,t){return b.access(this,b.attr,e,t,arguments.length>1)},removeAttr:function(e){return this.each(function(){b.removeAttr(this,e)})},prop:function(e,t){return b.access(this,b.prop,e,t,arguments.length>1)},removeProp:function(e){return e=b.propFix[e]||e,this.each(function(){try{this[e]=t,delete this[e]}catch(n){}})},addClass:function(e){var t,n,r,i,o,a=0,s=this.length,u="string"==typeof e&&e;if(b.isFunction(e))return this.each(function(t){b(this).addClass(e.call(this,t,this.className))});if(u)for(t=(e||"").match(w)||[];s>a;a++)if(n=this[a],r=1===n.nodeType&&(n.className?(" "+n.className+" ").replace(X," "):" ")){o=0;while(i=t[o++])0>r.indexOf(" "+i+" ")&&(r+=i+" ");n.className=b.trim(r)}return this},removeClass:function(e){var t,n,r,i,o,a=0,s=this.length,u=0===arguments.length||"string"==typeof e&&e;if(b.isFunction(e))return this.each(function(t){b(this).removeClass(e.call(this,t,this.className))});if(u)for(t=(e||"").match(w)||[];s>a;a++)if(n=this[a],r=1===n.nodeType&&(n.className?(" "+n.className+" ").replace(X," "):"")){o=0;while(i=t[o++])while(r.indexOf(" "+i+" ")>=0)r=r.replace(" "+i+" "," ");n.className=e?b.trim(r):""}return this},toggleClass:function(e,t){var n=typeof e,r="boolean"==typeof t;return b.isFunction(e)?this.each(function(n){b(this).toggleClass(e.call(this,n,this.className,t),t)}):this.each(function(){if("string"===n){var o,a=0,s=b(this),u=t,l=e.match(w)||[];while(o=l[a++])u=r?u:!s.hasClass(o),s[u?"addClass":"removeClass"](o)}else(n===i||"boolean"===n)&&(this.className&&b._data(this,"__className__",this.className),this.className=this.className||e===!1?"":b._data(this,"__className__")||"")})},hasClass:function(e){var t=" "+e+" ",n=0,r=this.length;for(;r>n;n++)if(1===this[n].nodeType&&(" "+this[n].className+" ").replace(X," ").indexOf(t)>=0)return!0;return!1},val:function(e){var n,r,i,o=this[0];{if(arguments.length)return i=b.isFunction(e),this.each(function(n){var o,a=b(this);1===this.nodeType&&(o=i?e.call(this,n,a.val()):e,null==o?o="":"number"==typeof o?o+="":b.isArray(o)&&(o=b.map(o,function(e){return null==e?"":e+""})),r=b.valHooks[this.type]||b.valHooks[this.nodeName.toLowerCase()],r&&"set"in r&&r.set(this,o,"value")!==t||(this.value=o))});if(o)return r=b.valHooks[o.type]||b.valHooks[o.nodeName.toLowerCase()],r&&"get"in r&&(n=r.get(o,"value"))!==t?n:(n=o.value,"string"==typeof n?n.replace(U,""):null==n?"":n)}}}),b.extend({valHooks:{option:{get:function(e){var t=e.attributes.value;return!t||t.specified?e.value:e.text}},select:{get:function(e){var t,n,r=e.options,i=e.selectedIndex,o="select-one"===e.type||0>i,a=o?null:[],s=o?i+1:r.length,u=0>i?s:o?i:0;for(;s>u;u++)if(n=r[u],!(!n.selected&&u!==i||(b.support.optDisabled?n.disabled:null!==n.getAttribute("disabled"))||n.parentNode.disabled&&b.nodeName(n.parentNode,"optgroup"))){if(t=b(n).val(),o)return t;a.push(t)}return a},set:function(e,t){var n=b.makeArray(t);return b(e).find("option").each(function(){this.selected=b.inArray(b(this).val(),n)>=0}),n.length||(e.selectedIndex=-1),n}}},attr:function(e,n,r){var o,a,s,u=e.nodeType;if(e&&3!==u&&8!==u&&2!==u)return typeof e.getAttribute===i?b.prop(e,n,r):(a=1!==u||!b.isXMLDoc(e),a&&(n=n.toLowerCase(),o=b.attrHooks[n]||(J.test(n)?z:I)),r===t?o&&a&&"get"in o&&null!==(s=o.get(e,n))?s:(typeof e.getAttribute!==i&&(s=e.getAttribute(n)),null==s?t:s):null!==r?o&&a&&"set"in o&&(s=o.set(e,r,n))!==t?s:(e.setAttribute(n,r+""),r):(b.removeAttr(e,n),t))},removeAttr:function(e,t){var n,r,i=0,o=t&&t.match(w);if(o&&1===e.nodeType)while(n=o[i++])r=b.propFix[n]||n,J.test(n)?!Q&&G.test(n)?e[b.camelCase("default-"+n)]=e[r]=!1:e[r]=!1:b.attr(e,n,""),e.removeAttribute(Q?n:r)},attrHooks:{type:{set:function(e,t){if(!b.support.radioValue&&"radio"===t&&b.nodeName(e,"input")){var n=e.value;return e.setAttribute("type",t),n&&(e.value=n),t}}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(e,n,r){var i,o,a,s=e.nodeType;if(e&&3!==s&&8!==s&&2!==s)return a=1!==s||!b.isXMLDoc(e),a&&(n=b.propFix[n]||n,o=b.propHooks[n]),r!==t?o&&"set"in o&&(i=o.set(e,r,n))!==t?i:e[n]=r:o&&"get"in o&&null!==(i=o.get(e,n))?i:e[n]},propHooks:{tabIndex:{get:function(e){var n=e.getAttributeNode("tabindex");return n&&n.specified?parseInt(n.value,10):V.test(e.nodeName)||Y.test(e.nodeName)&&e.href?0:t}}}}),z={get:function(e,n){var r=b.prop(e,n),i="boolean"==typeof r&&e.getAttribute(n),o="boolean"==typeof r?K&&Q?null!=i:G.test(n)?e[b.camelCase("default-"+n)]:!!i:e.getAttributeNode(n);return o&&o.value!==!1?n.toLowerCase():t},set:function(e,t,n){return t===!1?b.removeAttr(e,n):K&&Q||!G.test(n)?e.setAttribute(!Q&&b.propFix[n]||n,n):e[b.camelCase("default-"+n)]=e[n]=!0,n}},K&&Q||(b.attrHooks.value={get:function(e,n){var r=e.getAttributeNode(n);return b.nodeName(e,"input")?e.defaultValue:r&&r.specified?r.value:t},set:function(e,n,r){return b.nodeName(e,"input")?(e.defaultValue=n,t):I&&I.set(e,n,r)}}),Q||(I=b.valHooks.button={get:function(e,n){var r=e.getAttributeNode(n);return r&&("id"===n||"name"===n||"coords"===n?""!==r.value:r.specified)?r.value:t},set:function(e,n,r){var i=e.getAttributeNode(r);return i||e.setAttributeNode(i=e.ownerDocument.createAttribute(r)),i.value=n+="","value"===r||n===e.getAttribute(r)?n:t}},b.attrHooks.contenteditable={get:I.get,set:function(e,t,n){I.set(e,""===t?!1:t,n)}},b.each(["width","height"],function(e,n){b.attrHooks[n]=b.extend(b.attrHooks[n],{set:function(e,r){return""===r?(e.setAttribute(n,"auto"),r):t}})})),b.support.hrefNormalized||(b.each(["href","src","width","height"],function(e,n){b.attrHooks[n]=b.extend(b.attrHooks[n],{get:function(e){var r=e.getAttribute(n,2);return null==r?t:r}})}),b.each(["href","src"],function(e,t){b.propHooks[t]={get:function(e){return e.getAttribute(t,4)}}})),b.support.style||(b.attrHooks.style={get:function(e){return e.style.cssText||t},set:function(e,t){return e.style.cssText=t+""}}),b.support.optSelected||(b.propHooks.selected=b.extend(b.propHooks.selected,{get:function(e){var t=e.parentNode;return t&&(t.selectedIndex,t.parentNode&&t.parentNode.selectedIndex),null}})),b.support.enctype||(b.propFix.enctype="encoding"),b.support.checkOn||b.each(["radio","checkbox"],function(){b.valHooks[this]={get:function(e){return null===e.getAttribute("value")?"on":e.value}}}),b.each(["radio","checkbox"],function(){b.valHooks[this]=b.extend(b.valHooks[this],{set:function(e,n){return b.isArray(n)?e.checked=b.inArray(b(e).val(),n)>=0:t}})});var Z=/^(?:input|select|textarea)$/i,et=/^key/,tt=/^(?:mouse|contextmenu)|click/,nt=/^(?:focusinfocus|focusoutblur)$/,rt=/^([^.]*)(?:\.(.+)|)$/;function it(){return!0}function ot(){return!1}b.event={global:{},add:function(e,n,r,o,a){var s,u,l,c,p,f,d,h,g,m,y,v=b._data(e);if(v){r.handler&&(c=r,r=c.handler,a=c.selector),r.guid||(r.guid=b.guid++),(u=v.events)||(u=v.events={}),(f=v.handle)||(f=v.handle=function(e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)},f.elem=e),n=(n||"").match(w)||[""],l=n.length;while(l--)s=rt.exec(n[l])||[],g=y=s[1],m=(s[2]||"").split(".").sort(),p=b.event.special[g]||{},g=(a?p.delegateType:p.bindType)||g,p=b.event.special[g]||{},d=b.extend({type:g,origType:y,data:o,handler:r,guid:r.guid,selector:a,needsContext:a&&b.expr.match.needsContext.test(a),namespace:m.join(".")},c),(h=u[g])||(h=u[g]=[],h.delegateCount=0,p.setup&&p.setup.call(e,o,m,f)!==!1||(e.addEventListener?e.addEventListener(g,f,!1):e.attachEvent&&e.attachEvent("on"+g,f))),p.add&&(p.add.call(e,d),d.handler.guid||(d.handler.guid=r.guid)),a?h.splice(h.delegateCount++,0,d):h.push(d),b.event.global[g]=!0;e=null}},remove:function(e,t,n,r,i){var o,a,s,u,l,c,p,f,d,h,g,m=b.hasData(e)&&b._data(e);if(m&&(c=m.events)){t=(t||"").match(w)||[""],l=t.length;while(l--)if(s=rt.exec(t[l])||[],d=g=s[1],h=(s[2]||"").split(".").sort(),d){p=b.event.special[d]||{},d=(r?p.delegateType:p.bindType)||d,f=c[d]||[],s=s[2]&&RegExp("(^|\\.)"+h.join("\\.(?:.*\\.|)")+"(\\.|$)"),u=o=f.length;while(o--)a=f[o],!i&&g!==a.origType||n&&n.guid!==a.guid||s&&!s.test(a.namespace)||r&&r!==a.selector&&("**"!==r||!a.selector)||(f.splice(o,1),a.selector&&f.delegateCount--,p.remove&&p.remove.call(e,a));u&&!f.length&&(p.teardown&&p.teardown.call(e,h,m.handle)!==!1||b.removeEvent(e,d,m.handle),delete c[d])}else for(d in c)b.event.remove(e,d+t[l],n,r,!0);b.isEmptyObject(c)&&(delete m.handle,b._removeData(e,"events"))}},trigger:function(n,r,i,a){var s,u,l,c,p,f,d,h=[i||o],g=y.call(n,"type")?n.type:n,m=y.call(n,"namespace")?n.namespace.split("."):[];if(l=f=i=i||o,3!==i.nodeType&&8!==i.nodeType&&!nt.test(g+b.event.triggered)&&(g.indexOf(".")>=0&&(m=g.split("."),g=m.shift(),m.sort()),u=0>g.indexOf(":")&&"on"+g,n=n[b.expando]?n:new b.Event(g,"object"==typeof n&&n),n.isTrigger=!0,n.namespace=m.join("."),n.namespace_re=n.namespace?RegExp("(^|\\.)"+m.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,n.result=t,n.target||(n.target=i),r=null==r?[n]:b.makeArray(r,[n]),p=b.event.special[g]||{},a||!p.trigger||p.trigger.apply(i,r)!==!1)){if(!a&&!p.noBubble&&!b.isWindow(i)){for(c=p.delegateType||g,nt.test(c+g)||(l=l.parentNode);l;l=l.parentNode)h.push(l),f=l;f===(i.ownerDocument||o)&&h.push(f.defaultView||f.parentWindow||e)}d=0;while((l=h[d++])&&!n.isPropagationStopped())n.type=d>1?c:p.bindType||g,s=(b._data(l,"events")||{})[n.type]&&b._data(l,"handle"),s&&s.apply(l,r),s=u&&l[u],s&&b.acceptData(l)&&s.apply&&s.apply(l,r)===!1&&n.preventDefault();if(n.type=g,!(a||n.isDefaultPrevented()||p._default&&p._default.apply(i.ownerDocument,r)!==!1||"click"===g&&b.nodeName(i,"a")||!b.acceptData(i)||!u||!i[g]||b.isWindow(i))){f=i[u],f&&(i[u]=null),b.event.triggered=g;try{i[g]()}catch(v){}b.event.triggered=t,f&&(i[u]=f)}return n.result}},dispatch:function(e){e=b.event.fix(e);var n,r,i,o,a,s=[],u=h.call(arguments),l=(b._data(this,"events")||{})[e.type]||[],c=b.event.special[e.type]||{};if(u[0]=e,e.delegateTarget=this,!c.preDispatch||c.preDispatch.call(this,e)!==!1){s=b.event.handlers.call(this,e,l),n=0;while((o=s[n++])&&!e.isPropagationStopped()){e.currentTarget=o.elem,a=0;while((i=o.handlers[a++])&&!e.isImmediatePropagationStopped())(!e.namespace_re||e.namespace_re.test(i.namespace))&&(e.handleObj=i,e.data=i.data,r=((b.event.special[i.origType]||{}).handle||i.handler).apply(o.elem,u),r!==t&&(e.result=r)===!1&&(e.preventDefault(),e.stopPropagation()))}return c.postDispatch&&c.postDispatch.call(this,e),e.result}},handlers:function(e,n){var r,i,o,a,s=[],u=n.delegateCount,l=e.target;if(u&&l.nodeType&&(!e.button||"click"!==e.type))for(;l!=this;l=l.parentNode||this)if(1===l.nodeType&&(l.disabled!==!0||"click"!==e.type)){for(o=[],a=0;u>a;a++)i=n[a],r=i.selector+" ",o[r]===t&&(o[r]=i.needsContext?b(r,this).index(l)>=0:b.find(r,this,null,[l]).length),o[r]&&o.push(i);o.length&&s.push({elem:l,handlers:o})}return n.length>u&&s.push({elem:this,handlers:n.slice(u)}),s},fix:function(e){if(e[b.expando])return e;var t,n,r,i=e.type,a=e,s=this.fixHooks[i];s||(this.fixHooks[i]=s=tt.test(i)?this.mouseHooks:et.test(i)?this.keyHooks:{}),r=s.props?this.props.concat(s.props):this.props,e=new b.Event(a),t=r.length;while(t--)n=r[t],e[n]=a[n];return e.target||(e.target=a.srcElement||o),3===e.target.nodeType&&(e.target=e.target.parentNode),e.metaKey=!!e.metaKey,s.filter?s.filter(e,a):e},props:"altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(e,t){return null==e.which&&(e.which=null!=t.charCode?t.charCode:t.keyCode),e}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(e,n){var r,i,a,s=n.button,u=n.fromElement;return null==e.pageX&&null!=n.clientX&&(i=e.target.ownerDocument||o,a=i.documentElement,r=i.body,e.pageX=n.clientX+(a&&a.scrollLeft||r&&r.scrollLeft||0)-(a&&a.clientLeft||r&&r.clientLeft||0),e.pageY=n.clientY+(a&&a.scrollTop||r&&r.scrollTop||0)-(a&&a.clientTop||r&&r.clientTop||0)),!e.relatedTarget&&u&&(e.relatedTarget=u===e.target?n.toElement:u),e.which||s===t||(e.which=1&s?1:2&s?3:4&s?2:0),e}},special:{load:{noBubble:!0},click:{trigger:function(){return b.nodeName(this,"input")&&"checkbox"===this.type&&this.click?(this.click(),!1):t}},focus:{trigger:function(){if(this!==o.activeElement&&this.focus)try{return this.focus(),!1}catch(e){}},delegateType:"focusin"},blur:{trigger:function(){return this===o.activeElement&&this.blur?(this.blur(),!1):t},delegateType:"focusout"},beforeunload:{postDispatch:function(e){e.result!==t&&(e.originalEvent.returnValue=e.result)}}},simulate:function(e,t,n,r){var i=b.extend(new b.Event,n,{type:e,isSimulated:!0,originalEvent:{}});r?b.event.trigger(i,null,t):b.event.dispatch.call(t,i),i.isDefaultPrevented()&&n.preventDefault()}},b.removeEvent=o.removeEventListener?function(e,t,n){e.removeEventListener&&e.removeEventListener(t,n,!1)}:function(e,t,n){var r="on"+t;e.detachEvent&&(typeof e[r]===i&&(e[r]=null),e.detachEvent(r,n))},b.Event=function(e,n){return this instanceof b.Event?(e&&e.type?(this.originalEvent=e,this.type=e.type,this.isDefaultPrevented=e.defaultPrevented||e.returnValue===!1||e.getPreventDefault&&e.getPreventDefault()?it:ot):this.type=e,n&&b.extend(this,n),this.timeStamp=e&&e.timeStamp||b.now(),this[b.expando]=!0,t):new b.Event(e,n)},b.Event.prototype={isDefaultPrevented:ot,isPropagationStopped:ot,isImmediatePropagationStopped:ot,preventDefault:function(){var e=this.originalEvent;this.isDefaultPrevented=it,e&&(e.preventDefault?e.preventDefault():e.returnValue=!1)},stopPropagation:function(){var e=this.originalEvent;this.isPropagationStopped=it,e&&(e.stopPropagation&&e.stopPropagation(),e.cancelBubble=!0)},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=it,this.stopPropagation()}},b.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(e,t){b.event.special[e]={delegateType:t,bindType:t,handle:function(e){var n,r=this,i=e.relatedTarget,o=e.handleObj;
return(!i||i!==r&&!b.contains(r,i))&&(e.type=o.origType,n=o.handler.apply(this,arguments),e.type=t),n}}}),b.support.submitBubbles||(b.event.special.submit={setup:function(){return b.nodeName(this,"form")?!1:(b.event.add(this,"click._submit keypress._submit",function(e){var n=e.target,r=b.nodeName(n,"input")||b.nodeName(n,"button")?n.form:t;r&&!b._data(r,"submitBubbles")&&(b.event.add(r,"submit._submit",function(e){e._submit_bubble=!0}),b._data(r,"submitBubbles",!0))}),t)},postDispatch:function(e){e._submit_bubble&&(delete e._submit_bubble,this.parentNode&&!e.isTrigger&&b.event.simulate("submit",this.parentNode,e,!0))},teardown:function(){return b.nodeName(this,"form")?!1:(b.event.remove(this,"._submit"),t)}}),b.support.changeBubbles||(b.event.special.change={setup:function(){return Z.test(this.nodeName)?(("checkbox"===this.type||"radio"===this.type)&&(b.event.add(this,"propertychange._change",function(e){"checked"===e.originalEvent.propertyName&&(this._just_changed=!0)}),b.event.add(this,"click._change",function(e){this._just_changed&&!e.isTrigger&&(this._just_changed=!1),b.event.simulate("change",this,e,!0)})),!1):(b.event.add(this,"beforeactivate._change",function(e){var t=e.target;Z.test(t.nodeName)&&!b._data(t,"changeBubbles")&&(b.event.add(t,"change._change",function(e){!this.parentNode||e.isSimulated||e.isTrigger||b.event.simulate("change",this.parentNode,e,!0)}),b._data(t,"changeBubbles",!0))}),t)},handle:function(e){var n=e.target;return this!==n||e.isSimulated||e.isTrigger||"radio"!==n.type&&"checkbox"!==n.type?e.handleObj.handler.apply(this,arguments):t},teardown:function(){return b.event.remove(this,"._change"),!Z.test(this.nodeName)}}),b.support.focusinBubbles||b.each({focus:"focusin",blur:"focusout"},function(e,t){var n=0,r=function(e){b.event.simulate(t,e.target,b.event.fix(e),!0)};b.event.special[t]={setup:function(){0===n++&&o.addEventListener(e,r,!0)},teardown:function(){0===--n&&o.removeEventListener(e,r,!0)}}}),b.fn.extend({on:function(e,n,r,i,o){var a,s;if("object"==typeof e){"string"!=typeof n&&(r=r||n,n=t);for(a in e)this.on(a,n,r,e[a],o);return this}if(null==r&&null==i?(i=n,r=n=t):null==i&&("string"==typeof n?(i=r,r=t):(i=r,r=n,n=t)),i===!1)i=ot;else if(!i)return this;return 1===o&&(s=i,i=function(e){return b().off(e),s.apply(this,arguments)},i.guid=s.guid||(s.guid=b.guid++)),this.each(function(){b.event.add(this,e,i,r,n)})},one:function(e,t,n,r){return this.on(e,t,n,r,1)},off:function(e,n,r){var i,o;if(e&&e.preventDefault&&e.handleObj)return i=e.handleObj,b(e.delegateTarget).off(i.namespace?i.origType+"."+i.namespace:i.origType,i.selector,i.handler),this;if("object"==typeof e){for(o in e)this.off(o,n,e[o]);return this}return(n===!1||"function"==typeof n)&&(r=n,n=t),r===!1&&(r=ot),this.each(function(){b.event.remove(this,e,r,n)})},bind:function(e,t,n){return this.on(e,null,t,n)},unbind:function(e,t){return this.off(e,null,t)},delegate:function(e,t,n,r){return this.on(t,e,n,r)},undelegate:function(e,t,n){return 1===arguments.length?this.off(e,"**"):this.off(t,e||"**",n)},trigger:function(e,t){return this.each(function(){b.event.trigger(e,t,this)})},triggerHandler:function(e,n){var r=this[0];return r?b.event.trigger(e,n,r,!0):t}}),function(e,t){var n,r,i,o,a,s,u,l,c,p,f,d,h,g,m,y,v,x="sizzle"+-new Date,w=e.document,T={},N=0,C=0,k=it(),E=it(),S=it(),A=typeof t,j=1<<31,D=[],L=D.pop,H=D.push,q=D.slice,M=D.indexOf||function(e){var t=0,n=this.length;for(;n>t;t++)if(this[t]===e)return t;return-1},_="[\\x20\\t\\r\\n\\f]",F="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",O=F.replace("w","w#"),B="([*^$|!~]?=)",P="\\["+_+"*("+F+")"+_+"*(?:"+B+_+"*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|("+O+")|)|)"+_+"*\\]",R=":("+F+")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|"+P.replace(3,8)+")*)|.*)\\)|)",W=RegExp("^"+_+"+|((?:^|[^\\\\])(?:\\\\.)*)"+_+"+$","g"),$=RegExp("^"+_+"*,"+_+"*"),I=RegExp("^"+_+"*([\\x20\\t\\r\\n\\f>+~])"+_+"*"),z=RegExp(R),X=RegExp("^"+O+"$"),U={ID:RegExp("^#("+F+")"),CLASS:RegExp("^\\.("+F+")"),NAME:RegExp("^\\[name=['\"]?("+F+")['\"]?\\]"),TAG:RegExp("^("+F.replace("w","w*")+")"),ATTR:RegExp("^"+P),PSEUDO:RegExp("^"+R),CHILD:RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+_+"*(even|odd|(([+-]|)(\\d*)n|)"+_+"*(?:([+-]|)"+_+"*(\\d+)|))"+_+"*\\)|)","i"),needsContext:RegExp("^"+_+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+_+"*((?:-\\d)?\\d*)"+_+"*\\)|)(?=[^-]|$)","i")},V=/[\x20\t\r\n\f]*[+~]/,Y=/^[^{]+\{\s*\[native code/,J=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,G=/^(?:input|select|textarea|button)$/i,Q=/^h\d$/i,K=/'|\\/g,Z=/\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,et=/\\([\da-fA-F]{1,6}[\x20\t\r\n\f]?|.)/g,tt=function(e,t){var n="0x"+t-65536;return n!==n?t:0>n?String.fromCharCode(n+65536):String.fromCharCode(55296|n>>10,56320|1023&n)};try{q.call(w.documentElement.childNodes,0)[0].nodeType}catch(nt){q=function(e){var t,n=[];while(t=this[e++])n.push(t);return n}}function rt(e){return Y.test(e+"")}function it(){var e,t=[];return e=function(n,r){return t.push(n+=" ")>i.cacheLength&&delete e[t.shift()],e[n]=r}}function ot(e){return e[x]=!0,e}function at(e){var t=p.createElement("div");try{return e(t)}catch(n){return!1}finally{t=null}}function st(e,t,n,r){var i,o,a,s,u,l,f,g,m,v;if((t?t.ownerDocument||t:w)!==p&&c(t),t=t||p,n=n||[],!e||"string"!=typeof e)return n;if(1!==(s=t.nodeType)&&9!==s)return[];if(!d&&!r){if(i=J.exec(e))if(a=i[1]){if(9===s){if(o=t.getElementById(a),!o||!o.parentNode)return n;if(o.id===a)return n.push(o),n}else if(t.ownerDocument&&(o=t.ownerDocument.getElementById(a))&&y(t,o)&&o.id===a)return n.push(o),n}else{if(i[2])return H.apply(n,q.call(t.getElementsByTagName(e),0)),n;if((a=i[3])&&T.getByClassName&&t.getElementsByClassName)return H.apply(n,q.call(t.getElementsByClassName(a),0)),n}if(T.qsa&&!h.test(e)){if(f=!0,g=x,m=t,v=9===s&&e,1===s&&"object"!==t.nodeName.toLowerCase()){l=ft(e),(f=t.getAttribute("id"))?g=f.replace(K,"\\$&"):t.setAttribute("id",g),g="[id='"+g+"'] ",u=l.length;while(u--)l[u]=g+dt(l[u]);m=V.test(e)&&t.parentNode||t,v=l.join(",")}if(v)try{return H.apply(n,q.call(m.querySelectorAll(v),0)),n}catch(b){}finally{f||t.removeAttribute("id")}}}return wt(e.replace(W,"$1"),t,n,r)}a=st.isXML=function(e){var t=e&&(e.ownerDocument||e).documentElement;return t?"HTML"!==t.nodeName:!1},c=st.setDocument=function(e){var n=e?e.ownerDocument||e:w;return n!==p&&9===n.nodeType&&n.documentElement?(p=n,f=n.documentElement,d=a(n),T.tagNameNoComments=at(function(e){return e.appendChild(n.createComment("")),!e.getElementsByTagName("*").length}),T.attributes=at(function(e){e.innerHTML="<select></select>";var t=typeof e.lastChild.getAttribute("multiple");return"boolean"!==t&&"string"!==t}),T.getByClassName=at(function(e){return e.innerHTML="<div class='hidden e'></div><div class='hidden'></div>",e.getElementsByClassName&&e.getElementsByClassName("e").length?(e.lastChild.className="e",2===e.getElementsByClassName("e").length):!1}),T.getByName=at(function(e){e.id=x+0,e.innerHTML="<a name='"+x+"'></a><div name='"+x+"'></div>",f.insertBefore(e,f.firstChild);var t=n.getElementsByName&&n.getElementsByName(x).length===2+n.getElementsByName(x+0).length;return T.getIdNotName=!n.getElementById(x),f.removeChild(e),t}),i.attrHandle=at(function(e){return e.innerHTML="<a href='#'></a>",e.firstChild&&typeof e.firstChild.getAttribute!==A&&"#"===e.firstChild.getAttribute("href")})?{}:{href:function(e){return e.getAttribute("href",2)},type:function(e){return e.getAttribute("type")}},T.getIdNotName?(i.find.ID=function(e,t){if(typeof t.getElementById!==A&&!d){var n=t.getElementById(e);return n&&n.parentNode?[n]:[]}},i.filter.ID=function(e){var t=e.replace(et,tt);return function(e){return e.getAttribute("id")===t}}):(i.find.ID=function(e,n){if(typeof n.getElementById!==A&&!d){var r=n.getElementById(e);return r?r.id===e||typeof r.getAttributeNode!==A&&r.getAttributeNode("id").value===e?[r]:t:[]}},i.filter.ID=function(e){var t=e.replace(et,tt);return function(e){var n=typeof e.getAttributeNode!==A&&e.getAttributeNode("id");return n&&n.value===t}}),i.find.TAG=T.tagNameNoComments?function(e,n){return typeof n.getElementsByTagName!==A?n.getElementsByTagName(e):t}:function(e,t){var n,r=[],i=0,o=t.getElementsByTagName(e);if("*"===e){while(n=o[i++])1===n.nodeType&&r.push(n);return r}return o},i.find.NAME=T.getByName&&function(e,n){return typeof n.getElementsByName!==A?n.getElementsByName(name):t},i.find.CLASS=T.getByClassName&&function(e,n){return typeof n.getElementsByClassName===A||d?t:n.getElementsByClassName(e)},g=[],h=[":focus"],(T.qsa=rt(n.querySelectorAll))&&(at(function(e){e.innerHTML="<select><option selected=''></option></select>",e.querySelectorAll("[selected]").length||h.push("\\["+_+"*(?:checked|disabled|ismap|multiple|readonly|selected|value)"),e.querySelectorAll(":checked").length||h.push(":checked")}),at(function(e){e.innerHTML="<input type='hidden' i=''/>",e.querySelectorAll("[i^='']").length&&h.push("[*^$]="+_+"*(?:\"\"|'')"),e.querySelectorAll(":enabled").length||h.push(":enabled",":disabled"),e.querySelectorAll("*,:x"),h.push(",.*:")})),(T.matchesSelector=rt(m=f.matchesSelector||f.mozMatchesSelector||f.webkitMatchesSelector||f.oMatchesSelector||f.msMatchesSelector))&&at(function(e){T.disconnectedMatch=m.call(e,"div"),m.call(e,"[s!='']:x"),g.push("!=",R)}),h=RegExp(h.join("|")),g=RegExp(g.join("|")),y=rt(f.contains)||f.compareDocumentPosition?function(e,t){var n=9===e.nodeType?e.documentElement:e,r=t&&t.parentNode;return e===r||!(!r||1!==r.nodeType||!(n.contains?n.contains(r):e.compareDocumentPosition&&16&e.compareDocumentPosition(r)))}:function(e,t){if(t)while(t=t.parentNode)if(t===e)return!0;return!1},v=f.compareDocumentPosition?function(e,t){var r;return e===t?(u=!0,0):(r=t.compareDocumentPosition&&e.compareDocumentPosition&&e.compareDocumentPosition(t))?1&r||e.parentNode&&11===e.parentNode.nodeType?e===n||y(w,e)?-1:t===n||y(w,t)?1:0:4&r?-1:1:e.compareDocumentPosition?-1:1}:function(e,t){var r,i=0,o=e.parentNode,a=t.parentNode,s=[e],l=[t];if(e===t)return u=!0,0;if(!o||!a)return e===n?-1:t===n?1:o?-1:a?1:0;if(o===a)return ut(e,t);r=e;while(r=r.parentNode)s.unshift(r);r=t;while(r=r.parentNode)l.unshift(r);while(s[i]===l[i])i++;return i?ut(s[i],l[i]):s[i]===w?-1:l[i]===w?1:0},u=!1,[0,0].sort(v),T.detectDuplicates=u,p):p},st.matches=function(e,t){return st(e,null,null,t)},st.matchesSelector=function(e,t){if((e.ownerDocument||e)!==p&&c(e),t=t.replace(Z,"='$1']"),!(!T.matchesSelector||d||g&&g.test(t)||h.test(t)))try{var n=m.call(e,t);if(n||T.disconnectedMatch||e.document&&11!==e.document.nodeType)return n}catch(r){}return st(t,p,null,[e]).length>0},st.contains=function(e,t){return(e.ownerDocument||e)!==p&&c(e),y(e,t)},st.attr=function(e,t){var n;return(e.ownerDocument||e)!==p&&c(e),d||(t=t.toLowerCase()),(n=i.attrHandle[t])?n(e):d||T.attributes?e.getAttribute(t):((n=e.getAttributeNode(t))||e.getAttribute(t))&&e[t]===!0?t:n&&n.specified?n.value:null},st.error=function(e){throw Error("Syntax error, unrecognized expression: "+e)},st.uniqueSort=function(e){var t,n=[],r=1,i=0;if(u=!T.detectDuplicates,e.sort(v),u){for(;t=e[r];r++)t===e[r-1]&&(i=n.push(r));while(i--)e.splice(n[i],1)}return e};function ut(e,t){var n=t&&e,r=n&&(~t.sourceIndex||j)-(~e.sourceIndex||j);if(r)return r;if(n)while(n=n.nextSibling)if(n===t)return-1;return e?1:-1}function lt(e){return function(t){var n=t.nodeName.toLowerCase();return"input"===n&&t.type===e}}function ct(e){return function(t){var n=t.nodeName.toLowerCase();return("input"===n||"button"===n)&&t.type===e}}function pt(e){return ot(function(t){return t=+t,ot(function(n,r){var i,o=e([],n.length,t),a=o.length;while(a--)n[i=o[a]]&&(n[i]=!(r[i]=n[i]))})})}o=st.getText=function(e){var t,n="",r=0,i=e.nodeType;if(i){if(1===i||9===i||11===i){if("string"==typeof e.textContent)return e.textContent;for(e=e.firstChild;e;e=e.nextSibling)n+=o(e)}else if(3===i||4===i)return e.nodeValue}else for(;t=e[r];r++)n+=o(t);return n},i=st.selectors={cacheLength:50,createPseudo:ot,match:U,find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(e){return e[1]=e[1].replace(et,tt),e[3]=(e[4]||e[5]||"").replace(et,tt),"~="===e[2]&&(e[3]=" "+e[3]+" "),e.slice(0,4)},CHILD:function(e){return e[1]=e[1].toLowerCase(),"nth"===e[1].slice(0,3)?(e[3]||st.error(e[0]),e[4]=+(e[4]?e[5]+(e[6]||1):2*("even"===e[3]||"odd"===e[3])),e[5]=+(e[7]+e[8]||"odd"===e[3])):e[3]&&st.error(e[0]),e},PSEUDO:function(e){var t,n=!e[5]&&e[2];return U.CHILD.test(e[0])?null:(e[4]?e[2]=e[4]:n&&z.test(n)&&(t=ft(n,!0))&&(t=n.indexOf(")",n.length-t)-n.length)&&(e[0]=e[0].slice(0,t),e[2]=n.slice(0,t)),e.slice(0,3))}},filter:{TAG:function(e){return"*"===e?function(){return!0}:(e=e.replace(et,tt).toLowerCase(),function(t){return t.nodeName&&t.nodeName.toLowerCase()===e})},CLASS:function(e){var t=k[e+" "];return t||(t=RegExp("(^|"+_+")"+e+"("+_+"|$)"))&&k(e,function(e){return t.test(e.className||typeof e.getAttribute!==A&&e.getAttribute("class")||"")})},ATTR:function(e,t,n){return function(r){var i=st.attr(r,e);return null==i?"!="===t:t?(i+="","="===t?i===n:"!="===t?i!==n:"^="===t?n&&0===i.indexOf(n):"*="===t?n&&i.indexOf(n)>-1:"$="===t?n&&i.slice(-n.length)===n:"~="===t?(" "+i+" ").indexOf(n)>-1:"|="===t?i===n||i.slice(0,n.length+1)===n+"-":!1):!0}},CHILD:function(e,t,n,r,i){var o="nth"!==e.slice(0,3),a="last"!==e.slice(-4),s="of-type"===t;return 1===r&&0===i?function(e){return!!e.parentNode}:function(t,n,u){var l,c,p,f,d,h,g=o!==a?"nextSibling":"previousSibling",m=t.parentNode,y=s&&t.nodeName.toLowerCase(),v=!u&&!s;if(m){if(o){while(g){p=t;while(p=p[g])if(s?p.nodeName.toLowerCase()===y:1===p.nodeType)return!1;h=g="only"===e&&!h&&"nextSibling"}return!0}if(h=[a?m.firstChild:m.lastChild],a&&v){c=m[x]||(m[x]={}),l=c[e]||[],d=l[0]===N&&l[1],f=l[0]===N&&l[2],p=d&&m.childNodes[d];while(p=++d&&p&&p[g]||(f=d=0)||h.pop())if(1===p.nodeType&&++f&&p===t){c[e]=[N,d,f];break}}else if(v&&(l=(t[x]||(t[x]={}))[e])&&l[0]===N)f=l[1];else while(p=++d&&p&&p[g]||(f=d=0)||h.pop())if((s?p.nodeName.toLowerCase()===y:1===p.nodeType)&&++f&&(v&&((p[x]||(p[x]={}))[e]=[N,f]),p===t))break;return f-=i,f===r||0===f%r&&f/r>=0}}},PSEUDO:function(e,t){var n,r=i.pseudos[e]||i.setFilters[e.toLowerCase()]||st.error("unsupported pseudo: "+e);return r[x]?r(t):r.length>1?(n=[e,e,"",t],i.setFilters.hasOwnProperty(e.toLowerCase())?ot(function(e,n){var i,o=r(e,t),a=o.length;while(a--)i=M.call(e,o[a]),e[i]=!(n[i]=o[a])}):function(e){return r(e,0,n)}):r}},pseudos:{not:ot(function(e){var t=[],n=[],r=s(e.replace(W,"$1"));return r[x]?ot(function(e,t,n,i){var o,a=r(e,null,i,[]),s=e.length;while(s--)(o=a[s])&&(e[s]=!(t[s]=o))}):function(e,i,o){return t[0]=e,r(t,null,o,n),!n.pop()}}),has:ot(function(e){return function(t){return st(e,t).length>0}}),contains:ot(function(e){return function(t){return(t.textContent||t.innerText||o(t)).indexOf(e)>-1}}),lang:ot(function(e){return X.test(e||"")||st.error("unsupported lang: "+e),e=e.replace(et,tt).toLowerCase(),function(t){var n;do if(n=d?t.getAttribute("xml:lang")||t.getAttribute("lang"):t.lang)return n=n.toLowerCase(),n===e||0===n.indexOf(e+"-");while((t=t.parentNode)&&1===t.nodeType);return!1}}),target:function(t){var n=e.location&&e.location.hash;return n&&n.slice(1)===t.id},root:function(e){return e===f},focus:function(e){return e===p.activeElement&&(!p.hasFocus||p.hasFocus())&&!!(e.type||e.href||~e.tabIndex)},enabled:function(e){return e.disabled===!1},disabled:function(e){return e.disabled===!0},checked:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&!!e.checked||"option"===t&&!!e.selected},selected:function(e){return e.parentNode&&e.parentNode.selectedIndex,e.selected===!0},empty:function(e){for(e=e.firstChild;e;e=e.nextSibling)if(e.nodeName>"@"||3===e.nodeType||4===e.nodeType)return!1;return!0},parent:function(e){return!i.pseudos.empty(e)},header:function(e){return Q.test(e.nodeName)},input:function(e){return G.test(e.nodeName)},button:function(e){var t=e.nodeName.toLowerCase();return"input"===t&&"button"===e.type||"button"===t},text:function(e){var t;return"input"===e.nodeName.toLowerCase()&&"text"===e.type&&(null==(t=e.getAttribute("type"))||t.toLowerCase()===e.type)},first:pt(function(){return[0]}),last:pt(function(e,t){return[t-1]}),eq:pt(function(e,t,n){return[0>n?n+t:n]}),even:pt(function(e,t){var n=0;for(;t>n;n+=2)e.push(n);return e}),odd:pt(function(e,t){var n=1;for(;t>n;n+=2)e.push(n);return e}),lt:pt(function(e,t,n){var r=0>n?n+t:n;for(;--r>=0;)e.push(r);return e}),gt:pt(function(e,t,n){var r=0>n?n+t:n;for(;t>++r;)e.push(r);return e})}};for(n in{radio:!0,checkbox:!0,file:!0,password:!0,image:!0})i.pseudos[n]=lt(n);for(n in{submit:!0,reset:!0})i.pseudos[n]=ct(n);function ft(e,t){var n,r,o,a,s,u,l,c=E[e+" "];if(c)return t?0:c.slice(0);s=e,u=[],l=i.preFilter;while(s){(!n||(r=$.exec(s)))&&(r&&(s=s.slice(r[0].length)||s),u.push(o=[])),n=!1,(r=I.exec(s))&&(n=r.shift(),o.push({value:n,type:r[0].replace(W," ")}),s=s.slice(n.length));for(a in i.filter)!(r=U[a].exec(s))||l[a]&&!(r=l[a](r))||(n=r.shift(),o.push({value:n,type:a,matches:r}),s=s.slice(n.length));if(!n)break}return t?s.length:s?st.error(e):E(e,u).slice(0)}function dt(e){var t=0,n=e.length,r="";for(;n>t;t++)r+=e[t].value;return r}function ht(e,t,n){var i=t.dir,o=n&&"parentNode"===i,a=C++;return t.first?function(t,n,r){while(t=t[i])if(1===t.nodeType||o)return e(t,n,r)}:function(t,n,s){var u,l,c,p=N+" "+a;if(s){while(t=t[i])if((1===t.nodeType||o)&&e(t,n,s))return!0}else while(t=t[i])if(1===t.nodeType||o)if(c=t[x]||(t[x]={}),(l=c[i])&&l[0]===p){if((u=l[1])===!0||u===r)return u===!0}else if(l=c[i]=[p],l[1]=e(t,n,s)||r,l[1]===!0)return!0}}function gt(e){return e.length>1?function(t,n,r){var i=e.length;while(i--)if(!e[i](t,n,r))return!1;return!0}:e[0]}function mt(e,t,n,r,i){var o,a=[],s=0,u=e.length,l=null!=t;for(;u>s;s++)(o=e[s])&&(!n||n(o,r,i))&&(a.push(o),l&&t.push(s));return a}function yt(e,t,n,r,i,o){return r&&!r[x]&&(r=yt(r)),i&&!i[x]&&(i=yt(i,o)),ot(function(o,a,s,u){var l,c,p,f=[],d=[],h=a.length,g=o||xt(t||"*",s.nodeType?[s]:s,[]),m=!e||!o&&t?g:mt(g,f,e,s,u),y=n?i||(o?e:h||r)?[]:a:m;if(n&&n(m,y,s,u),r){l=mt(y,d),r(l,[],s,u),c=l.length;while(c--)(p=l[c])&&(y[d[c]]=!(m[d[c]]=p))}if(o){if(i||e){if(i){l=[],c=y.length;while(c--)(p=y[c])&&l.push(m[c]=p);i(null,y=[],l,u)}c=y.length;while(c--)(p=y[c])&&(l=i?M.call(o,p):f[c])>-1&&(o[l]=!(a[l]=p))}}else y=mt(y===a?y.splice(h,y.length):y),i?i(null,a,y,u):H.apply(a,y)})}function vt(e){var t,n,r,o=e.length,a=i.relative[e[0].type],s=a||i.relative[" "],u=a?1:0,c=ht(function(e){return e===t},s,!0),p=ht(function(e){return M.call(t,e)>-1},s,!0),f=[function(e,n,r){return!a&&(r||n!==l)||((t=n).nodeType?c(e,n,r):p(e,n,r))}];for(;o>u;u++)if(n=i.relative[e[u].type])f=[ht(gt(f),n)];else{if(n=i.filter[e[u].type].apply(null,e[u].matches),n[x]){for(r=++u;o>r;r++)if(i.relative[e[r].type])break;return yt(u>1&&gt(f),u>1&&dt(e.slice(0,u-1)).replace(W,"$1"),n,r>u&&vt(e.slice(u,r)),o>r&&vt(e=e.slice(r)),o>r&&dt(e))}f.push(n)}return gt(f)}function bt(e,t){var n=0,o=t.length>0,a=e.length>0,s=function(s,u,c,f,d){var h,g,m,y=[],v=0,b="0",x=s&&[],w=null!=d,T=l,C=s||a&&i.find.TAG("*",d&&u.parentNode||u),k=N+=null==T?1:Math.random()||.1;for(w&&(l=u!==p&&u,r=n);null!=(h=C[b]);b++){if(a&&h){g=0;while(m=e[g++])if(m(h,u,c)){f.push(h);break}w&&(N=k,r=++n)}o&&((h=!m&&h)&&v--,s&&x.push(h))}if(v+=b,o&&b!==v){g=0;while(m=t[g++])m(x,y,u,c);if(s){if(v>0)while(b--)x[b]||y[b]||(y[b]=L.call(f));y=mt(y)}H.apply(f,y),w&&!s&&y.length>0&&v+t.length>1&&st.uniqueSort(f)}return w&&(N=k,l=T),x};return o?ot(s):s}s=st.compile=function(e,t){var n,r=[],i=[],o=S[e+" "];if(!o){t||(t=ft(e)),n=t.length;while(n--)o=vt(t[n]),o[x]?r.push(o):i.push(o);o=S(e,bt(i,r))}return o};function xt(e,t,n){var r=0,i=t.length;for(;i>r;r++)st(e,t[r],n);return n}function wt(e,t,n,r){var o,a,u,l,c,p=ft(e);if(!r&&1===p.length){if(a=p[0]=p[0].slice(0),a.length>2&&"ID"===(u=a[0]).type&&9===t.nodeType&&!d&&i.relative[a[1].type]){if(t=i.find.ID(u.matches[0].replace(et,tt),t)[0],!t)return n;e=e.slice(a.shift().value.length)}o=U.needsContext.test(e)?0:a.length;while(o--){if(u=a[o],i.relative[l=u.type])break;if((c=i.find[l])&&(r=c(u.matches[0].replace(et,tt),V.test(a[0].type)&&t.parentNode||t))){if(a.splice(o,1),e=r.length&&dt(a),!e)return H.apply(n,q.call(r,0)),n;break}}}return s(e,p)(r,t,d,n,V.test(e)),n}i.pseudos.nth=i.pseudos.eq;function Tt(){}i.filters=Tt.prototype=i.pseudos,i.setFilters=new Tt,c(),st.attr=b.attr,b.find=st,b.expr=st.selectors,b.expr[":"]=b.expr.pseudos,b.unique=st.uniqueSort,b.text=st.getText,b.isXMLDoc=st.isXML,b.contains=st.contains}(e);var at=/Until$/,st=/^(?:parents|prev(?:Until|All))/,ut=/^.[^:#\[\.,]*$/,lt=b.expr.match.needsContext,ct={children:!0,contents:!0,next:!0,prev:!0};b.fn.extend({find:function(e){var t,n,r,i=this.length;if("string"!=typeof e)return r=this,this.pushStack(b(e).filter(function(){for(t=0;i>t;t++)if(b.contains(r[t],this))return!0}));for(n=[],t=0;i>t;t++)b.find(e,this[t],n);return n=this.pushStack(i>1?b.unique(n):n),n.selector=(this.selector?this.selector+" ":"")+e,n},has:function(e){var t,n=b(e,this),r=n.length;return this.filter(function(){for(t=0;r>t;t++)if(b.contains(this,n[t]))return!0})},not:function(e){return this.pushStack(ft(this,e,!1))},filter:function(e){return this.pushStack(ft(this,e,!0))},is:function(e){return!!e&&("string"==typeof e?lt.test(e)?b(e,this.context).index(this[0])>=0:b.filter(e,this).length>0:this.filter(e).length>0)},closest:function(e,t){var n,r=0,i=this.length,o=[],a=lt.test(e)||"string"!=typeof e?b(e,t||this.context):0;for(;i>r;r++){n=this[r];while(n&&n.ownerDocument&&n!==t&&11!==n.nodeType){if(a?a.index(n)>-1:b.find.matchesSelector(n,e)){o.push(n);break}n=n.parentNode}}return this.pushStack(o.length>1?b.unique(o):o)},index:function(e){return e?"string"==typeof e?b.inArray(this[0],b(e)):b.inArray(e.jquery?e[0]:e,this):this[0]&&this[0].parentNode?this.first().prevAll().length:-1},add:function(e,t){var n="string"==typeof e?b(e,t):b.makeArray(e&&e.nodeType?[e]:e),r=b.merge(this.get(),n);return this.pushStack(b.unique(r))},addBack:function(e){return this.add(null==e?this.prevObject:this.prevObject.filter(e))}}),b.fn.andSelf=b.fn.addBack;function pt(e,t){do e=e[t];while(e&&1!==e.nodeType);return e}b.each({parent:function(e){var t=e.parentNode;return t&&11!==t.nodeType?t:null},parents:function(e){return b.dir(e,"parentNode")},parentsUntil:function(e,t,n){return b.dir(e,"parentNode",n)},next:function(e){return pt(e,"nextSibling")},prev:function(e){return pt(e,"previousSibling")},nextAll:function(e){return b.dir(e,"nextSibling")},prevAll:function(e){return b.dir(e,"previousSibling")},nextUntil:function(e,t,n){return b.dir(e,"nextSibling",n)},prevUntil:function(e,t,n){return b.dir(e,"previousSibling",n)},siblings:function(e){return b.sibling((e.parentNode||{}).firstChild,e)},children:function(e){return b.sibling(e.firstChild)},contents:function(e){return b.nodeName(e,"iframe")?e.contentDocument||e.contentWindow.document:b.merge([],e.childNodes)}},function(e,t){b.fn[e]=function(n,r){var i=b.map(this,t,n);return at.test(e)||(r=n),r&&"string"==typeof r&&(i=b.filter(r,i)),i=this.length>1&&!ct[e]?b.unique(i):i,this.length>1&&st.test(e)&&(i=i.reverse()),this.pushStack(i)}}),b.extend({filter:function(e,t,n){return n&&(e=":not("+e+")"),1===t.length?b.find.matchesSelector(t[0],e)?[t[0]]:[]:b.find.matches(e,t)},dir:function(e,n,r){var i=[],o=e[n];while(o&&9!==o.nodeType&&(r===t||1!==o.nodeType||!b(o).is(r)))1===o.nodeType&&i.push(o),o=o[n];return i},sibling:function(e,t){var n=[];for(;e;e=e.nextSibling)1===e.nodeType&&e!==t&&n.push(e);return n}});function ft(e,t,n){if(t=t||0,b.isFunction(t))return b.grep(e,function(e,r){var i=!!t.call(e,r,e);return i===n});if(t.nodeType)return b.grep(e,function(e){return e===t===n});if("string"==typeof t){var r=b.grep(e,function(e){return 1===e.nodeType});if(ut.test(t))return b.filter(t,r,!n);t=b.filter(t,r)}return b.grep(e,function(e){return b.inArray(e,t)>=0===n})}function dt(e){var t=ht.split("|"),n=e.createDocumentFragment();if(n.createElement)while(t.length)n.createElement(t.pop());return n}var ht="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",gt=/ jQuery\d+="(?:null|\d+)"/g,mt=RegExp("<(?:"+ht+")[\\s/>]","i"),yt=/^\s+/,vt=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,bt=/<([\w:]+)/,xt=/<tbody/i,wt=/<|&#?\w+;/,Tt=/<(?:script|style|link)/i,Nt=/^(?:checkbox|radio)$/i,Ct=/checked\s*(?:[^=]|=\s*.checked.)/i,kt=/^$|\/(?:java|ecma)script/i,Et=/^true\/(.*)/,St=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,At={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],area:[1,"<map>","</map>"],param:[1,"<object>","</object>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:b.support.htmlSerialize?[0,"",""]:[1,"X<div>","</div>"]},jt=dt(o),Dt=jt.appendChild(o.createElement("div"));At.optgroup=At.option,At.tbody=At.tfoot=At.colgroup=At.caption=At.thead,At.th=At.td,b.fn.extend({text:function(e){return b.access(this,function(e){return e===t?b.text(this):this.empty().append((this[0]&&this[0].ownerDocument||o).createTextNode(e))},null,e,arguments.length)},wrapAll:function(e){if(b.isFunction(e))return this.each(function(t){b(this).wrapAll(e.call(this,t))});if(this[0]){var t=b(e,this[0].ownerDocument).eq(0).clone(!0);this[0].parentNode&&t.insertBefore(this[0]),t.map(function(){var e=this;while(e.firstChild&&1===e.firstChild.nodeType)e=e.firstChild;return e}).append(this)}return this},wrapInner:function(e){return b.isFunction(e)?this.each(function(t){b(this).wrapInner(e.call(this,t))}):this.each(function(){var t=b(this),n=t.contents();n.length?n.wrapAll(e):t.append(e)})},wrap:function(e){var t=b.isFunction(e);return this.each(function(n){b(this).wrapAll(t?e.call(this,n):e)})},unwrap:function(){return this.parent().each(function(){b.nodeName(this,"body")||b(this).replaceWith(this.childNodes)}).end()},append:function(){return this.domManip(arguments,!0,function(e){(1===this.nodeType||11===this.nodeType||9===this.nodeType)&&this.appendChild(e)})},prepend:function(){return this.domManip(arguments,!0,function(e){(1===this.nodeType||11===this.nodeType||9===this.nodeType)&&this.insertBefore(e,this.firstChild)})},before:function(){return this.domManip(arguments,!1,function(e){this.parentNode&&this.parentNode.insertBefore(e,this)})},after:function(){return this.domManip(arguments,!1,function(e){this.parentNode&&this.parentNode.insertBefore(e,this.nextSibling)})},remove:function(e,t){var n,r=0;for(;null!=(n=this[r]);r++)(!e||b.filter(e,[n]).length>0)&&(t||1!==n.nodeType||b.cleanData(Ot(n)),n.parentNode&&(t&&b.contains(n.ownerDocument,n)&&Mt(Ot(n,"script")),n.parentNode.removeChild(n)));return this},empty:function(){var e,t=0;for(;null!=(e=this[t]);t++){1===e.nodeType&&b.cleanData(Ot(e,!1));while(e.firstChild)e.removeChild(e.firstChild);e.options&&b.nodeName(e,"select")&&(e.options.length=0)}return this},clone:function(e,t){return e=null==e?!1:e,t=null==t?e:t,this.map(function(){return b.clone(this,e,t)})},html:function(e){return b.access(this,function(e){var n=this[0]||{},r=0,i=this.length;if(e===t)return 1===n.nodeType?n.innerHTML.replace(gt,""):t;if(!("string"!=typeof e||Tt.test(e)||!b.support.htmlSerialize&&mt.test(e)||!b.support.leadingWhitespace&&yt.test(e)||At[(bt.exec(e)||["",""])[1].toLowerCase()])){e=e.replace(vt,"<$1></$2>");try{for(;i>r;r++)n=this[r]||{},1===n.nodeType&&(b.cleanData(Ot(n,!1)),n.innerHTML=e);n=0}catch(o){}}n&&this.empty().append(e)},null,e,arguments.length)},replaceWith:function(e){var t=b.isFunction(e);return t||"string"==typeof e||(e=b(e).not(this).detach()),this.domManip([e],!0,function(e){var t=this.nextSibling,n=this.parentNode;n&&(b(this).remove(),n.insertBefore(e,t))})},detach:function(e){return this.remove(e,!0)},domManip:function(e,n,r){e=f.apply([],e);var i,o,a,s,u,l,c=0,p=this.length,d=this,h=p-1,g=e[0],m=b.isFunction(g);if(m||!(1>=p||"string"!=typeof g||b.support.checkClone)&&Ct.test(g))return this.each(function(i){var o=d.eq(i);m&&(e[0]=g.call(this,i,n?o.html():t)),o.domManip(e,n,r)});if(p&&(l=b.buildFragment(e,this[0].ownerDocument,!1,this),i=l.firstChild,1===l.childNodes.length&&(l=i),i)){for(n=n&&b.nodeName(i,"tr"),s=b.map(Ot(l,"script"),Ht),a=s.length;p>c;c++)o=l,c!==h&&(o=b.clone(o,!0,!0),a&&b.merge(s,Ot(o,"script"))),r.call(n&&b.nodeName(this[c],"table")?Lt(this[c],"tbody"):this[c],o,c);if(a)for(u=s[s.length-1].ownerDocument,b.map(s,qt),c=0;a>c;c++)o=s[c],kt.test(o.type||"")&&!b._data(o,"globalEval")&&b.contains(u,o)&&(o.src?b.ajax({url:o.src,type:"GET",dataType:"script",async:!1,global:!1,"throws":!0}):b.globalEval((o.text||o.textContent||o.innerHTML||"").replace(St,"")));l=i=null}return this}});function Lt(e,t){return e.getElementsByTagName(t)[0]||e.appendChild(e.ownerDocument.createElement(t))}function Ht(e){var t=e.getAttributeNode("type");return e.type=(t&&t.specified)+"/"+e.type,e}function qt(e){var t=Et.exec(e.type);return t?e.type=t[1]:e.removeAttribute("type"),e}function Mt(e,t){var n,r=0;for(;null!=(n=e[r]);r++)b._data(n,"globalEval",!t||b._data(t[r],"globalEval"))}function _t(e,t){if(1===t.nodeType&&b.hasData(e)){var n,r,i,o=b._data(e),a=b._data(t,o),s=o.events;if(s){delete a.handle,a.events={};for(n in s)for(r=0,i=s[n].length;i>r;r++)b.event.add(t,n,s[n][r])}a.data&&(a.data=b.extend({},a.data))}}function Ft(e,t){var n,r,i;if(1===t.nodeType){if(n=t.nodeName.toLowerCase(),!b.support.noCloneEvent&&t[b.expando]){i=b._data(t);for(r in i.events)b.removeEvent(t,r,i.handle);t.removeAttribute(b.expando)}"script"===n&&t.text!==e.text?(Ht(t).text=e.text,qt(t)):"object"===n?(t.parentNode&&(t.outerHTML=e.outerHTML),b.support.html5Clone&&e.innerHTML&&!b.trim(t.innerHTML)&&(t.innerHTML=e.innerHTML)):"input"===n&&Nt.test(e.type)?(t.defaultChecked=t.checked=e.checked,t.value!==e.value&&(t.value=e.value)):"option"===n?t.defaultSelected=t.selected=e.defaultSelected:("input"===n||"textarea"===n)&&(t.defaultValue=e.defaultValue)}}b.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(e,t){b.fn[e]=function(e){var n,r=0,i=[],o=b(e),a=o.length-1;for(;a>=r;r++)n=r===a?this:this.clone(!0),b(o[r])[t](n),d.apply(i,n.get());return this.pushStack(i)}});function Ot(e,n){var r,o,a=0,s=typeof e.getElementsByTagName!==i?e.getElementsByTagName(n||"*"):typeof e.querySelectorAll!==i?e.querySelectorAll(n||"*"):t;if(!s)for(s=[],r=e.childNodes||e;null!=(o=r[a]);a++)!n||b.nodeName(o,n)?s.push(o):b.merge(s,Ot(o,n));return n===t||n&&b.nodeName(e,n)?b.merge([e],s):s}function Bt(e){Nt.test(e.type)&&(e.defaultChecked=e.checked)}b.extend({clone:function(e,t,n){var r,i,o,a,s,u=b.contains(e.ownerDocument,e);if(b.support.html5Clone||b.isXMLDoc(e)||!mt.test("<"+e.nodeName+">")?o=e.cloneNode(!0):(Dt.innerHTML=e.outerHTML,Dt.removeChild(o=Dt.firstChild)),!(b.support.noCloneEvent&&b.support.noCloneChecked||1!==e.nodeType&&11!==e.nodeType||b.isXMLDoc(e)))for(r=Ot(o),s=Ot(e),a=0;null!=(i=s[a]);++a)r[a]&&Ft(i,r[a]);if(t)if(n)for(s=s||Ot(e),r=r||Ot(o),a=0;null!=(i=s[a]);a++)_t(i,r[a]);else _t(e,o);return r=Ot(o,"script"),r.length>0&&Mt(r,!u&&Ot(e,"script")),r=s=i=null,o},buildFragment:function(e,t,n,r){var i,o,a,s,u,l,c,p=e.length,f=dt(t),d=[],h=0;for(;p>h;h++)if(o=e[h],o||0===o)if("object"===b.type(o))b.merge(d,o.nodeType?[o]:o);else if(wt.test(o)){s=s||f.appendChild(t.createElement("div")),u=(bt.exec(o)||["",""])[1].toLowerCase(),c=At[u]||At._default,s.innerHTML=c[1]+o.replace(vt,"<$1></$2>")+c[2],i=c[0];while(i--)s=s.lastChild;if(!b.support.leadingWhitespace&&yt.test(o)&&d.push(t.createTextNode(yt.exec(o)[0])),!b.support.tbody){o="table"!==u||xt.test(o)?"<table>"!==c[1]||xt.test(o)?0:s:s.firstChild,i=o&&o.childNodes.length;while(i--)b.nodeName(l=o.childNodes[i],"tbody")&&!l.childNodes.length&&o.removeChild(l)
}b.merge(d,s.childNodes),s.textContent="";while(s.firstChild)s.removeChild(s.firstChild);s=f.lastChild}else d.push(t.createTextNode(o));s&&f.removeChild(s),b.support.appendChecked||b.grep(Ot(d,"input"),Bt),h=0;while(o=d[h++])if((!r||-1===b.inArray(o,r))&&(a=b.contains(o.ownerDocument,o),s=Ot(f.appendChild(o),"script"),a&&Mt(s),n)){i=0;while(o=s[i++])kt.test(o.type||"")&&n.push(o)}return s=null,f},cleanData:function(e,t){var n,r,o,a,s=0,u=b.expando,l=b.cache,p=b.support.deleteExpando,f=b.event.special;for(;null!=(n=e[s]);s++)if((t||b.acceptData(n))&&(o=n[u],a=o&&l[o])){if(a.events)for(r in a.events)f[r]?b.event.remove(n,r):b.removeEvent(n,r,a.handle);l[o]&&(delete l[o],p?delete n[u]:typeof n.removeAttribute!==i?n.removeAttribute(u):n[u]=null,c.push(o))}}});var Pt,Rt,Wt,$t=/alpha\([^)]*\)/i,It=/opacity\s*=\s*([^)]*)/,zt=/^(top|right|bottom|left)$/,Xt=/^(none|table(?!-c[ea]).+)/,Ut=/^margin/,Vt=RegExp("^("+x+")(.*)$","i"),Yt=RegExp("^("+x+")(?!px)[a-z%]+$","i"),Jt=RegExp("^([+-])=("+x+")","i"),Gt={BODY:"block"},Qt={position:"absolute",visibility:"hidden",display:"block"},Kt={letterSpacing:0,fontWeight:400},Zt=["Top","Right","Bottom","Left"],en=["Webkit","O","Moz","ms"];function tn(e,t){if(t in e)return t;var n=t.charAt(0).toUpperCase()+t.slice(1),r=t,i=en.length;while(i--)if(t=en[i]+n,t in e)return t;return r}function nn(e,t){return e=t||e,"none"===b.css(e,"display")||!b.contains(e.ownerDocument,e)}function rn(e,t){var n,r,i,o=[],a=0,s=e.length;for(;s>a;a++)r=e[a],r.style&&(o[a]=b._data(r,"olddisplay"),n=r.style.display,t?(o[a]||"none"!==n||(r.style.display=""),""===r.style.display&&nn(r)&&(o[a]=b._data(r,"olddisplay",un(r.nodeName)))):o[a]||(i=nn(r),(n&&"none"!==n||!i)&&b._data(r,"olddisplay",i?n:b.css(r,"display"))));for(a=0;s>a;a++)r=e[a],r.style&&(t&&"none"!==r.style.display&&""!==r.style.display||(r.style.display=t?o[a]||"":"none"));return e}b.fn.extend({css:function(e,n){return b.access(this,function(e,n,r){var i,o,a={},s=0;if(b.isArray(n)){for(o=Rt(e),i=n.length;i>s;s++)a[n[s]]=b.css(e,n[s],!1,o);return a}return r!==t?b.style(e,n,r):b.css(e,n)},e,n,arguments.length>1)},show:function(){return rn(this,!0)},hide:function(){return rn(this)},toggle:function(e){var t="boolean"==typeof e;return this.each(function(){(t?e:nn(this))?b(this).show():b(this).hide()})}}),b.extend({cssHooks:{opacity:{get:function(e,t){if(t){var n=Wt(e,"opacity");return""===n?"1":n}}}},cssNumber:{columnCount:!0,fillOpacity:!0,fontWeight:!0,lineHeight:!0,opacity:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":b.support.cssFloat?"cssFloat":"styleFloat"},style:function(e,n,r,i){if(e&&3!==e.nodeType&&8!==e.nodeType&&e.style){var o,a,s,u=b.camelCase(n),l=e.style;if(n=b.cssProps[u]||(b.cssProps[u]=tn(l,u)),s=b.cssHooks[n]||b.cssHooks[u],r===t)return s&&"get"in s&&(o=s.get(e,!1,i))!==t?o:l[n];if(a=typeof r,"string"===a&&(o=Jt.exec(r))&&(r=(o[1]+1)*o[2]+parseFloat(b.css(e,n)),a="number"),!(null==r||"number"===a&&isNaN(r)||("number"!==a||b.cssNumber[u]||(r+="px"),b.support.clearCloneStyle||""!==r||0!==n.indexOf("background")||(l[n]="inherit"),s&&"set"in s&&(r=s.set(e,r,i))===t)))try{l[n]=r}catch(c){}}},css:function(e,n,r,i){var o,a,s,u=b.camelCase(n);return n=b.cssProps[u]||(b.cssProps[u]=tn(e.style,u)),s=b.cssHooks[n]||b.cssHooks[u],s&&"get"in s&&(a=s.get(e,!0,r)),a===t&&(a=Wt(e,n,i)),"normal"===a&&n in Kt&&(a=Kt[n]),""===r||r?(o=parseFloat(a),r===!0||b.isNumeric(o)?o||0:a):a},swap:function(e,t,n,r){var i,o,a={};for(o in t)a[o]=e.style[o],e.style[o]=t[o];i=n.apply(e,r||[]);for(o in t)e.style[o]=a[o];return i}}),e.getComputedStyle?(Rt=function(t){return e.getComputedStyle(t,null)},Wt=function(e,n,r){var i,o,a,s=r||Rt(e),u=s?s.getPropertyValue(n)||s[n]:t,l=e.style;return s&&(""!==u||b.contains(e.ownerDocument,e)||(u=b.style(e,n)),Yt.test(u)&&Ut.test(n)&&(i=l.width,o=l.minWidth,a=l.maxWidth,l.minWidth=l.maxWidth=l.width=u,u=s.width,l.width=i,l.minWidth=o,l.maxWidth=a)),u}):o.documentElement.currentStyle&&(Rt=function(e){return e.currentStyle},Wt=function(e,n,r){var i,o,a,s=r||Rt(e),u=s?s[n]:t,l=e.style;return null==u&&l&&l[n]&&(u=l[n]),Yt.test(u)&&!zt.test(n)&&(i=l.left,o=e.runtimeStyle,a=o&&o.left,a&&(o.left=e.currentStyle.left),l.left="fontSize"===n?"1em":u,u=l.pixelLeft+"px",l.left=i,a&&(o.left=a)),""===u?"auto":u});function on(e,t,n){var r=Vt.exec(t);return r?Math.max(0,r[1]-(n||0))+(r[2]||"px"):t}function an(e,t,n,r,i){var o=n===(r?"border":"content")?4:"width"===t?1:0,a=0;for(;4>o;o+=2)"margin"===n&&(a+=b.css(e,n+Zt[o],!0,i)),r?("content"===n&&(a-=b.css(e,"padding"+Zt[o],!0,i)),"margin"!==n&&(a-=b.css(e,"border"+Zt[o]+"Width",!0,i))):(a+=b.css(e,"padding"+Zt[o],!0,i),"padding"!==n&&(a+=b.css(e,"border"+Zt[o]+"Width",!0,i)));return a}function sn(e,t,n){var r=!0,i="width"===t?e.offsetWidth:e.offsetHeight,o=Rt(e),a=b.support.boxSizing&&"border-box"===b.css(e,"boxSizing",!1,o);if(0>=i||null==i){if(i=Wt(e,t,o),(0>i||null==i)&&(i=e.style[t]),Yt.test(i))return i;r=a&&(b.support.boxSizingReliable||i===e.style[t]),i=parseFloat(i)||0}return i+an(e,t,n||(a?"border":"content"),r,o)+"px"}function un(e){var t=o,n=Gt[e];return n||(n=ln(e,t),"none"!==n&&n||(Pt=(Pt||b("<iframe frameborder='0' width='0' height='0'/>").css("cssText","display:block !important")).appendTo(t.documentElement),t=(Pt[0].contentWindow||Pt[0].contentDocument).document,t.write("<!doctype html><html><body>"),t.close(),n=ln(e,t),Pt.detach()),Gt[e]=n),n}function ln(e,t){var n=b(t.createElement(e)).appendTo(t.body),r=b.css(n[0],"display");return n.remove(),r}b.each(["height","width"],function(e,n){b.cssHooks[n]={get:function(e,r,i){return r?0===e.offsetWidth&&Xt.test(b.css(e,"display"))?b.swap(e,Qt,function(){return sn(e,n,i)}):sn(e,n,i):t},set:function(e,t,r){var i=r&&Rt(e);return on(e,t,r?an(e,n,r,b.support.boxSizing&&"border-box"===b.css(e,"boxSizing",!1,i),i):0)}}}),b.support.opacity||(b.cssHooks.opacity={get:function(e,t){return It.test((t&&e.currentStyle?e.currentStyle.filter:e.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":t?"1":""},set:function(e,t){var n=e.style,r=e.currentStyle,i=b.isNumeric(t)?"alpha(opacity="+100*t+")":"",o=r&&r.filter||n.filter||"";n.zoom=1,(t>=1||""===t)&&""===b.trim(o.replace($t,""))&&n.removeAttribute&&(n.removeAttribute("filter"),""===t||r&&!r.filter)||(n.filter=$t.test(o)?o.replace($t,i):o+" "+i)}}),b(function(){b.support.reliableMarginRight||(b.cssHooks.marginRight={get:function(e,n){return n?b.swap(e,{display:"inline-block"},Wt,[e,"marginRight"]):t}}),!b.support.pixelPosition&&b.fn.position&&b.each(["top","left"],function(e,n){b.cssHooks[n]={get:function(e,r){return r?(r=Wt(e,n),Yt.test(r)?b(e).position()[n]+"px":r):t}}})}),b.expr&&b.expr.filters&&(b.expr.filters.hidden=function(e){return 0>=e.offsetWidth&&0>=e.offsetHeight||!b.support.reliableHiddenOffsets&&"none"===(e.style&&e.style.display||b.css(e,"display"))},b.expr.filters.visible=function(e){return!b.expr.filters.hidden(e)}),b.each({margin:"",padding:"",border:"Width"},function(e,t){b.cssHooks[e+t]={expand:function(n){var r=0,i={},o="string"==typeof n?n.split(" "):[n];for(;4>r;r++)i[e+Zt[r]+t]=o[r]||o[r-2]||o[0];return i}},Ut.test(e)||(b.cssHooks[e+t].set=on)});var cn=/%20/g,pn=/\[\]$/,fn=/\r?\n/g,dn=/^(?:submit|button|image|reset|file)$/i,hn=/^(?:input|select|textarea|keygen)/i;b.fn.extend({serialize:function(){return b.param(this.serializeArray())},serializeArray:function(){return this.map(function(){var e=b.prop(this,"elements");return e?b.makeArray(e):this}).filter(function(){var e=this.type;return this.name&&!b(this).is(":disabled")&&hn.test(this.nodeName)&&!dn.test(e)&&(this.checked||!Nt.test(e))}).map(function(e,t){var n=b(this).val();return null==n?null:b.isArray(n)?b.map(n,function(e){return{name:t.name,value:e.replace(fn,"\r\n")}}):{name:t.name,value:n.replace(fn,"\r\n")}}).get()}}),b.param=function(e,n){var r,i=[],o=function(e,t){t=b.isFunction(t)?t():null==t?"":t,i[i.length]=encodeURIComponent(e)+"="+encodeURIComponent(t)};if(n===t&&(n=b.ajaxSettings&&b.ajaxSettings.traditional),b.isArray(e)||e.jquery&&!b.isPlainObject(e))b.each(e,function(){o(this.name,this.value)});else for(r in e)gn(r,e[r],n,o);return i.join("&").replace(cn,"+")};function gn(e,t,n,r){var i;if(b.isArray(t))b.each(t,function(t,i){n||pn.test(e)?r(e,i):gn(e+"["+("object"==typeof i?t:"")+"]",i,n,r)});else if(n||"object"!==b.type(t))r(e,t);else for(i in t)gn(e+"["+i+"]",t[i],n,r)}b.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(e,t){b.fn[t]=function(e,n){return arguments.length>0?this.on(t,null,e,n):this.trigger(t)}}),b.fn.hover=function(e,t){return this.mouseenter(e).mouseleave(t||e)};var mn,yn,vn=b.now(),bn=/\?/,xn=/#.*$/,wn=/([?&])_=[^&]*/,Tn=/^(.*?):[ \t]*([^\r\n]*)\r?$/gm,Nn=/^(?:about|app|app-storage|.+-extension|file|res|widget):$/,Cn=/^(?:GET|HEAD)$/,kn=/^\/\//,En=/^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,Sn=b.fn.load,An={},jn={},Dn="*/".concat("*");try{yn=a.href}catch(Ln){yn=o.createElement("a"),yn.href="",yn=yn.href}mn=En.exec(yn.toLowerCase())||[];function Hn(e){return function(t,n){"string"!=typeof t&&(n=t,t="*");var r,i=0,o=t.toLowerCase().match(w)||[];if(b.isFunction(n))while(r=o[i++])"+"===r[0]?(r=r.slice(1)||"*",(e[r]=e[r]||[]).unshift(n)):(e[r]=e[r]||[]).push(n)}}function qn(e,n,r,i){var o={},a=e===jn;function s(u){var l;return o[u]=!0,b.each(e[u]||[],function(e,u){var c=u(n,r,i);return"string"!=typeof c||a||o[c]?a?!(l=c):t:(n.dataTypes.unshift(c),s(c),!1)}),l}return s(n.dataTypes[0])||!o["*"]&&s("*")}function Mn(e,n){var r,i,o=b.ajaxSettings.flatOptions||{};for(i in n)n[i]!==t&&((o[i]?e:r||(r={}))[i]=n[i]);return r&&b.extend(!0,e,r),e}b.fn.load=function(e,n,r){if("string"!=typeof e&&Sn)return Sn.apply(this,arguments);var i,o,a,s=this,u=e.indexOf(" ");return u>=0&&(i=e.slice(u,e.length),e=e.slice(0,u)),b.isFunction(n)?(r=n,n=t):n&&"object"==typeof n&&(a="POST"),s.length>0&&b.ajax({url:e,type:a,dataType:"html",data:n}).done(function(e){o=arguments,s.html(i?b("<div>").append(b.parseHTML(e)).find(i):e)}).complete(r&&function(e,t){s.each(r,o||[e.responseText,t,e])}),this},b.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(e,t){b.fn[t]=function(e){return this.on(t,e)}}),b.each(["get","post"],function(e,n){b[n]=function(e,r,i,o){return b.isFunction(r)&&(o=o||i,i=r,r=t),b.ajax({url:e,type:n,dataType:o,data:r,success:i})}}),b.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:yn,type:"GET",isLocal:Nn.test(mn[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":Dn,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":e.String,"text html":!0,"text json":b.parseJSON,"text xml":b.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(e,t){return t?Mn(Mn(e,b.ajaxSettings),t):Mn(b.ajaxSettings,e)},ajaxPrefilter:Hn(An),ajaxTransport:Hn(jn),ajax:function(e,n){"object"==typeof e&&(n=e,e=t),n=n||{};var r,i,o,a,s,u,l,c,p=b.ajaxSetup({},n),f=p.context||p,d=p.context&&(f.nodeType||f.jquery)?b(f):b.event,h=b.Deferred(),g=b.Callbacks("once memory"),m=p.statusCode||{},y={},v={},x=0,T="canceled",N={readyState:0,getResponseHeader:function(e){var t;if(2===x){if(!c){c={};while(t=Tn.exec(a))c[t[1].toLowerCase()]=t[2]}t=c[e.toLowerCase()]}return null==t?null:t},getAllResponseHeaders:function(){return 2===x?a:null},setRequestHeader:function(e,t){var n=e.toLowerCase();return x||(e=v[n]=v[n]||e,y[e]=t),this},overrideMimeType:function(e){return x||(p.mimeType=e),this},statusCode:function(e){var t;if(e)if(2>x)for(t in e)m[t]=[m[t],e[t]];else N.always(e[N.status]);return this},abort:function(e){var t=e||T;return l&&l.abort(t),k(0,t),this}};if(h.promise(N).complete=g.add,N.success=N.done,N.error=N.fail,p.url=((e||p.url||yn)+"").replace(xn,"").replace(kn,mn[1]+"//"),p.type=n.method||n.type||p.method||p.type,p.dataTypes=b.trim(p.dataType||"*").toLowerCase().match(w)||[""],null==p.crossDomain&&(r=En.exec(p.url.toLowerCase()),p.crossDomain=!(!r||r[1]===mn[1]&&r[2]===mn[2]&&(r[3]||("http:"===r[1]?80:443))==(mn[3]||("http:"===mn[1]?80:443)))),p.data&&p.processData&&"string"!=typeof p.data&&(p.data=b.param(p.data,p.traditional)),qn(An,p,n,N),2===x)return N;u=p.global,u&&0===b.active++&&b.event.trigger("ajaxStart"),p.type=p.type.toUpperCase(),p.hasContent=!Cn.test(p.type),o=p.url,p.hasContent||(p.data&&(o=p.url+=(bn.test(o)?"&":"?")+p.data,delete p.data),p.cache===!1&&(p.url=wn.test(o)?o.replace(wn,"$1_="+vn++):o+(bn.test(o)?"&":"?")+"_="+vn++)),p.ifModified&&(b.lastModified[o]&&N.setRequestHeader("If-Modified-Since",b.lastModified[o]),b.etag[o]&&N.setRequestHeader("If-None-Match",b.etag[o])),(p.data&&p.hasContent&&p.contentType!==!1||n.contentType)&&N.setRequestHeader("Content-Type",p.contentType),N.setRequestHeader("Accept",p.dataTypes[0]&&p.accepts[p.dataTypes[0]]?p.accepts[p.dataTypes[0]]+("*"!==p.dataTypes[0]?", "+Dn+"; q=0.01":""):p.accepts["*"]);for(i in p.headers)N.setRequestHeader(i,p.headers[i]);if(p.beforeSend&&(p.beforeSend.call(f,N,p)===!1||2===x))return N.abort();T="abort";for(i in{success:1,error:1,complete:1})N[i](p[i]);if(l=qn(jn,p,n,N)){N.readyState=1,u&&d.trigger("ajaxSend",[N,p]),p.async&&p.timeout>0&&(s=setTimeout(function(){N.abort("timeout")},p.timeout));try{x=1,l.send(y,k)}catch(C){if(!(2>x))throw C;k(-1,C)}}else k(-1,"No Transport");function k(e,n,r,i){var c,y,v,w,T,C=n;2!==x&&(x=2,s&&clearTimeout(s),l=t,a=i||"",N.readyState=e>0?4:0,r&&(w=_n(p,N,r)),e>=200&&300>e||304===e?(p.ifModified&&(T=N.getResponseHeader("Last-Modified"),T&&(b.lastModified[o]=T),T=N.getResponseHeader("etag"),T&&(b.etag[o]=T)),204===e?(c=!0,C="nocontent"):304===e?(c=!0,C="notmodified"):(c=Fn(p,w),C=c.state,y=c.data,v=c.error,c=!v)):(v=C,(e||!C)&&(C="error",0>e&&(e=0))),N.status=e,N.statusText=(n||C)+"",c?h.resolveWith(f,[y,C,N]):h.rejectWith(f,[N,C,v]),N.statusCode(m),m=t,u&&d.trigger(c?"ajaxSuccess":"ajaxError",[N,p,c?y:v]),g.fireWith(f,[N,C]),u&&(d.trigger("ajaxComplete",[N,p]),--b.active||b.event.trigger("ajaxStop")))}return N},getScript:function(e,n){return b.get(e,t,n,"script")},getJSON:function(e,t,n){return b.get(e,t,n,"json")}});function _n(e,n,r){var i,o,a,s,u=e.contents,l=e.dataTypes,c=e.responseFields;for(s in c)s in r&&(n[c[s]]=r[s]);while("*"===l[0])l.shift(),o===t&&(o=e.mimeType||n.getResponseHeader("Content-Type"));if(o)for(s in u)if(u[s]&&u[s].test(o)){l.unshift(s);break}if(l[0]in r)a=l[0];else{for(s in r){if(!l[0]||e.converters[s+" "+l[0]]){a=s;break}i||(i=s)}a=a||i}return a?(a!==l[0]&&l.unshift(a),r[a]):t}function Fn(e,t){var n,r,i,o,a={},s=0,u=e.dataTypes.slice(),l=u[0];if(e.dataFilter&&(t=e.dataFilter(t,e.dataType)),u[1])for(i in e.converters)a[i.toLowerCase()]=e.converters[i];for(;r=u[++s];)if("*"!==r){if("*"!==l&&l!==r){if(i=a[l+" "+r]||a["* "+r],!i)for(n in a)if(o=n.split(" "),o[1]===r&&(i=a[l+" "+o[0]]||a["* "+o[0]])){i===!0?i=a[n]:a[n]!==!0&&(r=o[0],u.splice(s--,0,r));break}if(i!==!0)if(i&&e["throws"])t=i(t);else try{t=i(t)}catch(c){return{state:"parsererror",error:i?c:"No conversion from "+l+" to "+r}}}l=r}return{state:"success",data:t}}b.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/(?:java|ecma)script/},converters:{"text script":function(e){return b.globalEval(e),e}}}),b.ajaxPrefilter("script",function(e){e.cache===t&&(e.cache=!1),e.crossDomain&&(e.type="GET",e.global=!1)}),b.ajaxTransport("script",function(e){if(e.crossDomain){var n,r=o.head||b("head")[0]||o.documentElement;return{send:function(t,i){n=o.createElement("script"),n.async=!0,e.scriptCharset&&(n.charset=e.scriptCharset),n.src=e.url,n.onload=n.onreadystatechange=function(e,t){(t||!n.readyState||/loaded|complete/.test(n.readyState))&&(n.onload=n.onreadystatechange=null,n.parentNode&&n.parentNode.removeChild(n),n=null,t||i(200,"success"))},r.insertBefore(n,r.firstChild)},abort:function(){n&&n.onload(t,!0)}}}});var On=[],Bn=/(=)\?(?=&|$)|\?\?/;b.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var e=On.pop()||b.expando+"_"+vn++;return this[e]=!0,e}}),b.ajaxPrefilter("json jsonp",function(n,r,i){var o,a,s,u=n.jsonp!==!1&&(Bn.test(n.url)?"url":"string"==typeof n.data&&!(n.contentType||"").indexOf("application/x-www-form-urlencoded")&&Bn.test(n.data)&&"data");return u||"jsonp"===n.dataTypes[0]?(o=n.jsonpCallback=b.isFunction(n.jsonpCallback)?n.jsonpCallback():n.jsonpCallback,u?n[u]=n[u].replace(Bn,"$1"+o):n.jsonp!==!1&&(n.url+=(bn.test(n.url)?"&":"?")+n.jsonp+"="+o),n.converters["script json"]=function(){return s||b.error(o+" was not called"),s[0]},n.dataTypes[0]="json",a=e[o],e[o]=function(){s=arguments},i.always(function(){e[o]=a,n[o]&&(n.jsonpCallback=r.jsonpCallback,On.push(o)),s&&b.isFunction(a)&&a(s[0]),s=a=t}),"script"):t});var Pn,Rn,Wn=0,$n=e.ActiveXObject&&function(){var e;for(e in Pn)Pn[e](t,!0)};function In(){try{return new e.XMLHttpRequest}catch(t){}}function zn(){try{return new e.ActiveXObject("Microsoft.XMLHTTP")}catch(t){}}b.ajaxSettings.xhr=e.ActiveXObject?function(){return!this.isLocal&&In()||zn()}:In,Rn=b.ajaxSettings.xhr(),b.support.cors=!!Rn&&"withCredentials"in Rn,Rn=b.support.ajax=!!Rn,Rn&&b.ajaxTransport(function(n){if(!n.crossDomain||b.support.cors){var r;return{send:function(i,o){var a,s,u=n.xhr();if(n.username?u.open(n.type,n.url,n.async,n.username,n.password):u.open(n.type,n.url,n.async),n.xhrFields)for(s in n.xhrFields)u[s]=n.xhrFields[s];n.mimeType&&u.overrideMimeType&&u.overrideMimeType(n.mimeType),n.crossDomain||i["X-Requested-With"]||(i["X-Requested-With"]="XMLHttpRequest");try{for(s in i)u.setRequestHeader(s,i[s])}catch(l){}u.send(n.hasContent&&n.data||null),r=function(e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete Pn[a]),i)4!==u.readyState&&u.abort();else{p={},s=u.status,l=u.getAllResponseHeaders(),"string"==typeof u.responseText&&(p.text=u.responseText);try{c=u.statusText}catch(f){c=""}s||!n.isLocal||n.crossDomain?1223===s&&(s=204):s=p.text?200:404}}catch(d){i||o(-1,d)}p&&o(s,c,p,l)},n.async?4===u.readyState?setTimeout(r):(a=++Wn,$n&&(Pn||(Pn={},b(e).unload($n)),Pn[a]=r),u.onreadystatechange=r):r()},abort:function(){r&&r(t,!0)}}}});var Xn,Un,Vn=/^(?:toggle|show|hide)$/,Yn=RegExp("^(?:([+-])=|)("+x+")([a-z%]*)$","i"),Jn=/queueHooks$/,Gn=[nr],Qn={"*":[function(e,t){var n,r,i=this.createTween(e,t),o=Yn.exec(t),a=i.cur(),s=+a||0,u=1,l=20;if(o){if(n=+o[2],r=o[3]||(b.cssNumber[e]?"":"px"),"px"!==r&&s){s=b.css(i.elem,e,!0)||n||1;do u=u||".5",s/=u,b.style(i.elem,e,s+r);while(u!==(u=i.cur()/a)&&1!==u&&--l)}i.unit=r,i.start=s,i.end=o[1]?s+(o[1]+1)*n:n}return i}]};function Kn(){return setTimeout(function(){Xn=t}),Xn=b.now()}function Zn(e,t){b.each(t,function(t,n){var r=(Qn[t]||[]).concat(Qn["*"]),i=0,o=r.length;for(;o>i;i++)if(r[i].call(e,t,n))return})}function er(e,t,n){var r,i,o=0,a=Gn.length,s=b.Deferred().always(function(){delete u.elem}),u=function(){if(i)return!1;var t=Xn||Kn(),n=Math.max(0,l.startTime+l.duration-t),r=n/l.duration||0,o=1-r,a=0,u=l.tweens.length;for(;u>a;a++)l.tweens[a].run(o);return s.notifyWith(e,[l,o,n]),1>o&&u?n:(s.resolveWith(e,[l]),!1)},l=s.promise({elem:e,props:b.extend({},t),opts:b.extend(!0,{specialEasing:{}},n),originalProperties:t,originalOptions:n,startTime:Xn||Kn(),duration:n.duration,tweens:[],createTween:function(t,n){var r=b.Tween(e,l.opts,t,n,l.opts.specialEasing[t]||l.opts.easing);return l.tweens.push(r),r},stop:function(t){var n=0,r=t?l.tweens.length:0;if(i)return this;for(i=!0;r>n;n++)l.tweens[n].run(1);return t?s.resolveWith(e,[l,t]):s.rejectWith(e,[l,t]),this}}),c=l.props;for(tr(c,l.opts.specialEasing);a>o;o++)if(r=Gn[o].call(l,e,c,l.opts))return r;return Zn(l,c),b.isFunction(l.opts.start)&&l.opts.start.call(e,l),b.fx.timer(b.extend(u,{elem:e,anim:l,queue:l.opts.queue})),l.progress(l.opts.progress).done(l.opts.done,l.opts.complete).fail(l.opts.fail).always(l.opts.always)}function tr(e,t){var n,r,i,o,a;for(i in e)if(r=b.camelCase(i),o=t[r],n=e[i],b.isArray(n)&&(o=n[1],n=e[i]=n[0]),i!==r&&(e[r]=n,delete e[i]),a=b.cssHooks[r],a&&"expand"in a){n=a.expand(n),delete e[r];for(i in n)i in e||(e[i]=n[i],t[i]=o)}else t[r]=o}b.Animation=b.extend(er,{tweener:function(e,t){b.isFunction(e)?(t=e,e=["*"]):e=e.split(" ");var n,r=0,i=e.length;for(;i>r;r++)n=e[r],Qn[n]=Qn[n]||[],Qn[n].unshift(t)},prefilter:function(e,t){t?Gn.unshift(e):Gn.push(e)}});function nr(e,t,n){var r,i,o,a,s,u,l,c,p,f=this,d=e.style,h={},g=[],m=e.nodeType&&nn(e);n.queue||(c=b._queueHooks(e,"fx"),null==c.unqueued&&(c.unqueued=0,p=c.empty.fire,c.empty.fire=function(){c.unqueued||p()}),c.unqueued++,f.always(function(){f.always(function(){c.unqueued--,b.queue(e,"fx").length||c.empty.fire()})})),1===e.nodeType&&("height"in t||"width"in t)&&(n.overflow=[d.overflow,d.overflowX,d.overflowY],"inline"===b.css(e,"display")&&"none"===b.css(e,"float")&&(b.support.inlineBlockNeedsLayout&&"inline"!==un(e.nodeName)?d.zoom=1:d.display="inline-block")),n.overflow&&(d.overflow="hidden",b.support.shrinkWrapBlocks||f.always(function(){d.overflow=n.overflow[0],d.overflowX=n.overflow[1],d.overflowY=n.overflow[2]}));for(i in t)if(a=t[i],Vn.exec(a)){if(delete t[i],u=u||"toggle"===a,a===(m?"hide":"show"))continue;g.push(i)}if(o=g.length){s=b._data(e,"fxshow")||b._data(e,"fxshow",{}),"hidden"in s&&(m=s.hidden),u&&(s.hidden=!m),m?b(e).show():f.done(function(){b(e).hide()}),f.done(function(){var t;b._removeData(e,"fxshow");for(t in h)b.style(e,t,h[t])});for(i=0;o>i;i++)r=g[i],l=f.createTween(r,m?s[r]:0),h[r]=s[r]||b.style(e,r),r in s||(s[r]=l.start,m&&(l.end=l.start,l.start="width"===r||"height"===r?1:0))}}function rr(e,t,n,r,i){return new rr.prototype.init(e,t,n,r,i)}b.Tween=rr,rr.prototype={constructor:rr,init:function(e,t,n,r,i,o){this.elem=e,this.prop=n,this.easing=i||"swing",this.options=t,this.start=this.now=this.cur(),this.end=r,this.unit=o||(b.cssNumber[n]?"":"px")},cur:function(){var e=rr.propHooks[this.prop];return e&&e.get?e.get(this):rr.propHooks._default.get(this)},run:function(e){var t,n=rr.propHooks[this.prop];return this.pos=t=this.options.duration?b.easing[this.easing](e,this.options.duration*e,0,1,this.options.duration):e,this.now=(this.end-this.start)*t+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),n&&n.set?n.set(this):rr.propHooks._default.set(this),this}},rr.prototype.init.prototype=rr.prototype,rr.propHooks={_default:{get:function(e){var t;return null==e.elem[e.prop]||e.elem.style&&null!=e.elem.style[e.prop]?(t=b.css(e.elem,e.prop,""),t&&"auto"!==t?t:0):e.elem[e.prop]},set:function(e){b.fx.step[e.prop]?b.fx.step[e.prop](e):e.elem.style&&(null!=e.elem.style[b.cssProps[e.prop]]||b.cssHooks[e.prop])?b.style(e.elem,e.prop,e.now+e.unit):e.elem[e.prop]=e.now}}},rr.propHooks.scrollTop=rr.propHooks.scrollLeft={set:function(e){e.elem.nodeType&&e.elem.parentNode&&(e.elem[e.prop]=e.now)}},b.each(["toggle","show","hide"],function(e,t){var n=b.fn[t];b.fn[t]=function(e,r,i){return null==e||"boolean"==typeof e?n.apply(this,arguments):this.animate(ir(t,!0),e,r,i)}}),b.fn.extend({fadeTo:function(e,t,n,r){return this.filter(nn).css("opacity",0).show().end().animate({opacity:t},e,n,r)},animate:function(e,t,n,r){var i=b.isEmptyObject(e),o=b.speed(t,n,r),a=function(){var t=er(this,b.extend({},e),o);a.finish=function(){t.stop(!0)},(i||b._data(this,"finish"))&&t.stop(!0)};return a.finish=a,i||o.queue===!1?this.each(a):this.queue(o.queue,a)},stop:function(e,n,r){var i=function(e){var t=e.stop;delete e.stop,t(r)};return"string"!=typeof e&&(r=n,n=e,e=t),n&&e!==!1&&this.queue(e||"fx",[]),this.each(function(){var t=!0,n=null!=e&&e+"queueHooks",o=b.timers,a=b._data(this);if(n)a[n]&&a[n].stop&&i(a[n]);else for(n in a)a[n]&&a[n].stop&&Jn.test(n)&&i(a[n]);for(n=o.length;n--;)o[n].elem!==this||null!=e&&o[n].queue!==e||(o[n].anim.stop(r),t=!1,o.splice(n,1));(t||!r)&&b.dequeue(this,e)})},finish:function(e){return e!==!1&&(e=e||"fx"),this.each(function(){var t,n=b._data(this),r=n[e+"queue"],i=n[e+"queueHooks"],o=b.timers,a=r?r.length:0;for(n.finish=!0,b.queue(this,e,[]),i&&i.cur&&i.cur.finish&&i.cur.finish.call(this),t=o.length;t--;)o[t].elem===this&&o[t].queue===e&&(o[t].anim.stop(!0),o.splice(t,1));for(t=0;a>t;t++)r[t]&&r[t].finish&&r[t].finish.call(this);delete n.finish})}});function ir(e,t){var n,r={height:e},i=0;for(t=t?1:0;4>i;i+=2-t)n=Zt[i],r["margin"+n]=r["padding"+n]=e;return t&&(r.opacity=r.width=e),r}b.each({slideDown:ir("show"),slideUp:ir("hide"),slideToggle:ir("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(e,t){b.fn[e]=function(e,n,r){return this.animate(t,e,n,r)}}),b.speed=function(e,t,n){var r=e&&"object"==typeof e?b.extend({},e):{complete:n||!n&&t||b.isFunction(e)&&e,duration:e,easing:n&&t||t&&!b.isFunction(t)&&t};return r.duration=b.fx.off?0:"number"==typeof r.duration?r.duration:r.duration in b.fx.speeds?b.fx.speeds[r.duration]:b.fx.speeds._default,(null==r.queue||r.queue===!0)&&(r.queue="fx"),r.old=r.complete,r.complete=function(){b.isFunction(r.old)&&r.old.call(this),r.queue&&b.dequeue(this,r.queue)},r},b.easing={linear:function(e){return e},swing:function(e){return.5-Math.cos(e*Math.PI)/2}},b.timers=[],b.fx=rr.prototype.init,b.fx.tick=function(){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length||b.fx.stop(),Xn=t},b.fx.timer=function(e){e()&&b.timers.push(e)&&b.fx.start()},b.fx.interval=13,b.fx.start=function(){Un||(Un=setInterval(b.fx.tick,b.fx.interval))},b.fx.stop=function(){clearInterval(Un),Un=null},b.fx.speeds={slow:600,fast:200,_default:400},b.fx.step={},b.expr&&b.expr.filters&&(b.expr.filters.animated=function(e){return b.grep(b.timers,function(t){return e===t.elem}).length}),b.fn.offset=function(e){if(arguments.length)return e===t?this:this.each(function(t){b.offset.setOffset(this,e,t)});var n,r,o={top:0,left:0},a=this[0],s=a&&a.ownerDocument;if(s)return n=s.documentElement,b.contains(n,a)?(typeof a.getBoundingClientRect!==i&&(o=a.getBoundingClientRect()),r=or(s),{top:o.top+(r.pageYOffset||n.scrollTop)-(n.clientTop||0),left:o.left+(r.pageXOffset||n.scrollLeft)-(n.clientLeft||0)}):o},b.offset={setOffset:function(e,t,n){var r=b.css(e,"position");"static"===r&&(e.style.position="relative");var i=b(e),o=i.offset(),a=b.css(e,"top"),s=b.css(e,"left"),u=("absolute"===r||"fixed"===r)&&b.inArray("auto",[a,s])>-1,l={},c={},p,f;u?(c=i.position(),p=c.top,f=c.left):(p=parseFloat(a)||0,f=parseFloat(s)||0),b.isFunction(t)&&(t=t.call(e,n,o)),null!=t.top&&(l.top=t.top-o.top+p),null!=t.left&&(l.left=t.left-o.left+f),"using"in t?t.using.call(e,l):i.css(l)}},b.fn.extend({position:function(){if(this[0]){var e,t,n={top:0,left:0},r=this[0];return"fixed"===b.css(r,"position")?t=r.getBoundingClientRect():(e=this.offsetParent(),t=this.offset(),b.nodeName(e[0],"html")||(n=e.offset()),n.top+=b.css(e[0],"borderTopWidth",!0),n.left+=b.css(e[0],"borderLeftWidth",!0)),{top:t.top-n.top-b.css(r,"marginTop",!0),left:t.left-n.left-b.css(r,"marginLeft",!0)}}},offsetParent:function(){return this.map(function(){var e=this.offsetParent||o.documentElement;while(e&&!b.nodeName(e,"html")&&"static"===b.css(e,"position"))e=e.offsetParent;return e||o.documentElement})}}),b.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(e,n){var r=/Y/.test(n);b.fn[e]=function(i){return b.access(this,function(e,i,o){var a=or(e);return o===t?a?n in a?a[n]:a.document.documentElement[i]:e[i]:(a?a.scrollTo(r?b(a).scrollLeft():o,r?o:b(a).scrollTop()):e[i]=o,t)},e,i,arguments.length,null)}});function or(e){return b.isWindow(e)?e:9===e.nodeType?e.defaultView||e.parentWindow:!1}b.each({Height:"height",Width:"width"},function(e,n){b.each({padding:"inner"+e,content:n,"":"outer"+e},function(r,i){b.fn[i]=function(i,o){var a=arguments.length&&(r||"boolean"!=typeof i),s=r||(i===!0||o===!0?"margin":"border");return b.access(this,function(n,r,i){var o;return b.isWindow(n)?n.document.documentElement["client"+e]:9===n.nodeType?(o=n.documentElement,Math.max(n.body["scroll"+e],o["scroll"+e],n.body["offset"+e],o["offset"+e],o["client"+e])):i===t?b.css(n,r,s):b.style(n,r,i,s)},n,a?i:t,a,null)}})}),e.jQuery=e.$=b,"function"==typeof define&&define.amd&&define.amd.jQuery&&define("jquery",[],function(){return b})})(window);

jQuery.noConflict();

/*  file:7  */
/**
 * Copyright 2006  Mipang.com.
 * All Rights Reserved.
 */


/**
 * Mipang's Places Class. version 2
 *
 * SmartPlaceInput{} 
 ** require global.js **
 */


var _mp_spi_top_win = window;

function MP_SmartPlaceInput(initParams){
    /**admin url*/
    this.AdminUrl= "/places/place_admin_xml.ue";
    this.SearchUrl = "/places/place_search_xml.ue";



    if(typeof MIPANG != 'undefined' && typeof MIPANG.location != 'undefined')
	this.main_url = MIPANG.location.scheme+'://'+MIPANG.location.main_host;
    else
	this.main_url = '';


    this.EXT = {};
    this.initialized = false;
    /**init me*/
    this.init(initParams);
}

MP_SmartPlaceInput.prototype.init=function(params){
    /**
      params:
      textfield: 
     */
    if(this.initialized) return;
    
    if(typeof params != 'object')
	return;
    
    var EXT=this.EXT;
    EXT.instance = this;

    EXT.textfield = GetElement(window,params.textfield);
    EXT.textfield.EXT = EXT;


    EXT.MyPlaces = params.places||[];
    EXT.onselect = params.onselect||function(pid,name,pname){};

    EXT.SetSelect = function(pid,name,pname){
	EXT.place_selected = [pid,name];

	var textbox = this.textfield;
	textbox.value = name;
	this.onselect(pid,name,pname);
	RemoveClass(textbox,'pending');
	RemoveClass(textbox,'error');
	AddClass(textbox,'valid');
    };

    EXT.CleanSelect = function(){
	var textbox = this.textfield;
	this.onselect(0,textbox.value,'');
	RemoveClass(textbox,'valid');
    };

    /** place[pd] Define (Ajax Stuff)*/
    EXT.pf = {
	id:0,/**Place ID*/
	name:1,/**Place Name*/
	aka:2,/** Place's Aka */
	aka2:3,
	pname:4/** Parent Place Name*/
    };
    
    /**init selected place*/
    if(params.selected){
	EXT.place_selected = params.selected;
	EXT.SetSelect(params.selected[0],params.selected[1],params.selected[2]?params.selected[2]:'');
    }else
	EXT.place_selected = [0,''];


    this.initialized = true;

    /**init AC_states*/
    AC_states.put(window.name + EXT.textfield.id, new AC_state());

    /**textfield event attach...*/
    this.InitTextbox();
};

MP_SmartPlaceInput.prototype.InitTextbox=function(){
    if(!this.initialized) return;
    
    var win = window;
    var EXT = this.EXT;
    var box = EXT.textfield;

    try{
	if(!box.style) box.setAttribute('style','');
	box.style.MozUserSelect='none';
    }catch(e1){}
    try{
	box.style.unselectable='on';
	box.setAttribute('autocomplete','off');
	box.setAttribute('disableautocomplete',true);
    }catch(e2){}
    
    box.onclick=function(e){
	if(this.placebox_timeout)
	    clearTimeout(this.placebox_timeout);
	if(this.addguide_timeout)
	    clearTimeout(this.addguide_timeout);

	this.placebox_show = false;
	this.addguide_show = false;

	/**hide fist.*/
	this.EXT.instance.HideMyPlaces.call(EXT.instance);
	this.EXT.instance.HideAddGuide.call(EXT.instance);
	this.EXT.instance.AC_HideHints.call(EXT.instance);
	
	this.EXT.instance.ShowMyPlaces.call(EXT.instance);
	
    };
    box.onblur=function(e){

	this.EXT.instance.AC_HideHints.call(EXT.instance);

	if( !this.placebox_show ){
	    if(this.placebox_timeout)
		clearTimeout(this.placebox_timeout);

	    this.EXT.instance.HideMyPlaces.call(EXT.instance);

	}
	if( !this.addguide_show ){
	    if(this.addguide_timeout)
		clearTimeout(this.addguide_timeout);

	    this.EXT.instance.HideAddGuide.call(EXT.instance);
	}
    };

    /**key event*/
    box.onkeyup=function(e){
	e = e ? e : win.event;
	var keycode = EV_GetKeyCode(e);
	
	if( typeof box.oldvalue == 'undefined') box.oldvalue='';

	switch (keycode) {
	case 9:
	case 38:/**up*/ case 40:/**down*/
	case 27:/**esc*/
	case 37:/**left*/ case 39:/**right*/ 
	    return;
	case 188:/** , */
	case 13:/**enter*/
	    if(AC_cancel_keystroke)
		return;
	default:
	}

	if(this.EXT.query_timeout)
	    clearTimeout(this.EXT.query_timeout);
	
	box.oldvalue = box.value;

	this.EXT.CleanSelect();
	
	var key = Trim(this.EXT.textfield.value);
	var domain = 0;

	/**sub query??*/
	if(/^[^,，，]+[,，，]/.test(key) && key.replace(/[,，，].*$/,'') == this.EXT.place_selected[1]  && this.EXT.place_selected[0]){
	    domain = this.EXT.place_selected[0];
	    key = key.replace(/^[^,，，]*[,，，]/,'');
	    this.EXT.place_search_key = key;
	}else
	    this.EXT.place_search_key = key;

	this.EXT.query_timeout = setTimeout(
					    function(){
						EXT.instance.AC_QueryMatchPlaces.call(
										      EXT.instance,
										      key,
										      domain
										      );
					    },300);
    };
    /***/


    box.onkeydown = function(e) {
	return _mp_spi_top_win.AC_OnKeyDown(win, this, e);
    };
    box.onkeypress = function(e) {
	return _mp_spi_top_win.AC_OnKeyPress(win, this, e);
    };
    
    /**
      box.onblur = function() {
      _mp_spi_top_win.AC_OnBlur(win, this);
      };
    */
    
    box.onfocus = function() {
	/**this.EXT.instance.AC_UpdateHints.call(this.EXT.instance);*/
    };
    
    /**
      box.onclick = function() {
      _mp_spi_top_win.AC_UpdateHintsNow(win, this.id);
      };
    */
    

};

MP_SmartPlaceInput.prototype.ShowMyPlaces=function(){
    if(!this.initialized) return;

    var EXT = this.EXT;
    var h = [""];

    h.push('<div class="bdlBlue" style="border-width:1px;border-style:solid;padding:1px;text-align:left;"><div class="bglBlue2" style="padding:5px;">');
    /**h.push('<div style="height:18px;width:240px;">'
	   +(EXT.MyPlaces.length?'从下列地方中选取或':'')
	   +'<span style="color:red;">直接输入地名</span>(<a href="/help/faq.ue#psi" target="_blank">帮助</a>)</div>');
    **/

    h.push('<div style=""><span class="Red">提示</span>：请尽量输入<b>短地名</b>。');
    h.push('<br/>如 西湖，而不是 杭州西湖');
    h.push('<br/>如 临海，而不是 临海市');
    h.push('</div>');
    

    if(EXT.MyPlaces.length && 0){
	h.push('<table cellpadding="0" cellspacing="0" border="0"><tbody><tr><td style="padding:0;vertical-align:top;">');
	h.push('<ul class="pl" style="">');
	
	var cn = Math.ceil(EXT.MyPlaces.length/3);

	for(var i=0;i<EXT.MyPlaces.length;i++){
	    var p=EXT.MyPlaces[i];
	    h.push('<li><span class="l" onclick="javascript:_ge(\''+EXT.textfield.id+'\').EXT.SetSelect('+p[0]+',\''+StrSafeInline(p[1])+'\',\''+StrSafeInline(p[2]?p[2]:'')+'\');">'+HtmlEscape(p[1])+'</span></li>');
	    
	    if(!((i+1)%cn))
		h.push('</ul></td><td style="padding:0;vertical-align:top;"><ul class="pl" style="">');
	}
	
	h.push('</ul>');
	h.push('</td></tr></tbody></table>');
    }else{
	/**
	h.push('<div class="DateTime"><span>很抱歉，还没有你的地方信息<!--，可能是你还没有登录-->；<br/>你可以直接在输入框中输入地名。</span></div>');
	*/

    }
    
    h.push('<div class="ClearBreak"></div></div></div>');
    
    var textfield = EXT.textfield;
    var div = CreateDIV(window, "eps");
    div.innerHTML = h.join("");
    var s = div.style;
    s.zIndex=500;
    if (s.display != "block") {
	s.display = "block";
	s.top = (GetPageOffsetTop(textfield) + textfield.offsetHeight + 0) + "px";
	s.left = GetPageOffsetLeft(textfield) + "px";
    }
    /**s.overflow='auto';*/


    /** build iframe **/
    var iframe = _ge('eps-iframe');
    if(!iframe){
	iframe = document.createElement('iframe');
	iframe.id = 'eps-iframe';
	iframe.frameBorder='0';
	iframe.setAttribute('style','');
	iframe.style.position='absolute';
	document.body.insertBefore(iframe,document.body.firstChild);
    }

    iframe.style.left = div.style.left;
    iframe.style.top = div.style.top;
    iframe.style.width = div.offsetWidth + 'px';
    iframe.style.height = div.offsetHeight + 'px';
    iframe.style.display = '';

    /**event attach*/
    div.onmouseover=function(e){
	var textfield = EXT.textfield;
	if(textfield.placebox_timeout)
	    clearTimeout(textfield.placebox_timeout);
	
	textfield.placebox_show = true;
    };
    div.onmouseout=function(e){
	var textfield = EXT.textfield;
	if(textfield.placebox_timeout)
	    clearTimeout(textfield.placebox_timeout);
	textfield.placebox_timeout = setTimeout(function(){
		textfield.placebox_show=false;
		textfield.EXT.instance.HideMyPlaces.call(textfield.EXT.instance);
	    },200);
    };


};

MP_SmartPlaceInput.prototype.ShowAddGuide=function(){
    if(!this.initialized) return;

    var EXT = this.EXT;
    var textfield = EXT.textfield;

    var key = Trim(this.EXT.textfield.value);
    var domain = 0;

    /**sub query??*/
    if(/^[^,，，]+[,，，]/.test(key) && key.replace(/[,，，].*$/,'') == this.EXT.place_selected[1]  && this.EXT.place_selected[0]){
	domain = this.EXT.place_selected[0];
	key = key.replace(/^[^,，，]*[,，，]/,'');
    }



    var h = [""];

    h.push('<div class="bdlBlue" style="border-width:1px;border-style:solid;padding:1px;text-align:left;"><div class="bglBlue2_" style="padding:5px;background-color:#ffffcc;">');
    
    h.push('找不到这个地方，请尽量输入<b>短地名</b>。');
    h.push('<br/>如 西湖，而不是 杭州西湖');
    h.push('<br/>如 临海，而不是 临海市');
    
    h.push('<br/><br/>也有可能米胖还没有收录&quot;'+HtmlEscape(key)+'&quot;这个地方，<br/>没关系，你可以马上<a href="'+this.main_url+'/places/new?domain='+(domain?domain:'')+'&amp;name='+UrlEncode(key)+'" target="_blank">添加&quot;'+HtmlEscape(key)+'&quot;</a>到米胖。');
    
    h.push('<div class="ClearBreak"></div></div></div>');
    

    var div = CreateDIV(window, "pag");
    div.innerHTML = h.join("");
    var s = div.style;
    s.zIndex=500;
    if (s.display != "block") {
	s.display = "block";
	s.top = (GetPageOffsetTop(textfield) + textfield.offsetHeight + 0) + "px";
	s.left = GetPageOffsetLeft(textfield) + "px";
    }
    /**s.overflow='auto';*/


    /** build iframe **/
    var iframe = _ge('pag-iframe');
    if(!iframe){
	iframe = document.createElement('iframe');
	iframe.id = 'pag-iframe';
	iframe.frameBorder='0';
	iframe.setAttribute('style','');
	iframe.style.position='absolute';
	document.body.insertBefore(iframe,document.body.firstChild);
    }

    iframe.style.left = div.style.left;
    iframe.style.top = div.style.top;
    iframe.style.width = div.offsetWidth + 'px';
    iframe.style.height = div.offsetHeight + 'px';
    iframe.style.display = '';


    /**event attach*/
    div.onmouseover=function(e){
	var textfield = EXT.textfield;
	if(textfield.addguide_timeout)
	    clearTimeout(textfield.addguide_timeout);
	
	textfield.addguide_show = true;
    };
    div.onmouseout=function(e){
	var textfield = EXT.textfield;
	if(textfield.addguide_timeout)
	    clearTimeout(textfield.addguide_timeout);
	textfield.addguide_timeout = setTimeout(function(){
		textfield.addguide_show=false;
		textfield.EXT.instance.HideAddGuide.call(textfield.EXT.instance);
	    },10000);
    };

};
MP_SmartPlaceInput.prototype.HideAddGuide=function(){
    if(!this.initialized) return;
    try{
	ShowElement(GetElement(window,"pag"),false);
	_ge('pag-iframe').style.display = 'none';
    }catch(e){}

};

MP_SmartPlaceInput.prototype.HideMyPlaces=function(){
    if(!this.initialized) return;
    try{
	ShowElement(GetElement(window,"eps"),false);
	_ge('eps-iframe').style.display='none';
    }catch(e){}

};
MP_SmartPlaceInput.prototype.AC_HideHints=function(){
    if(!this.initialized) return;
    try{
	AC_HideHints(window);
    }catch(e){}
};

MP_SmartPlaceInput.prototype.AC_HideHintsNow=function(){
    if(!this.initialized) return;
    try{
	AC_HideHintsNow(window);
    }catch(e){}
};

/**
 * Auto Complete
 */

/**Ajax Stuff*/
MP_SmartPlaceInput.prototype.AC_QueryMatchPlaces=function(keyword,domain){
    /**
      keyworld: piece of place name
      domain: placeID,search in this domain
    */
    if(!this.initialized) return;

    if(!keyword && !domain) return;
    
    var EXT = this.EXT;

    /*************Cache************/
    var places = null;
    if( ( places=AC_CacheLookup(keyword,domain) ) ){
	
	RemoveClass(EXT.textfield,'valid');
	RemoveClass(EXT.textfield,'pending');
	RemoveClass(EXT.textfield,'error');

	this.AC_UpdateMatchs(places);
	
	this.AC_UpdateHints();
	
	return;
	/**use cache data,just return here*/
    }

    /**************END Cache**************/

    /**set callback stuff*/
    EXT.QueryMatchPlaces_onLoad = function(success,rsXML,rsText,params,CBParams){
	RemoveClass(EXT.textfield,'valid');
	RemoveClass(EXT.textfield,'pending');
	RemoveClass(EXT.textfield,'error');

	if(success.code!=0){
	    /**for debug*/
	    /**alert('发生错误(#'+success.code+'):'+success.desc);*/
	    
	    AddClass(EXT.textfield,'error');
	    return;
	}
	/**success.*/
	var places = null;
	try{
	    var doc = rsXML.documentElement;
	    var t = doc.getElementsByTagName('places');
	    var ts = getNodeValue(t[0]);
	    places = eval(ts);
	}catch(e){
	    places = [];
	}

	try{
	if( places[0][0]<=0 && params.q ){
	    this.instance.HideMyPlaces(this.instance);
	    this.instance.AC_HideHints(this.instance);
	    this.instance.ShowAddGuide(this.instance);
	    return;
	}
	}catch(e){}

	this.instance.AC_UpdateMatchs.call(this.instance,places);

	this.instance.AC_UpdateHints.call(this.instance);

	/**cache it*/
	AC_CacheAdd(params.q,places,params.domain);
	
    };
    
    /**do request*/
    var  params={
	action:'Search',
	q:keyword,
	domain:domain
    };

    /**show status*/
    RemoveClass(this.EXT.textfield,'valid');
    RemoveClass(this.EXT.textfield,'error');
    AddClass(this.EXT.textfield,'pending');

    MyAPI.callMethod('QueryMatchPlaces',params,EXT,null,this.SearchUrl);
    
};

MP_SmartPlaceInput.prototype.AC_UpdateMatchs=function(places){
    if(!this.initialized) return;
    
    var EXT =this.EXT;
    var textbox = EXT.textfield;

    var state = AC_GetState(window,textbox.id);
    AssertTrue(state);

    if(places[1] && places[1].length){
	state.match_info.places = places[1];
	state.match_info.match_num = places[0][0];
	state.match_info.match_total = places[0][1];

	if(state.selected_match == -1)
	    state.selected_match = 0;

    }else
	state.clear();

};

MP_SmartPlaceInput.prototype.AC_UpdateHints=function()
{
    if(!this.initialized) return;
    
    var EXT = this.EXT;
    var textbox = EXT.textfield;

    AC_UpdateHints(window,textbox);
    
};

MP_SmartPlaceInput.prototype.AC_RenderHintsWindow=function()
{
    if(!this.initialized) return;

    this.HideMyPlaces();
    this.HideAddGuide();
    
    var EXT = this.EXT;
    var textbox = EXT.textfield;

    if (!AC_IsActiveTextboxId(window, textbox.id)) {
	this.AC_HideHintsNow();
    }
    AC_SetActiveTextboxId(window, textbox.id);

    var win = window;

    var pf = this.EXT.pf;
    
    var state = AC_GetState(win,textbox.id);

    var ListSize = 20; /**be equal to AC_SetSelection()*/

    var key = String(EXT.place_search_key).toLowerCase();

    /**sub query?*/
    var keyOrig = Trim(textbox.value);
    var domain = 0;

    /**sub query??*/
    if(/^[^,，，]+[,，，]/.test(keyOrig) && keyOrig.replace(/[,，，].*$/,'') == EXT.place_selected[1]  && EXT.place_selected[0]){
	domain = EXT.place_selected[0];
    }
    /***/


    AssertTrue(state.match_info && state.match_info.places.length > 0);

    var h =['<div class="bdlBlue" style="border-width:1px;padding:1px;">'];
    
    /** add help **/

    h.push('<div style="background-color:;"><span class="Red">提示</span>：用鼠标选取</div>');

    /********/

    h.push('<div class="ac bglBlue2" style="">');
    for (var i = 0; i < state.match_info.places.length && i < ListSize; i++) {
	var place = state.match_info.places[i];
	Debug("Place: " + place);
	h.push(
	       '<span class="l'
	       + ((i == state.selected_match) ? ' sel" ' : '" ') + 'id="' + 'h_' + i + '">' 
	       + (place[pf.pname]? HtmlEscape(place[pf.pname]+','):'') 
	       + AC_FormatPlace(pf,place,key) + '</span>'
	       );
    }

    if(state.match_info.match_num > ListSize)
	h.push('<span class="l" style="text-align:center;font-weight:bold;color:#666;">. . .</span>');
    
    if(state.match_info.places.length && key!='' && String(state.match_info.places[0][pf.name]).toLowerCase() != key)
	h.push('<span class="l" id="hpa_'+Now()+'" style="font-size:12px;background-color:#ffffcc;padding-top:3px;padding-bottom:3px;"><a class="pale_red" href="'+this.main_url+'/places/new?domain='+(domain?domain:'')+'&amp;name='+UrlEncode(key)+'" target="_blank" style="">添加&quot;'+HtmlEscape(key)+'&quot;到米胖</a></span>');
    
    h.push( '</div></div>');
    var div = CreateDIV(win, "hm");
    if(div.hide_timeout)
	clearTimeout(div.hide_timeout);

    div.innerHTML = h.join("");

    var s = div.style;
    s.zIndex=500;
    if (s.display != "block") {
	s.display = "block";
	s.top = (GetPageOffsetTop(textbox) + textbox.offsetHeight)+'px';
	s.left = GetPageOffsetLeft(textbox)+'px';
    }
    /**s.overflow='auto';*/


    /** build iframe **/
    var iframe = _ge('hm-iframe');
    if(!iframe){
	iframe = document.createElement('iframe');
	iframe.id = 'hm-iframe';
	iframe.frameBorder='0';
	iframe.setAttribute('style','');
	iframe.style.position='absolute';
	document.body.insertBefore(iframe,document.body.firstChild);
    }

    iframe.style.left = div.style.left;
    iframe.style.top = div.style.top;
    iframe.style.width = div.offsetWidth + 'px';
    iframe.style.height = div.offsetHeight + 'px';
    iframe.style.display = '';
    
    
    setTimeout(function(){
	    try{ ScrollIntoView(window,div,"m");}catch(e){}
	},100);


    /**attach event*/

    div.onmouseover = function(e){
	e = e ? e : window.event;
	var src = EV_GetEventTarget(e);
	var info = {};
	var dep=3;
	for(;src && dep--;src=src.parentNode){
	    if(src.id && src.id.indexOf('h_') != -1){
		info.id_prefix = 'h_';
		info.type = 6;/**mouse over event*/
		info.id_n = src.id.substr(2);
		AC_MouseMovementHandler(window,info);
	    }
	}
    };

    div.onclick = function(e){
	e = e ? e : window.event;
	var src = EV_GetEventTarget(e);
	var dep=3;
	for(;src && dep--;src=src.parentNode){
	    if(src.id && src.id.indexOf('hpa_') != -1){
		return true;
	    }
	}
	/**else*/
	AC_Complete(window,textbox);
    };

};




var MPP_windata =[];
function GetWindowData(win)
{
    var data = MPP_windata[win.name];
    if (!data) {
	MPP_windata[win.name] = data =[];
    }
    return data;
}

function ClearWindowData(win_name)
{
    if (MPP_windata[win_name]) {
	MPP_windata[win_name] = null;
    }
}

var AC_cache = {
    table:[],/** Array(30)[ domain,'key',new AC_state() ] , key is LowerCase */
    maxlen:50,
    cursor:0
};
var AC_cancel_keystroke;
var AC_states = new Map();

function AC_state()
{
    this.clear();
}

AC_state.prototype.clear = function()
{
    /**this.match_info = null;*/
    this.match_info = [];
    this.match_info.places = [];
    this.match_info.match_num = 0;
    this.match_info.match_total = 0;

    this.selected_match = -1;
    this.cursor_pos = 0;
};
function AC_GetState(win, id)
{
    var state = AC_states.get(win.name + id);
    AssertTrue(state);
    return state;
}

function AC_GetActiveTextboxId(win)
{
    return GetWindowData(win).AC_active;
}

function AC_SetActiveTextboxId(win, id)
{
    GetWindowData(win).AC_active = id;
}

function AC_IsActiveTextboxId(win, id)
{
    return id == GetWindowData(win).AC_active;
}


function AC_FindPlaceIndex(places, cur_place)
{
    for (var i = 0; i < places.length; i++) {
	if (places[i][0] == cur_place[0]) {
	    /**only check place_id*/
	    return i;
	}
    }
    return -1;
}


function AC_OnKeyDown(win, textbox, e)
{
    try {
	e = e ? e : win.event;
	var keycode = EV_GetKeyCode(e);
	AC_cancel_keystroke = false;
	switch (keycode) {
	case 188:/** , */
	case 9:
	    if (e.shiftKey) {
		break;
	    }
	case 13:
	    if (AC_Complete(win, textbox)) {
		AC_HideHintsNow(win);
		AC_cancel_keystroke = true;
	    }
	    break;
	case 38:
	case 40:
	    if (AC_IsActiveTextboxId(win, textbox.id)) {
		AC_MoveSelection(win, textbox, keycode == 38);
		AC_cancel_keystroke = true;
	    }
	    break;
	case 27:
	    break;
	default:/**
	    AC_UpdateHints(win, textbox);
		*/
	}
	return (!AC_cancel_keystroke);
    }
    catch(ex) {
	DumpException(ex);
    }
}
function AC_OnKeyPress(win, textbox, e)
{
    return (!AC_cancel_keystroke);
}

function AC_OnBlur(win, textbox)
{
    try {
	win.setTimeout('_mp_spi_top_win.AC_OnBlur2(window,"' + textbox.id + '")',
		       200);
    }
    catch(ex) {
	DumpException(ex);
    }
}
function AC_OnBlur2(win, id)
{
    try {
	if (AC_IsActiveTextboxId(win, id)) {
	    AC_HideHints(win);
	}
    }
    catch(ex) {
	DumpException(ex);
    }
}

function AC_MouseMovementHandler(win, info)
{
    if (info.id_prefix == "h_" && info.type == 6) {
	var textbox = GetElement(win, AC_GetActiveTextboxId(win));
	AC_SetSelection(win, textbox, parseInt(info.id_n));
    }
}
function AC_UpdateHints(win, textbox)
{

    var windata = GetWindowData(win);
    if (windata.AC_timeout) {
	win.clearTimeout(windata.AC_timeout);
    }
    windata.AC_timeout =
	win.setTimeout('_mp_spi_top_win.AC_UpdateHintsNow(window,"' + textbox.id +
		       '")', 50);
}

function AC_UpdateHintsNow(win, id)
{
    try {
	GetWindowData(win).timeout = null;
	var textbox = GetElement(win, id);
	var state = AC_GetState(win, textbox.id);

	if (textbox.value && state.match_info.places.length ) {
	    var partial = textbox.value;
	    if (partial.length > 0) {
		state.cursor_pos = 0;

		AC_ShowHints(win, textbox, state,
			     (partial));
		return;
	    }
	}
	AC_HideHintsNow(win);
    }
    catch(e) {
	DumpException(e);
    }
}


function AC_GetPartialName(str, cursor){
    var segment=AC_GetEditSegment(str,cursor);
    var partial=str.substring(segment[0],segment[1]);
    return partial.replace(/\"/g,"");
}
function AC_GetEditSegment(str, cursor)
{
    return[AC_GetEditStart(str, cursor), AC_GetEditEnd(str, cursor)];
}

function AC_GetEditStart(str, cursor)
{
    AssertTrue(cursor <= str.length);
    var good_char = cursor - 1;
    for (var i = good_char; i >= 0; i--) {
	var ch = str.charAt(i);
	if (ch == ',') {
	    break;
	} else {
	    if (!IsSpace(ch)) {
		good_char = i;
	    }
	}
    }
    return good_char;
}

function AC_GetEditEnd(str, cursor)
{
    AssertTrue(cursor <= str.length);
    var i;
    for (i = cursor; i < str.length; i++) {
	var ch = str.charAt(i);
	if (ch == ',' || ch == '"') {
	    break;
	}
    }
    return i;
}

function AC_Complete(win, textbox)
{
    var state = AC_GetState(win, textbox.id);
    if (state.match_info && state.selected_match >= 0
	&& state.selected_match < state.match_info.places.length
	&& state.cursor_pos >= 0) {
	var places = state.match_info.places;
	var selected = state.selected_match;
	AC_CompleteTo(win, textbox, state,places[selected]);
	return true;
    }
    return false;
}

function AC_CompleteTo(win, textbox, state, place)
{
    var cursor = state.cursor_pos;
    if (cursor >= 0) {
	var textstr = textbox.value;
	var EXT = textbox.EXT;
	var pf = EXT.pf;

	if (is_safari) {
	    win.setTimeout(function() {
		    EXT.SetSelect(place[pf.id],place[pf.name],place[pf.pname]);
			   }
			   , 0);
	} else {
	    EXT.SetSelect(place[pf.id],place[pf.name],place[pf.pname]);
	}

	SetCursorPos(win, textbox,
		     place[pf.name].length);
	state.clear();
	return true;
    }
    return false;
}


function AC_MatchSubstring(str, substr)
{
    for (var pos = 0;; pos++) {
	pos = str.indexOf(substr, pos);
	if (pos < 0) {
	    return -1;
	}
	return pos;
	/**
	  if (pos == 0 || !IsLetterOrDigit(str.charAt(pos - 1))) {
	  return pos;
	  }
	*/
    }
}
function AC_MoveSelection(win, textbox, up)
{
    var dir = (up) ? -1 : 1;
    var state = AC_GetState(win, textbox.id);
    AC_SetSelection(win, textbox, state.selected_match + dir);
}

function AC_SetSelection(win, textbox, pos)
{
    var state = AC_GetState(win, textbox.id);
    AssertTrue(textbox && state);
    if (pos != state.selected_match && state.match_info != null && pos >= 0
	&& pos < state.match_info.places.length && pos < 20) {
	state.selected_match = pos;
	AC_RenderHintsWindow(win, textbox, state);
    }
}
function AC_ShowHints(win, textbox, state, str)
{
    var curr_place = null;
    if (state.selected_match > 0 && state.selected_match < state.match_info.places.length) {
	/**curr_place = state.match_info.places[state.selected_match];*/
    }
    if (state.match_info && state.match_info.places.length > 0) {
	state.selected_match = 0;
	if (curr_place) {
	    var new_index =
		AC_FindPlaceIndex(state.match_info.places,
				    curr_place);
	    if (new_index >= 0) {
		state.selected_match = new_index;
	    }
	}
	AC_RenderHintsWindow(win, textbox, state);
    } else {
	AC_HideHintsNow(win);
    }
}

function AC_RenderHintsWindow(win,textbox,state)
{
    try{
	var instance = textbox.EXT.instance;
	instance.AC_RenderHintsWindow.call(instance);
    }catch(e){}
}

function AC_HideHints(win)
{
    var h = GetElement(win,"hm");
    h.hide_timeout = setTimeout("_mp_spi_top_win.AC_HideHintsNow(window)",200);
}

function AC_HideHintsNow(win)
{
    var h = GetElement(win, "hm");
    if (h) {
	ShowElement(h, false);
	try{_ge('hm-iframe').style.display='none';}catch(ex){}
    }
    var active_id = AC_GetActiveTextboxId(win);
    if (active_id) {
	AC_GetState(win, active_id).clear();
    }
    AC_SetActiveTextboxId(win, null);
    if (MPP_windata.AC_timeout) {
	win.clearTimeout(win.AC_timeout);
	MPP_windata.AC_timeout = null;
    }
}


function AC_FormatPlace(pf,place, keyword)
{

    /**aka1*/
    var aka1 = (place[pf.aka] && AC_MatchSubstring(place[pf.aka].toLowerCase(),keyword)!=-1 ? ( '&nbsp<span style="display:inline;color:#888;padding:0;">' +BoldSubstring(place[pf.aka],keyword) + '</span>') : '');
    
    var aka2 = (place[pf.aka2] && AC_MatchSubstring(place[pf.aka2].toLowerCase(),keyword)!=-1 ? ( (place[pf.aka] && aka1 ?',':'&nbsp;') + '<span style="display:inline;color:#888;padding:0;">' +BoldSubstring(place[pf.aka2],keyword) + '</span>') : '');
	    
    return BoldSubstring(place[pf.name], keyword) + aka1 + aka2;
}

function BoldSubstring(str, prefix)
{
    if (prefix != "") {
	var pos = AC_MatchSubstring(str.toLowerCase(), prefix);
	if (pos != -1) {
	    return (HtmlEscape(str.substr(0, pos)) + "<b>" +
		    HtmlEscape(str.substr(pos, prefix.length)) + "</b>" +
		    HtmlEscape(str.substr(pos + prefix.length)));
	}
    }
    return HtmlEscape(str);
}


function AC_CacheLookup(keyword,domain)
{
    var key = String(keyword).toLowerCase();
    domain = domain ? domain : 0;

    for(var i=0;i<AC_cache.table.length;i++){
	if( key == AC_cache.table[i][1] && domain == AC_cache.table[i][0] ){
	    /**get it*/
	    var state = AC_cache.table[i][2];

	    var r =  [ [state.match_info.match_num,state.match_info.match_total]
		    ,state.match_info.places ];
	    return r;
	    
	}
    }

    return null;

}
function AC_CacheAdd(keyword,places,domain)
{

    var key = String(keyword).toLowerCase();
    domain = domain ? domain : 0;
    
    var state = new AC_state();

    if(places[1] && places[1].length){
	state.match_info.places = places[1];
	state.match_info.match_num = places[0][0];
	state.match_info.match_total = places[0][1];

	if(state.selected_match == -1)
	    state.selected_match = 0;
	
	/**replace the old one*/
	var dup=0;
	for(var i=0;i<AC_cache.table.length;i++){
	    if(key == AC_cache.table[i][1] && domain == AC_cache.table[i][0]){
		AC_cache.table[i] = [ domain,key,state ];
		dup++;
	    }
	}
	
	if(!dup){
	    var cur = AC_cache.cursor;
	    var maxlen = AC_cache.maxlen;
	    AC_cache.table[ cur % maxlen ] = null;
	    AC_cache.table[ cur % maxlen ] = [ domain,key,state ];
	    
	    AC_cache.cursor = (cur + 1) % maxlen;
	}
    }
   
}

/*  file:8  */
/**
 * Copyright 2006-2007  Mipang.com.
 * All Rights Reserved.
 *
 * Author: RuanChunping 
 * Email: ruanchunping@gmail.com
 * Blog: http://nukq.malmam.com
 **/

/**
 * PlaceMagic Class v0 
 * require global.js
 */

function PlaceMagic(initparams)
{
    this.initialized=false;
    this.EXT = {};
    this.instance = this;
    this.callback=null;
    this.init(initparams);
}

PlaceMagic.prototype.init=function(params)
{
    this.initialized = true;

    var EXT = this.EXT;

    EXT.NodeCache = {size:10,current:0,pool:[]};

    ExportHandle(this,'_PlaceMagic_Class_');

    
    if(typeof MIPANG != 'undefined' && typeof MIPANG.location != 'undefined'){
	this.static_url = 'http://'+MIPANG.location.static_host;
	this.travel_url = 'http://'+MIPANG.location.travel_host;
	this.main_url = 'http://'+MIPANG.location.main_host;
    }else{
	this.static_url = '';
	this.travel_url = '';
	this.main_url = '';
    }
};

PlaceMagic.prototype.ShowNode=function(place_id,e,xy,noget)
{
    if(!this.initialized) return;
    
    var EXT = this.EXT;

    try{

    e = e || window.event;

    e.cancelBubble=true;
    if("stopPropagation" in e){
	e.stopPropagation();
    }

    if(("cancelBubble" in e ) || ("stopPropagation" in e)){
	EXT.__disable_bubble_fix = true;
    }

    }catch(ex){

    }

    /** check cache */

    var has_cache = false;

    var c_len = EXT.NodeCache.pool.length;
    var node = null;
    for(var i=0;i<c_len;i++){
	if(EXT.NodeCache.pool[i]['place']['id'] == place_id){
	    node = EXT.NodeCache.pool[i];
	    has_cache = true;
	    break;
	}
    }

    /************/
    if(xy && !has_cache){
	/** show loading */
	if(typeof xy == 'string'){
	    
	    try{ _ge(xy).className = 'loading-bg';}catch(eee){}

	}else{

	    var lbox = CreateDIV2(window,'pm-loading-box');
	    if(!lbox.style)
		lbox.setAttribute('style','');
	    
	    var s = lbox.style;

	    s.left = xy[0]+'px';
	    s.top = xy[1]+'px';
	    s.visibility = 'visible';
	    s.display = 'block';

	}
    }else{
	/** hide loading */

	var lbox = CreateDIV2(window,'pm-loading-box');
	lbox.style.visibility = 'hidden';
	lbox.style.display = 'none';
    }


    if(!has_cache && !noget){
	/** get Node */

	this.GetNode(place_id,{show:true});
	return;
    }

    /**alert(node['list'].length);**/

    if(node['list'].length==0){

	window.location.href = this.travel_url + '/'+place_id+'/';
	return;
    }


    var expand_img = [this.static_url+'/places/index_view/btn_expand_13_4.png',13,13];

    var h=[];

    var loading_id = 'pm-loading-id-'+place_id+'-'+(new Date()).getTime();

    h.push('<div>');
    
    h.push('<table cellpadding="0" cellspacing="0" width="100%" border="0"><tr>');
    

    h.push('<td style="padding:0;"><h1 class="pm-header">');
    if(place_id!=0)
	h.push('<a title="展开" href="javascript:void(0);" onclick="javascript:window.'+this.handle_str+'.ShowNode(0,null,\''+loading_id+'\');return false;"><img src="'+expand_img[0]+'" alt="" title="展开" width="'+expand_img[1]+'" height="'+expand_img[2]+'" style="vertical-align:middle;" class="trans_png" /></a> ');
    h.push('<a href="'+this.travel_url+'" target="_blank" title="目的地">目的地</a>');

    for(var i=0;i<node['path'].length;i++){
	var p = node['path'][i];
	if(i>0 || 1)
	    h.push(' &gt; ');
	
	if(p['id']!=place_id)
	    h.push('<a title="展开" href="javascript:void(0);" onclick="javascript:window.'+this.handle_str+'.ShowNode('+p['id']+',null,\''+loading_id+'\');return false;"><img src="'+expand_img[0]+'" alt="" title="展开" width="'+expand_img[1]+'" height="'+expand_img[2]+'" style="vertical-align:middle;" class="trans_png" /></a> ');
	h.push('<a href="'+this.travel_url+'/'+p['id']+'/" target="_blank" title="'+HtmlEscape(p['name']+(p['aka']?' - ':'')+p['aka'])+'">'+HtmlEscape(p['name'])+'</a>');
    }
    h.push('</h1></td>');
    
    h.push('<td style="padding:0;width:60px;text-align:right;" class="" id="'+loading_id+'">');
    h.push('<a href="#" onclick="javascript:window.'+this.handle_str+'.CloseNode();return false;" target="_self"><img src="'+this.static_url+'/places/index_view/close_40_2.png" class="trans_png" style="float:right;width:40px;height:40px;" /></a>');

    h.push('</td></tr></table>');
    
    h.push('<div class="pm-content">');

    /** no table format **/
    for(var i=0;0/**disabled*/ && i<node['list'].length;i++){
	var p = node['list'][i];
	
	if(i>0)
	    h.push(' &nbsp; &nbsp; ');
	
	h.push('<span class="item">');
	if(p['has_child']){
	    h.push('<a title="展开" href="javascript:void(0);" onclick="javascript:window.'+this.handle_str+'.ShowNode('+p['id']+',null,\''+loading_id+'\');return false;"><img src="'+expand_img[0]+'" alt="" title="展开" width="'+expand_img[1]+'" height="'+expand_img[2]+'" style="vertical-align:middle;" class="trans_png" /></a> ');
	}else{
	    h.push('<img src="'+this.static_url+'/images/cleardot.gif" width="'+expand_img[1]+'" height="'+expand_img[2]+'" alt="" />');
	}
	h.push('<a href="'+this.travel_url+'/'+p['id']+'/" target="_blank">'+HtmlEscape(p['name'])+'</a></span>');
    }
    /** */

    /** table format list */
    var tb_cols = 8;
    h.push('<table cols="'+tb_cols+'" style="width:100%;border:0;" cellspacing="0" cellpadding="0" border="0"><tbody><tr>');

    for(var i=0,j=0;i<node['list'].length;i++){
	var p = node['list'][i];
	var new_row = false;
	var colspan = 1;

	var cp = 'azAZ09';
	var nl = String(p['name']).length;
	var al = 0;/** alpha char count */
	var cl = 0;/** multi-byte char count */

	var ds = ''; /** debug */
	for(var k=0;nl && k<nl;k++){
	    var c = String(p['name']).charCodeAt(k);
	    ds+=c+'|';/** debug*/
	    
	    if( (c>=cp.charCodeAt(0) && c<=cp.charCodeAt(1))
		|| (c>=cp.charCodeAt(2) && c<=cp.charCodeAt(3))
		|| (c>=cp.charCodeAt(4) && c<=cp.charCodeAt(5))
		){
		al++;
	    }else{
		cl++;
	    }
	}

	/** cal the colspan **/
	
	if((cl+1)>5){
	    colspan+=Math.ceil((cl+1)/5) - 1;
	}/**else if(cl>5){
	    colspan+=2;
	}else if(cl>7){
	    colspan+=3;
	    }*/

	if((al+2)>10){
	    colspan+=Math.ceil((al+2)/10) - 1;
	}/**else if(al>15){
	    colspan+=2;
	}else if(al>21){
	    colspan+=3;
	    }*/
	
	if(colspan > tb_cols)
	    colspan = tb_cols;
	
	var _j = j;
	if( ( (j%tb_cols) + colspan - 1 >= tb_cols) 
	    ){
	    i--;
	    j=0;
	    h.push('</tr><tr>');
	    continue;
	}else{
	    j += colspan;
	} 

	h.push('<td class="item"'+(colspan>1?(' colspan="'+colspan+'"'):'')+' style="width:'+(100/tb_cols*colspan)+'%" >');
	
	/**h.push(colspan+'/'+_j+'<br>');*/

	/** h.push(al+','+cl+' :: '); for debug **/
	
	/** h.push(ds+'<br>'); for debug **/

	if(p['has_child']){
	    h.push('<a title="展开" href="javascript:void(0);" onclick="javascript:window.'+this.handle_str+'.ShowNode('+p['id']+',null,null);return false;"><img src="'+expand_img[0]+'" alt="" title="展开" width="'+expand_img[1]+'" height="'+expand_img[2]+'" style="vertical-align:middle;" class="trans_png" /></a> ');
	}else{
	    h.push('<img src="'+this.static_url+'/images/cleardot.gif" width="'+expand_img[1]+'" height="'+expand_img[2]+'" alt="" /> ');
	}
	h.push('<a href="'+this.travel_url+'/'+p['id']+'/" target="_blank" title="'+HtmlEscape(p['name']+(p['aka']?' - ':'')+p['aka'])+'">'+HtmlEscape(p['name'])+'</a>');

	h.push('</td>');

	if( !(j%tb_cols) || new_row ){
	    j=0;
	    h.push('</tr><tr>');
	}else{
	    
	}
	
    }
    h.push('</tr></tbody></table>');
    /** */
    
    h.push('</div>');

    if(place_id!=0){
	h.push('<div style="font-weight:normal;text-align:right;color:#ddd;">没有你要找的地方？<a href="'+this.main_url+'/places/new" target="_blank" style="color:#ddd;">请按此添加</a>！</div>');
    }

    h.push('</div>');

    this._show_box(h.join(''));
};

PlaceMagic.prototype._show_box=function(html)
{
    if(!this.initialized) return;
    
    var EXT = this.EXT;
    
    EXT.__show_timestamp = (new Date()).getTime();
    
    /** create bg/fg box */
    if(!EXT._box_bg){
	EXT._box_bg = CreateDIV2(window,'pm-box-bg');
	if(!EXT._box_bg.style)
	    EXT._box_bg.setAttribute('style','');

	var bef=function(e){e=e||window.event;e.cancelBubble=true;if("stopPropagation" in e){e.stopPropagation();}return false;};
	var bs = EXT._box_bg.style;
	var bg = EXT._box_bg;
	bg.onmousedown=(bg.onmouseup=(bg.onmousemove=(bg.onkeydown=(bg.onkeyup=(bg.onkeypress=(bg.onclick=(bg.ondblclick=bef)))))));

    }

    if(!EXT._box){
	EXT._box = CreateDIV2(window,'pm-box');
	if(!EXT._box.style)
	    EXT._box.setAttribute('style','');

	var bet=function(e){e=e||window.event;e.cancelBubble=true;if("stopPropagation" in e){e.stopPropagation();}return true;};
	var fs = EXT._box.style;
	var bg = EXT._box;
	bg._onmousedown=(bg.onmouseup=(bg._onmousemove=(bg.onkeydown=(bg.onkeyup=(bg.onkeypress=(bg._onclick=(bg.ondblclick=bef)))))));

	bg.onclick=function(){
	    EXT.__pm_box_onclick = true;
	    return true;
	};
    }
    
    /** position them */

    var _this = this;
    if(!window.__box_onscroll){
	window.__box_onscroll = function(){_this._box_resize();};
    }
    if(!window.__doc_onclick){

	window.__doc_onclick = function(e){
	    e = e || window.event;
	    if("button" in e){
		/** ignore right button on firefox */
		if(e.button != 0)
		    return;
	    }
	    /** alert(EXT.__pm_box_onclick);*/
	    if(EXT.__pm_box_onclick){
		EXT.__pm_box_onclick = false;
		return;
	    }
	
	    _this.CloseNode();

	};

    }

    EXT._box.innerHTML = '';
    EXT._box.innerHTML = html;

    EXT._box_bg.style.display='block';
    EXT._box.style.display='block';

    this._box_resize();

    if(is_nav || 1){
	EXT._box_bg.style.visibility='visible';
	EXT._box.style.visibility='visible';
    }else{
	/** smooth show **/
	this._box_smooth_show();
    }

    if(!EXT.__ev_attached){
	if(!(is_nav || is_ie7)){
	    EV_Detach(window,'scroll',window.__box_onscroll);
	    EV_Attach(window,'scroll',window.__box_onscroll);
	}
	EV_Attach(window,'resize',window.__box_onscroll);

	EXT.__ev_attached = true;


    }

    EXT.__pm__box_onclick = false;
    EV_Detach(document,'click',window.__doc_onclick);
    EV_Attach(document,'click',window.__doc_onclick);
    
};

PlaceMagic.prototype._box_resize=function()
{
    if(!this.initialized) return;
    var EXT = this.EXT;
    
    var BG = EXT._box_bg;
    var FG = EXT._box;
    
    var w = GetWindowWidth(window);
    var h = GetWindowHeight(window);

    var l=(w-FG.offsetWidth)/2+GetScrollLeft(window);

    var max_height = 500;

    var t = 0;
    if(FG.offsetHeight>max_height && 0){
	t=(h-max_height)/2+GetScrollTop(window);
    }else{
	t=Math.max(0,(h-FG.offsetHeight))/2+GetScrollTop(window);

	if(h-FG.offsetHeight < 0 ){

	    setTimeout('EV_Detach(window,\'scroll\',window.__box_onscroll)',300);
	}else{
	    
	    if(!(is_nav || is_ie7)){
		EV_Detach(window,'scroll',window.__box_onscroll);
		EV_Attach(window,'scroll',window.__box_onscroll);
	    }
	}
    }

    /**alert(FG.offsetWidth);*/
    BG.style.width = '620px';/**(FG.offsetWidth+20)+'px';*/
    if(FG.offsetHeight > max_height && 0){
	FG.style.height = max_height + 'px';
	AddClass(FG,'pm-box-scroll');
	
	BG.style.height = (max_height+20)+'px';
    }else{
	BG.style.height = (FG.offsetHeight + 20) + 'px';
	RemoveClass(FG,'pm-box-scroll');
    }
    BG.style.left = Math.ceil(Math.max(0,(l-10))) + 'px';

    if((is_nav || is_ie7) && h-FG.offsetHeight>=0 ){
	BG.style.position='fixed';
	FG.style.position='fixed';
	BG.style.top = Math.ceil( Math.max(0,(h-FG.offsetHeight)/2 - 10 ) ) + 'px';
	FG.style.top = Math.ceil( Math.max(0,(h-FG.offsetHeight)/2 ) ) + 'px';
    }else{
	BG.style.top = Math.ceil( Math.max(0,(t - 10)) ) + 'px';
	FG.style.top = Math.ceil(t) + 'px';
    }

    FG.style.left = Math.ceil(l) + 'px';

};

var _pm_box_ss_doing = false;
var _pm_box_ss_h = 0;
var _pm_box_ss_t = 0;
var _pm_box_ss_c = 0;
var _pm_box_ss_ti_handle = null;
var _pm_box_el_bg = null;
var _pm_box_el_fg = null;
PlaceMagic.prototype._box_smooth_show=function()
{
    if(!this.initialized) return;
    var EXT = this.EXT;
    
    if(!_pm_box_ss_doing){
	_pm_box_ss_h = EXT._box_bg.offsetHeight;
	_pm_box_ss_t = String(EXT._box_bg.style.top).replace(/px/,'')*1;
	_pm_box_ss_c = 0;

	_pm_box_el_bg = EXT._box_bg;
	_pm_box_el_fg = EXT._box;

	if(_pm_box_ss_ti_handle){
	    try{ clearInterval(_pm_box_ss_ti_handle);}catch(ex){}
	}
	
	/** position: fix bug */
	/**if(is_ie7 || is_nav){
	    _pm_box_el_bg.style.position = 'absolute';
	}
	**/

	_pm_box_ss_doing = true;
	_pm_box_smooth_show_core(20);
	_pm_box_ss_ti_handle = setInterval(function(){_pm_box_smooth_show_core(20);},15);
    }else{
	_pm_box_ss_doing = false;
	if(_pm_box_ss_ti_handle){
	    try{ clearInterval(_pm_box_ss_ti_handle);}catch(ex){}
	}
	this._box_resize();
	EXT._box_bg.style.visibility = 'visible';
	EXT._box_bg.style.overflow = 'auto';
	EXT._box.style.visibility = 'visible';
    }
};
function _pm_box_smooth_show_core(step)
{
    var h = 0;
    if(_pm_box_ss_c == 0 ){
	h = 2;
    }else{
	h = Math.ceil(_pm_box_ss_h * _pm_box_ss_c / 100);
    }
    var t = Math.max(0,Math.ceil(_pm_box_ss_t + ( _pm_box_ss_h / 2 ) - ( h / 2 )));
    
    if( h > _pm_box_ss_h){
	if(_pm_box_ss_ti_handle){
	    try{ clearInterval(_pm_box_ss_ti_handle);}catch(ex){}
	}
	_pm_box_el_bg.style.top = _pm_box_ss_t + 'px';
	_pm_box_el_bg.style.height = _pm_box_ss_h + 'px';
	_pm_box_el_bg.style.overflow = 'auto';
	_pm_box_el_bg.style.visibility = 'visible';

	_pm_box_el_fg.style.visibility = 'visible';

	_pm_box_ss_doing = false;
    }else{
	
	_pm_box_el_bg.style.top = t + 'px';
	_pm_box_el_bg.style.height = h + 'px';
	_pm_box_el_bg.style.overflow = 'hidden';
	_pm_box_el_bg.style.visibility = 'visible';
    }

    _pm_box_ss_c += step;
}


PlaceMagic.prototype.CloseNode=function()
{
    if(!this.initialized) return;
    
    var EXT = this.EXT;

    if(!EXT.__disable_bubble_fix && (new Date()).getTime() - EXT.__show_timestamp < 800){
	return;
    }

    var FG = EXT._box;
    var BG = EXT._box_bg;

    FG.style.visibility = 'hidden';
    FG.style.display='none';
    BG.style.visibility = 'hidden';
    BG.style.display='none';

    EV_Detach(document,'click',window.__doc_onclick);
    EXT.__pm_box_onclick = false;

};

PlaceMagic.prototype.GetNode=function(place_id,options)
{
    if(!this.initialized) return;

    var EXT = this.EXT;
    var _this = this;

    var params = {
	id:place_id
    };
    
    var AJ = {
	o:_this,
	EXT:EXT,
	place_id:place_id,
	options:options,

	'Place_GetNode_onLoad':function(s,rsXML,rsText,p,b)
	{
	    /**alert(rsText);*/
	    if(s.code!=0){
		alert('发生错误(#'+s.code+'):'+s.desc);
		return;
	    }
	    /**success.*/

	    var doc = rsXML.documentElement;
	    if(!doc) return;
	    
	    var p = {};

	    var nodep = doc.getElementsByTagName('place')[0];
	    if(!nodep) return;

	    p['place'] = {
		'id':nodep.getAttribute('id')*1,
		'pid':nodep.getAttribute('pid')*1,
		'name':nodep.getAttribute('name'),
		'aka':nodep.getAttribute('aka'),
		'pname':nodep.getAttribute('pname')
	    };

	    /** parse path tree */
	    p['path'] = [];
	    var nodepath = nodep.getElementsByTagName('path')[0];
	    if(nodepath){
		var nis = nodepath.getElementsByTagName('item');
		if(nis && nis.length){
		    for(var i=0;i<nis.length;i++){
			var ni = nis[i];
			
			var ai = {
			    'id':ni.getAttribute('id')*1,
			    'pid':ni.getAttribute('pid')*1,
			    'name':ni.getAttribute('name'),
			    'aka':ni.getAttribute('aka')
			};
			
			p['path'].push(ai);
		    }
		}
	    }

	    /** parse list */
	    p['list'] = [];
	    
	    var nodel = nodep.getElementsByTagName('list')[0];
	    if(nodel){
		var nis = nodel.getElementsByTagName('item');
		if(nis && nis.length){
		    for(var i=0;i<nis.length;i++){
			var ni = nis[i];

			var ai = {
			    'id':ni.getAttribute('id')*1,
			    'pid':ni.getAttribute('pid')*1,
			    'name':ni.getAttribute('name'),
			    'aka':ni.getAttribute('aka'),
			    'has_child':ni.getAttribute('has_child')*1
			};
			
			p['list'].push(ai);
		    }
		}
	    }
	    
	    /** ok, parse done, add to cache */
	
	    var C = this.EXT.NodeCache;
	    
	    C.pool[ C.current++ % C.size ] = p;
	    

	    if(this.options && this.options.show){
		this.o.ShowNode(this.place_id,null,null,true/**noget*/);
	    }
	}


    };

    MyAPI.callMethod('Place.GetNode',params,AJ,null);
};

/*  file:9  */
/**
 * Copyright 2006-2008  Mipang.com.
 * All Rights Reserved.
 **/


/**  */
if(!window.__base_uid)
    window.__base_uid = 1000;

/** task list Class */
function TaskList()
{
    this.init();
}
TaskList.prototype.init=function()
{
    this.list = {};
};
TaskList.prototype.Add=function(name,call,CBparams)
{
    var list = this.list;
    if(!list[name]){
	var l = new Object();
	l.stack = [];
	l.cursor = 0;
	list[name]=l;
    }
    var L = list[name];
    L.stack[L.stack.length] = [call,CBparams];
};
TaskList.prototype.Run=function(name)
{
    var list=this.list;

    if(!list[name])
	return;
    var l = list[name];
    if(l.cursor+1 <= l.stack.length){
	l.stack[l.cursor][0]( l.stack[l.cursor][1] );
	l.cursor++;
    }
    if(l.cursor>=l.stack.length){
	try{
	    list[name] = null;
	    delete list[name];
	}catch(e){}
    }
};

/** Tip Class */
function Tip(){}
Tip.prototype.ReLocation=function(){
    var div = GetElement(window,'tip');
    var s=div.style;
    s.top = GetScrollTop(window)+3+'px';
    s.right = '3px';
};
Tip.prototype.Show=function(html)
{
    var h=[''];
    h.push('<div class="bgRed" style="background:#cc0000;color:#fff;font:normal 13px Arial;padding:2px 3px;">'+html+'</div>');

    var div = document.getElementById('tip');
    if(!div){
	div = document.createElement('div');
	div.id = 'tip';

	div.setAttribute('style','');
	var ss = div.style;
	ss.position = 'absolute';
	ss.display = 'none';
	ss.top = '-10000px';

	var p = document.body;
	if(p.hasChildNodes()){
	    p.insertBefore(div,p.firstChild);
	}else{
	    p.appendChild(div);
	}
    }


    if(!div.style) div.setAttribute('style','');
    var s = div.style;
    
    s.position = 'absolute';
    div.innerHTML = h.join('');

    ShowElement(div,true);

    /**s.width = '250px';*/
    s.zIndex=20000;
    this.ReLocation();


    var _this = this;
    var sm = function(){
	_this.ReLocation();
    };
    
    var E = new Events();
     E.Attach(window,'scroll',sm);

};

Tip.prototype.Hide=function()
{
    try{
	ShowElement(GetElement(window,'tip'),false);
    }catch(e){}
};


/** **** */

/** Labels Class */
function Labels()
{
    this.labels=[];
    this.fields={id:0,name:1,permission:2,count:3,unreads:4,apply:5};
    this.AdminUrl = '/labels/labels_admin_xml.ue';
    this.Tip = new Tip();
}
/** Get Labels 
    NOT SUPPORT TASKLIST */
Labels.prototype.GetLabels=function(params)
{
    /**
       params{
       reltype:'Blog/Image'
       relid:'blog/img id'
       callback:function([labels])
       }
     */

    if(typeof params != 'object')
	return;
    
    var LB = this;

    this.Tip.Show('加载数据<b>...</b>');

    /**args.*/
    var _params = {
	action:'getLabels',
	reltype:params.reltype,
	relid:params.relid
    };

    /**set callback*/
    var AJ = {};
    AJ.GetLabels_onLoad = function(success,rsXML,rsText,params,CBParams)
    {	
	/** hide tip*/
	LB.Tip.Hide();

	/***/

	/**	alert(rsText);*/
	if(success.code!=0){
	    alert('发生错误(#'+success.code+'):'+success.desc);
	    return;
	}
	/**success.*/
	/** clear first*/
	LB.labels.length=0;
	
	var f=LB.fields;

	var doc = rsXML.documentElement;
	var labels = doc.getElementsByTagName('label');
	if(labels && labels.length){
	    for(var i=0;i<labels.length;i++){
		var l=labels[i];
		
		var L=[];
		L[f.id]=l.getAttribute('id');
		L[f.name]=getNodeValue(l);
		L[f.permission]=l.getAttribute('permission');
		L[f.count]=l.getAttribute('count');
		L[f.unreads]=l.getAttribute('unreads');
		L[f.apply]=l.getAttribute('apply');
		    
		LB.labels[LB.labels.length] = L;
	    }
	}
	    

	/** callback?*/
	if(CBParams.params.callback){
	    CBParams.params.callback(LB.labels);
	}

    };

    MyAPI.callMethod('GetLabels',_params,AJ,{params:params},this.AdminUrl);

};

/** Apply Labels */
Labels.prototype.Apply=function(params)
{
    /**
       params{
       labels:[labels]
       reltype:'Blog/Image'
       relid:'blog/img id'
       callback:function([labels])
       }
     */

    if(typeof params != 'object')
	return;

    var labels=params.labels;
    if(!labels || !labels.length)
	return;
    
    var T = this;

    this.Tip.Show('添加分类<b>...</b>');

    var ts='';
    for(var i=0;i<labels.length;i++){
	ts+= (i>0?'&':'')+'label[]='+UrlEncode(labels[i]);
    }


    /**args.*/
    var _params = {
	action:'ApplyMulti',
	reltype:params.reltype,
	relid:params.relid,
	RAW_QUERY:ts
    };

    /**set callback*/
    var AJ = {};
    AJ.ApplyLabels_onLoad = function(success,rsXML,rsText,params,CBParams)
    {	
	/** hide tip*/
	T.Tip.Hide();

	/***/

	/**	alert(rsText);*/
	if(success.code!=0){
	    alert('发生错误(#'+success.code+'):'+success.desc);
	    return;
	}
	/**success.*/

	/** callback?*/
	if(CBParams.params.callback){
	    CBParams.params.callback(CBParams.params.labels);
	}

    };

    MyAPI.callMethod('ApplyLabels',_params,AJ,{params:params},this.AdminUrl);
};

/** UnApply ONE Label */
Labels.prototype.UnApply=function(params)
{
    /**
       params{
       labels:[label' id] **ONLY ONE SUPPORT NOW**
       reltype:'Blog/Image'
       relid:'blog/img id'
       callback:function([labels])
       }
     */

    if(typeof params != 'object')
	return;
    
    var labels = params.labels;
    
    if(!labels || !labels.length)
	return;

    var T = this;

    this.Tip.Show('撤销分类<b>...</b>');



    /**args.*/
    var _params = {
	action:'UnApply',
	reltype:params.reltype,
	relid:params.relid,
	id:params.labels[0]
    };

    /**set callback*/
    var AJ = {};
    AJ.UnApplyLabels_onLoad = function(success,rsXML,rsText,params,CBParams)
    {	
	/** hide tip*/
	T.Tip.Hide();

	/***/

	/**	alert(rsText);*/
	if(success.code!=0){
	    alert('发生错误(#'+success.code+'):'+success.desc);
	    return;
	}
	/**success.*/

	/** callback?*/
	if(CBParams.params.callback){
	    CBParams.params.callback(CBParams.params.labels);
	}

    };

    MyAPI.callMethod('UnApplyLabels',_params,AJ,{params:params},this.AdminUrl);
};

/** Apply Labels */
Labels.prototype.CreateAndApply=function(params)
{
    /**
       params{
       label:label name
       reltype:'Blog/Image'
       relid:'blog/img id'
       callback:function(label)
       }
     */

    if(typeof params != 'object')
	return;

    var label=params.label;
    if(!label || Trim(label)=='')
	return;
    
    var T = this;

    this.Tip.Show('添加分类<b>...</b>');

    /**args.*/
    var _params = {
	action:'CreateLabelAndApply',
	reltype:params.reltype,
	relid:params.relid,
	name:label
    };

    /**set callback*/
    var AJ = {};
    AJ.CreateAndApply_onLoad = function(success,rsXML,rsText,params,CBParams)
    {	
	/** hide tip*/
	T.Tip.Hide();

	/***/

	/**	alert(rsText);*/
	if(success.code!=0){
	    alert('发生错误(#'+success.code+'):'+success.desc);
	    return;
	}
	/**success.*/

	/** callback?*/
	if(CBParams.params.callback){
	    CBParams.params.callback(CBParams.params.labels);
	}

    };

    MyAPI.callMethod('CreateAndApply',_params,AJ,{params:params},this.AdminUrl);
};

/***/

/** Tags Class */
function Tags()
{
    this.tags=[];
    this.fields={name:0,apply:1};
    this.AdminUrl = '/tags/tags_admin_xml.ue';
    this.Tip = new Tip();
}
/** Get Tagss 
    NOT SUPPORT TASKLIST */
Tags.prototype.GetTags=function(params)
{
    /**
       params{
       reltype:'Blog/Image'
       relid:'blog/img id'
       callback:function([tags])
       }
     */

    if(typeof params != 'object')
	return;
    
    var T = this;

    this.Tip.Show('加载数据<b>...</b>');

    /**args.*/
    var _params = {
	action:'GetAppliedTags',
	reltype:params.reltype,
	relid:params.relid
    };

    /**set callback*/
    var AJ = {};
    AJ.GetTags_onLoad = function(success,rsXML,rsText,params,CBParams)
    {	
	/** hide tip*/
	T.Tip.Hide();

	/***/

	/**	alert(rsText);*/
	if(success.code!=0){
	    alert('发生错误(#'+success.code+'):'+success.desc);
	    return;
	}
	/**success.*/
	/** clear first*/
	T.tags.length=0;
	
	var f=T.fields;

	var doc = rsXML.documentElement;
	var tags = doc.getElementsByTagName('tag');
	if(tags && tags.length){
	    for(var i=0;i<tags.length;i++){
		var t=tags[i];
		
		var L=[];
		L[f.name]=getNodeValue(t);
		L[f.apply]=t.getAttribute('apply');
		    
		T.tags[T.tags.length] = L;
	    }
	}
	    

	/** callback?*/
	if(CBParams.params.callback){
	    CBParams.params.callback(T.tags);
	}

    };

    MyAPI.callMethod('GetTags',_params,AJ,{params:params},this.AdminUrl);

};
/** Apply Tags */
Tags.prototype.Apply=function(params)
{
    /**
       params{
       tags:[tags]
       reltype:'Blog/Image'
       relid:'blog/img id'
       callback:function([tags])
       }
     */

    if(typeof params != 'object')
	return;

    var tags=params.tags;
    if(!tags || !tags.length)
	return;
    
    var T = this;

    this.Tip.Show('添加标签<b>...</b>');

    var ts='';
    for(var i=0;i<tags.length;i++){
	ts+= (i>0?'&':'')+'name[]='+UrlEncode(tags[i]);
    }


    /**args.*/
    var _params = {
	action:'AddMulti',
	reltype:params.reltype,
	relid:params.relid,
	RAW_QUERY:ts
    };

    /**set callback*/
    var AJ = {};
    AJ.ApplyTags_onLoad = function(success,rsXML,rsText,params,CBParams)
    {	
	/** hide tip*/
	T.Tip.Hide();

	/***/

	/**	alert(rsText);*/
	if(success.code!=0){
	    alert('发生错误(#'+success.code+'):'+success.desc);
	    return;
	}
	/**success.*/

	/** callback?*/
	if(CBParams.params.callback){
	    CBParams.params.callback(CBParams.params.tags);
	}

    };

    MyAPI.callMethod('ApplyTags',_params,AJ,{params:params},this.AdminUrl);
};

/** UnApply ONE Tag */
Tags.prototype.UnApply=function(params)
{
    /**
       params{
       tags:[tag'name] ** ONLY ONE SUPPORT NOW **
       reltype:'Blog/Image'
       relid:'blog/img id'
       callback:function(tag)
       }
     */

    if(typeof params != 'object')
	return;
    
    var tags = params.tags;
    if(!tags || !tags.length)
	return;

    var T = this;

    this.Tip.Show('删除标签<b>...</b>');



    /**args.*/
    var _params = {
	action:'Remove',
	reltype:params.reltype,
	relid:params.relid,
	name:params.tags[0]
    };

    /**set callback*/
    var AJ = {};
    AJ.UnApplyTags_onLoad = function(success,rsXML,rsText,params,CBParams)
    {	
	/** hide tip*/
	T.Tip.Hide();

	/***/

	/**	alert(rsText);*/
	if(success.code!=0){
	    alert('发生错误(#'+success.code+'):'+success.desc);
	    return;
	}
	/**success.*/

	/** callback?*/
	if(CBParams.params.callback){
	    CBParams.params.callback(CBParams.params.tags);
	}

    };

    MyAPI.callMethod('UnApplyTags',_params,AJ,{params:params},this.AdminUrl);
};
/***/

/** Dialog Class */
function Dialog(){
    this.on = false;
    this.EXT = {};
    this.instance = this;
    this.callback=null;
    this.init();
}
Dialog.prototype.init=function()
{
    var EXT = this.EXT;

    EXT.instance = this;
    EXT.Event = new Events();

    this.handle_str = '_DialogClass_'+(new Date()).getTime()+(window.__base_uid++); 
    
    window[this.handle_str] = this;


    EXT.BG_id = 'DBG';
    EXT.FG_id = 'DFG';

    EXT.IF_id = 'DIF';
    
    EXT.BG = CreateDIV2(window,EXT.BG_id);

    var bg=EXT.BG;
    
    var opacity=function(a,b){
	if("opacity" in a.style){
	    a.style.opacity=b?0.5:1
	}else if("MozOpacity" in a.style){
	    a.style.MozOpacity=b?0.5:1
	}else if("filter" in a.style){
	    a.style.filter=b?"alpha(opacity=50)":"alpha(opacity=100)"
	}
    };
    var bef=function(e){e=e||window.event;e.cancelBubble=true;if("stopPropagation" in e){e.stopPropagation()}return false;};
    var bet=function(e){e=e||window.event;e.cancelBubble=true;if("stopPropagation" in e){e.stopPropagation()}return true;};
    
    bg.setAttribute('style','');

    bg.style.width=(bg.style.height="100%");
    bg.style.left=(bg.style.top=(bg.style.right=(bg.style.bottom="0px")));
    bg.style.zIndex=200;
    bg.style.background="#fff";
    opacity(bg,true);
    bg.style.position="absolute";
    bg.onmousedown=(bg.onmouseup=(bg.onmousemove=(bg.onkeydown=(bg.onkeyup=(bg.onkeypress=(bg.onclick=(bg.ondblclick=bef)))))));

    ShowElement(bg,false);
    
    EXT.FG = CreateDIV2(window,EXT.FG_id);
    var fg=EXT.FG;

    fg.onmousedown=(fg.onmouseup=(fg.onmousemove=(fg.onkeydown=(fg.onkeyup=(fg.onclick=(fg.ondblclick=bet))))));
    fg.onkeypress=bet;
    fg.style.position="absolute";
    fg.style.display="none";
    fg.style.zIndex=201;
    opacity(fg,false);
    fg.style.overflow='auto';/** fix bug for cursor lost in ff */

    ShowElement(fg,false);


    /** create iframe layer **/

    var iframe = document.createElement('iframe');
    iframe.id = EXT.IF_id;
    iframe.frameBorder='0';
    iframe.setAttribute('style','');
    iframe.style.position='absolute';
    iframe.style.zIndex = 190;
    iframe.style.top = iframe.style.left = '0px';
    iframe.style.display = 'none';
    EXT.IF = iframe;
    
    if(document.body.hasChildNodes())
	document.body.insertBefore(iframe,document.body.firstChild);
    else
	document.body.appendChild(iframe);

    /**onloadRegisterHandler(function(){document.body.appendChild(iframe);});**/



};

Dialog.prototype._CloseDialog=function(btn_idx)
{
    try{
	if(this.callback){/** callback must return true/false */
	    var r = this.callback(btn_idx);
	    if(!r)
		return;
	}
    }catch(e){}

    this.Hide();
};
Dialog.prototype.ResizeBox=function()
{
    var EXT = this.EXT;

    var h=GetWindowHeight(window);
    var w=GetWindowWidth(window);
    var bh = Math.max(document.getElementsByTagName('body')[0].offsetHeight,h);
    EXT.BG.style.height = bh+'px';
    /**EXT.BG.style.width = w+'px'; */
    
    var e=(w-EXT.FG.offsetWidth)/2+GetScrollLeft(window);
    var f=(h-EXT.FG.offsetHeight)/2+GetScrollTop(window);
    EXT.FG.style.left=e+"px";
    EXT.FG.style.top=f+"px";
    

    if(EXT.IF){

	EXT.IF.style.left = e + 'px';
	EXT.IF.style.top  = f + 'px';
	EXT.IF.style.width = EXT.FG.offsetWidth + 'px';
	EXT.IF.style.height = EXT.FG.offsetHeight + 'px';

    }
};
Dialog.prototype.ShowBox=function(html)
{
    var EXT=this.EXT;
    var Event = EXT.Event;

    var _this = this;

    var sm = function(){
	_this.ResizeBox();
    };


    EXT.FG.style.visibility='hidden';

    EXT.FG.innerHTML = html;

    Event.Attach(window,'resize',sm);
    Event.Attach(window,'scroll',sm);

    EXT.FG.style.top='0px';
    EXT.FG.style.left='0px';
    
    ShowElement(EXT.BG,true);
    ShowElement(EXT.FG,true);

    if(EXT.IF){
	ShowElement(EXT.IF,true);
    }

    sm();

    EXT.FG.style.visibility='visible';

};
Dialog.prototype.Show=function(callback,title,body,btns)
{
    /** params:{
	callback:function(btn_idx){}
	title:html_title
	body:html_body
	btns:['html_btn',...]
	}*/
    var EXT = this.EXT;
    
    if(this.on)
	return;

    this.on=true;
    this.callback=callback;
    var e=['<table class="dialog" cellspacing="0" cellpadding="0"><tr><td><div class="t1">&nbsp;</div><div class="t2">&nbsp;</div>'];

    e.push('<div class="border titlebar">'+title+"</div>");
    e.push('<div class="border body" id="',"dialogcontent",'">');
    e.push(body);
    e.push('<div style="text-align:center;"><table class="buttontable" style="margin-left:auto;margin-right:auto;text-align:;" cellspacing="0" cols="');
    e.push(btns.length,'"><tr>');
    for(var f=0;f<btns.length;++f){
	e.push('<td align="center"><span onclick="javascript:window.'+this.handle_str+'._CloseDialog.call(window.'+this.handle_str+',',f,')">',btns[f],"</span></td>");
    }
    e.push("</tr></table></div></div>");

    e.push('<div class="b2">&nbsp;</div><div class="b1">&nbsp;</div></td></tr></table>');

    this.ShowBox(e.join(""));

};
Dialog.prototype.Hide=function()
{
    var EXT=this.EXT;
    
    ShowElement(EXT.FG,false);
    ShowElement(EXT.BG,false);

    if(EXT.IF){
	ShowElement(EXT.IF,false);
    }

    this.on=false;
};

/***/

/** Events Class */
function Events(){this.init();}
Events.prototype.init=function()
{
    if(!Function.prototype._ME_bind){
	Function.prototype._ME_bind=function(a){
	    if(typeof this!="function"){
		throw new Error("Bind must be called as a method of a function object.");
	    }
	    var b=this;
	    var c=Array.prototype.splice.call(arguments,1,arguments.length);
	    return function(){
		var d=c.concat();
		for(var e=0;e<arguments.length;e++){
		    d.push(arguments[e]);
		}
		return b.apply(a,d);
	    };
	};
    }
    this.a={};
    this.b=0;
};
Events.prototype._c=function(f){if(!f.le){f.le=(++this.b);}return f.le;};
Events.prototype._d=function(f,g,h,i)
{
    var j=this._c(f);
    var k=this._c(h);
    i=!(!i);
    var l=j+"_"+g+"_"+k+"_"+i;
    return l;
};
Events.prototype.Attach=function(f,g,h,i)
{
    var _this = this;
    var e=function(f){
	var g=Array.prototype.splice.call(arguments,1,arguments.length);
	return _this.a[f].listener.apply(null,g);
    };
    
    var j=this._d(f,g,h,i);
    if(j in this.a){
	return j;
    }
    var k=e._ME_bind(null,j);
    
    this.a[j]={listener:h,proxy:k};
    if(f.addEventListener){
	f.addEventListener(g,k,i);
    }else if(f.attachEvent){
	f.attachEvent("on"+g,k);
    }else{
	throw new Error("Node {"+f+"} does not support event listeners.");
    }
    return j;
};
Events.prototype.Detach=function(f,g,h,i)
{
    var j=this._d(f,g,h,i);
    if(!(j in this.a)){
	return false;
    }
    var k=this.a[j].proxy;
    if(f.removeEventListener){
	f.removeEventListener(g,k,i);
    }else if(f.detachEvent){
	f.detachEvent("on"+g,k);
    }
    delete this.a[j];
    return true;
};
/***/

/** Window Class Version 0.1 */
function Window(){
    this.initiazlied = false;
    this.on = false;
    this.EXT = {};
    this.instance = this;
    this.callback=null;
    this.init();
}
Window.prototype.init=function()
{
    var EXT = this.EXT;

    EXT.instance = this;

    this.initialized = true;

    EXT.Event = new Events();

    ExportHandle(this,'WindowClass');

    EXT.BG_id = this.handle_str+'window_BG';
    EXT.FG_id = this.handle_str+'window_FG';

    EXT.min_box_id = this.handle_str+'min_box_id';
    EXT.mm_box_id = this.handle_str+'mm_box_id';
    /** preload imgs */

    EXT.btn_min_img = ['//s.mipang.com/images/w_min_white.gif','//s.mipang.com/images/w_min_gray.gif'];
    EXT.btn_max_img = ['//s.mipang.com/images/w_max_white.gif','//s.mipang.com/images/w_max_gray.gif'];
    EXT.btn_img_cache=[];
    for(var i=0;i<EXT.btn_min_img.length;i++){
	var _i = new Image();_i.src=EXT.btn_min_img[i];
	EXT.btn_img_cache.push(_i);
    }
    for(var i=0;i<EXT.btn_max_img.length;i++){
	var _i = new Image();_i.src=EXT.btn_max_img[i];
	EXT.btn_img_cache.push(_i);
    }
    /**/

    /** background */
    EXT.BG = CreateDIV2(window,EXT.BG_id);

    var bg=EXT.BG;
    
    var opacity=function(a,b){
	if("opacity" in a.style){
	    a.style.opacity=b?0.5:1
	}else if("MozOpacity" in a.style){
	    a.style.MozOpacity=b?0.5:1
	}else if("filter" in a.style){
	    a.style.filter=b?"alpha(opacity=50)":"alpha(opacity=100)"
	}
    };
    var bef=function(e){e=e||window.event;e.cancelBubble=true;if("stopPropagation" in e){e.stopPropagation()}return false;};
    var bet=function(e){e=e||window.event;e.cancelBubble=true;if("stopPropagation" in e){e.stopPropagation()}return true;};
    
    bg.setAttribute('style','');

    bg.style.width=(bg.style.height="100%");
    bg.style.left=(bg.style.top=(bg.style.right=(bg.style.bottom="0px")));
    bg.style.zIndex=100;
    bg.style.background="#fff";
    opacity(bg,true);
    bg.style.position="absolute";
    bg.onmousedown=(bg.onmouseup=(bg.onmousemove=(bg.onkeydown=(bg.onkeyup=(bg.onkeypress=(bg.onclick=(bg.ondblclick=bef)))))));

    ShowElement(bg,false);
    
    /** Front ground */
    EXT.FG = CreateDIV2(window,EXT.FG_id);
    var fg=EXT.FG;

    fg.onmousedown=(fg.onmouseup=(fg.onmousemove=(fg.onkeydown=(fg.onkeyup=(fg.onclick=(fg.ondblclick=bet))))));
    fg.onkeypress=bet;
    fg.style.position="absolute";
    fg.style.display="none";
    fg.style.zIndex=101;
    opacity(fg,false);
    fg.style.overflow='auto';/** fix bug for cursor lost in ff */

    ShowElement(fg,false);

    /** min window box */
    var min = EXT.min_box = CreateDIV2(window,EXT.min_box_id);
    
    min.onmousedown=(min.onmouseup=(min.onmousemove=(min.onkeydown=(min.onkeyup=(min.onclick=(min.ondblclick=bet))))));
    min.onkeypress=bet;
    min.style.position="absolute";
    min.style.display="none";
    min.style.zIndex=111;
    min.style.top = min.style.left = '-10000px';
    /** opacity(fg,false);*/
    min.style.overflow='auto';/** fix bug for cursor lost in ff */

    ShowElement(min,false);
    
    /** move box */
    var mm = EXT.mm_box = CreateDIV2(window,EXT.mm_box_id);
    mm.onmousedown=(mm.onmouseup=(mm.onmousemove=(mm.onkeydown=(mm.onkeyup=(mm.onclick=(mm.ondblclick=bet))))));
    mm.onkeypress=bet;
    mm.style.position="absolute";
    mm.style.display="none";
    mm.style.zIndex=111;
    mm.style.top = mm.style.left = '-10000px';
    /** opacity(fg,false);*/
    mm.style.overflow='hidden';/**auto';*/ 
    /** fix bug for cursor lost in ff */
    mm.className = 'window_mm';
    mm.innerHTML = '&nbsp;';
    ShowElement(min,false);
};

Window.prototype._CloseWindow=function(btn_idx)
{
    try{
	if(this.callback){/** callback must return true/false */
	    var r = this.callback(btn_idx);
	    if(!r)
		return;
	}
    }catch(e){}

    this.Hide();
};

Window.prototype.Minsize=function()
{
    if(!this.initialized) return;

    var EXT = this.EXT;
    var Event = EXT.Event;

    var _this = this;
    
    var min = EXT.min_box;
    var e=['<table class="window window_min" cellspacing="0" cellpadding="0"><tr><td><div class="t1">&nbsp;</div><div class="t2">&nbsp;</div>'];
    e.push('<div class="border titlebar"><table cellspacing="0" cellpadding="0"><tr><td onclick="javascript:window.'+this.handle_str+'.Maxsize();return false;" style="white-space:nowrap;padding:0;cursor:pointer;">'+EXT.title+'</td><td style="padding:0 0 0 10px;white-space:nowrap;"><div class="top_btn"><span><img src="//s.mipang.com/images/w_min_gray.gif" alt="最小化" title="最小化" /></span> <span onclick="javascript:window.'+this.handle_str+'.Maxsize();return false;"><img src="//s.mipang.com/images/w_max_white.gif" alt="最大化" title="最大化" /></span></label></div></td></tr></table></div>');
    e.push('<div class="b2">&nbsp;</div><div class="b1">&nbsp;</div></td></tr></table>');


    /** 1. fill content in min window */

    min.style.visibility = 'hidden';
    min.innerHTML = e.join('');

    var _sm2 = window[this.handle_str+'resize_min_window'] = function(){
	_this.Resize_Min_Window();
    };

    /** Attach Event */
    Event.Attach(window,'resize',_sm2);
    Event.Attach(window,'scroll',_sm2);

    /** pre show min window */
    ShowElement(min,true);
    _sm2();
    
    /** 
     * 2. show mm box 
     * -------------
     * |           |
     * -------------
     */

    var h=GetWindowHeight(window);
    var w=GetWindowWidth(window);
    

    EXT.mm_info ={
	w:w,
	h:h,
	ww:EXT.FG.offsetWidth,
	wh:EXT.FG.offsetHeight,
	wl:String(EXT.FG.style.left).replace(/(\..*$|[^0-9])/g,''),
	wt:String(EXT.FG.style.top).replace(/(\..*$|[^0-9])/g,''),
	mw:EXT.min_box.offsetWidth,
	mh:EXT.min_box.offsetHeight,
	ml:0,
	mt:(h-30)+GetScrollTop(window),
	step_start:1,
	step:6
    };

    var mms = EXT.mm_box.style;
    mms.border='3px dashed #ccc';
    mms.width=(EXT.mm_info.ww-6)+'px';
    mms.height=(EXT.mm_info.wh-6)+'px';
    mms.left = EXT.mm_info.wl+'px';
    mms.top = EXT.mm_info.wt +'px';
    ShowElement(EXT.mm_box,true);

    EXT.mm_info.step_handle = 
    setInterval(function(){
	    var EXT = _this.EXT;
	    var info = EXT.mm_info;
	    var mms = EXT.mm_box.style;

	    if(info.step_start>info.step){
		mms.left=mms.top = '-10000px';
		ShowElement(EXT.mm_box,false);

		if(info.step_handle){
		    try{
		    clearInterval(info.step_handle);
		    info.step_handle=null;
		    }catch(e){}
		}
	    }
	    mms.width = Math.max(info.ww - ((info.ww - info.mw) / info.step) * info.step_start + 6 , 6)+'px';
	    mms.height = Math.max(info.wh - ((info.wh - info.mh) / info.step) * info.step_start + 6 , 6)+'px';
	    mms.left = Math.max(info.wl - ((info.wl - info.ml) / info.step) * info.step_start ,0 ) + 'px';
	    mms.top = Math.max(info.wt - ((info.wt - info.mt) / info.step) * info.step_start ,0 ) + 'px';
	    
	    info.step_start ++;
	},60);

    /** hide Main Window */
    /** Unattach Event */
    var sm = window[this.handle_str+'resize'];

    Event.Detach(window,'resize',sm);
    Event.Detach(window,'scroll',sm);
    /**/

    EXT.BG.style.top = EXT.BG.style.left = '-10000px';
    EXT.FG.style.top = EXT.FG.style.left = '-10000px';
    ShowElement(EXT.BG,false);
    ShowElement(EXT.FG,false);


    /** Show min Window */
    setTimeout(function(){
	    EXT.min_box.style.visibility = 'visible';
	},60*EXT.mm_info.step + 100);
};
Window.prototype.Maxsize=function()
{
    if(!this.initialized) return;
    var EXT = this.EXT;
    var Event = EXT.Event;
    var _this = this;

    /** Show Main Window */
    var sm = window[this.handle_str+'resize'] = function(){
	_this.ResizeBox();
    };
    /** Attach Event */
    Event.Attach(window,'resize',sm);
    Event.Attach(window,'scroll',sm);

    EXT.FG.style.top='0px';
    EXT.FG.style.left='0px';
    
    ShowElement(EXT.BG,true);
    ShowElement(EXT.FG,true);

    sm();

    /** Hide min Window */

    /** Unattach Event */
    var _sm2 = window[this.handle_str+'resize_min_window'];

    Event.Detach(window,'resize',_sm2);
    Event.Detach(window,'scroll',_sm2);
    /**/
    EXT.min_box.style.left = EXT.min_box.style.top = '-10000px';
    ShowElement(EXT.min_box,false);
};

Window.prototype.ShowBox=function(html)
{
    var EXT=this.EXT;
    var Event = EXT.Event;

    var _this = this;

    var sm = window[this.handle_str+'resize'] = function(){
	_this.ResizeBox();
    };


    EXT.FG.style.visibility='hidden';

    EXT.FG.innerHTML = html;

    Event.Attach(window,'resize',sm);
    Event.Attach(window,'scroll',sm);

    EXT.FG.style.top='0px';
    EXT.FG.style.left='0px';
    
    ShowElement(EXT.BG,true);
    ShowElement(EXT.FG,true);

    sm();

    EXT.FG.style.visibility='visible';

};
Window.prototype.ResizeBox=function()
{
    var EXT = this.EXT;

    var h=GetWindowHeight(window);
    var w=GetWindowWidth(window);
    var bh = Math.max(document.getElementsByTagName('body')[0].offsetHeight,h);
    EXT.BG.top = EXT.BG.left = '0px';
    EXT.BG.style.height = bh+'px';
    /**EXT.BG.style.width = w+'px'; */
    
    var e=(w-EXT.FG.offsetWidth)/2+GetScrollLeft(window);
    var f=(h-EXT.FG.offsetHeight)/2+GetScrollTop(window);
    EXT.FG.style.left=e+"px";
    EXT.FG.style.top=f+"px";
};
Window.prototype.Resize_Min_Window=function()
{
    var EXT = this.EXT;

    var h=GetWindowHeight(window);
    var w=GetWindowWidth(window);
    
    var l=0;/**(w-EXT.FG.offsetWidth)/2+GetScrollLeft(window);*/
    var t=(h-EXT.min_box.offsetHeight)+GetScrollTop(window);
    EXT.min_box.style.left=l+"px";
    EXT.min_box.style.top=t+"px";
};



Window.prototype.Show=function(callback,title,body,btns)
{
    /** params:{
	callback:function(btn_idx){}
	title:html_title
	body:html_body
	btns:['html_btn',...]
	}*/
    var EXT = this.EXT;
    
    if(this.on){
	alert('已经有一个Window实例,当前版本不支持同时打开多个Window实例!');
	return;
    }
    /** save title here for min window using. */
    EXT.title = title;

    this.on=true;
    this.callback=callback;
    var e=['<table class="window" cellspacing="0" cellpadding="0"><tr><td><div class="t1">&nbsp;</div><div class="t2">&nbsp;</div>'];

    e.push('<div class="border titlebar"><div class="top_btn"><span onclick="javascript:window.'+this.handle_str+'.Minsize();return false;"><img src="//s.mipang.com/images/w_min_white.gif" alt="最小化" title="最小化" /></span> <span><img src="//s.mipang.com/images/w_max_gray.gif" alt="最大化" title="最大化" /></span></label></div>'+title+"</div>");
    e.push('<div class="border body" id="',"dialogcontent",'">');
    e.push(body);
    e.push('<div style="text-align:center;">');
    /** 
	e.push('<table class="buttontable" style="margin-left:auto;margin-right:auto;text-align:;" cellspacing="0" cols="');
    e.push(btns.length,'"><tr>');
    for(var f=0;f<btns.length;++f){
	e.push('<td align="center"><span onclick="javascript:window.'+this.handle_str+'._CloseWindow.call(window.'+this.handle_str_',f,')">',btns[f],'</span></td>');
    }
    e.push("</tr></table>");
    */
    e.push("</div></div>");

    e.push('<div class="b2">&nbsp;</div><div class="b1">&nbsp;</div></td></tr></table>');

    this.ShowBox(e.join(""));

};
Window.prototype.Hide=function()
{
    var EXT=this.EXT;
    
    ShowElement(EXT.FG,false);
    ShowElement(EXT.BG,false);

    this.on=false;
};

/***/



/*  file:10  */
var CtripCU={};


CtripCU.isDateTime=function(a){
    var c=a.match(/^((19|20)\d{2})-(\d{1,2})-(\d{1,2})$/);
    if(!c)
	return false;
    for(var d=1;d<5;d++)
	c[d]=parseInt(c[d],10);
    if(c[3]<1||c[3]>12||c[4]<1||c[4]>31)
	return false;
    var f=new Date(c[1],c[3]-1,c[4]);
    return f.getDate()==c[4]?f:null
};

CtripCU.parseStdDate=function(str){
    var c="January|1@February|2@March|3@April|4@May|5@June|6@July|7@August|8@September|9@October|10@November|11@December|12";
    var d=str.replace(/[ \-,\.\/]+/g,"-").replace(/(^|-)0+(?=\d+)/g,"$1").replace(/[a-z]{3,}/i,function(a){return(_1=c.match(new RegExp("(^|@)"+a+"[^\\|]*\\|(\\d+)","i")))?_1[2]:a}).replace(/^([^-]{1,2}-[^-]{1,2})-([^-]{4})$/,"$2-$1");
    return CtripCU.isDateTime(d)?d:null
};


CtripCU.parseDate=function(str){
    var _v_arr,_v_today=(new Date()).dateValue(),_v_str=str;
    _v_arr=_v_str.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (!_v_arr) return _v_today;
    for (var i=1;i<4;i++)
	_v_arr[i]=parseInt(_v_arr[i],10);
    if (_v_arr[1]<1000||_v_arr[1]>9999) _v_arr[1]=_v_today.getFullYear();
    if (_v_arr[2]<1||_v_arr[2]>12) _v_arr[2]=_v_today.getMonth()+1;
    if (_v_arr[3]<1||_v_arr[3]>31||(new Date(_v_arr[1],_v_arr[2]-1,1)).getMonth()!=(new Date(_v_arr[1],_v_arr[2]-1,_v_arr[3])).getMonth())
	_v_arr[3]=_v_today.getDate();
    return new Date(_v_arr[1],_v_arr[2]-1,_v_arr[3]);
};

CtripCU.engMonthConvert=function(str){
    return str;
};


CtripCU.isNull=function(dEL){
    return Trim(dEL.value)=="";//||dEL.value==dEL.module.notice.tip
};


Date.prototype.addDate=function(day){
    return new Date(this.getFullYear(),this.getMonth(),this.getDate()+day);
};

Date.prototype.toStdString=function(){
    return this.getFullYear()+"-"+(this.getMonth()+1)+"-"+this.getDate();
};

Date.prototype.dateValue=function(){
    return new Date(this.getFullYear(),this.getMonth(),this.getDate())
};



//酒店
/**
onloadRegisterHandler(function(){
	var form=__.forms["hotelForm"];
	var perdate=form["perdate"].value,postdate=form["postdate"].value;
	var perdateCalc=perdate.isDateTime();postdateCalc=postdate.isDateTime();
	var cityname=form["cityname"],cityId=form["cityId"],city=form["city"],district=form["district"];
	var starttime=form["starttime"],deptime=form["deptime"];
	var Price=form["Price"],BegPrice=form["BegPrice"],EndPrice=form["EndPrice"];
	form.onsubmit=function(){
		var flag=[];
		if (cityname.isNull()){
			$alert(cityname,$s2t("请选择宾馆所在城市"));
			return false;
		}
		if (starttime.isNull()){
			$alert(starttime,$s2t("请选择入住日期"));
			return false;
		}
		flag[0]=starttime.value.isDateTime();
		if (!flag[0]){
			$alert(starttime,$s2t("日期格式为yyyy-mm-dd"));
			return false;
		}
		if (perdateCalc&&flag<perdateCalc){
			$alert(starttime,$s2t("入住时间不能早于")+perdate);
			return false;
		}
		if (deptime.isNull()){
			$alert(deptime,$s2t("请选择离店日期"));
			return false;
		}
		flag[1]=deptime.value.isDateTime();
		if (!flag[1]){
			$alert(deptime,$s2t("日期格式为yyyy-mm-dd"));
			return false;
		}
		if (flag[1]<=flag[0]){
			$alert(deptime,$s2t("您选择的离店日期早于/等于入住日期，请重新选择。"));
			return false;
		}
		

		if (flag[1]-flag[0]>2419200000){
			$alert(deptime,$s2t("入住时间段不能超过28天"));
			return false;
		}
		var priceRange=Price.value.split("|");
		BegPrice.value=priceRange[0];
		EndPrice.value=priceRange[1];
		function adjustCityId(id){
			id=parseInt(id,10);
			if (id<20000)
				return id-100;
			if (id<80000)
				return id-20000;
			return id-80000;
		}
		if (cityId.value>80000){
			district.value=adjustCityId(cityId.value);
			city.value="";
		}else{
			city.value=adjustCityId(cityId.value);
			district.value="";
		}
		return true;
	};
});

**/




var __$$=new function(){
    this.status=new function(){
	this.domReady=false;
	this.busy=0;
	this.domReadyFunc=[];
	this.dealt={};
	this.regEvent=[];
	this.regEventHash={};
	this.charset='gb2312';
	this.version={"gb2312":"zh-cn","big5":"zh-tw","utf-8":"en"}[this.charset];
	var a=document.getElementsByTagName("script");
	this.debug=false;
	this.alertDiv=document.getElementById("tuna_alert");
	this.container=document.getElementById("jsContainer");
	this.saveStatus=document.getElementById("jsSaveStatus");
	this.today=new Date().toStdString()
    };
};

__$$.string={display:"@\u9660|\u9660@显示|隐藏@"};
__$$.string.calendar={
    "zh-cn":{
	a:"年",
	b:"月"
    }
}[__$$.status.version];


function CtripCalendar(inputEL){
    this.inputEL = inputEL;

    this.uid = 'c'+gen_unique();

    this.signature = 'ccalendar'+gen_unique();

    this.inputEL.calendar = this;

    this.obj = null;
    this.iframe = null;
}
CtripCalendar.prototype.should_use_iframe=ua.ie()<7||(ua.osx()&&ua.firefox());

CtripCalendar.get_calendar=function(el)
{
    var loop = 20;
    while(typeof el.calendar == 'undefined' && loop-->0){
	el = el.parentNode;
    }
    
    return el.calendar ? el.calendar : null;
};

//CtripCalendar.container = null;
CtripCalendar.calendar_stack=null;

CtripCalendar.prototype.show_selecter=function()
{
    if(!this.obj)
	this.build_selecter();

    this.show();

    return this;
};

CtripCalendar.prototype.show=function()
{

    if(this.calendarDiv&&this.calendarDiv.style.display){
	this.calendarDiv.style.visibility='hidden';
	this.calendarDiv.style.display='';
	this.reset_selecter();
	this.calendarDiv.style.visibility='';
	this.calendarDiv.calendar=this;
    }else{
	this.reset_selecter();
    }

    var stack=CtripCalendar.calendar_stack?
	CtripCalendar.calendar_stack:
	CtripCalendar.calendar_stack=[];


    for(var i=stack.length-1;i>=0;i--){
	if(stack[i]==this){
	    stack.splice(i,1);
	}else{
	    stack[i].hide(true);
	}
    }
    stack.push(this);
    return this;
};

CtripCalendar.prototype.hide=function(temporary)
{
    if(this.calendarDiv){this.calendarDiv.style.display='none';}
    if(this.iframe){this.iframe.style.display='none';}
    //if(this.overlay){this.overlay.style.display='none';}
    //if(this.timeout){clearTimeout(this.timeout);this.timeout=null;return;}
    if(!temporary){
	if(CtripCalendar.calendar_stack){
	    var stack=CtripCalendar.calendar_stack;
	    for(var i=stack.length-1;i>=0;i--){
		if(stack[i]==this){
		    stack.splice(i,1);
		}
	    }
	    if(stack.length){
		stack[stack.length-1].show();
	    }
	}
	if(this.obj){
	    this.obj.parentNode.removeChild(this.obj);
	    this.obj=null;
	}
    }
    return this;
};

CtripCalendar.prototype.reset_selecter=function()
{
    var xy = GetPageOffset(this.inputEL);
    var w = this.inputEL.offsetWidth;
    var h = this.inputEL.offsetHeight;
    var cw = this.calendarDiv.childNodes[0].offsetWidth + this.calendarDiv.childNodes[1].offsetWidth;
    var tw = GetWindowWidth(window);
    
    if ((xy.x + cw + 10) <= tw){
	this.calendarDiv.style.left = xy.x + 'px';
        this.calendarDiv.style.top = xy.y + h + 'px';
    }else{
	this.calendarDiv.style.left = (xy.x - cw + 110) + 'px';
        this.calendarDiv.style.top = xy.y + h + 'px';
    }
  
    if(this.iframe)
	this.reset_iframe();

    return this;
};

CtripCalendar.prototype.init_selecter=function()
{
    /**
    if(CtripCalendar.container){
	this.obj = CtripCalendar.container;
	return this;
    }
	**/
    
    var div=document.createElement("div");

    div.setAttribute('style','');
    div.style.width="0px";
    div.style.height="0px";

    onloadRegisterHandler(function(){
	document.body.appendChild(div);
    });

    this.obj = div;

    this.obj.calendar = this;

    //CtripCalendar.container = this.obj;


    var html = [];
    html.push("<div id=\""+this.uid+"tuna_calendar\" class=\"tuna_calendar clearfix\" style=\"display:none;position:absolute;z-index:120;\">");
    html.push("<table id=\""+this.uid+"calendar_month1\" cellpadding=\"0\" cellspacing=\"0\">");
    html.push("<thead><tr><th colspan=\"7\" class=\"calendar_title01\"><span id=\""+this.uid+"calendar_lastmonth\">&lt;--<\/span><div id=\""+this.uid+"calendar_title1\">2007年8月<\/div><\/th><\/tr><\/thead>");
    html.push("<tbody><tr><th class=\"day0\">日<\/th><th>一<\/th><th>二<\/th><th>三<\/th><th>四<\/th><th>五<\/th><th class=\"day6\">六<\/th><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"over_day\">1<\/a><\/td><td><a href=\"###\" class=\"over_day\">2<\/a><\/td><td><a href=\"###\" class=\"over_day\">3<\/a><\/td><td><a href=\"###\" class=\"over_day\">4<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"over_day\">5<\/a><\/td><td><a href=\"###\" class=\"over_day\">6<\/a><\/td><td><a href=\"###\" class=\"over_day\">7<\/a><\/td><td><a href=\"###\" class=\"over_day\">8<\/a><\/td><td><a href=\"###\" class=\"over_day\">9<\/a><\/td><td><a href=\"###\" class=\"over_day\">10<\/a><\/td><td><a href=\"###\" class=\"over_day\">11<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"over_day\">12<\/a><\/td><td><a href=\"###\" class=\"over_day\">13<\/a><\/td><td><a href=\"###\" class=\"over_day\">14<\/a><\/td><td><a href=\"###\" class=\"over_day\">15<\/a><\/td><td><a href=\"###\" class=\"over_day\">16<\/a><\/td><td><a href=\"###\" class=\"over_day\">17<\/a><\/td><td><a href=\"###\" class=\"selected_day\">18<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"cue_day\">19<\/a><\/td><td><a href=\"###\" class=\"cue_day\">20<\/a><\/td><td><a href=\"###\" class=\"current_day\">21<\/a><\/td><td><a href=\"###\" class=\"enable_day\">22<\/a><\/td><td><a href=\"###\" class=\"enable_day\">23<\/a><\/td><td><a href=\"###\" class=\"enable_day\">24<\/a><\/td><td><a href=\"###\" class=\"enable_day\">25<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"enable_day\">26<\/a><\/td><td><a href=\"###\" class=\"limit_day\">27<\/a><\/td><td><a href=\"###\" class=\"enable_day\">28<\/a><\/td><td><a href=\"###\" class=\"enable_day\">29<\/a><\/td><td><a href=\"###\" class=\"enable_day\">30<\/a><\/td><td><a href=\"###\" class=\"enable_day\">31<\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><\/tr>");
    html.push("</tbody><\/table>");
    html.push("<table id=\""+this.uid+"calendar_month2\" cellpadding=\"0\" cellspacing=\"0\">");
    html.push("<thead><tr><th colspan=\"7\" class=\"calendar_title02\"><span id=\""+this.uid+"calendar_nextmonth\">--&gt;<\/span><div id=\""+this.uid+"calendar_title2\">2007年9月<\/div><\/th><\/tr><\/thead>");
    html.push("<tbody><tr><th class=\"day0\">日<\/th><th>一<\/th><th>二<\/th><th>三<\/th><th>四<\/th><th>五<\/th><th class=\"day6\">六<\/th><\/tr>"); 
    html.push("<tr><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"enable_day\">1<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"enable_day\">2<\/a><\/td><td><a href=\"###\" class=\"enable_day\">3<\/a><\/td><td><a href=\"###\" class=\"enable_day\">4<\/a><\/td><td><a href=\"###\" class=\"enable_day\">5<\/a><\/td><td><a href=\"###\" class=\"enable_day\">6<\/a><\/td><td><a href=\"###\" class=\"enable_day\">7<\/a><\/td><td><a href=\"###\" class=\"enable_day\">8<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"enable_day\">9<\/a><\/td><td><a href=\"###\" class=\"enable_day\">10<\/a><\/td><td><a href=\"###\" class=\"enable_day\">11<\/a><\/td><td><a href=\"###\" class=\"enable_day\">12<\/a><\/td><td><a href=\"###\" class=\"enable_day\">13<\/a><\/td><td><a href=\"###\" class=\"enable_day\">14<\/a><\/td><td><a href=\"###\" class=\"enable_day\">15<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"enable_day\">16<\/a><\/td><td><a href=\"###\" class=\"enable_day\">17<\/a><\/td><td><a href=\"###\" class=\"enable_day\">18<\/a><\/td><td><a href=\"###\" class=\"enable_day\">19<\/a><\/td><td><a href=\"###\" class=\"enable_day\">20<\/a><\/td><td><a href=\"###\" class=\"enable_day\">21<\/a><\/td><td><a href=\"###\" class=\"enable_day\">22<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"enable_day\">23<\/a><\/td><td><a href=\"###\" class=\"enable_day\">24<\/a><\/td><td><a href=\"###\" class=\"enable_day\">25<\/a><\/td><td><a href=\"###\" class=\"enable_day\">26<\/a><\/td><td><a href=\"###\" class=\"enable_day\">27<\/a><\/td><td><a href=\"###\" class=\"enable_day\">28<\/a><\/td><td><a href=\"###\" class=\"enable_day\">29<\/a><\/td><\/tr>");
    html.push("<tr><td><a href=\"###\" class=\"enable_day\">30<\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><td><a href=\"###\" class=\"blank_day\"><\/a><\/td><\/tr>");
    html.push("</tbody><\/table><\/div>");

    set_inner_html(this.obj, html.join(''));
    
    return this;
};

CtripCalendar.prototype.build_selecter = function()
{

    if(!this.obj)
	this.init_selecter();


    if(this.should_use_iframe)
	this.build_iframe();
    

    var _v_div = this.calendarDiv = ge(this.uid+"tuna_calendar");


    var _v_today=new Date();
    var _v_mm1=ge(this.uid+"calendar_title1"),_v_mm2=ge(this.uid+"calendar_title2");
    var _v_mt1=ge(this.uid+"calendar_month1"),_v_mt2=ge(this.uid+"calendar_month2");
    var _v_th=_v_div.getElementsByTagName("th");
    
    /* build weekday bar */
    for (var i=0;i<_v_th.length;i++)
	if (i%8>0) 
	    _v_th[i].firstChild.nodeValue="日一二三四五六".charAt(i%8-1);
    


    var _v_obj = this.inputEL;
	    
    if(typeof _v_obj.module == 'undefined')
	_v_obj.module = {};

    var $ref = this.$ref = _v_obj.module.calendar={};
    _v_obj.setAttribute("autoComplete","off");
    addEventBase(window,"beforeunload",function(){_v_obj.setAttribute("autoComplete","on"); },this.signature);
	    
    _v_obj.value=_v_obj.value||_v_obj.getAttribute("value")||"";
    $ref.focusNext=_v_obj.getAttribute("mod_calendar_focusNext");
    $ref.focusNext=$ref.focusNext&&$ref.focusNext.match(/^(1|true)$/i);
    $ref.rangeStart=_v_obj.getAttribute("mod_calendar_rangeStart");
    $ref.rangeStart=(!$ref.rangeStart)?null:CtripCU.parseDate($ref.rangeStart).dateValue();
    $ref.rangeEnd=_v_obj.getAttribute("mod_calendar_rangeEnd");
    $ref.rangeEnd=(!$ref.rangeEnd)?null:CtripCU.parseDate($ref.rangeEnd).dateValue();
    $ref.rangeException=_v_obj.getAttribute("mod_calendar_rangeException");
    $ref.rangeException=(!$ref.rangeException)?null:$ref.rangeException.replace(/-0?/gi,"-").split("|");
    $ref.permit=_v_obj.getAttribute("mod_calendar_permit");
    $ref.permit=(!$ref.permit)?null:$ref.permit.replace(/-0?/gi,"-").split("|");
    $ref.weekday=_v_obj.getAttribute("mod_calendar_weekday")||"1234567";
    $ref.prohibit=_v_obj.getAttribute("mod_calendar_prohibit");
    $ref.prohibit=(!$ref.prohibit)?null:$ref.prohibit.replace(/-0?/gi,"-").split("|");
    $ref.reference=_v_obj.getAttribute("mod_calendar_reference");
    $ref.reference=(!$ref.reference)?null:ge($ref.reference);

    $ref.today=_v_obj.getAttribute("mod_calendar_today") || "";

    $ref.today=(!$ref.today)?_v_today:CtripCU.parseDate($ref.today).dateValue();
   
    if($ref.rangeStart) $ref.rangeStart = $ref.today;
    

	    
    $ref.hook={};
    (_v_obj.getAttribute("mod_calendar_hook")||"").replace(/(on)?([^;:]+):([^;]+)/gi,function(a,b,c,d){
	$ref.hook[c.toLowerCase()]=_[d];
    });

    /**
    var _m_body_mousedown=function(e){
	this.hide(true);
    }.bind(this);
    **/

    var _m_calendar_mousedown=function(e){
	this.ignore_blur=true;
	stopPropagation(e);
    }.bind(this);

    
    var _m_focus=function(){
	
	this.render_calendar();
	this.show();

	
    }.bind(this);
	    
    
    var _m_blur=function(){
	if(this.ignore_blur){
	    this.ignore_blur = false;
	    setTimeout(function(){
		this.inputEL.focus();
	    }.bind(this),100);
	    return;
	}
	this.hide(true);
	/**
	if (_v_obj.module.notice)
	    _v_obj.module.notice.enabled=true;
	**/
    }.bind(this);

    //addEventBase(document,"mousedown",_m_body_mousedown,this.signature);
    addEventBase(_v_div,"mousedown",_m_calendar_mousedown,this.signature);

    addEventBase(_v_obj,"focus",_m_focus,this.signature);
    addEventBase(_v_obj,"blur",_m_blur,this.signature);

    return this;
};

CtripCalendar.prototype.render_calendar=function()
{
    var _v_obj = this.inputEL;
    var $ref = this.$ref;

    var _uid = this.uid;

    var _v_div = this.calendarDiv = ge(_uid+"tuna_calendar");


    var _v_select;
    var _v_today=$ref.today;
    var _v_mm1=ge(_uid+"calendar_title1"),_v_mm2=ge(_uid+"calendar_title2");
    var _v_mt1=ge(_uid+"calendar_month1"),_v_mt2=ge(_uid+"calendar_month2");
    var _v_th=_v_div.getElementsByTagName("th");
    
    
    if(!$ref.currentDate)
	$ref.currentDate=CtripCU.isDateTime(CtripCU.parseStdDate(Trim(_v_obj.value))||"");



    if (!$ref.currentDate){
	$ref.currentDate=/*$ref.today || */$ref.rangeStart || new Date();
	if ($ref.reference){
	    var refDate=CtripCU.isDateTime( CtripCU.parseStdDate( Trim(CtripCU.isNull($ref.reference) ? "":$ref.reference.value) )||"");
	    if (refDate>$ref.currentDate)
		$ref.currentDate=refDate;
	}
	while (true){
	    var dateStr=$ref.currentDate.toStdString();
	    if (("|"+($ref.rangeException||[]).join("|")+"|").indexOf("|"+dateStr+"|")==-1
		&&("|"+($ref.prohibit||[]).join("|")+"|").indexOf("|"+dateStr+"|")==-1
		&&$ref.weekday.indexOf($ref.currentDate.getDay()||"7")!=-1
		||("|"+($ref.permit||[]).join("|")+"|").indexOf("|"+dateStr+"|")!=-1){
		break;
	    }
	    if (!$ref.rangeEnd||$ref.rangeEnd&&$ref.currentDate<$ref.rangeEnd)
		$ref.currentDate=$ref.currentDate.addDate(1);
	    else{
		$ref.currentDate=new Date();
		break;
	    }
	}
    }

    
    function _m_mousedown(e){
	_v_obj.value=(this.date.getFullYear()+"-"+String(this.date.getMonth()+1+100).replace(/^./,'')+"-"+String(this.date.getDate()+100).replace(/^./,'') );

	

	stopPropagation(e);

	//if(this.outerHTML) this.outerHTML=this.outerHTML+' ';
	if ($ref.hook["change"])
	    $ref.hook["change"](_v_obj);
	//_v_obj.blur();
	
	if ($ref.focusNext){
	    //setTimeout(function(){_v_obj.$focusNext();},10);
	    // find the next input

	    var inputs = _v_obj.form.getElementsByTagName('input');
	    var next_input = null;
	    for(var i=0;i<inputs.length;i++){
		if(inputs[i] == _v_obj && typeof inputs[i+1] != 'undefined'){
		    next_input = inputs[i+1];
		    break;
		}
	    }

	    if(next_input){
		setTimeout(function(){next_input.focus();},100);
	    }
	}
    }


    function _m_build(_v_year,_v_month,_v_table){

	function _m_query(_v_obj,_v_date,_v_class,_v_flag){
	    var _v_day=_v_date?_v_date.getDate():"",_v_id=_v_day?_uid+"d_"+_v_year+"-"+(_v_month+1)+"-"+_v_day:"",_t_weekday=_v_flag&&_v_date?($ref.weekday.indexOf(_v_date.getDay()||7)!=-1):1;
	    _v_obj=_v_obj.firstChild;
	    if (_v_obj.lastChild)
		_v_obj.lastChild.nodeValue=_v_day;
	    else
		_v_obj.appendChild(document.createTextNode(_v_day));
	    _v_obj.date=_v_date;
	    _v_obj.id=_v_id;
	    _v_obj.className=_t_weekday?_v_class:"limit_day";
	    _v_obj.onmousedown=_v_flag&&_t_weekday?_m_mousedown:null;
	    if (_v_obj.replaceNode){
		_v_obj.bak=null;
		_v_obj.bak=_v_obj.cloneNode(true);
	    }
	}
	var _v_td=_v_table.getElementsByTagName("td");
	_v_table.rows[1].className=_v_year==_v_today.getFullYear()&&_v_month==_v_today.getMonth()?"currentmonth01":"";
	var _v_firstday=new Date(_v_year,_v_month,1),_v_lastday=new Date(_v_year,_v_month+1,0),_v_day=_v_lastday.getDate(),_v_week=_v_firstday.getDay(),_t_date,_t_value,_t_ref,_t_flag;
	for (var i=0;i<_v_week;i++)
	    _m_query(_v_td[i],null,"blank_day",0);
	
	_t_ref=$ref.reference&& CtripCU.isDateTime(_t_value=CtripCU.engMonthConvert($ref.reference.value)) ? CtripCU.parseDate(_t_value):null;
	
	for (var i=0;i<_v_day;i++){
	    _t_date=new Date(_v_year,_v_month,i+1);
	    _t_flag=(!$ref.rangeStart||_t_date>=$ref.rangeStart)&&(!$ref.rangeEnd||_t_date<=$ref.rangeEnd);
	    _m_query(_v_td[i+_v_week],_t_date,_t_flag?(_t_ref&&_t_date<=_t_ref?"cue_day":"enable_day"):"over_day",_t_flag);
	}
	for (var i=_v_day+_v_week;i<42;i++)
	    _m_query(_v_td[i],null,"blank_day",0);
    }
    
  
    var _t_date=new Date($ref.currentDate.getFullYear(),$ref.currentDate.getMonth()+1,1),_t_obj;
    var _v_date_y=$ref.currentDate.getFullYear(),_v_date_m=$ref.currentDate.getMonth();
    var _t_date_y=_t_date.getFullYear(),_t_date_m=_t_date.getMonth();
    _v_mm1.innerHTML=(_v_date_y+'年'+(_v_date_m+1)+'月');
    _v_mm2.innerHTML=(_t_date_y+'年'+(_t_date_m+1)+'月');
    _m_build(_v_date_y,_v_date_m,_v_mt1);
    _m_build(_t_date_y,_t_date_m,_v_mt2);
    if ($ref.rangeException)
	for (var i=0;i<$ref.rangeException.length;i++)
	    if (_t_obj=ge(_uid+"d_"+$ref.rangeException[i])){
		_t_obj.className="over_day";
		_t_obj.onmousedown=null;
	    }
    if ($ref.permit)
	for (var i=0;i<$ref.permit.length;i++)
	    if (_t_obj=ge(_uid+"d_"+$ref.permit[i])){
		_t_obj.className="enable_day";
		_t_obj.onmousedown=_m_mousedown;
	    }
    if ($ref.prohibit)
	for (var i=0;i<$ref.prohibit.length;i++)
	    if (_t_obj=ge(_uid+"d_"+$ref.prohibit[i])){
		_t_obj.className="limit_day";
		_t_obj.onmousedown=null;
	    }
    if (_t_obj=ge(_uid+"d_"+_v_today.getFullYear()+"-"+(_v_today.getMonth()+1)+"-"+_v_today.getDate())){
	_t_obj.className+=" current_day";
    }
    if (_v_select) _v_select.className=_v_select.className.replace(/selected_day/gi,"");
    if (_t_obj=ge(_uid+"d_"+CtripCU.engMonthConvert(_v_obj.value).replace(/-0?/gi,"-").replace(/^(\d{1,2}_\d{1,2})_(\d{4})$/,"$2-$1"))){
	_t_obj.className+=" selected_day";
	    _v_select=_t_obj;
    }
    //_v_div.$setIframe();



    if(1){
	if (_v_select) _v_select.className=_v_select.className.replace(/selected_day/gi,"");
	_v_select=ge(_uid+"d_"+CtripCU.engMonthConvert(_v_obj.value).replace(/-0?/gi,"-").replace(/^(\d{1,2}_\d{1,2})_(\d{4})$/,"$2-$1"));
	if (_v_select) _v_select.className+=" selected_day";
	//return;
    }
    if (_v_obj.module.notice){
	_v_obj.module.notice.enabled=false;
	_v_obj.style.color="";
	if (_v_obj.value==_v_obj.module.notice.tip)
	    _v_obj.value="";
    }
    ge(_uid+"calendar_lastmonth").onmousedown=ge(_uid+"calendar_nextmonth").onmousedown=function(e){
	$ref.currentDate=new Date($ref.currentDate.getFullYear(),$ref.currentDate.getMonth()+(/last/.test(this.id)?-2:2),1);

	var cal = CtripCalendar.get_calendar(this);

	cal.ignore_blur = true;

	//stopPropagation(e);

	//cal.hide(true);
	cal.render_calendar();
	cal.show();
    };

    
    
    
    //$ref.currentDate=new Date($ref.currentDate.getFullYear(),$ref.currentDate.getMonth(),1);
    ///////
    //_m_show();
//    _v_div.onmousedown=function(){};
    

};

CtripCalendar.prototype.build_iframe=function()
{

    var iframe_id = 'CtripCalendar_iframe_id_'+gen_unique();

    if(!this.iframe && !(this.iframe=ge(iframe_id))){
	this.iframe=document.createElement('iframe');
	this.iframe.id=iframe_id;
	this.iframe.src="javascript:(function(){return '<!DOCTYPE html><html/>';})();";
	//this.iframe.src= '//www.mipang.com/dummy.html';
	onloadRegisterHandler(function(){
	    document.body.appendChild(this.iframe);
	}.bind(this));
    }

    this.iframe.frameBorder='0';

    this.iframe.setAttribute('style','');
    this.iframe.style.position='absolute';
    this.iframe.style.zIndex = 90;
    this.iframe.style.display='none';
    //this.iframe.style.top = this.iframe.style.left = '-1000px';


    /**filter:alpha(opacity=0);*/
    if("opacity" in this.iframe.style){
	this.iframe.style.opacity=0;
    }else if("MozOpacity" in this.iframe.style){
	this.iframe.style.MozOpacity=0;
    }else if("filter" in this.iframe.style){
	this.iframe.style.filter="alpha(opacity=0)";
    }

    return this;
};

CtripCalendar.prototype.reset_iframe=function()
{
    this.iframe.style.display='';

    var xy = GetPageOffset(this.calendarDiv);

    

    this.iframe.style.top = xy.y+'px';
    this.iframe.style.left = xy.x+'px';
    this.iframe.style.width = this.calendarDiv.offsetWidth+'px';
    this.iframe.style.height = this.calendarDiv.offsetHeight+'px';


    return this;
};

/*  file:11  */
/*
* Game suggester box.
*/


var ctrip_city_suggester_obj = {};

function ctrip_city_suggester_simple(inputEL,onSelect,onEnter,onDatabaseLoaded,stopChecker)
{
    this.inputEL = inputEL || null;
    this.callback_onSelect = onSelect || null;
    this.callback_onEnter = onEnter || null;

    this.stopChecker = stopChecker || false;
    
    this.obj_index = "suggester_obj_"+gen_unique();
    ctrip_city_suggester_obj[this.obj_index] = {};
    
    this.suggester_obj = ctrip_city_suggester_obj[this.obj_index];

    /* 用户动作? */
    this._user_focused = false;

    this._init();
}
ctrip_city_suggester_simple.suggester_stack=null;

ctrip_city_suggester_simple.prototype._init = function()
{

    this.uid = gen_unique();


    


    this.select_pos = -1;


    if(!this.inputEL.id)
	this.inputEL.id = 'fss-inputEL-id-'+gen_unique();

    try{
	if(!this.inputEL.style)
	    this.inputEL.setAttribute(style,'');
	this.inputEL.setAttribute('autocomplete','off');
	this.inputEL.setAttribute('disableautocomplete',true);
    }catch(ex){}

    this.build_suggester();


    this.init_events();

    this.database = [];

    this._city_list_loaded = false;

    this.get_city_list();


    if(!this.stopChecker){
	this.search_build_checker();
    }

    /*this.data*/

    this.render_suggester();

    /* for debug */
    /**
    var debugEL = document.createElement('div');
    onloadRegisterHandler(function(){ document.body.insertBefore(debugEL,document.body.firstChild);  });
    this.debugEL = debugEL;
	**/
    return this;
};
ctrip_city_suggester_simple.prototype.get_city_list_url=function()
{
    return '/copartner/ctrip/ajax/hotel_city_list.ue';
};
ctrip_city_suggester_simple.prototype.get_city_list=function()
{
    
    if(typeof this.suggester_obj.city_list != 'undefined'){
	this.database = this.suggester_obj.city_list;
	this._city_list_loaded = true;
	return this.suggester_obj.city_list;
    }

    var ajax = new fbAjax();
    ajax.onDone = function(obj,text){
	try{
	    this.suggester_obj.city_list = eval('('+text+')');

	    this.database = this.suggester_obj.city_list;

	    this._city_list_loaded = true;

	    this.build_regexp_string();

	    this.database = [];
	    this.render_suggester();
	    
	    if(this.inputEL.is_focused)
		this.show_suggester();

	}catch(ex){alert(ex);}
    }.bind(this);
    ajax.onFail = function(obj){
	//alert(obj.transport.responseText);
    };

    ajax.post(this.get_city_list_url(),'method=GetCityList');

    return this;
};

ctrip_city_suggester_simple.prototype.use_iframe = function()
{
    return true;
};

ctrip_city_suggester_simple.prototype.build_suggester=function()
{
    var listboxEL = document.createElement('div');
    
    listboxEL.id = 'fss-listbox-'+this.uid;
    listboxEL.setAttribute('style','');
    listboxEL.style.zIndex = 120;
    listboxEL.style.position = 'absolute';
    listboxEL.style.display = 'none';
    listboxEL.style.textAlign = 'left';
    listboxEL.style.left = '-10000px';
    listboxEL.style.top = '-10000px';


    listboxEL.style.width = this.inputEL.offsetWidth + 'px';
    //listboxEL.style.height = '100px';
    listboxEL.style.backgroundColor = '#fff';

    onloadRegisterHandler(function(){ document.body.appendChild(listboxEL); });

    this.listboxEL = listboxEL;

    if(this.use_iframe())
	this.build_iframe();


    listboxEL.the_instance = this;

    try{
	this.inputEL.the_instance = this;
    }catch(ex){}

    return this;
};
ctrip_city_suggester_simple.prototype.build_iframe=function()
{
    var iframe = document.createElement('iframe');
  
    iframe.setAttribute('style','');
    iframe.style.zIndex = 110;
    iframe.frameBorder='0';
    iframe.style.position='absolute';
    iframe.style.display = 'none';
    iframe.style.top = iframe.style.left = '-10000px';

    /**filter:alpha(opacity=0);*/
    if("opacity" in iframe.style){
	iframe.style.opacity=0;
    }else if("MozOpacity" in iframe.style){
	iframe.style.MozOpacity=0;
    }else if("filter" in iframe.style){
	iframe.style.filter="alpha(opacity=0)";
    }

    onloadRegisterHandler(function(){ document.body.appendChild(iframe); });
    
    this.iframe = iframe;

    

    return this;
};

ctrip_city_suggester_simple.prototype.get_tip_info_height=function()
{
    var skipHeight = 0;

    try{
	var itemsEL = ge(this.items_wrapper_id);
    
	/* ----- skip the infoDiv height calc ----- */
	var skipNodes = [];
	var _maxloops = 3;
	var _el = itemsEL.previousSibling;
	while(_el && _maxloops-->0){
	    skipNodes.push(_el);
	    _el = _el.previousSibling;
	}
	if(_maxloops<=0){
	    skipNodes = [];
	}
	
	for(var i=0;i<skipNodes.length;i++){
	    skipHeight += skipNodes[i].offsetHeight;
	}
    }catch(ex){
	skipHeight = 0;
    }
    /* ---------------------------------------- */
    return skipHeight;
};
ctrip_city_suggester_simple.prototype.fix_suggester_position=function(norefix)
{
    
    try{

	var xy = GetPageOffset(this.inputEL);
	var w = Math.ceil(this.inputEL.offsetWidth * 1.5);
	var h = this.inputEL.offsetHeight;
	
	var winh = GetWindowHeight(window);
	var winw = GetWindowWidth(window);

	if((Math.floor(xy.x)+ w) < winw){
	    this.listboxEL.style.left = Math.floor(xy.x) + 'px';
	}else{
	    this.listboxEL.style.left = (Math.floor(xy.x) + this.inputEL.offsetWidth - w) + 'px';
	}
	this.listboxEL.style.top = Math.floor(xy.y + h - 1) + 'px';
	this.listboxEL.style.width = w + 'px';

	var itemsEL = ge(this.items_wrapper_id);
	
	itemsEL.style.width = (w-2)+'px';
	
	var items_height = Math.ceil(itemsEL.scrollHeight);
	
	var winScrollTop = GetScrollTop(window);

	//alert(winScrollTop);

	var hspace = Math.floor(winh - (xy.y - winScrollTop) - h - 10);
    
    //alert(hspace+'-'+items_height);
    //itemsEL.style.height = Math.ceil(itemsEL.scrollHeight)+'px';

	hspace -= this.get_tip_info_height();

    var ih = Math.min(items_height , hspace);

    
    itemsEL.style.height = ih + 'px';

    if(typeof itemsEL.scroll_event_inited == 'undefined'){
	/**
	var x = document.createElement('div');
	x.id = 'debug';
	document.body.insertBefore(x,document.body.firstChild);
	addEventBase(itemsEL,'scroll',function(e){ ge('debug').innerHTML = this.scrollTop; });
	itemsEL.scroll_event_inited = true;
	**/
    }

    if(this.use_iframe()){
	var bw = this.listboxEL.offsetWidth;
	var bh = this.listboxEL.offsetHeight;
	this.iframe.style.width = bw + 'px';
	this.iframe.style.height = bh + 'px';
	this.iframe.style.top = Math.floor(xy.y + h -1) + 'px';
	this.iframe.style.left = this.listboxEL.style.left;
    }

    if(!norefix){
	setTimeout(function(){ this.fix_suggester_position(true); }.bind(this),100);
    }

    }catch(ex){}

    return this;
};

ctrip_city_suggester_simple.prototype.close_suggester = function()
{
    this.listboxEL.style.display = 'none';
    if(this.use_iframe())
	this.iframe.style.display = 'none';
    return this;
};

ctrip_city_suggester_simple.prototype.show_suggester = function()
{
    if(!this._user_focused) return this;

    if(this._last_select_item_time && new Date().getTime() - this._last_select_item_time < 500
       && this.inputEL.value == ''
      ) {
	this.close_suggester();
	return this;
    }

    this.listboxEL.style.display = 'block';
    if(this.use_iframe())
	this.iframe.style.display = '';

    this.fix_suggester_position();
    
    var stack=ctrip_city_suggester_simple.suggester_stack?
	ctrip_city_suggester_simple.suggester_stack:
	ctrip_city_suggester_simple.suggester_stack=[];

    for(var i=stack.length-1;i>=0;i--){
	if(stack[i]==this){
	    stack.splice(i,1);
	}else{
	    stack[i].close_suggester();
	}
    }
    stack.push(this);
    

    return this;
};


ctrip_city_suggester_simple.prototype.init_events = function()
{

    var onClick = function(e){
	stopPropagation(e);

	this._user_focused = true;
	
	if(typeof this.inputEL._first_clicked == 'undefined' && 0){

	    this.inputEL._first_clicked = true;
	    
	    if(this._city_list_loaded){
		this.database = [];
		this.render_suggester();
		this.show_suggester();
	    }

	    return;
	}
	

	if(typeof this.suggester_obj.city_list != 'undefined'){
	    if(this.database.length == 0){

		if(Trim(this.inputEL.value)){
		    this.input_old_value = '';
		    this.search_start_input();
		}else{
		    this._list_tip_info = '输入中文/拼音或&uarr;&darr;选择';
		    this.database = this.suggester_obj.city_list;
		    this.render_suggester();
		}
		
	    }
	}

	this.show_suggester();
    }.bind(this);

    var onClose = function(e){
	this.close_suggester();
    }.bind(this);

    var onFocus = function(e){

	this._user_focused = true;

	this.inputEL.is_focused=1;
	this.input_old_value='';

	if(this._city_list_loaded){
	    this.database = [];
	    this.render_suggester();
	    this.show_suggester();
	}
    }.bind(this);
    var onBlur = function(e){
	this.inputEL.is_focused=0;
    }.bind(this);
    
    addEventBase(this.inputEL,'focus',onFocus);

    addEventBase(this.inputEL,'click',onClick);

    addEventBase(this.listboxEL,'click',function(e){ stopPropagation(e); });
    
    addEventBase(document,'click',onClose,this.obj_index);

    addEventBase(window,'resize',function(e){ this.fix_suggester_position(); }.bind(this),this.obj_index);
    //addEventBase(document.documentElement,'scroll',function(e){ alert('OO');});

    var onKeyUP = function(e){
	e = e || window.event;
	this.event_onkeyup(e);
	return false;
    }.bind(this);
    addEventBase(this.inputEL,'keyup',onKeyUP);

    var onKeyDown = function(e){
	e = e || window.event;
	this.event_onkeydown(e);

	return false;
    }.bind(this);
    addEventBase(this.inputEL,'keydown',onKeyDown);


    this.inputEL.onchange = function(){
	this.search_start_input();
    }.bind(this);
    
    return;
};

ctrip_city_suggester_simple.prototype.render_suggester=function()
{

    var uid = this.uid;

    var icon_prefix = 'uicon-'+uid;

    this.items_wrapper_id = 'items-wrapper-'+uid;

    var flist = this.database;

    var html = [''];

    html.push( '<div style="border:1px solid #bdc7d8;border-top:0px solid #ddd;">');


    
    if(this._list_tip_info){
	html.push('<div style="border-top:1px solid #bdc7d8;background-color:#eee;padding:3px 5px;">'+this._list_tip_info+'</div>');
	this._list_tip_info = '';
    }
    

    html.push('<div id="'+this.items_wrapper_id+'" style="" class="user_suggest_items">');


    for(var i=0;this._city_list_loaded && i<flist.length;i++){
	var f = flist[i];

	html.push('<div class="user_suggest_item'+(i == 0 ? ' user_suggest_item_first':'')+'"');
	html.push(' onmouseover="ctrip_city_suggester_simple.get_instance(this).suggest_item_MOVE('+i+');"');
	//html.push(' onmouseout="RemoveClass(this,\'user_suggest_item_MO\')"');
	html.push(' onclick="ctrip_city_suggester_simple.get_instance(this).select_item('+i+');"');
	html.push(' id="user_suggest_item_'+uid+'_'+i+'"');
	html.push('>');
	html.push('<table cellpadding="0" cellspacing="0" width="100%"><tbody><tr>');


	html.push('<td class="usi_nickname usi_name">'/*<div>*/);
	html.push(this.suggest_item_format(f.pinyin));
	html.push(/*</div>*/'</td>');
	
	html.push('<td class="usi_nickname usi_name" style="text-align:right;'+(ua.ie()?'padding-right:20px;':'')+'">'/*<div>*/);
	html.push(this.suggest_item_format(f.name));
	html.push(/*</div>*/'</td>');

	//html.push('<td class="usi_icon"><div style="height:30px;width:45px;text-align:left;" id="'+icon_prefix+i+'">&nbsp;</div>');
	//html.push('</td>');

	html.push('</tr></tbody></table>');
	html.push('</div>');
    }


    if(!this._city_list_loaded){

	html.push('<div style="background-color:#eee;padding:3px 5px;"><em>正在加载城市数据...</em></div>');

    }else{

    
	if(flist.length == 0){ 

	    var key = this.inputEL.value;


	    if(typeof this.suggester_obj.city_list != 'undefined' 
	       && this.suggester_obj.city_list.length == 0){

		html.push('<div style="background-color:#eee;padding:3px 5px;">还没有城市数据！</div>');

	    }else{

		if(!Trim(key)){

		    html.push('<div style="background-color:#eee;padding:3px 5px;">输入城市名字，或者<br>点击输入框显示所有城市！</div>');

		}else{

		    html.push('<div style="background-color:#eee;padding:3px 5px;">没有找到"'
			      +HtmlEscape(Trim(key))+'"！</div>');
		}
	    }

	}

    }

    html.push('</div></div>');


    //html.push('<scr'+'ipt type="text/javascript"> setTimeout(\'city_suggester_icon_render("'+icon_prefix+'");\',100); </scr'+'ipt>');
    
    set_inner_html(this.listboxEL,html.join(''));
};

ctrip_city_suggester_simple.prototype.suggest_item_format=function(name)
{
    var key = Trim(this.inputEL.value);
    if(!key)
	return HtmlEscapeInsertWbrs(name,10,'','');

    var n = name.replace(new RegExp("("+regexp_escape(key)+")","ig"),"<wbr><b class=\"k\">$1</b><wbr>");

    return n;
};

ctrip_city_suggester_simple.prototype.get_the_items_box=function()
{
    var itemsEL = ge(this.items_wrapper_id);
    return itemsEL;
    //return this.listboxEL.firstChild.firstChild;
}

ctrip_city_suggester_simple.prototype.select_item = function(idx)
{

    this.select_pos = idx;

    if(this.database[idx]){
	var theObj = this.database[idx];
	if(this.callback_onSelect)
	    this.callback_onSelect(theObj,this);
    }else{
	if(this.callback_onEnter)
	    this.callback_onEnter(this.inputEL.value,this);
    }

    this.close_suggester();
    
    if(!this.do_not_reset){
	this.inputEL.value = '';
    }
    this.input_old_value = '';
    this.database = [];

    this._last_select_item_time = new Date().getTime();

    return this;
};

ctrip_city_suggester_simple.prototype.suggest_item_MOVE = function(idx)
{

    this.suggest_item_MU(this.select_pos);

    this.select_pos = idx;

    this.suggest_item_MO(idx);
    
    return this;
};

ctrip_city_suggester_simple.prototype.select_item_down = function(dir)
{

    var flist = this.database;

    if(dir != -1)
	dir = 1;

    this.select_pos+=dir;

    if(dir > 0)
	this.select_pos = Math.min(this.select_pos,flist.length-1);
    else
	this.select_pos = Math.max(-1,this.select_pos);


    this.locate_the_select_item(dir);
    
    return this;
};
ctrip_city_suggester_simple.prototype.select_item_up = function()
{
    return this.select_item_down(-1);
};
ctrip_city_suggester_simple.prototype.select_item_scrollTo=function(y)
{
    var Lbox = this.get_the_items_box();
    
    try{ Lbox.scrollTop = y; }catch(ex){}

    return this;
};
ctrip_city_suggester_simple.prototype.select_item_pagedown=function(dir)
{
    if(dir != -1)
	dir = 1;

    var flist = this.database;

    var bh = this.listboxEL.offsetHeight - this.get_tip_info_height();
    var Lbox = this.get_the_items_box();

    if(Lbox.scrollHeight > bh){
	
	var oldScrollTop = Lbox.scrollTop;
	
	var toScrollTop;
	if(dir>0)
	    toScrollTop = Math.min(Lbox.scrollHeight - bh,Math.ceil(oldScrollTop + bh));
	else
	    toScrollTop = Math.max(0,Math.floor(oldScrollTop - bh));

	this.select_item_scrollTo(toScrollTop);

	/* calc the pos */
	
	var pos = Math.min(flist.length-1,
	    Math.max(0,Math.floor((Lbox.scrollTop + bh /2) / Lbox.scrollHeight * flist.length)));

	var dltHeight = Lbox.scrollTop + bh - Lbox.scrollHeight;


	/**this.debugEL.innerHTML = dltHeight;**/

	/* move to end */
	if(dltHeight < 3 && dltHeight > -3){
	    pos = flist.length-1;
	}

	/* move to start */
	if(Lbox.scrollTop < 3)
	    pos = 0;

	this.suggest_item_MOVE(pos);

    }

    return this;
};
ctrip_city_suggester_simple.prototype.select_item_pageup=function()
{
    return this.select_item_pagedown(-1);
};
ctrip_city_suggester_simple.prototype.select_item_scrollToHome=function()
{
    this.select_item_scrollTo(0);
    this.select_item_pageup();
};
ctrip_city_suggester_simple.prototype.select_item_scrollToEnd=function()
{
    var Lbox = this.get_the_items_box();
    var y = Math.floor(Lbox.scrollHeight -3);
    this.select_item_scrollTo(y);
    this.select_item_pagedown();
};
ctrip_city_suggester_simple.prototype.suggest_item_MO=function(idx)
{
    var id = 'user_suggest_item_'+this.uid+'_'+idx;
    try{
	var el = ge(id);
	AddClass(el,'user_suggest_item_MO');
    }catch(ex){}
    return this;
};
ctrip_city_suggester_simple.prototype.suggest_item_MU=function(idx)
{
    var id = 'user_suggest_item_'+this.uid+'_'+idx;
    try{
	var el = ge(id);
	RemoveClass(el,'user_suggest_item_MO');
    }catch(ex){}
    return this;
};
ctrip_city_suggester_simple.prototype.locate_the_select_item=function(dir)
{
    var flist = this.database;
    
    var start = Math.max(0,this.select_pos-3);
    var end = Math.min(this.select_pos+3,flist.length-1);
    for(var i=start;i<=end;i++){
	if(i == this.select_pos)
	    this.suggest_item_MO(i);
	else
	    this.suggest_item_MU(i);
    }

    if(this.select_pos < 0)
	return this;


    /* scroll the box up/down */

    var curEL = ge('user_suggest_item_'+this.uid+'_'+this.select_pos);

    var bxy = GetPageOffset(this.listboxEL);
    var ixy = GetPageOffset(curEL);
    
    var bh = this.listboxEL.offsetHeight - this.get_tip_info_height();

    var Lbox = this.get_the_items_box();

    var itop = Math.floor(ixy.y);
    var ibottom = Math.ceil(ixy.y + curEL.offsetHeight);

    if(dir>0){
	
	if(ibottom > bxy.y + bh + Lbox.scrollTop){
	    Lbox.scrollTop = Math.min(Lbox.scrollHeight,Math.ceil(ibottom - bxy.y - bh));
	}
	
    }else{
	
	if(itop < bxy.y+Lbox.scrollTop){
	    Lbox.scrollTop = Math.max(0,Math.ceil(itop - bxy.y));
	}
    }
    
    /**
    this.debugEL.innerHTML = 'box{x:'+bxy.x+',y:'+bxy.y+',h:'+bh+',sT:'+Lbox.scrollTop+'} item{yT:'+itop+',yB:'+ibottom+'}';
**/

    return this;
};

ctrip_city_suggester_simple.prototype.build_regexp_string=function()
{
    var flist = this.suggester_obj.city_list;

    var regexps = [];
    for(var i=0;i<flist.length;i++){
	var str = flist[i].name+flist[i].pinyin;
	regexps.push(str.replace(/\r?\n/,'')+'[%'+i+'%]');
    }
    regexps.push('');

    this.suggester_obj.regexps_string = regexps.join('\n');

    //alert(this.suggester_obj.regexps_string);

    return this;
};


ctrip_city_suggester_simple.prototype.event_onkeyup=function(e)
{

    var key_code = EV_GetKeyCode(e);

    /**alert(key_code);**/

    switch(key_code){
    case 40:case 38:
    case 34:case 33:
    case 36:case 35:
	
    case 13:case 9:
	return this;
	break;
    default:
	break;
    }    

    this.search_start_input();
    return this;
};

ctrip_city_suggester_simple.prototype.event_onkeydown=function(e)
{
    
    var key_code = EV_GetKeyCode(e);

    /**alert(key_code);**/

    switch(key_code){
    case 40:
	this.select_item_down();
	break;
    case 38:
	this.select_item_up();
	break;
    case 34: /* page down */
	this.select_item_pagedown();
	break;
    case 33: /* page up */
	this.select_item_pageup();
	break;
    case 36: /* home */
	this.select_item_scrollToHome();
	break;
    case 35: /* end */
	this.select_item_scrollToEnd();
	break;
    case 13:
    case 9:
	
	this.select_item(this.select_pos);
	//alert('enter');
	//stopPropagation(e);
	event_prevent(e);
	setTimeout('ge("'+this.inputEL.id+'").focus()',10);
	break;
    default:
	break;
    }
    
    return this;
};

/* --- for search --- */
ctrip_city_suggester_simple.prototype.search_start_input=function()
{
    //this._search_last_input_timestamp = (new Date()).getTime();
    return this;
};

ctrip_city_suggester_simple.prototype.search_build_checker=function()
{
    if(typeof this._search_checker_time_hdl == 'undefined'){
	this._search_checker_time_hdl = setInterval(function(){ this.search_checker(); }.bind(this),100);
    }
    return this;
};
ctrip_city_suggester_simple.prototype.search_checker=function()
{
    //var now = (new Date()).getTime();

    /*
    if(this._search_last_input_timestamp && now - this._search_last_input_timestamp > 80){
	this._search_last_input_timestamp = null;
*/

    if(!this.input_old_value){
	this.input_old_value = '';
    }
    
    var new_value = this.inputEL.value;
    
    if( new_value != this.input_old_value){
    
	this.input_old_value = new_value;

	var n = this.search();

	if(n>0){
	    this.render_suggester();

	    this.show_suggester();

	    this.suggest_item_MOVE(0);
	}else{
	    
	    if(!Trim(this.inputEL.value) && typeof this.suggester_obj.city_list != 'undefined' ){
		// do not render all list,too slow.
		// this.database = this.suggester_obj.city_list;
	    }
	    
	    this.render_suggester();
	    this.show_suggester();
	    this.suggest_item_MOVE(-1);
	}
	
    }
    
    return this;
};
/*
* search from the city list ,return result length.
*/
ctrip_city_suggester_simple.prototype.search=function(key)
{
    if(!key){
	key = Trim(this.inputEL.value);
    }

    /**this.debugEL.innerHTML = key;**/

    var result=[];


    if(!key){
	this.database = result;
	return 0;
    }


    try{
	var rt = new RegExp(""+regexp_escape(key)+".*?\\[%(\\d+)%\\]","ig");

	//alert(rt);
	var m = this.suggester_obj.regexps_string.match(rt);

	for(var i=0;m && i<m.length;i++){
	    
	    var index = m[i].replace(/^.*\[%(\d+)%\].*$/,"$1")*1;
	    
	    if(typeof this.suggester_obj.city_list[index] != 'undefined'){
		result.push(this.suggester_obj.city_list[index]);
	    }

	}


	/**this.debugEL.innerHTML += result;**/

    }catch(ex){
	/*alert(ex);*/

	return 0;
    }


    if(result.length || 1){
	this.database = result;
    }

    return result.length;
};

/* ----- utilits ----- */
function city_suggester_icon_render(prefix)
{
    var flist = this.database;
    for(var i=0;i<flist.length;i++){
	setTimeout('set_inner_html(ge("'+prefix+i+'"),\'<img src="'+flist[i].buddyicon+'" style="width:30px;height:30px;border:0;" />\');',100);
    }
}

ctrip_city_suggester_simple.get_instance = function(el)
{
    var e = el;
    var loop = 20;
    while( e && typeof e.the_instance == 'undefined' && loop-- > 0){
	e = e.parentNode;
    }

    return e.the_instance;
};



//-------------- guohang 
function guohang_city_suggester_simple(inputEL,onSelect,onEnter,onDatabaseLoaded)
{

    this.parent.construct(this,inputEL,onSelect,onEnter,onDatabaseLoaded);

}

guohang_city_suggester_simple.class_extend(ctrip_city_suggester_simple);


guohang_city_suggester_simple.prototype.get_city_list_url=function()
{
    return '/copartner/guohang/ajax/guohang_city_list.ue';
};


function _17u_city_suggester_simple(inputEL,onSelect,onEnter,onDatabaseLoaded)
{

    this.parent.construct(this,inputEL,onSelect,onEnter,onDatabaseLoaded);

}

_17u_city_suggester_simple.class_extend(ctrip_city_suggester_simple);

_17u_city_suggester_simple.prototype.get_city_list_url=function()
{
    return '/copartner/17u/ajax/17u_city_list.ue';
};




